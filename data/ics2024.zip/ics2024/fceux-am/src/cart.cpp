/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

/// \file
/// \brief This file contains all code for coordinating the mapping in of the address space external to the NES.

#include "types.h"
#include "fceu.h"
#include "ppu.h"
#include "driver.h"

#include "cart.h"
#include "x6502.h"

#include "file.h"
#include "utils/memory.h"

uint8 *Page[32], *VPage[8];
uint8 **VPageR = VPage;
uint8 *VPageG[8];
uint8 *MMC5SPRVPage[8];
uint8 *MMC5BGVPage[8];

static uint8 PRGIsRAM[32];  /* This page is/is not PRG RAM. */

/* 16 are (sort of) reserved for UNIF/iNES and 16 to map other stuff. */
uint8 CHRram[32];
uint8 PRGram[32];

uint8 *PRGptr[32];
uint8 *CHRptr[32];

uint32 PRGsize[32];
uint32 CHRsize[32];

uint32 PRGmask2[32];
uint32 PRGmask4[32];
uint32 PRGmask8[32];
uint32 PRGmask16[32];
uint32 PRGmask32[32];

uint32 CHRmask1[32];
uint32 CHRmask2[32];
uint32 CHRmask4[32];
uint32 CHRmask8[32];

/**
 * @brief Sets the page pointer and RAM flag for a specified memory range.
 *
 * This method updates the `PRGIsRAM` and `Page` arrays for a given memory range.
 * The memory range is determined by the starting address `A` and the size `s`.
 * The method iterates over the specified range and sets the `PRGIsRAM` flag to indicate
 * whether the memory is RAM or not, and updates the `Page` array with the appropriate
 * pointer offset.
 *
 * @param s The size of the memory range to be updated. This size is divided by 2
 *          to determine the number of iterations.
 * @param A The starting address of the memory range. This address is shifted right
 *          by 11 bits to calculate the base index `AB` in the `PRGIsRAM` and `Page` arrays.
 * @param p A pointer to the memory page. If `p` is not null, it is used to calculate
 *          the offset for the `Page` array. If `p` is null, both `PRGIsRAM` and `Page`
 *          are set to 0 for the specified range.
 * @param ram An integer flag indicating whether the memory range is RAM (non-zero)
 *            or not (zero). This flag is stored in the `PRGIsRAM` array.
 */
static INLINE void setpageptr(int s, uint32 A, uint8 *p, int ram) {
	uint32 AB = A >> 11;
	int x;

	if (p)
		for (x = (s >> 1) - 1; x >= 0; x--) {
			PRGIsRAM[AB + x] = ram;
			Page[AB + x] = p - A;
		}
	else
		for (x = (s >> 1) - 1; x >= 0; x--) {
			PRGIsRAM[AB + x] = 0;
			Page[AB + x] = 0;
		}
}

static uint8 nothing[8192];
/**
 * @brief Resets the cartridge mapping by initializing the memory pages and pointers.
 * 
 * This method performs the following operations:
 * 1. Resets the PPU hooks by calling `PPU_ResetHooks()`.
 * 2. Iterates over the first 32 memory pages and initializes them:
 *    - Sets `Page[x]` to a calculated offset from `nothing`.
 *    - Resets `PRGptr[x]` and `CHRptr[x]` to 0.
 *    - Resets `PRGsize[x]` and `CHRsize[x]` to 0.
 * 3. Iterates over the first 8 MMC5 memory pages and initializes them:
 *    - Sets `MMC5SPRVPage[x]`, `MMC5BGVPage[x]`, and `VPageR[x]` to a calculated offset from `nothing`.
 * 
 * This method is typically used to reset the memory mapping state of the cartridge to a default or initial state.
 */
void ResetCartMapping(void) {
	int x;

	PPU_ResetHooks();

	for (x = 0; x < 32; x++) {
		Page[x] = nothing - x * 2048;
		PRGptr[x] = CHRptr[x] = 0;
		PRGsize[x] = CHRsize[x] = 0;
	}
	for (x = 0; x < 8; x++) {
		MMC5SPRVPage[x] = MMC5BGVPage[x] = VPageR[x] = nothing - 0x400 * x;
	}
}

/**
 * @brief Sets up the PRG (Program ROM) memory mapping for a specific chip.
 *
 * This method configures the PRG memory mapping for a given chip by assigning the provided
 * memory pointer, size, and RAM flag. It also calculates and sets up the necessary mask values
 * for different PRG memory access patterns (2KB, 4KB, 8KB, 16KB, and 32KB).
 *
 * @param chip The index of the chip for which the PRG mapping is being configured.
 * @param p Pointer to the PRG memory block that will be mapped to the chip.
 * @param size The size of the PRG memory block in bytes.
 * @param ram A flag indicating whether the PRG memory is RAM (1) or ROM (0).
 */
void SetupCartPRGMapping(int chip, uint8 *p, uint32 size, int ram) {
	PRGptr[chip] = p;
	PRGsize[chip] = size;

	PRGmask2[chip] = (size >> 11) - 1;
	PRGmask4[chip] = (size >> 12) - 1;
	PRGmask8[chip] = (size >> 13) - 1;
	PRGmask16[chip] = (size >> 14) - 1;
	PRGmask32[chip] = (size >> 15) - 1;

	PRGram[chip] = ram ? 1 : 0;
}

/**
 * @brief Sets up the CHR (Character ROM) mapping for a specific chip.
 *
 * This method configures the CHR memory mapping for a given chip by assigning the provided
 * memory pointer, size, and RAM flag. It also calculates and sets the appropriate mask values
 * based on the size of the CHR memory. These masks are used for addressing the CHR memory
 * in different granularities (1K, 2K, 4K, 8K).
 *
 * @param chip The index of the chip for which the CHR mapping is being set up.
 * @param p A pointer to the CHR memory block that will be mapped to the chip.
 * @param size The size of the CHR memory block in bytes.
 * @param ram A flag indicating whether the CHR memory is RAM (1) or ROM (0).
 */
void SetupCartCHRMapping(int chip, uint8 *p, uint32 size, int ram) {
	CHRptr[chip] = p;
	CHRsize[chip] = size;

	CHRmask1[chip] = (size >> 10) - 1;
	CHRmask2[chip] = (size >> 11) - 1;
	CHRmask4[chip] = (size >> 12) - 1;
	CHRmask8[chip] = (size >> 13) - 1;

	CHRram[chip] = ram;
}

/**
 * @brief Retrieves a value from the cartridge's memory page based on the given address.
 *
 * This method takes a memory address `A`, shifts it right by 11 bits to determine the appropriate
 * page index, and then returns the value stored at the corresponding location in the page.
 * The method is typically used in emulators to simulate memory access in cartridge-based systems.
 *
 * @param A The memory address from which to retrieve the value.
 * @return The value stored at the computed location in the cartridge's memory page.
 */
DECLFR(CartBR) {
	return Page[A >> 11][A];
}

/**
 * @brief Writes a value to the specified memory address in the cartridge's PRG ROM or RAM.
 * 
 * This method checks if the memory address `A` is mapped to a RAM page by verifying the `PRGIsRAM` array.
 * If the address is mapped to RAM and the corresponding page is valid (i.e., `Page[A >> 11]` is not null),
 * the value `V` is written to the memory location `Page[A >> 11][A]`.
 * 
 * @param A The memory address where the value should be written.
 * @param V The value to be written to the memory address.
 */
DECLFW(CartBW) {
	//printf("Ok: %04x:%02x, %d\n",A,V,PRGIsRAM[A>>11]);
	if (PRGIsRAM[A >> 11] && Page[A >> 11])
		Page[A >> 11][A] = V;
}

/**
 * @brief Reads a byte from the cartridge's memory based on the given address.
 *
 * This method checks if the memory page corresponding to the given address `A` exists.
 * If the page does not exist, it returns the value of `X.DB` (likely a default byte or buffer).
 * If the page exists, it returns the byte located at the specified address within that page.
 *
 * @param A The address from which to read the byte.
 * @return The byte read from the cartridge's memory or `X.DB` if the page is not available.
 */
DECLFR(CartBROB) {
	if (!Page[A >> 11])
		return(X.DB);
	else
		return Page[A >> 11][A];
}

/**
 * @brief Sets the second PRG ROM page for the specified region.
 *
 * This method configures the second PRG ROM page by applying a mask to the provided value `V`,
 * and then setting the page pointer based on the masked value. The masked value is used to
 * calculate the offset within the PRG ROM data. If the PRG pointer for the region `r` is valid,
 * the page pointer is set to the calculated address; otherwise, it is set to null. The method
 * also updates the PRG RAM flag for the specified region.
 *
 * @param r The region index to configure.
 * @param A The address within the region to set the page pointer for.
 * @param V The value to apply to the PRG ROM page. This value is masked with `PRGmask2[r]`
 *          to ensure it falls within the valid range for the region.
 */
void setprg2r(int r, uint32 A, uint32 V) {
	V &= PRGmask2[r];
	setpageptr(2, A, PRGptr[r] ? (&PRGptr[r][V << 11]) : 0, PRGram[r]);
}

/**
 * @brief Sets the Program ROM (PRG) bank for the second 8KB segment in the NES memory map.
 * 
 * This method configures the PRG ROM bank for the second 8KB segment of the NES memory map.
 * It delegates the actual configuration to the `setprg2r` method, specifying the first PRG ROM
 * bank register (0) and the provided bank address (A) and value (V).
 * 
 * @param A The address within the second 8KB segment where the bank should be mapped.
 * @param V The value representing the PRG ROM bank to be set.
 */
void setprg2(uint32 A, uint32 V) {
	setprg2r(0, A, V);
}

/**
 * @brief Sets the PRG ROM bank for the 4th page in the memory map.
 *
 * This method configures the PRG ROM bank for the 4th page by masking the provided value `V`
 * with the appropriate mask from `PRGmask4` and then setting the page pointer. The page pointer
 * is determined by the `PRGptr` array, which contains pointers to the PRG ROM banks. If the
 * pointer for the specified bank `r` is valid, the method calculates the new pointer by offsetting
 * it with the masked value `V` shifted left by 12 bits. If the pointer is null, the page pointer
 * is set to null. The method also updates the PRG RAM for the 4th page using `PRGram`.
 *
 * @param r The index of the PRG ROM bank to use.
 * @param A The address in the memory map where the page will be set.
 * @param V The value to set for the PRG ROM bank, which will be masked with `PRGmask4[r]`.
 */
void setprg4r(int r, uint32 A, uint32 V) {
	V &= PRGmask4[r];
	setpageptr(4, A, PRGptr[r] ? (&PRGptr[r][V << 12]) : 0, PRGram[r]);
}

/**
 * @brief Sets the program ROM for the 4K bank at the specified address.
 *
 * This method configures the program ROM for a 4K memory bank located at the address `A`.
 * It delegates the actual configuration to the `setprg4r` method, specifying the region `0`
 * as the target region for the bank. The value `V` determines which 4K bank of the program
 * ROM is mapped to the address `A`.
 *
 * @param A The address where the 4K bank should be mapped.
 * @param V The index of the 4K bank in the program ROM to map to the address `A`.
 */
void setprg4(uint32 A, uint32 V) {
	setprg4r(0, A, V);
}

/**
 * @brief Sets the Program ROM (PRG) bank for an 8KB or 2KB memory region.
 *
 * This method configures the memory mapping for a specified PRG bank based on the provided parameters.
 * If the PRG bank size is 8KB or larger, it maps the entire 8KB region to the specified address `A`.
 * If the PRG bank size is smaller than 8KB, it maps four 2KB regions starting at address `A`.
 *
 * @param r The index of the PRG bank to configure.
 * @param A The base address in memory where the PRG bank will be mapped.
 * @param V The value used to determine the offset within the PRG bank.
 *
 * @details The method first checks the size of the PRG bank `r`. If the size is 8192 bytes or larger,
 * it applies the appropriate mask to `V` and maps the 8KB region using `setpageptr`. If the size is
 * smaller than 8192 bytes, it iterates over four 2KB regions, applying the mask and mapping each
 * region individually using `setpageptr`.
 */
void setprg8r(int r, uint32 A, uint32 V) {
	if (PRGsize[r] >= 8192) {
		V &= PRGmask8[r];
		setpageptr(8, A, PRGptr[r] ? (&PRGptr[r][V << 13]) : 0, PRGram[r]);
	} else {
		uint32 VA = V << 2;
		int x;
		for (x = 0; x < 4; x++)
			setpageptr(2, A + (x << 11), PRGptr[r] ? (&PRGptr[r][((VA + x) & PRGmask2[r]) << 11]) : 0, PRGram[r]);
	}
}

/**
 * @brief Sets the program ROM bank for an 8KB segment at the specified address.
 *
 * This method configures the program ROM bank for an 8KB segment starting at the address `A`.
 * It uses the `setprg8r` function with a fixed parameter `0` to set the bank. The value `V` specifies
 * the bank number to be mapped to the address range.
 *
 * @param A The starting address of the 8KB segment where the bank will be mapped.
 * @param V The bank number to map to the specified address range.
 */
void setprg8(uint32 A, uint32 V) {
	setprg8r(0, A, V);
}

/**
 * @brief Sets the PRG ROM page for a 16KB memory region.
 *
 * This method configures the PRG ROM page for a 16KB memory region starting at address `A`.
 * The specific PRG ROM bank is determined by the value `V`, which is masked and adjusted based on the size of the PRG ROM.
 * If the PRG ROM size is 16KB or larger, the entire 16KB region is mapped to the specified bank.
 * If the PRG ROM size is smaller than 16KB, the region is divided into 2KB pages, and each page is mapped to the corresponding bank.
 *
 * @param r The index of the PRG ROM region to configure.
 * @param A The starting address of the 16KB memory region.
 * @param V The value used to determine the PRG ROM bank to map.
 */
void setprg16r(int r, uint32 A, uint32 V) {
	if (PRGsize[r] >= 16384) {
		V &= PRGmask16[r];
		setpageptr(16, A, PRGptr[r] ? (&PRGptr[r][V << 14]) : 0, PRGram[r]);
	} else {
		uint32 VA = V << 3;
		int x;

		for (x = 0; x < 8; x++)
			setpageptr(2, A + (x << 11), PRGptr[r] ? (&PRGptr[r][((VA + x) & PRGmask2[r]) << 11]) : 0, PRGram[r]);
	}
}

/**
 * @brief Sets the 16KB PRG ROM bank for the specified address.
 *
 * This method configures the 16KB Program ROM (PRG ROM) bank at the given address `A`
 * to the specified value `V`. It internally calls `setprg16r` with a fixed bank index
 * of `0`, indicating that the operation applies to the first PRG ROM bank.
 *
 * @param A The address where the PRG ROM bank should be set.
 * @param V The value to set for the PRG ROM bank.
 */
void setprg16(uint32 A, uint32 V) {
	setprg16r(0, A, V);
}

/**
 * @brief Sets the program memory (PRG) pointer for a 32KB region or maps multiple 2KB pages based on the provided parameters.
 *
 * This method configures the PRG memory mapping for a specified region `r`. If the PRG size for the region is at least 32KB,
 * it directly sets the pointer for the 32KB region at address `A` using the value `V` masked by the 32KB PRG mask. If the PRG size
 * is less than 32KB, it maps 16 consecutive 2KB pages starting at address `A`, using the value `V` shifted and masked appropriately.
 *
 * @param r The region index to configure.
 * @param A The base address where the PRG memory mapping starts.
 * @param V The value used to determine the offset within the PRG memory.
 */
void setprg32r(int r, uint32 A, uint32 V) {
	if (PRGsize[r] >= 32768) {
		V &= PRGmask32[r];
		setpageptr(32, A, PRGptr[r] ? (&PRGptr[r][V << 15]) : 0, PRGram[r]);
	} else {
		uint32 VA = V << 4;
		int x;

		for (x = 0; x < 16; x++)
			setpageptr(2, A + (x << 11), PRGptr[r] ? (&PRGptr[r][((VA + x) & PRGmask2[r]) << 11]) : 0, PRGram[r]);
	}
}

/**
 * @brief Sets the program memory (PRG) for a 32-bit address range.
 * 
 * This method configures the PRG memory for a specified 32-bit address range.
 * It delegates the actual setting of the PRG memory to the `setprg32r` method,
 * using a fixed bank index of 0. The address range and value are passed as parameters.
 * 
 * @param A The 32-bit address range to set the PRG memory for.
 * @param V The 32-bit value to set in the PRG memory.
 */
void setprg32(uint32 A, uint32 V) {
	setprg32r(0, A, V);
}

/**
 * @brief Sets the CHR (Character) memory region for a given ROM bank.
 *
 * This method updates the CHR memory mapping for the specified ROM bank `r`. It ensures
 * that the CHR memory is properly aligned and accessible based on the provided address `A`
 * and value `V`. If the CHR memory for the specified bank is not allocated, the method
 * exits early. The method also updates the PPU (Picture Processing Unit) CHR RAM status
 * based on whether the CHR memory is RAM or ROM. Finally, it updates the virtual page
 * mapping for the specified address range.
 *
 * @param r The ROM bank index to update the CHR memory for.
 * @param A The address within the CHR memory region to update.
 * @param V The value to set for the CHR memory region, masked by the CHR mask for the bank.
 */
void setchr1r(int r, uint32 A, uint32 V) {
	if (!CHRptr[r]) return;
	FCEUPPU_LineUpdate();
	V &= CHRmask1[r];
	if (CHRram[r])
		PPUCHRRAM |= (1 << (A >> 10));
	else
		PPUCHRRAM &= ~(1 << (A >> 10));
	VPageR[(A) >> 10] = &CHRptr[r][(V) << 10] - (A);
}

/**
 * @brief Sets the CHR (Character) memory for a specific region in the PPU (Picture Processing Unit).
 *
 * This method updates the CHR memory for the specified region `r` by mapping the provided address `A` 
 * to the corresponding CHR data `V`. The method ensures that the CHR memory is properly aligned and 
 * updated in the PPU's memory pages. If the CHR memory for the region is not allocated, the method 
 * returns immediately without performing any action.
 *
 * The method also updates the PPUCHRRAM register to reflect whether the CHR memory is RAM or ROM, 
 * based on the `CHRram` flag for the region. If the CHR memory is RAM, the corresponding bits in 
 * PPUCHRRAM are set; otherwise, they are cleared.
 *
 * @param r The region index in the CHR memory to be updated.
 * @param A The address in the PPU memory space where the CHR data will be mapped.
 * @param V The CHR data value to be set, which is masked according to the region's CHR mask.
 */
void setchr2r(int r, uint32 A, uint32 V) {
	if (!CHRptr[r]) return;
	FCEUPPU_LineUpdate();
	V &= CHRmask2[r];
	VPageR[(A) >> 10] = VPageR[((A) >> 10) + 1] = &CHRptr[r][(V) << 11] - (A);
	if (CHRram[r])
		PPUCHRRAM |= (3 << (A >> 10));
	else
		PPUCHRRAM &= ~(3 << (A >> 10));
}

/**
 * @brief Sets the CHR (Character) memory for a specific region in the PPU (Picture Processing Unit).
 *
 * This method updates the CHR memory mapping for a given region `r` in the PPU. It ensures that the
 * CHR memory is properly mapped to the specified address `A` with the value `V`. The method performs
 * the following operations:
 * 1. Checks if the CHR pointer for the region `r` is valid. If not, the method returns immediately.
 * 2. Updates the PPU line to ensure synchronization.
 * 3. Masks the value `V` with the appropriate CHR mask for the region `r`.
 * 4. Maps the CHR memory to the specified address `A` by updating the VPageR (Virtual Page Register)
 *    entries for the corresponding address range.
 * 5. Updates the PPUCHRRAM (PPU CHR RAM) flag to indicate whether the CHR memory is RAM or ROM.
 *
 * @param r The region index in the CHR memory.
 * @param A The address in the PPU memory space where the CHR memory should be mapped.
 * @param V The value to be written to the CHR memory.
 */
void setchr4r(int r, uint32 A, uint32 V) {
	if (!CHRptr[r]) return;
	FCEUPPU_LineUpdate();
	V &= CHRmask4[r];
	VPageR[(A) >> 10] = VPageR[((A) >> 10) + 1] =
							VPageR[((A) >> 10) + 2] = VPageR[((A) >> 10) + 3] = &CHRptr[r][(V) << 12] - (A);
	if (CHRram[r])
		PPUCHRRAM |= (15 << (A >> 10));
	else
		PPUCHRRAM &= ~(15 << (A >> 10));
}

/**
 * @brief Sets the CHR (Character ROM) bank for the specified region.
 *
 * This method updates the CHR bank for the given region `r` with the value `V`. 
 * It first checks if the CHR pointer for the region is valid; if not, the method exits early.
 * The method then updates the PPU (Picture Processing Unit) line to ensure proper synchronization.
 * The value `V` is masked with the appropriate CHR mask for the region to ensure it is within valid bounds.
 * The method then updates the VPageR array, which represents the CHR pages, by pointing each entry to the 
 * corresponding CHR bank in memory. If the CHR region is RAM (CHRram), the PPUCHRRAM flag is set to indicate 
 * that CHR RAM is in use. Otherwise, the PPUCHRRAM flag is cleared.
 *
 * @param r The region index for which the CHR bank is being set.
 * @param V The value to set the CHR bank to.
 */
void setchr8r(int r, uint32 V) {
	int x;

	if (!CHRptr[r]) return;
	FCEUPPU_LineUpdate();
	V &= CHRmask8[r];
	for (x = 7; x >= 0; x--)
		VPageR[x] = &CHRptr[r][V << 13];
	if (CHRram[r])
		PPUCHRRAM |= (255);
	else
		PPUCHRRAM = 0;
}

/**
 * @brief Sets the CHR (Character) bank for the first 8KB CHR ROM bank.
 *
 * This method is used to configure the CHR bank for the first 8KB CHR ROM bank
 * in an NES emulator or similar system. It delegates the actual setting of the
 * bank to the `setchr1r` method, specifying the first bank (index 0) as the target.
 *
 * @param A The address within the CHR bank to be set.
 * @param V The value to set at the specified address in the CHR bank.
 */
void setchr1(uint32 A, uint32 V) {
	setchr1r(0, A, V);
}

/**
 * @brief Sets the character data at the specified address in the second CHR ROM bank.
 *
 * This method is a wrapper for `setchr2r` and is used to set the character data 
 * at the given address `A` in the second CHR ROM bank. The value `V` is written 
 * to the specified address. The method internally calls `setchr2r` with a fixed 
 * bank index of 0, indicating the second CHR ROM bank.
 *
 * @param A The address in the CHR ROM bank where the value will be set.
 * @param V The value to be written at the specified address.
 */
void setchr2(uint32 A, uint32 V) {
	setchr2r(0, A, V);
}

/**
 * @brief Sets a 4KB CHR (Character) memory block at the specified address.
 *
 * This method is a wrapper for `setchr4r`, which sets a 4KB CHR memory block
 * in the specified region. It delegates the actual setting operation to
 * `setchr4r` with the region index set to 0.
 *
 * @param A The address where the 4KB CHR block should be set.
 * @param V The value to set at the specified address.
 */
void setchr4(uint32 A, uint32 V) {
	setchr4r(0, A, V);
}

/**
 * @brief Sets the 8KB CHR (Character) ROM bank for the first 8KB of the PPU (Picture Processing Unit) memory.
 * 
 * This method is used to configure the CHR ROM bank for the first 8KB of the PPU memory space. 
 * It internally calls the `setchr8r` method with a fixed parameter of `0` to specify the first 8KB region,
 * and the provided `V` parameter to specify the bank number.
 * 
 * @param V The bank number to set for the first 8KB of CHR ROM. This value is typically an 8-bit integer,
 *          but it is passed as a `uint32` for compatibility with the underlying implementation.
 */
void setchr8(uint32 V) {
	setchr8r(0, V);
}

/* This function can be called without calling SetupCartMirroring(). */

void setntamem(uint8 *p, int ram, uint32 b) {
	FCEUPPU_LineUpdate();
	vnapage[b] = p;
	PPUNTARAM &= ~(1 << b);
	if (ram)
		PPUNTARAM |= 1 << b;
}

static int mirrorhard = 0;
/**
 * @brief Sets the mirroring configuration for the PPU's nametable memory.
 * 
 * This method updates the nametable mirroring by assigning specific offsets to the 
 * PPU's nametable pages (`vnapage`). The offsets are calculated based on the provided 
 * parameters `a`, `b`, `c`, and `d`, which determine the starting address for each 
 * nametable page within the `NTARAM` memory. Each parameter is multiplied by `0x400` 
 * (1024 bytes) to align with the size of a single nametable. The method also calls 
 * `FCEUPPU_LineUpdate()` to ensure the PPU's internal state is synchronized before 
 * applying the changes.
 * 
 * @param a The offset multiplier for the first nametable page (vnapage[0]).
 * @param b The offset multiplier for the second nametable page (vnapage[1]).
 * @param c The offset multiplier for the third nametable page (vnapage[2]).
 * @param d The offset multiplier for the fourth nametable page (vnapage[3]).
 */
void setmirrorw(int a, int b, int c, int d) {
	FCEUPPU_LineUpdate();
	vnapage[0] = NTARAM + a * 0x400;
	vnapage[1] = NTARAM + b * 0x400;
	vnapage[2] = NTARAM + c * 0x400;
	vnapage[3] = NTARAM + d * 0x400;
}

/**
 * @brief Sets the mirroring mode for the PPU (Picture Processing Unit) nametable memory.
 *
 * This method updates the nametable memory mapping based on the specified mirroring type.
 * It first calls `FCEUPPU_LineUpdate()` to ensure the PPU state is up-to-date. If the `mirrorhard`
 * flag is not set, it adjusts the `vnapage` array to reflect the new mirroring configuration.
 * The `vnapage` array represents the memory pages for the four nametable regions (0x2000-0x2FFF).
 * The mirroring type `t` determines how the nametable memory is mirrored:
 * - `MI_H`: Horizontal mirroring, where the first two pages point to `NTARAM` and the last two
 *   pages point to `NTARAM + 0x400`.
 * - `MI_V`: Vertical mirroring, where the first and third pages point to `NTARAM`, and the second
 *   and fourth pages point to `NTARAM + 0x400`.
 * - `MI_0`: Single-screen mirroring, where all four pages point to `NTARAM`.
 * - `MI_1`: Single-screen mirroring, where all four pages point to `NTARAM + 0x400`.
 * After updating the `vnapage` array, the `PPUNTARAM` register is set to `0xF` to indicate
 * the new nametable configuration.
 *
 * @param t The mirroring type to set, which can be one of `MI_H`, `MI_V`, `MI_0`, or `MI_1`.
 */
void setmirror(int t) {
	FCEUPPU_LineUpdate();
	if (!mirrorhard) {
		switch (t) {
		case MI_H:
			vnapage[0] = vnapage[1] = NTARAM; vnapage[2] = vnapage[3] = NTARAM + 0x400;
			break;
		case MI_V:
			vnapage[0] = vnapage[2] = NTARAM; vnapage[1] = vnapage[3] = NTARAM + 0x400;
			break;
		case MI_0:
			vnapage[0] = vnapage[1] = vnapage[2] = vnapage[3] = NTARAM;
			break;
		case MI_1:
			vnapage[0] = vnapage[1] = vnapage[2] = vnapage[3] = NTARAM + 0x400;
			break;
		}
		PPUNTARAM = 0xF;
	}
}

/**
 * @brief Configures the mirroring behavior of the cartridge memory based on the provided parameters.
 *
 * This method sets up the mirroring mode for the cartridge memory. If the mirroring mode `m` is less than 4,
 * it configures the mirroring using the `setmirror` function and sets `mirrorhard` to 0. Otherwise, it sets up
 * custom mirroring by assigning specific memory addresses to the `vnapage` array and configuring `PPUNTARAM`.
 * Finally, the `mirrorhard` flag is set to the provided `hard` value.
 *
 * @param m The mirroring mode to be configured. If less than 4, standard mirroring is used; otherwise, custom mirroring is applied.
 * @param hard A flag to determine the hard mirroring behavior, which is set at the end of the method.
 * @param extra A pointer to additional memory used for custom mirroring when `m` is 4 or greater.
 */
void SetupCartMirroring(int m, int hard, uint8 *extra) {
	if (m < 4) {
		mirrorhard = 0;
		setmirror(m);
	} else {
		vnapage[0] = NTARAM;
		vnapage[1] = NTARAM + 0x400;
		vnapage[2] = extra;
		vnapage[3] = extra + 0x400;
		PPUNTARAM = 0xF;
	}
	mirrorhard = hard;
}

/* Called when a game is closed. */
void FCEU_CloseGenie(void) {
	/* No good reason to free() the Game Genie ROM image data. */
	VPageR = VPage;
}

/**
 * @brief Disables or "kills" the Game Genie functionality within the emulator.
 * 
 * This method is responsible for deactivating the Game Genie cheat system, ensuring
 * that no Game Genie codes are applied or active during emulation. This is typically
 * called when the user wants to revert to the original, unmodified game behavior
 * or when the emulator needs to reset its state.
 */
void FCEU_KillGenie(void) {
}
