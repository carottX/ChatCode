/* FCE Ultra - NES/Famicom Emulator
*
* Copyright notice for this file:
*  Copyright (C) 2002 Xodnizel
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "types.h"
#include "video.h"
#include "fceu.h"
#include "file.h"
#include "utils/memory.h"
#include "state.h"
#include "palette.h"
#include "input.h"
#include "drawing.h"
#include "driver.h"
#include "drivers/common/vidblit.h"

//XBuf:
//0-63 is reserved for 7 special colours used by FCEUX (overlay, etc.)
//64-127 is the most-used emphasis setting per frame
//128-195 is the palette with no emphasis
//196-255 is the palette with all emphasis bits on
u8 *XBuf=NULL; //used for current display
//u8 *XBackBuf=NULL; //ppu output is stashed here before drawing happens
//u8 *XDBuf=NULL; //corresponding to XBuf but with deemph bits
//u8 *XDBackBuf=NULL; //corresponding to XBackBuf but with deemph bits
int ClipSidesOffset=0;	//Used to move displayed messages when Clips left and right sides is checked
static u8 *xbsave=NULL;

/**
 * @brief Terminates and cleans up the virtual video system.
 * 
 * This method is responsible for shutting down and releasing any resources
 * associated with the virtual video system. It ensures that all allocated
 * memory, handles, and other resources are properly freed, and any ongoing
 * video processing or rendering tasks are gracefully terminated. This function
 * should be called when the virtual video system is no longer needed or before
 * the application exits to prevent resource leaks and ensure a clean shutdown.
 */
void FCEU_KillVirtualVideo(void)
{
}

/**
* Return: Flag that indicates whether the function was succesful or not.
*
* TODO: This function is Windows-only. It should probably be moved.
**/
int FCEU_InitVirtualVideo(void)
{
	//Some driver code may allocate XBuf externally.
	//256 bytes per scanline, * 240 scanline maximum, +16 for alignment,
	if(XBuf)
		return 1;

	XBuf = (u8*)FCEU_malloc(256 * 256 + 16);
	//XBackBuf = (u8*)FCEU_malloc(256 * 256 + 16);
	//XDBuf = (u8*)FCEU_malloc(256 * 256 + 16);
	//XDBackBuf = (u8*)FCEU_malloc(256 * 256 + 16);
	if(!XBuf)
	//if(!XBuf || !XBackBuf || !XDBuf || !XDBackBuf)
	{
		return 0;
	}

	xbsave = XBuf;

	if( sizeof(uint8*) == 4 )
	{
		uintptr_t m = (uintptr_t)XBuf;
		m = ( 8 - m) & 7;
		XBuf+=m;
	}

	memset(XBuf,128,256*256);
	//memset(XBackBuf,128,256*256);

	return 1;
}

#ifdef FRAMESKIP
/**
 * @brief Displays the frames per second (FPS) on the screen.
 *
 * This method is a dummy function that serves as a placeholder for rendering
 * operations. Its primary purpose is to call the `ShowFPS()` function, which
 * updates and displays the current FPS value on the screen. This can be useful
 * for debugging or performance monitoring purposes.
 */
void FCEU_PutImageDummy(void)
{
	ShowFPS();
}
#endif

uint64 FCEUD_GetTime(void);
uint32 FCEUD_GetTimeFreq(void);
bool Show_FPS = false;

/**
 * @brief Sets the visibility of the Frames Per Second (FPS) display.
 *
 * This method allows the user to control whether the FPS counter is displayed
 * on the screen. By passing `true`, the FPS counter will be shown; passing `false`
 * will hide it. This is useful for monitoring performance or reducing on-screen
 * clutter during gameplay or emulation.
 *
 * @param showFPS A boolean value indicating whether to show the FPS counter.
 *               `true` to display the FPS counter, `false` to hide it.
 */
void FCEUI_SetShowFPS(bool showFPS)
{
	Show_FPS = showFPS;
}

static uint64 boop[60];
static int boopcount = 0;

/**
 * @brief Displays the current frames per second (FPS) of the system.
 * 
 * This method calculates and prints the FPS based on the time elapsed between frames. 
 * It only performs this action if the `Show_FPS` flag is set to true. The method uses 
 * a circular buffer (`boop`) to store timestamps of recent frames and calculates the 
 * FPS by comparing the current time with the oldest timestamp in the buffer. The FPS 
 * is displayed along with the system time in seconds. The method ensures that the FPS 
 * is updated approximately every second.
 * 
 * The FPS calculation is adjusted for different frame rates depending on the system's 
 * video standard (PAL or NTSC). For PAL systems, the frame rate is 50 FPS, while for 
 * NTSC systems, it is 60 FPS. The method also clears the previous FPS display by 
 * printing backspace characters before updating the FPS value.
 * 
 * Note: The FPS is not averaged over exactly one second but is close enough for most 
 * practical purposes.
 */
void ShowFPS(void)
{
	static uint32 tsc = 0;
	if(Show_FPS == false)
		return;
	uint32 now = FCEUD_GetTime();
	uint32 da = now - boop[boopcount];
	int booplimit = PAL?50:60;
	boop[boopcount] = now;

	if (now - tsc > 1000) {
		tsc = now;
		for (int i = 0; i < 40; i ++) putch('\b');
		printf("(System time: %ds) FPS = %d", now / 1000, booplimit * FCEUD_GetTimeFreq() / da);
	}
	// It's not averaging FPS over exactly 1 second, but it's close enough.
	boopcount = (boopcount + 1) % booplimit;
}
