/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 1998 BERO
 *  Copyright (C) 2003 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "types.h"
#include "x6502.h"
#include "fceu.h"
#include "ppu.h"
#include "sound.h"
#include "file.h"
#include "utils/memory.h"

#include "cart.h"
#include "palette.h"
#include "state.h"
#include "video.h"
#include "input.h"
#include "driver.h"

#define debug_loggingCD false

#define VBlankON    (PPU[0] & 0x80)	//Generate VBlank NMI
#define Sprite16    (PPU[0] & 0x20)	//Sprites 8x16/8x8
#define BGAdrHI     (PPU[0] & 0x10)	//BG pattern adr $0000/$1000
#define SpAdrHI     (PPU[0] & 0x08)	//Sprite pattern adr $0000/$1000
#define INC32       (PPU[0] & 0x04)	//auto increment 1/32

#define SpriteON    (PPU[1] & 0x10)	//Show Sprite
#define ScreenON    (PPU[1] & 0x08)	//Show screen
#define PPUON       (PPU[1] & 0x18)	//PPU should operate
#define GRAYSCALE   (PPU[1] & 0x01)	//Grayscale (AND palette entries with 0x30)

#define SpriteLeft8 (PPU[1] & 0x04)
#define BGLeft8     (PPU[1] & 0x02)

#define PPU_status  (PPU[2])

#define READPAL(ofs)    (PALRAM[(ofs)] & (GRAYSCALE ? 0x30 : 0xFF))
#define READUPAL(ofs)   (UPALRAM[(ofs)] & (GRAYSCALE ? 0x30 : 0xFF))

static void FetchSpriteData(void);
static void RefreshLine(int lastpixel);
static void RefreshSprites(void);
static void CopySprites(uint8 *target);

static void Fixit1(void);
static uint32 ppulut1[256];
static uint32 ppulut2[256];
static uint32 ppulut3[128];

static bool new_ppu_reset = false;

int test = 0;

#define _BITS 8
struct BITREVLUT {
	uint8 lut [1 << _BITS];
	/**
	 * @brief Constructs a bit-reversed lookup table (LUT) for a given number of bits.
	 * 
	 * This method generates a lookup table that contains the bit-reversed values of all integers
	 * from 0 to (2^_BITS - 1). The bit-reversed value of an integer is obtained by reversing the
	 * order of its binary digits. For example, the bit-reversed value of 6 (binary 110) is 3 (binary 011).
	 * 
	 * The method initializes the LUT with the first two values (0 and the middle value of the range).
	 * It then iteratively fills the LUT by reversing the bits of the previous entries and adding
	 * a calculated offset. The process continues until all 2^_BITS values are populated in the LUT.
	 * 
	 * @note The size of the LUT is determined by the value of _BITS, which should be set prior to
	 * calling this method. The LUT is stored in the `lut` array, which must be large enough to
	 * accommodate 2^_BITS elements.
	 */
	BITREVLUT() {
			int bits = _BITS;
			int n = 1 << _BITS;
	
			int m = 1;
			int a = n >> 1;
			int j = 2;
	
			lut[0] = 0;
			lut[1] = a;
	
			while (--bits) {
				m <<= 1;
				a >>= 1;
				for (int i = 0; i < m; i++)
					lut[j++] = lut[i] + a;
			}
		}

	/**
	 * @brief Overloads the subscript operator to provide access to elements in the lookup table (LUT).
	 * 
	 * This method allows accessing elements in the internal lookup table (LUT) using the subscript operator.
	 * It returns the element at the specified index. The index is expected to be within the valid range
	 * of the LUT, otherwise, the behavior is undefined.
	 * 
	 * @param index The position of the element to retrieve from the LUT.
	 * @return uint8 The value stored at the specified index in the LUT.
	 */
	uint8 operator[](int index) {
	    return lut[index];
	}
} bitrevlut;

struct PPUSTATUS {
	int32 sl;
	int32 cycle, end_cycle;
};

struct SPRITE_READ {
	int32 num;
	int32 count;
	int32 fetch;
	int32 found;
	int32 found_pos[8];
	int32 ret;
	int32 last;
	int32 mode;

	/**
	 * @brief Resets all internal state variables to their initial values.
	 * 
	 * This method sets all member variables to zero, effectively clearing any previous state.
	 * Specifically, it resets the following variables:
	 * - `num`, `count`, `fetch`, `found`, `ret`, `last`, and `mode` to 0.
	 * - All elements of the `found_pos` array to 0, ensuring that any previous position data is cleared.
	 * 
	 * This method is typically called to initialize the object's state before starting a new operation
	 * or to clear any residual data from a previous operation.
	 */
	void reset() {
	    num = count = fetch = found = ret = last = mode = 0;
	    found_pos[0] = found_pos[1] = found_pos[2] = found_pos[3] = 0;
	    found_pos[4] = found_pos[5] = found_pos[6] = found_pos[7] = 0;
	}

	/**
	 * @brief Initializes the state variables for a new scanline.
	 *
	 * This method resets all relevant state variables to their default values in preparation for
	 * processing a new scanline. It sets the following variables:
	 * - `num` to 1, indicating the starting position or identifier for the scanline.
	 * - `found` to 0, indicating that no elements have been found yet.
	 * - `fetch` to 1, enabling the fetching of data for the scanline.
	 * - `count` to 0, resetting the counter for processed elements.
	 * - `last` to 64, setting the maximum or last position in the scanline.
	 * - `mode` to 0, resetting the operational mode.
	 * - `found_pos` array to 0, clearing any previously found positions.
	 * This ensures a clean state for processing the next scanline.
	 */
	void start_scanline() {
			num = 1;
			found = 0;
			fetch = 1;
			count = 0;
			last = 64;
			mode = 0;
			found_pos[0] = found_pos[1] = found_pos[2] = found_pos[3] = 0;
			found_pos[4] = found_pos[5] = found_pos[6] = found_pos[7] = 0;
		}
};

//doesn't need to be savestated as it is just a reflection of the current position in the ppu loop
PPUPHASE ppuphase;

//this needs to be savestated since a game may be trying to read from this across vblanks
SPRITE_READ spr_read;

//definitely needs to be savestated
uint8 idleSynch = 1;

//uses the internal counters concept at http://nesdev.icequake.net/PPU%20addressing.txt
struct PPUREGS {
	//normal clocked regs. as the game can interfere with these at any time, they need to be savestated
	uint32 fv;	//3
	uint32 v;	//1
	uint32 h;	//1
	uint32 vt;	//5
	uint32 ht;	//5

	//temp unlatched regs (need savestating, can be written to at any time)
	uint32 _fv, _v, _h, _vt, _ht;

	//other regs that need savestating
	uint32 fh;	//3 (horz scroll)
	uint32 s;	//1 ($2000 bit 4: "Background pattern table address (0: $0000; 1: $1000)")

	//other regs that don't need saving
	uint32 par;	//8 (sort of a hack, just stored in here, but not managed by this system)

	//cached state data. these are always reset at the beginning of a frame and don't need saving
	//but just to be safe, we're gonna save it
	PPUSTATUS status;

	/**
	 * @brief Resets the internal state of the object to its initial values.
	 * 
	 * This method sets all member variables to zero, except for specific status-related variables.
	 * The status-related variables are initialized as follows:
	 * - `status.cycle` is set to 0.
	 * - `status.end_cycle` is set to 341.
	 * - `status.sl` is set to 241.
	 * 
	 * The method is typically used to reinitialize the object's state before starting a new operation
	 * or to clear any accumulated data from previous operations.
	 */
	void reset() {
	    fv = v = h = vt = ht = 0;
	    fh = par = s = 0;
	    _fv = _v = _h = _vt = _ht = 0;
	    status.cycle = 0;
	    status.end_cycle = 341;
	    status.sl = 241;
	}

	/**
	 * @brief Installs the latches by assigning the provided values to the corresponding member variables.
	 *
	 * This method sets the internal state of the object by copying the values of the provided parameters
	 * into the respective member variables. Specifically, it assigns the values of `_fv`, `_v`, `_h`, `_vt`,
	 * and `_ht` to the member variables `fv`, `v`, `h`, `vt`, and `ht`, respectively.
	 */
	void install_latches() {
	    fv = _fv;
	    v = _v;
	    h = _h;
	    vt = _vt;
	    ht = _ht;
	}

	/**
	 * @brief Installs the horizontal latches by assigning the provided values to the internal state.
	 * 
	 * This method sets the internal horizontal latch state (`ht`) and horizontal position (`h`)
	 * to the values provided by the external parameters `_ht` and `_h`, respectively. 
	 * This is typically used to initialize or update the horizontal latch configuration
	 * during the setup or operation of a system.
	 */
	void install_h_latches() {
	    ht = _ht;
	    h = _h;
	}

	/**
	 * @brief Clears all latch values in the object.
	 *
	 * This method resets the internal latch values to zero. Specifically, it sets the following
	 * member variables to 0: `_fv`, `_v`, `_h`, `_vt`, `_ht`, and `fh`. This is typically used to
	 * initialize or reset the state of the object, ensuring that all latch values are in a known
	 * default state.
	 */
	void clear_latches() {
	    _fv = _v = _h = _vt = _ht = 0;
	    fh = 0;
	}

	/**
	 * @brief Increments the horizontal scroll counter (HSC).
	 *
	 * The horizontal scroll counter is a 6-bit counter composed of two parts: 
	 * the HT counter (5 bits) and the H counter (1 bit). The HT counter is 
	 * incremented every 8 pixel dot clocks (or every 8/3 CPU clock cycles). 
	 * When the HT counter overflows (i.e., reaches 32), it increments the H counter.
	 * The HT counter is then masked to 5 bits, and the H counter is masked to 1 bit.
	 * This method updates both the HT and H counters accordingly.
	 */
	void increment_hsc() {
	    //The first one, the horizontal scroll counter, consists of 6 bits, and is
	    //made up by daisy-chaining the HT counter to the H counter. The HT counter is
	    //then clocked every 8 pixel dot clocks (or every 8/3 CPU clock cycles).
	    ht++;
	    h += (ht >> 5);
	    ht &= 31;
	    h &= 1;
	}

	/**
	 * Increments the vertical synchronization (VS) counter and updates related variables.
	 * 
	 * This method performs the following operations:
	 * 1. Increments the fine vertical counter (fv).
	 * 2. Calculates the overflow of the fine vertical counter (fv_overflow) by shifting fv right by 3 bits.
	 * 3. Adds the overflow to the vertical timing counter (vt) and ensures vt stays within the range 0-31 by masking with 31.
	 * 4. Checks if vt is exactly 30 and fv_overflow is 1, which indicates a specific overflow condition. If true:
	 *    - Increments the vertical counter (v).
	 *    - Resets vt to 0.
	 * 5. Ensures fv stays within the range 0-7 by masking with 7.
	 * 6. Ensures v stays within the range 0-1 by masking with 1.
	 * 
	 * This method is designed to handle vertical synchronization timing, particularly for emulating hardware behavior
	 * in systems like the Tecmo Super Bowl and resolving conflicts such as the P'radikus issue.
	 */
	void increment_vs() {
	    fv++;
	    int fv_overflow = (fv >> 3);
	    vt += fv_overflow;
	    vt &= 31;    //fixed tecmo super bowl
	    if (vt == 30 && fv_overflow == 1) {    //caution here (only do it at the exact instant of overflow) fixes p'radikus conflict
	        v++;
	        vt = 0;
	    }
	    fv &= 7;
	    v &= 1;
	}

	/**
	 * @brief Computes and returns the NTREAD value based on the current state of member variables.
	 *
	 * The NTREAD value is a 32-bit unsigned integer that combines several bit fields:
	 * - The most significant bit field is a fixed value of 0x2000 (8192 in decimal).
	 * - The next bit field is derived from the member variable `v`, shifted left by 11 bits.
	 * - The following bit field is derived from the member variable `h`, shifted left by 10 bits.
	 * - The next bit field is derived from the member variable `vt`, shifted left by 5 bits.
	 * - The least significant bit field is derived from the member variable `ht`.
	 *
	 * The method combines these bit fields using bitwise OR operations to produce the final NTREAD value.
	 *
	 * @return uint32 The computed NTREAD value.
	 */
	uint32 get_ntread() {
	    return 0x2000 | (v << 0xB) | (h << 0xA) | (vt << 5) | ht;
	}

	/**
	 * @brief Retrieves a 32-bit value by combining various bitfields from member variables.
	 *
	 * The method constructs a 32-bit value by shifting and combining the following bitfields:
	 * - The lower 2 bits of `fv` are shifted left by 12 positions.
	 * - The value of `v` is shifted left by 11 positions.
	 * - The value of `h` is shifted left by 10 positions.
	 * - The value of `vt` is shifted left by 5 positions.
	 * - The value of `ht` is used as-is (no shifting).
	 *
	 * The resulting value is a combination of these bitfields, each occupying specific positions
	 * in the 32-bit return value.
	 *
	 * @return uint32 A 32-bit value constructed from the combined bitfields.
	 */
	uint32 get_2007access() {
	    return ((fv & 3) << 0xC) | (v << 0xB) | (h << 0xA) | (vt << 5) | ht;
	}

	//The PPU has an internal 4-position, 2-bit shifter, which it uses for
	//obtaining the 2-bit palette select data during an attribute table byte
	//fetch. To represent how this data is shifted in the diagram, letters a..c
	//are used in the diagram to represent the right-shift position amount to
	//apply to the data read from the attribute data (a is always 0). This is why
	//you only see bits 0 and 1 used off the read attribute data in the diagram.
	uint32 get_atread() {
		return 0x2000 | (v << 0xB) | (h << 0xA) | 0x3C0 | ((vt & 0x1C) << 1) | ((ht & 0x1C) >> 2);
	}

	//address line 3 relates to the pattern table fetch occuring (the PPU always makes them in pairs).
	uint32 get_ptread() {
		return (s << 0xC) | (par << 0x4) | fv;
	}

	/**
	 * @brief Increments the VRAM address based on the provided flags.
	 *
	 * This method handles the increment of the VRAM address in two distinct scenarios:
	 * 1. When rendering is active, it unconditionally calls `increment_vs()` to increment the vertical scroll counter.
	 * 2. When rendering is not active, it increments the VRAM address based on the `by32` flag:
	 *    - If `by32` is true, the VT (vertical tile) counter is incremented directly.
	 *    - If `by32` is false, the HT (horizontal tile) counter is incremented, and the VT counter is incremented 
	 *      based on the carry from the HT counter. The H (horizontal), V (vertical), and FV (fine vertical) counters 
	 *      are also updated based on the carry from their respective preceding counters.
	 * 
	 * The method ensures that all counters (HT, VT, H, V, FV) are properly masked to stay within their valid ranges:
	 * - HT and VT are masked to 5 bits (0-31).
	 * - H and V are masked to 1 bit (0-1).
	 * - FV is masked to 3 bits (0-7).
	 *
	 * @param rendering A boolean flag indicating whether rendering is active.
	 * @param by32 A boolean flag indicating whether the VRAM address should be incremented by 32 (true) or by 1 (false).
	 */
	void increment2007(bool rendering, bool by32) {
	    if (rendering) {
	        increment_vs();  //yes, even if we're moving by 32
	        return;
	    }
	
	    if (by32) {
	        vt++;
	    } else {
	        ht++;
	        vt += (ht >> 5) & 1;
	    }
	    h += (vt >> 5);
	    v += (h >> 1);
	    fv += (v >> 1);
	    ht &= 31;
	    vt &= 31;
	    h &= 1;
	    v &= 1;
	    fv &= 7;
	}

	/**
	 * @brief Outputs detailed debugging information about the current state of PPU (Picture Processing Unit) registers and status.
	 * 
	 * This method logs the values of various PPU-related variables and status flags to the console or a debug output stream.
	 * It is primarily used for debugging purposes to inspect the internal state of the PPU during emulation.
	 * 
	 * The method prints the following information in a formatted manner:
	 * - `fv`, `v`, `h`, `vt`, `ht`: Current values of the fine vertical scroll, vertical scroll, horizontal scroll, vertical tile, and horizontal tile registers.
	 * - `_fv`, `_v`, `_h`, `_vt`, `_ht`: Previous values of the fine vertical scroll, vertical scroll, horizontal scroll, vertical tile, and horizontal tile registers.
	 * - `fh`, `s`, `par`: Values of the fine horizontal scroll, sprite evaluation, and parity-related registers.
	 * - `status.cycle`, `status.end_cycle`, `status.sl`: Current cycle count, end cycle, and scanline status within the PPU's rendering process.
	 * 
	 * This method is typically called during development or troubleshooting to verify the correctness of PPU emulation logic.
	 */
	void debug_log()
	{
		FCEU_printf("ppur: fv(%d), v(%d), h(%d), vt(%d), ht(%d)\n",fv,v,h,vt,ht);
		FCEU_printf("      _fv(%d), _v(%d), _h(%d), _vt(%d), _ht(%d)\n",_fv,_v,_h,_vt,_ht);
		FCEU_printf("      fh(%d), s(%d), par(%d)\n",fh,s,par);
		FCEU_printf("      .status cycle(%d), end_cycle(%d), sl(%d)\n",status.cycle,status.end_cycle,status.sl);
	}
} ppur;

/**
 * @brief Retrieves the current scanline being rendered by the PPU (Picture Processing Unit).
 *
 * This method returns the value of the scanline counter from the PPU's status register.
 * The scanline counter indicates the vertical line currently being processed during
 * the rendering of a frame. This is useful for synchronization and timing purposes
 * in emulators or graphics applications.
 *
 * @return int The current scanline number, as stored in the PPU's status register.
 */
int newppu_get_scanline() { return ppur.status.sl; }
/**
 * @brief Retrieves the current dot position in the PPU (Picture Processing Unit) rendering cycle.
 * 
 * This method returns the value of the `cycle` field from the `status` structure of the PPU.
 * The `cycle` field typically represents the horizontal position of the current pixel being rendered
 * within a scanline. This can be useful for timing and synchronization purposes in emulation or
 * rendering logic.
 * 
 * @return int The current dot position in the PPU rendering cycle.
 */
int newppu_get_dot() { return ppur.status.cycle; }
/**
 * @brief Performs a hacky emergency reset of the PPU (Picture Processing Unit) state.
 *
 * This method checks if the PPU's status indicates that the end cycle is zero. If so,
 * it triggers a reset of the PPU state by calling the `reset()` method on the `ppur` object.
 * This is typically used as a fallback mechanism to ensure the PPU is in a valid state
 * when unexpected conditions are detected.
 */
void newppu_hacky_emergency_reset()
{
	if(ppur.status.end_cycle == 0)
		ppur.reset();
}

/**
 * @brief Generates lookup tables (LUTs) for PPU (Picture Processing Unit) emulation.
 *
 * This method initializes three lookup tables (ppulut1, ppulut2, and ppulut3) used in PPU emulation.
 * - ppulut1 and ppulut2 are generated by iterating over 256 values and performing bitwise operations
 *   to rearrange bits in a specific pattern. ppulut2 is derived from ppulut1 by shifting its values left by 1 bit.
 * - ppulut3 is generated by iterating over 16 color codes and 8 x-offsets, calculating bit patterns based on
 *   pixel positions and x-offsets, and storing the results in a combined index.
 *
 * These LUTs are typically used to optimize PPU rendering by precomputing bit patterns and color mappings.
 */
static void makeppulut(void) {
	int x;
	int y;
	int cc, xo, pixel;


	for (x = 0; x < 256; x++) {
		ppulut1[x] = 0;
		for (y = 0; y < 8; y++)
			ppulut1[x] |= ((x >> (7 - y)) & 1) << (y * 4);
		ppulut2[x] = ppulut1[x] << 1;
	}

	for (cc = 0; cc < 16; cc++) {
		for (xo = 0; xo < 8; xo++) {
			ppulut3[xo | (cc << 3)] = 0;
			for (pixel = 0; pixel < 8; pixel++) {
				int shiftr;
				shiftr = (pixel + xo) / 8;
				shiftr *= 2;
				ppulut3[xo | (cc << 3)] |= ((cc >> shiftr) & 3) << (2 + pixel * 4);
			}
		}
	}
}

static int ppudead = 1;
static int kook = 0;
int fceuindbg = 0;

//mbg 6/23/08
//make the no-bg fill color configurable
//0xFF shall indicate to use palette[0]
uint8 gNoBGFillColor = 0xFF;

int MMC5Hack = 0;
uint32 MMC5HackVROMMask = 0;
uint8 *MMC5HackExNTARAMPtr = 0;
uint8 *MMC5HackVROMPTR = 0;
uint8 MMC5HackCHRMode = 0;
uint8 MMC5HackSPMode = 0;
uint8 MMC50x5130 = 0;
uint8 MMC5HackSPScroll = 0;
uint8 MMC5HackSPPage = 0;

int PEC586Hack = 0;

int QTAIHack = 0;
uint8 QTAINTRAM[2048];
uint8 qtaintramreg;

uint8 VRAMBuffer = 0, PPUGenLatch = 0;
uint8 *vnapage[4];
uint8 PPUNTARAM = 0;
uint8 PPUCHRRAM = 0;

//Color deemphasis emulation.  Joy...
static uint8 deemp = 0;
static int deempcnt[8];

void (*GameHBIRQHook)(void), (*GameHBIRQHook2)(void);
void (*PPU_hook)(uint32 A);

uint8 vtoggle = 0;
uint8 XOffset = 0;
uint8 SpriteDMA = 0; // $4014 / Writing $xx copies 256 bytes by reading from $xx00-$xxFF and writing to $2004 (OAM data)

uint32 TempAddr = 0, RefreshAddr = 0, DummyRead = 0, NTRefreshAddr = 0;

static int maxsprites = 8;

//scanline is equal to the current visible scanline we're on.
int scanline;
int g_rasterpos;
static uint32 scanlines_per_frame;

uint8 PPU[4];
uint8 PPUSPL;
uint8 NTARAM[0x800], PALRAM[0x20], SPRAM[0x100], SPRBUF[0x100];
uint8 UPALRAM[0x03];//for 0x4/0x8/0xC addresses in palette, the ones in
					//0x20 are 0 to not break fceu rendering.

static uint16 PALcache[256];
static int PALcache_outdate = 0;

/**
 * @brief Updates the PALcache by processing the current state of PALRAM.
 *
 * This method checks if the PALcache is outdated (via the `PALcache_outdate` flag).
 * If the cache is not outdated, the method returns immediately. Otherwise, it proceeds
 * to update the cache as follows:
 * 1. Sets the priority bits (bit 6) in specific PALRAM entries (indices 0, 4, 8, and 0xC)
 *    to ensure correct sprite emulation.
 * 2. Iterates over a 16x16 grid, combining pairs of PALRAM values into 16-bit entries
 *    and storing them in the PALcache.
 * 3. Reverts the priority bits in PALRAM to their original state by masking out bit 6.
 * 4. Marks the PALcache as up-to-date by setting `PALcache_outdate` to 0.
 *
 * The PALcache is used to store processed color data for efficient rendering, and this
 * method ensures it reflects the current state of PALRAM.
 */
static void update_PALcache() {
  if (!PALcache_outdate) return;
  //Priority bits, needed for sprite emulation.
  PALRAM[0] |= 64;
  PALRAM[4] |= 64;
  PALRAM[8] |= 64;
  PALRAM[0xC] |= 64;

  int x, y;
  int i = 0;
  for (x = 0; x < 16; x ++) {
    for (y = 0; y < 16; y ++) {
      PALcache[i ++] = (PALRAM[x] << 8) | PALRAM[y];
    }
  }

  //Reverse changes made before.
  PALRAM[0] &= 63;
  PALRAM[4] &= 63;
  PALRAM[8] &= 63;
  PALRAM[0xC] &= 63;

  PALcache_outdate = 0;
}

#define MMC5SPRVRAMADR(V)   &MMC5SPRVPage[(V) >> 10][(V)]
#define VRAMADR(V)          &VPage[(V) >> 10][(V)]

uint8* MMC5BGVRAMADR(uint32 A);

/**
 * @brief Reads a palette value based on the provided address.
 *
 * This method reads a palette value from memory based on the address `A`. The behavior
 * depends on the specific bits of the address:
 * - If the lower 2 bits of `A` are 0 (i.e., `A & 3 == 0`), it checks the next 2 bits:
 *   - If those bits are also 0 (i.e., `A & 0xC == 0`), it reads the palette value at address `0x00`.
 *   - Otherwise, it reads a value from the upper palette using the formula `((A & 0xC) >> 2) - 1`.
 * - If the lower 2 bits of `A` are not 0, it reads the palette value at the address `A & 0x1F`.
 *
 * @param A The address used to determine which palette value to read.
 * @return The palette value read from memory based on the address `A`.
 */
uint8 READPAL_MOTHEROFALL(uint32 A)
{
	if(!(A & 3)) {
		if(!(A & 0xC))
			return READPAL(0x00);
		else
			return READUPAL(((A & 0xC) >> 2) - 1);
	}
	else
		return READPAL(A & 0x1F);
}

//this duplicates logic which is embedded in the ppu rendering code
//which figures out where to get CHR data from depending on various hack modes
//mostly involving mmc5.
//this might be incomplete.
uint8* FCEUPPU_GetCHR(uint32 vadr, uint32 refreshaddr) {
	if (MMC5Hack) {
		if (MMC5HackCHRMode == 1) {
			uint8 *C = MMC5HackVROMPTR;
			C += (((MMC5HackExNTARAMPtr[refreshaddr & 0x3ff]) & 0x3f & MMC5HackVROMMask) << 12) + (vadr & 0xfff);
			C += (MMC50x5130 & 0x3) << 18;	//11-jun-2009 for kuja_killer
			return C;
		} else {
			return MMC5BGVRAMADR(vadr);
		}
	} else return VRAMADR(vadr);
}

//likewise for ATTR
int FCEUPPU_GetAttr(int ntnum, int xt, int yt) {
	int attraddr = 0x3C0 + ((yt >> 2) << 3) + (xt >> 2);
	int temp = (((yt & 2) << 1) + (xt & 2));
	int refreshaddr = xt + yt * 32;
	if (MMC5Hack && MMC5HackCHRMode == 1)
		return (MMC5HackExNTARAMPtr[refreshaddr & 0x3ff] & 0xC0) >> 6;
	else
		return (vnapage[ntnum][attraddr] & (3 << temp)) >> temp;
}

//new ppu-----
inline void FFCEUX_PPUWrite_Default(uint32 A, uint8 V) {
	uint32 tmp = A;

	if (PPU_hook) PPU_hook(A);

	if (tmp < 0x2000) {
		if (PPUCHRRAM & (1 << (tmp >> 10)))
			VPage[tmp >> 10][tmp] = V;
	} else if (tmp < 0x3F00) {
		if (QTAIHack && (qtaintramreg & 1)) {
			QTAINTRAM[((((tmp & 0xF00) >> 10) >> ((qtaintramreg >> 1)) & 1) << 10) | (tmp & 0x3FF)] = V;
		} else {
			if (PPUNTARAM & (1 << ((tmp & 0xF00) >> 10)))
				vnapage[((tmp & 0xF00) >> 10)][tmp & 0x3FF] = V;
		}
	} else {
		if (!(tmp & 3)) {
			if (!(tmp & 0xC)) {
				PALRAM[0x00] = PALRAM[0x04] = PALRAM[0x08] = PALRAM[0x0C] = V & 0x3F;
				PALRAM[0x10] = PALRAM[0x14] = PALRAM[0x18] = PALRAM[0x1C] = V & 0x3F;
				PALcache_outdate = 1;
			}
			else
				UPALRAM[((tmp & 0xC) >> 2) - 1] = V & 0x3F;
		} else {
			PALRAM[tmp & 0x1F] = V & 0x3F;
			PALcache_outdate = 1;
    }
	}
}

volatile int rendercount, vromreadcount, undefinedvromcount, LogAddress = -1;
unsigned char *cdloggervdata = NULL;
unsigned int cdloggerVideoDataSize = 0;

/**
 * @brief Retrieves the CHR memory address based on the given address `A`.
 *
 * This method calculates the CHR memory address by performing the following steps:
 * - If `cdloggerVideoDataSize` is non-zero, it calculates the offset of the address `A` 
 *   within the video memory pages (`VPage`) relative to the base CHR pointer (`CHRptr[0]`).
 * - If the calculated offset is within the valid range of `cdloggerVideoDataSize`, 
 *   the offset is returned as the CHR address.
 * - If `cdloggerVideoDataSize` is zero and `A` is less than 0x2000, `A` is returned directly.
 * - If none of the above conditions are met, the method returns -1, indicating an invalid address.
 *
 * @param A The input address to be converted to a CHR memory address.
 * @return The calculated CHR address if valid; otherwise, returns -1.
 */
int GetCHRAddress(int A) {
	if (cdloggerVideoDataSize) {
		int result = &VPage[A >> 10][A] - CHRptr[0];
		if ((result >= 0) && (result < (int)cdloggerVideoDataSize))
			return result;
	} else
		if(A < 0x2000) return A;
	return -1;
}

/**
 * @brief Calculates the offset of the given pointer relative to the CHR pointer.
 *
 * This method computes the difference between the provided pointer (`ptr`) and the base CHR pointer (`CHRptr[0]`).
 * The result is then checked against valid bounds:
 * - If `cdloggerVideoDataSize` is non-zero, the result must be within the range [0, cdloggerVideoDataSize).
 * - If `cdloggerVideoDataSize` is zero, the result must be within the range [0, 0x2000).
 * If the result falls within the valid bounds, it is returned. Otherwise, the method returns -1 to indicate an invalid offset.
 *
 * @param ptr A pointer to the memory location whose offset is to be calculated.
 * @return The calculated offset if valid; otherwise, -1.
 */
int GetCHROffset(uint8 *ptr) {
	int result = ptr - CHRptr[0];
	if (cdloggerVideoDataSize) {
		if ((result >= 0) && (result < (int)cdloggerVideoDataSize))
			return result;
	} else {
		if ((result >= 0) && (result < 0x2000))
			return result;
	}
	return -1;
}

#define RENDER_LOG(tmp) { \
		if (debug_loggingCD) \
		{ \
			int addr = GetCHRAddress(tmp); \
			if (addr != -1)	\
			{ \
				if (!(cdloggervdata[addr] & 1))	\
				{ \
					cdloggervdata[addr] |= 1; \
					if(cdloggerVideoDataSize) { \
						if (!(cdloggervdata[addr] & 2)) undefinedvromcount--; \
						rendercount++; \
					} \
				} \
			} \
		} \
}

#define RENDER_LOGP(tmp) { \
		if (debug_loggingCD) \
		{ \
			int addr = GetCHROffset(tmp); \
			if (addr != -1)	\
			{ \
				if (!(cdloggervdata[addr] & 1))	\
				{ \
					cdloggervdata[addr] |= 1; \
					if(cdloggerVideoDataSize) { \
						if (!(cdloggervdata[addr] & 2)) undefinedvromcount--; \
						rendercount++; \
					} \
				} \
			} \
		} \
}

/**
 * @brief Reads data from the PPU (Picture Processing Unit) memory based on the provided address.
 *
 * This method handles reading from different regions of the PPU memory:
 * - If the address is below 0x2000, it reads from the VPage array, which represents the pattern tables.
 * - If the address is between 0x2000 and 0x3F00, it reads from the vnapage array, which represents the nametables.
 * - If the address is 0x3F00 or above, it reads from the palette memory, handling special cases for background and sprite palettes.
 *
 * If a PPU hook is registered (PPU_hook), it is called with the address before performing the read operation.
 *
 * @param A The address to read from in the PPU memory.
 * @return The data read from the PPU memory at the specified address.
 */
uint8 FASTCALL FFCEUX_PPURead_Default(uint32 A) {
	uint32 tmp = A;

	if (PPU_hook) PPU_hook(A);

	if (tmp < 0x2000) {
		return VPage[tmp >> 10][tmp];
	} else if (tmp < 0x3F00) {
		return vnapage[(tmp >> 10) & 0x3][tmp & 0x3FF];
	} else {
		uint8 ret;
		if (!(tmp & 3)) {
			if (!(tmp & 0xC))
				ret = READPAL(0x00);
			else
				ret = READUPAL(((tmp & 0xC) >> 2) - 1);
		} else
			ret = READPAL(tmp & 0x1F);
		return ret;
	}
}


uint8 (FASTCALL *FFCEUX_PPURead)(uint32 A) = 0;
void (*FFCEUX_PPUWrite)(uint32 A, uint8 V) = 0;

#define CALL_PPUREAD(A) (FFCEUX_PPURead(A))

#define CALL_PPUWRITE(A, V) (FFCEUX_PPUWrite ? FFCEUX_PPUWrite(A, V) : FFCEUX_PPUWrite_Default(A, V))

//whether to use the new ppu
int newppu = 0;

/**
 * @brief Retrieves the current scroll position (xpos, ypos) of the PPU (Picture Processing Unit).
 * 
 * The method calculates the scroll position based on the PPU's internal state. The calculation 
 * depends on whether the "newppu" flag is set. If "newppu" is true, the scroll position is derived 
 * from the PPU's internal registers (ppur._vt, ppur._fv, ppur._v, ppur._ht, ppur.fh, ppur._h). 
 * If "newppu" is false, the scroll position is calculated using the RefreshAddr register and XOffset.
 * 
 * @param xpos Reference to an integer where the horizontal scroll position will be stored.
 * @param ypos Reference to an integer where the vertical scroll position will be stored.
 */
void ppu_getScroll(int &xpos, int &ypos) {
	if (newppu) {
		ypos = ppur._vt * 8 + ppur._fv + ppur._v * 256;
		xpos = ppur._ht * 8 + ppur.fh + ppur._h * 256;
	} else {
		xpos = ((RefreshAddr & 0x400) >> 2) | ((RefreshAddr & 0x1F) << 3) | XOffset;

		ypos = ((RefreshAddr & 0x3E0) >> 2) | ((RefreshAddr & 0x7000) >> 12);
		if (RefreshAddr & 0x800) ypos += 240;
	}
}
//---------------

static DECLFR(A2002) {
	if (newppu) {
		//once we thought we clear latches here, but that caused midframe glitches.
		//i think we should only reset the state machine for 2005/2006
		//ppur.clear_latches();
	}

	uint8 ret;

	FCEUPPU_LineUpdate();
	ret = PPU_status;
	ret |= PPUGenLatch & 0x1F;

	{
		vtoggle = 0;
		PPU_status &= 0x7F;
		PPUGenLatch = ret;
	}

	return ret;
}

/**
 * @brief Handles the PPU (Picture Processing Unit) memory access for address 0x2004.
 *
 * This method is responsible for managing the PPU's OAM (Object Attribute Memory) read operations
 * during the rendering process. It performs different actions based on the current PPU state, 
 * including initializing the OAM buffer, fetching sprite data, and handling sprite overflow.
 *
 * The method operates in multiple modes depending on the PPU's rendering cycle and the status of
 * the OAM buffer. It updates the `spr_read` structure to track the current state of sprite data 
 * fetching and returns the appropriate value from the OAM buffer or PPU memory.
 *
 * @return The value read from the OAM buffer or PPU memory, depending on the current state and 
 *         rendering cycle. If the PPU is not active, it updates the line and returns the PPU 
 *         latch value.
 */
static DECLFR(A2004) {
	if (newppu) {
		if ((ppur.status.sl < 241) && PPUON) {
			// from cycles 0 to 63, the
			// 32 byte OAM buffer gets init
			// to 0xFF
			if (ppur.status.cycle < 64)
				return spr_read.ret = 0xFF;
			else {
				for (int i = spr_read.last;
					 i != ppur.status.cycle; ++i) {
					if (i < 256) {
						switch (spr_read.mode) {
						case 0:
							if (spr_read.count < 2)
								spr_read.ret = (PPU[3] & 0xF8) + (spr_read.count << 2);
							else
								spr_read.ret = spr_read.count << 2;

							spr_read.found_pos[spr_read.found] = spr_read.ret;
							spr_read.ret = SPRAM[spr_read.ret];

							if (i & 1) {
								//odd cycle
								//see if in range
								if (!((ppur.status.sl - 1 - spr_read.ret) & ~(Sprite16 ? 0xF : 0x7))) {
									++spr_read.found;
									spr_read.fetch = 1;
									spr_read.mode = 1;
								} else {
									if (++spr_read.count == 64) {
										spr_read.mode = 4;
										spr_read.count = 0;
									} else if (spr_read.found == 8) {
										spr_read.fetch = 0;
										spr_read.mode = 2;
									}
								}
							}
							break;
						case 1:	//sprite is in range fetch next 3 bytes
							if (i & 1) {
								++spr_read.fetch;
								if (spr_read.fetch == 4) {
									spr_read.fetch = 1;
									if (++spr_read.count == 64) {
										spr_read.count = 0;
										spr_read.mode = 4;
									} else if (spr_read.found == 8) {
										spr_read.fetch = 0;
										spr_read.mode = 2;
									} else
										spr_read.mode = 0;
								}
							}

							if (spr_read.count < 2)
								spr_read.ret = (PPU[3] & 0xF8) + (spr_read.count << 2);
							else
								spr_read.ret = spr_read.count << 2;

							spr_read.ret = SPRAM[spr_read.ret | spr_read.fetch];
							break;
						case 2:	//8th sprite fetched
							spr_read.ret = SPRAM[(spr_read.count << 2) | spr_read.fetch];
							if (i & 1) {
								if (!((ppur.status.sl - 1 - SPRAM[((spr_read.count << 2) | spr_read.fetch)]) & ~((Sprite16) ? 0xF : 0x7))) {
									spr_read.fetch = 1;
									spr_read.mode = 3;
								} else {
									if (++spr_read.count == 64) {
										spr_read.count = 0;
										spr_read.mode = 4;
									}
									spr_read.fetch =
										(spr_read.fetch + 1) & 3;
								}
							}
							spr_read.ret = spr_read.count;
							break;
						case 3:	//9th sprite overflow detected
							spr_read.ret = SPRAM[spr_read.count | spr_read.fetch];
							if (i & 1) {
								if (++spr_read.fetch == 4) {
									spr_read.count = (spr_read.count + 1) & 63;
									spr_read.mode = 4;
								}
							}
							break;
						case 4:	//read OAM[n][0] until hblank
							if (i & 1)
								spr_read.count = (spr_read.count + 1) & 63;
							spr_read.fetch = 0;
							spr_read.ret = SPRAM[spr_read.count << 2];
							break;
						}
					} else if (i < 320) {
						spr_read.ret = (i & 0x38) >> 3;
						if (spr_read.found < (spr_read.ret + 1)) {
							if (spr_read.num) {
								spr_read.ret = SPRAM[252];
								spr_read.num = 0;
							} else
								spr_read.ret = 0xFF;
						} else if ((i & 7) < 4) {
							spr_read.ret =
								SPRAM[spr_read.found_pos[spr_read.ret] | spr_read.fetch++];
							if (spr_read.fetch == 4)
								spr_read.fetch = 0;
						} else
							spr_read.ret = SPRAM[spr_read.found_pos [spr_read.ret | 3]];
					} else {
						if (!spr_read.found)
							spr_read.ret = SPRAM[252];
						else
							spr_read.ret = SPRAM[spr_read.found_pos[0]];
						break;
					}
				}
				spr_read.last = ppur.status.cycle;
				return spr_read.ret;
			}
		} else
			return SPRAM[PPU[3]];
	} else {
		FCEUPPU_LineUpdate();
		return PPUGenLatch;
	}
}

/**
 * @brief Reads the value from the PPU (Picture Processing Unit) latch and updates the PPU line.
 * 
 * This method is responsible for updating the PPU line by calling `FCEUPPU_LineUpdate()` and then 
 * returning the value stored in `PPUGenLatch`. It is important to note that this method is not 
 * correct for reads from the memory address $2004, as indicated in the comment.
 * 
 * @return The value stored in `PPUGenLatch` after updating the PPU line.
 */
static DECLFR(A200x) {	/* Not correct for $2004 reads. */
	FCEUPPU_LineUpdate();
	return PPUGenLatch;
}

/**
 * @brief Handles the read operation for PPU register $2007 (VRAM data access).
 *
 * This method is responsible for reading data from the PPU's VRAM or palette RAM
 * based on the current `RefreshAddr`. It supports both the "new" and "old" PPU
 * implementations, with different behaviors for each. The method also handles
 * debug logging, dummy reads, and VRAM buffer updates. Depending on the address
 * range accessed, it may read from VRAM, palette RAM, or perform special handling
 * for palette data. Additionally, it updates the `RefreshAddr` based on the PPU's
 * current state and configuration (e.g., increment mode, scanline, etc.).
 *
 * @return The byte read from VRAM or palette RAM.
 */
static DECLFR(A2007) {
	uint8 ret;
	uint32 tmp = RefreshAddr & 0x3FFF;

	if (debug_loggingCD) {
		if (!DummyRead && (LogAddress != -1)) {
			if (!(cdloggervdata[LogAddress] & 2)) {
				cdloggervdata[LogAddress] |= 2;
				if ((!(cdloggervdata[LogAddress] & 1)) && cdloggerVideoDataSize) undefinedvromcount--;
				vromreadcount++;
			}
		} else
			DummyRead = 0;
	}

	if (newppu) {
		ret = VRAMBuffer;
		RefreshAddr = ppur.get_2007access() & 0x3FFF;
		if ((RefreshAddr & 0x3F00) == 0x3F00) {
			//if it is in the palette range bypass the
			//delayed read, and what gets filled in the temp
			//buffer is the address - 0x1000, also
			//if grayscale is set then the return is AND with 0x30
			//to get a gray color reading
			if (!(tmp & 3)) {
				if (!(tmp & 0xC))
					ret = READPAL(0x00);
				else
					ret = READUPAL(((tmp & 0xC) >> 2) - 1);
			} else
				ret = READPAL(tmp & 0x1F);
			VRAMBuffer = CALL_PPUREAD(RefreshAddr - 0x1000);
		} else {
			if (debug_loggingCD && (RefreshAddr < 0x2000))
				LogAddress = GetCHRAddress(RefreshAddr);
			VRAMBuffer = CALL_PPUREAD(RefreshAddr);
		}
		ppur.increment2007(ppur.status.sl >= 0 && ppur.status.sl < 241 && PPUON, INC32 != 0);
		RefreshAddr = ppur.get_2007access();
		return ret;
	} else {

		//OLDPPU
		FCEUPPU_LineUpdate();

		if (tmp >= 0x3F00) {	// Palette RAM tied directly to the output data, without VRAM buffer
			if (!(tmp & 3)) {
				if (!(tmp & 0xC))
					ret = READPAL(0x00);
				else
					ret = READUPAL(((tmp & 0xC) >> 2) - 1);
			} else
				ret = READPAL(tmp & 0x1F);
			{
				if ((tmp - 0x1000) < 0x2000)
					VRAMBuffer = VPage[(tmp - 0x1000) >> 10][tmp - 0x1000];
				else
					VRAMBuffer = vnapage[((tmp - 0x1000) >> 10) & 0x3][(tmp - 0x1000) & 0x3FF];
				if (PPU_hook) PPU_hook(tmp);
			}
		} else {
			ret = VRAMBuffer;
			{
				if (PPU_hook) PPU_hook(tmp);
				PPUGenLatch = VRAMBuffer;
				if (tmp < 0x2000) {

					if (debug_loggingCD)
						LogAddress = GetCHRAddress(tmp);
					if(MMC5Hack && newppu)
						VRAMBuffer = *MMC5BGVRAMADR(tmp);
					else
						VRAMBuffer = VPage[tmp >> 10][tmp];

				} else if (tmp < 0x3F00)
					VRAMBuffer = vnapage[(tmp >> 10) & 0x3][tmp & 0x3FF];
			}
		}

		{
			if ((ScreenON || SpriteON) && (scanline < 240)) {
				uint32 rad = RefreshAddr;
				if ((rad & 0x7000) == 0x7000) {
					rad ^= 0x7000;
					if ((rad & 0x3E0) == 0x3A0)
						rad ^= 0xBA0;
					else if ((rad & 0x3E0) == 0x3e0)
						rad ^= 0x3e0;
					else
						rad += 0x20;
				} else
					rad += 0x1000;
				RefreshAddr = rad;
			} else {
				if (INC32)
					RefreshAddr += 32;
				else
					RefreshAddr++;
			}
			if (PPU_hook) PPU_hook(RefreshAddr & 0x3fff);
		}
		return ret;
	}
}

/**
 * @brief Handles the B2000 write operation for the PPU (Picture Processing Unit).
 * 
 * This method updates the PPU state based on the provided value `V`. It performs the following operations:
 * 1. Updates the PPU line state using `FCEUPPU_LineUpdate()`.
 * 2. Stores the value `V` in the `PPUGenLatch` register.
 * 3. Checks if the NMI (Non-Maskable Interrupt) should be triggered based on the current PPU state and the value `V`.
 *    - NMI is triggered if the NMI enable bit in `PPU[0]` is not set, the NMI bit in `V` is set, and the NMI flag in `PPU_status` is set.
 * 4. Updates the `PPU[0]` register with the value `V`.
 * 5. Modifies the `TempAddr` register by clearing the lower 2 bits of the 10th and 11th bits and setting them based on the lower 2 bits of `V`.
 * 6. Updates the `ppur` structure fields (`_h`, `_v`, and `s`) based on the value `V`.
 */
static DECLFW(B2000) {
	FCEUPPU_LineUpdate();
	PPUGenLatch = V;

	if (!(PPU[0] & 0x80) && (V & 0x80) && (PPU_status & 0x80))
		TriggerNMI2();

	PPU[0] = V;
	TempAddr &= 0xF3FF;
	TempAddr |= (V & 3) << 10;

	ppur._h = V & 1;
	ppur._v = (V >> 1) & 1;
	ppur.s = (V >> 4) & 1;
}

/**
 * @brief Handles the B2001 write operation for the PPU (Picture Processing Unit).
 *
 * This method performs the following operations:
 * 1. Updates the PPU line state using `FCEUPPU_LineUpdate()`.
 * 2. If `paldeemphswap` is enabled, modifies the value `V` by swapping bits 6 and 5.
 * 3. Updates the PPUGenLatch and PPU[1] registers with the modified value of `V`.
 * 4. If the upper 3 bits of `V` are set, updates the `deemp` variable with the value of the upper 3 bits of `V`.
 *
 * @param V The value to be processed and written to the PPU registers.
 */
static DECLFW(B2001) {
	FCEUPPU_LineUpdate();
	if (paldeemphswap)
		V = (V&0x9F)|((V&0x40)>>1)|((V&0x20)<<1);
	PPUGenLatch = V;
	PPU[1] = V;
	if (V & 0xE0)
		deemp = V >> 5;
}

/**
 * @brief Updates the PPUGenLatch with the provided value.
 *
 * This static method is responsible for setting the PPUGenLatch to the value passed 
 * as the parameter. The PPUGenLatch is typically used in the context of emulating 
 * the Picture Processing Unit (PPU) of a system, where it holds a temporary value 
 * that is used in subsequent operations.
 *
 * @param V The value to be assigned to the PPUGenLatch.
 */
static DECLFW(B2002) {
	PPUGenLatch = V;
}

/**
 * @brief Updates the PPU (Picture Processing Unit) registers with the provided value.
 *
 * This method updates three PPU-related registers based on the input value `V`:
 * - `PPUGenLatch`: A general-purpose latch register in the PPU, which is set to the value of `V`.
 * - `PPU[3]`: The third register in the PPU array, which is also set to the value of `V`.
 * - `PPUSPL`: A register that stores the lower 3 bits of `V` (i.e., `V & 0x7`).
 *
 * @param V The value to be written to the PPU registers.
 */
static DECLFW(B2003) {
	PPUGenLatch = V;
	PPU[3] = V;
	PPUSPL = V & 0x7;
}

/**
 * @brief Handles the write operation for the B2004 register in the PPU (Picture Processing Unit).
 *
 * This method processes the write operation to the B2004 register, which is used to update
 * the PPU's internal state. The behavior of this method depends on whether the "newppu" flag
 * is set, indicating the use of a newer PPU model.
 *
 * If the "newppu" flag is set:
 * - The upper bits of the attribute data are masked out (ANDed with 0xE3) if the PPU[3] register
 *   is in a specific state (bit 1 and 0 set to 2).
 * - The value `V` is written to the SPRAM (Sprite RAM) at the address specified by PPU[3].
 * - The PPU[3] register is incremented and wrapped around to 0xFF.
 *
 * If the "newppu" flag is not set:
 * - The value `V` is written to the SPRAM based on the current state of PPUSPL (Sprite Pointer Low).
 * - If PPUSPL is greater than or equal to 8, the value is written to SPRAM at the address specified
 *   by PPU[3]. Otherwise, it is written to SPRAM at the address specified by PPUSPL.
 * - Both PPU[3] and PPUSPL are incremented after the write operation.
 *
 * @param V The value to be written to the B2004 register.
 */
static DECLFW(B2004) {
	PPUGenLatch = V;
	if (newppu) {
		//the attribute upper bits are not connected
		//so AND them out on write, since reading them
		//should return 0 in those bits.
		if ((PPU[3] & 3) == 2)
			V &= 0xE3;
		SPRAM[PPU[3]] = V;
		PPU[3] = (PPU[3] + 1) & 0xFF;
	} else {
		if (PPUSPL >= 8) {
			if (PPU[3] >= 8)
				SPRAM[PPU[3]] = V;
		} else {
			SPRAM[PPUSPL] = V;
		}
		PPU[3]++;
		PPUSPL++;
	}
}

/**
 * @brief Handles the B2005 write operation, updating the PPU's temporary address and related registers.
 *
 * This method processes a write operation to the B2005 register, which is used to set the PPU's
 * temporary address (TempAddr) and update related registers based on the current state of the vtoggle flag.
 * The vtoggle flag alternates between horizontal and vertical address updates.
 *
 * When vtoggle is 0 (false):
 * - The lower 5 bits of TempAddr are updated with bits 3-7 of the input value V.
 * - The XOffset is set to the lower 3 bits of V.
 * - The PPU's horizontal tile (ppur._ht) and fine horizontal scroll (ppur.fh) are updated.
 *
 * When vtoggle is 1 (true):
 * - The upper bits of TempAddr are updated with bits 3-7 of V, shifted appropriately.
 * - The PPU's vertical tile (ppur._vt) and fine vertical scroll (ppur._fv) are updated.
 *
 * After processing, the vtoggle flag is toggled to alternate between horizontal and vertical updates
 * on subsequent calls.
 *
 * @param V The input value written to the B2005 register.
 */
static DECLFW(B2005) {
	uint32 tmp = TempAddr;
	FCEUPPU_LineUpdate();
	PPUGenLatch = V;
	if (!vtoggle) {
		tmp &= 0xFFE0;
		tmp |= V >> 3;
		XOffset = V & 7;
		ppur._ht = V >> 3;
		ppur.fh = V & 7;
	} else {
		tmp &= 0x8C1F;
		tmp |= ((V & ~0x7) << 2);
		tmp |= (V & 7) << 12;
		ppur._vt = V >> 3;
		ppur._fv = V & 7;
	}
	TempAddr = tmp;
	vtoggle ^= 1;
}


/**
 * @brief Handles the B2006 memory write operation for the PPU (Picture Processing Unit).
 *
 * This method is responsible for updating the PPU's internal state based on the value written
 * to the B2006 address. It manages the toggling of the `vtoggle` flag to determine whether
 * the high or low byte of the address is being written. The method updates the `TempAddr`
 * and `ppur` (PPU registers) based on the value `V` and the current state of `vtoggle`.
 *
 * When `vtoggle` is 0, the method processes the high byte of the address, updating the
 * `TempAddr` and `ppur` registers with the appropriate bits from `V`. Specifically, it
 * updates the vertical tile index (`ppur._vt`), horizontal and vertical scroll bits
 * (`ppur._h`, `ppur._v`), and fine vertical scroll bits (`ppur._fv`).
 *
 * When `vtoggle` is 1, the method processes the low byte of the address, updating the
 * `TempAddr` and `ppur` registers accordingly. It also sets the `RefreshAddr` to the
 * updated `TempAddr`, triggers a dummy read, and calls the `PPU_hook` callback if it is
 * defined. Additionally, it updates the vertical tile index (`ppur._vt`) and horizontal
 * tile index (`ppur._ht`) and installs the latches in the `ppur` register.
 *
 * Finally, the method toggles the `vtoggle` flag to switch between processing the high
 * and low bytes of the address in subsequent calls.
 *
 * @param V The value being written to the B2006 address.
 */
static DECLFW(B2006) {
	FCEUPPU_LineUpdate();

	PPUGenLatch = V;
	if (!vtoggle) {
		TempAddr &= 0x00FF;
		TempAddr |= (V & 0x3f) << 8;

		ppur._vt &= 0x07;
		ppur._vt |= (V & 0x3) << 3;
		ppur._h = (V >> 2) & 1;
		ppur._v = (V >> 3) & 1;
		ppur._fv = (V >> 4) & 3;
	} else {
		TempAddr &= 0xFF00;
		TempAddr |= V;

		RefreshAddr = TempAddr;
		DummyRead = 1;
		if (PPU_hook)
			PPU_hook(RefreshAddr);

		ppur._vt &= 0x18;
		ppur._vt |= (V >> 5);
		ppur._ht = V & 31;

		ppur.install_latches();
	}

	vtoggle ^= 1;
}

/**
 * @brief Handles the PPU (Picture Processing Unit) write operation for address 0x2007.
 *
 * This method processes the write operation to the PPU's address 0x2007, which is used to write data to the PPU's memory.
 * The behavior of this method depends on whether the new PPU or the old PPU is being used, as well as the current state of the PPU.
 *
 * If debug logging is enabled, the method logs the video data if certain conditions are met.
 *
 * For the new PPU:
 * - The PPUGenLatch is updated with the provided value `V`.
 * - The RefreshAddr is updated based on the PPU's current state.
 * - The PPU's memory is updated by calling the appropriate write function.
 * - The PPU's address is incremented based on the current scanline and PPU state.
 *
 * For the old PPU:
 * - The PPUGenLatch is updated with the provided value `V`.
 * - Depending on the address being written to, the method updates different parts of the PPU's memory:
 *   - If the address is within the CHR RAM range, the CHR RAM is updated.
 *   - If the address is within the NT RAM range, the NT RAM is updated.
 *   - If the address is within the palette RAM range, the palette RAM is updated.
 * - The RefreshAddr is incremented based on the INC32 flag.
 * - If a PPU hook is registered, it is called with the updated address.
 *
 * @param V The value to be written to the PPU's memory.
 */
static DECLFW(B2007) {
	uint32 tmp = RefreshAddr & 0x3FFF;

	if (debug_loggingCD) {
		if(!cdloggerVideoDataSize && (tmp < 0x2000))
			cdloggervdata[tmp] = 0;
	}

	if (newppu) {
		PPUGenLatch = V;
		RefreshAddr = ppur.get_2007access() & 0x3FFF;
		CALL_PPUWRITE(RefreshAddr, V);
		ppur.increment2007(ppur.status.sl >= 0 && ppur.status.sl < 241 && PPUON, INC32 != 0);
		RefreshAddr = ppur.get_2007access();
	} else {
		PPUGenLatch = V;
		if (tmp < 0x2000) {
			if (PPUCHRRAM & (1 << (tmp >> 10)))
				VPage[tmp >> 10][tmp] = V;
		} else if (tmp < 0x3F00) {
			if (QTAIHack && (qtaintramreg & 1)) {
				QTAINTRAM[((((tmp & 0xF00) >> 10) >> ((qtaintramreg >> 1)) & 1) << 10) | (tmp & 0x3FF)] = V;
			} else {
				if (PPUNTARAM & (1 << ((tmp & 0xF00) >> 10)))
					vnapage[((tmp & 0xF00) >> 10)][tmp & 0x3FF] = V;
			}
		} else {
			if (!(tmp & 3)) {
				if (!(tmp & 0xC)) {
					PALRAM[0x00] = PALRAM[0x04] = PALRAM[0x08] = PALRAM[0x0C] = V & 0x3F;
					PALcache_outdate = 1;
        }
				else
					UPALRAM[((tmp & 0xC) >> 2) - 1] = V & 0x3F;
			} else {
				PALRAM[tmp & 0x1F] = V & 0x3F;
				PALcache_outdate = 1;
      }
		}
		if (INC32)
			RefreshAddr += 32;
		else
			RefreshAddr++;
		if (PPU_hook)
			PPU_hook(RefreshAddr & 0x3fff);
	}
}

/**
 * @brief Performs a DMA (Direct Memory Access) transfer for sprite data.
 *
 * This method reads 256 bytes of data from the memory location specified by the
 * calculated address (t + x) and writes them to the PPU's OAM (Object Attribute Memory)
 * starting at address 0x2004. The base address for the transfer is determined by
 * shifting the input value V left by 8 bits (V << 8). After the transfer, the
 * SpriteDMA variable is updated with the value of V.
 *
 * @param V The input value used to calculate the base address for the DMA transfer.
 */
static DECLFW(B4014) {
	uint32 t = V << 8;
	int x;

	for (x = 0; x < 256; x++)
		X6502_DMW(0x2004, X6502_DMR(t + x));
	SpriteDMA = V;
}

#define PAL(c)  ((c) + cc)

#define GETLASTPIXEL    (PAL ? ((timestamp * 48 - linestartts) / 15) : ((timestamp * 48 - linestartts) >> 4))

static uint8 *Pline, *Plinef;
static int firsttile;
int linestartts;	//no longer static so the debugger can see it
static int tofix = 0;

/**
 * @brief Resets the rendering line (RL) buffer and initializes related variables.
 *
 * This method performs the following operations:
 * 1. Fills the target buffer with 0xFF values using memset, effectively clearing it.
 * 2. Sets the global pointers `Plinef` and `Pline` to point to the target buffer.
 * 3. Resets `firsttile` to 0, indicating the start of the rendering process.
 * 4. Calculates and sets `linestartts` based on the current `timestamp` and `X.count`.
 * 5. Sets `tofix` to 0, indicating that the line is not yet fixed.
 * 6. Calls `FCEUPPU_LineUpdate()` to update the PPU (Picture Processing Unit) line.
 * 7. Sets `tofix` to 1, indicating that the line is now fixed.
 *
 * @param target A pointer to the buffer that will be reset and used for rendering.
 */
static void ResetRL(uint8 *target) {
	memset(target, 0xFF, 256);
	Plinef = target;
	Pline = target;
	firsttile = 0;
	linestartts = timestamp * 48 + X.count;
	tofix = 0;
	FCEUPPU_LineUpdate();
	tofix = 1;
}

static uint8 sprlinebuf[256 + 8];

/**
 * @brief Updates the PPU (Picture Processing Unit) line based on the current state.
 *
 * This method checks if the new PPU is active. If the new PPU is active, the method
 * immediately returns without performing any further actions. If the new PPU is not
 * active and the `Pline` pointer is valid, it retrieves the last pixel position using
 * the `GETLASTPIXEL` macro and calls the `RefreshLine` function to refresh the line
 * at the specified pixel position.
 *
 * @note This function is typically used in emulators to handle PPU line updates
 * during rendering cycles.
 */
void FCEUPPU_LineUpdate(void) {
	if (newppu)
		return;

	if (Pline) {
		int l = GETLASTPIXEL;
		RefreshLine(l);
	}
}

static bool rendersprites = true, renderbg = true;

/**
 * @brief Sets the rendering planes for the FCEUI (FCE Ultra Interface).
 * 
 * This method allows the user to enable or disable the rendering of sprites and
 * background layers in the FCEUI. By setting the corresponding boolean parameters,
 * the method updates the internal state of the rendering engine to reflect whether
 * sprites and/or background layers should be rendered.
 * 
 * @param sprites A boolean value indicating whether sprites should be rendered.
 *                If true, sprites will be rendered; if false, they will not.
 * @param bg      A boolean value indicating whether background layers should be rendered.
 *                If true, background layers will be rendered; if false, they will not.
 */
void FCEUI_SetRenderPlanes(bool sprites, bool bg) {
	rendersprites = sprites;
	renderbg = bg;
}

/**
 * @brief Retrieves the current rendering state of sprites and background planes.
 *
 * This method queries the current rendering settings for the sprites and background planes
 * and assigns the values to the provided boolean references. The method does not modify
 * the internal state of the rendering system but only provides a way to inspect the current
 * configuration.
 *
 * @param sprites Reference to a boolean variable that will be set to the current rendering
 *                state of the sprites. `true` indicates that sprites are being rendered,
 *                `false` otherwise.
 * @param bg Reference to a boolean variable that will be set to the current rendering
 *           state of the background planes. `true` indicates that the background is being
 *           rendered, `false` otherwise.
 */
void FCEUI_GetRenderPlanes(bool& sprites, bool& bg) {
	sprites = rendersprites;
	bg = renderbg;
}

static void CheckSpriteHit(int p);

/**
 * @brief Finalizes the rendering process for a specific line (line 272).
 * 
 * This method performs the following steps:
 * 1. Refreshes the specified line (line 272) to update its visual state.
 * 2. If the `tofix` flag is set, it calls the `Fixit1()` method to apply necessary corrections.
 * 3. Checks for sprite collisions or hits on the specified line (line 272).
 * 4. Resets the `Pline` variable to 0, indicating the end of the rendering process for the current line.
 */
static void EndRL(void) {
	RefreshLine(272);
	if (tofix)
		Fixit1();
	CheckSpriteHit(272);
	Pline = 0;
}

static int32 sphitx;
static uint8 sphitdata;

/**
 * @brief Checks for a collision between a sprite and the background or other sprites.
 * 
 * This method iterates over a range of horizontal positions (from `sphitx` to `sphitx + 8`)
 * and checks if there is a collision between the sprite and the background or other sprites.
 * If a collision is detected, the PPU status flag is updated to indicate the collision,
 * and the sprite hit position (`sphitx`) is set to `0x100` to prevent further checks.
 * 
 * @param p The horizontal position to check against, typically representing the sprite's position.
 */
static void CheckSpriteHit(int p) {
	int l = p - 16;
	int x;

	if (sphitx == 0x100) return;

	for (x = sphitx; x < (sphitx + 8) && x < l; x++) {
		if ((sphitdata & (0x80 >> (x - sphitx))) && !(Plinef[x] & 64) && x < 255) {
			PPU_status |= 0x40;
			sphitx = 0x100;
			break;
		}
	}
}

//spork the world.  Any sprites on this line? Then this will be set to 1.
//Needed for zapper emulation and *gasp* sprite emulation.
static int spork = 0;

// lasttile is really "second to last tile."
static void RefreshLine(int lastpixel) {
	static uint32 pshift[2];
	static uint32 atlatch;
	uint32 smorkus = RefreshAddr;

	#define RefreshAddr smorkus
	uint32 vofs;
	int X1;

	uint8 *P = Pline;
	int lasttile = lastpixel >> 3;
	int numtiles;

	if (sphitx != 0x100 && !(PPU_status & 0x40)) {
		if ((sphitx < (lastpixel - 16)) && !(sphitx < ((lasttile - 2) * 8)))
			lasttile++;
	}

	if (lasttile > 34) lasttile = 34;
	numtiles = lasttile - firsttile;

	if (numtiles <= 0) return;

	P = Pline;

  assert(!PPU_hook);
  assert(!PEC586Hack);
  assert(!MMC5Hack);
  assert(!QTAIHack);

  vofs = ((PPU[0] & 0x10) << 8) | ((RefreshAddr >> 12) & 7);

	uint8_t tem8 = READPAL(0) | 0x40;
	if (!ScreenON && !SpriteON) {
		memset(Pline, tem8, numtiles * 8);
		P += numtiles * 8;
		Pline = P;

		firsttile = lasttile;

		#define TOFIXNUM (272 - 0x4)
		if (lastpixel >= TOFIXNUM && tofix) {
			tofix = 0;
		}
		return;
	}

  update_PALcache();
  uint32 cc = 0;
  uint8 cc2;
  uint8 *C0 = vnapage[(RefreshAddr >> 10) & 3];
  if (RefreshAddr % 4 != 0) {
    uint8 zz = RefreshAddr >> 2;
    cc = (C0[0x3c0 | (zz & 0x7) | ((zz >> 2) & 0x38)] << 2) >> ((zz >> 2) & 0x4);
  }
  for (X1 = firsttile; X1 < lasttile; X1++) {
#include "pputile.inc"
  }

#undef RefreshAddr

	RefreshAddr = smorkus;
	if (firsttile <= 2 && 2 < lasttile && !(PPU[1] & 2)) {
		uint32 tem = tem8 | (tem8 << 8) | (tem8 << 16) | (tem8 << 24);
		*(uint32*)Plinef = *(uint32*)(Plinef + 4) = tem;
	}

	if (!ScreenON) {
		int tstart, tcount;

		tcount = lasttile - firsttile;
		tstart = firsttile - 2;
		if (tstart < 0) {
			tcount += tstart;
			tstart = 0;
		}
		if (tcount > 0)
			memset(Plinef + tstart * 8, tem8, tcount * 8);
	}

	if (lastpixel >= TOFIXNUM && tofix) {
		Fixit1();
		tofix = 0;
	}

	//This only works right because of a hack earlier in this function.
	CheckSpriteHit(lastpixel);

	Pline = P;
	firsttile = lasttile;
}

/**
 * @brief Adjusts the refresh address based on the current screen and sprite states.
 *
 * This method modifies the `RefreshAddr` by combining specific bits from the current `RefreshAddr`
 * and `TempAddr`. The operation is performed only if either `ScreenON` or `SpriteON` is true.
 * 
 * The method performs the following steps:
 * 1. Checks if either `ScreenON` or `SpriteON` is true.
 * 2. If true, it masks the `RefreshAddr` with `0xFBE0` to clear specific bits.
 * 3. It then combines the masked `RefreshAddr` with the lower 11 bits of `TempAddr` (masked with `0x041F`).
 * 4. The result is stored back into `RefreshAddr`.
 *
 * This operation ensures that the `RefreshAddr` is updated with the correct bits from `TempAddr`
 * while preserving the necessary bits from the original `RefreshAddr`.
 */
static INLINE void Fixit2(void) {
	if (ScreenON || SpriteON) {
		uint32 rad = RefreshAddr;
		rad &= 0xFBE0;
		rad |= TempAddr & 0x041f;
		RefreshAddr = rad;
	}
}

/**
 * @brief Adjusts the refresh address (`RefreshAddr`) based on certain conditions.
 *
 * This method modifies the `RefreshAddr` value if either `ScreenON` or `SpriteON` is true.
 * The adjustment depends on the current value of `RefreshAddr`:
 * - If the upper 3 bits of `RefreshAddr` (bits 12-14) are all set (0x7000), it toggles these bits
 *   and further adjusts the address based on the middle 5 bits (bits 5-9):
 *   - If the middle 5 bits are 0x3A0, it toggles bits 5-9 and 11.
 *   - If the middle 5 bits are 0x3E0, it toggles bits 5-9.
 *   - Otherwise, it increments the address by 0x20.
 * - If the upper 3 bits are not all set, it increments the address by 0x1000.
 * The modified address is then stored back into `RefreshAddr`.
 */
static void Fixit1(void) {
	if (ScreenON || SpriteON) {
		uint32 rad = RefreshAddr;

		if ((rad & 0x7000) == 0x7000) {
			rad ^= 0x7000;
			if ((rad & 0x3E0) == 0x3A0)
				rad ^= 0xBA0;
			else if ((rad & 0x3E0) == 0x3e0)
				rad ^= 0x3e0;
			else
				rad += 0x20;
		} else
			rad += 0x1000;
		RefreshAddr = rad;
	}
}

void MMC5_hb(int);		//Ugh ugh ugh.
static void DoLine(void) {
	if (scanline >= 240 && scanline != totalscanlines) {
		X6502_Run(256 + 69);
		scanline++;
		X6502_Run(16);
		return;
	}

	int x;
	uint32 *target = (uint32 *)(XBuf + ((scanline < 240 ? scanline : 240) << 8));
	//u8* dtarget = XDBuf + ((scanline < 240 ? scanline : 240) << 8);

	if (MMC5Hack) MMC5_hb(scanline);

	X6502_Run(256);
	EndRL();

	if (!renderbg) {// User asked to not display background data.
		uint8 col;
		if (gNoBGFillColor == 0xFF)
			col = READPAL(0);
		else col = gNoBGFillColor;
		uint8 tem8 = col | 0x40;
		memset(target, tem8, 256);
	}

	if (SpriteON)
		CopySprites((uint8 *)target);

	//greyscale handling (mask some bits off the color) ? ? ?
	if (ScreenON || SpriteON)
	{
		if (PPU[1] & 0x01) {
			for (x = 63; x >= 0; x--)
				target[x] &= 0x30303030;
		}
	}

	//some pathetic attempts at deemph
	if ((PPU[1] >> 5) == 0x7) {
		for (x = 63; x >= 0; x--)
			target[x] |= 0xc0c0c0c0;
	} else if (PPU[1] & 0xE0)
		for (x = 63; x >= 0; x--)
			target[x] |= 0x40404040;
	else
		for (x = 63; x >= 0; x--)
			target[x] = (target[x] & 0x3f3f3f3f) | 0x80808080;

	//write the actual deemph
	//for (x = 63; x >= 0; x--)
	//	*(uint32*)&dtarget[x << 2] = ((PPU[1]>>5)<<0)|((PPU[1]>>5)<<8)|((PPU[1]>>5)<<16)|((PPU[1]>>5)<<24);

	sphitx = 0x100;

	if (ScreenON || SpriteON)
		FetchSpriteData();

	if (GameHBIRQHook && (ScreenON || SpriteON) && ((PPU[0] & 0x38) != 0x18)) {
		X6502_Run(6);
		Fixit2();
		X6502_Run(4);
		GameHBIRQHook();
		X6502_Run(85 - 16 - 10);
	} else {
		X6502_Run(6);	// Tried 65, caused problems with Slalom(maybe others)
		Fixit2();
		X6502_Run(85 - 6 - 16);

		// A semi-hack for Star Trek: 25th Anniversary
		if (GameHBIRQHook && (ScreenON || SpriteON) && ((PPU[0] & 0x38) != 0x18))
			GameHBIRQHook();
	}

	DEBUG(FCEUD_UpdateNTView(scanline, 0));

	if (SpriteON)
		RefreshSprites();
	if (GameHBIRQHook2 && (ScreenON || SpriteON))
		GameHBIRQHook2();
	scanline++;
	if (scanline < 240) {
		ResetRL(XBuf + (scanline << 8));
	}
	X6502_Run(16);
}

#define V_FLIP  0x80
#define H_FLIP  0x40
#define SP_BACK 0x20

typedef struct {
	uint8 y, no, atr, x;
} SPR;

typedef struct {
	uint8 ca[2], atr, x;
} SPRB;

/**
 * @brief Disables or enables the sprite limitation based on the provided parameter.
 * 
 * This method adjusts the maximum number of sprites that can be displayed simultaneously.
 * If the parameter `a` is non-zero, the sprite limitation is disabled, allowing up to 64 sprites.
 * If `a` is zero, the sprite limitation is enabled, restricting the number of sprites to 8.
 * 
 * @param a An integer flag that determines whether to disable (non-zero) or enable (zero) the sprite limitation.
 */
void FCEUI_DisableSpriteLimitation(int a) {
	maxsprites = a ? 64 : 8;
}

static uint8 numsprites, SpriteBlurp;
/**
 * @brief Fetches sprite data for rendering during a scanline.
 *
 * This method processes sprite data stored in SPRAM (Sprite RAM) and prepares it for rendering.
 * It iterates through the sprite list, checks if each sprite is visible on the current scanline,
 * and fetches the corresponding sprite pattern data from VRAM (Video RAM). The method handles
 * both 8x8 and 8x16 sprite sizes, vertical flipping, and sprite priority. It also manages sprite
 * overflow by setting the appropriate PPU status flags when more than the maximum allowed sprites
 * are encountered on a scanline. Additionally, it supports custom hooks for advanced rendering
 * techniques or debugging purposes.
 *
 * The method updates the sprite buffer (SPRBUF) with the fetched sprite data and sets the number
 * of sprites (numsprites) and the sprite blurp flag (SpriteBlurp) for further processing by the
 * rendering engine.
 *
 * @note This method assumes that the PPU registers and VRAM are properly initialized and accessible.
 * It also relies on external hooks (PPU_hook) for custom behavior during sprite fetching.
 */
static void FetchSpriteData(void) {
	uint8 ns, sb;
	SPR *spr;
	uint8 H;
	int n;
	int vofs;
	uint8 P0 = PPU[0];

	spr = (SPR*)SPRAM;
	H = 8;

	ns = sb = 0;

	vofs = (uint32)(P0 & 0x8 & (((P0 & 0x20) ^ 0x20) >> 2)) << 9;
	H += (P0 & 0x20) >> 2;

	if (!PPU_hook)
		for (n = 63; n >= 0; n--, spr++) {
			if ((uint32)(scanline - spr->y) >= H) continue;
			if (ns < maxsprites) {
				if (n == 63) sb = 1;

				{
					SPRB dst;
					uint8 *C;
					int t;
					uint32 vadr;

					t = (int)scanline - (spr->y);

					if (Sprite16)
						vadr = ((spr->no & 1) << 12) + ((spr->no & 0xFE) << 4);
					else
						vadr = (spr->no << 4) + vofs;

					if (spr->atr & V_FLIP) {
						vadr += 7;
						vadr -= t;
						vadr += (P0 & 0x20) >> 1;
						vadr -= t & 8;
					} else {
						vadr += t;
						vadr += t & 8;
					}

					/* Fix this geniestage hack */
					if (MMC5Hack)
						C = MMC5SPRVRAMADR(vadr);
					else
						C = VRAMADR(vadr);

					if (SpriteON)
						RENDER_LOGP(C);
					dst.ca[0] = C[0];
					if (SpriteON)
						RENDER_LOGP(C + 8);
					dst.ca[1] = C[8];
					dst.x = spr->x;
					dst.atr = spr->atr;

					*(uint32*)&SPRBUF[ns << 2] = *(uint32*)&dst;
				}

				ns++;
			} else {
				PPU_status |= 0x20;
				break;
			}
		}
	else
		for (n = 63; n >= 0; n--, spr++) {
			if ((uint32)(scanline - spr->y) >= H) continue;

			if (ns < maxsprites) {
				if (n == 63) sb = 1;

				{
					SPRB dst;
					uint8 *C;
					int t;
					uint32 vadr;

					t = (int)scanline - (spr->y);

					if (Sprite16)
						vadr = ((spr->no & 1) << 12) + ((spr->no & 0xFE) << 4);
					else
						vadr = (spr->no << 4) + vofs;

					if (spr->atr & V_FLIP) {
						vadr += 7;
						vadr -= t;
						vadr += (P0 & 0x20) >> 1;
						vadr -= t & 8;
					} else {
						vadr += t;
						vadr += t & 8;
					}

					if (MMC5Hack)
						C = MMC5SPRVRAMADR(vadr);
					else
						C = VRAMADR(vadr);
					if (SpriteON)
						RENDER_LOGP(C);
					dst.ca[0] = C[0];
					if (ns < 8) {
						PPU_hook(0x2000);
						PPU_hook(vadr);
					}
					if (SpriteON)
						RENDER_LOGP(C + 8);
					dst.ca[1] = C[8];
					dst.x = spr->x;
					dst.atr = spr->atr;


					*(uint32*)&SPRBUF[ns << 2] = *(uint32*)&dst;
				}

				ns++;
			} else {
				PPU_status |= 0x20;
				break;
			}
		}

	//Handle case when >8 sprites per scanline option is enabled.
	if (ns > 8) PPU_status |= 0x20;
	else if (PPU_hook) {
		for (n = 0; n < (8 - ns); n++) {
			PPU_hook(0x2000);
			PPU_hook(vofs);
		}
	}
	numsprites = ns;
	SpriteBlurp = sb;
}

/**
 * @brief Refreshes the sprites by updating their pixel data in the sprite line buffer.
 *
 * This method iterates through the sprite buffer in reverse order, starting from the last sprite.
 * For each sprite, it calculates the pixel data based on the sprite's attributes and character data.
 * The pixel data is then written to the sprite line buffer (`sprlinebuf`) at the sprite's x-coordinate.
 * The method handles various sprite attributes such as horizontal flipping (`H_FLIP`) and background
 * priority (`SP_BACK`). Additionally, it updates the sprite hit detection data (`sphitx` and `sphitdata`)
 * if the sprite is the first one and certain conditions are met. Finally, it resets the `SpriteBlurp` flag
 * and sets the `spork` flag to indicate that the sprite refresh is complete.
 */
static void RefreshSprites(void) {
	int n;
	SPRB *spr;

	spork = 0;
	if (!numsprites) return;

	memset(sprlinebuf, 0x80, 256);
	numsprites--;
	spr = (SPRB*)SPRBUF + numsprites;

	for (n = numsprites; n >= 0; n--, spr--) {
		uint32 pixdata;
		uint8 J, atr;

		int x = spr->x;
		uint8 *C;
		int VB;

		pixdata = ppulut1[spr->ca[0]] | ppulut2[spr->ca[1]];
		J = spr->ca[0] | spr->ca[1];
		atr = spr->atr;

		if (J) {
			if (n == 0 && SpriteBlurp && !(PPU_status & 0x40)) {
				sphitx = x;
				sphitdata = J;
				if (atr & H_FLIP)
					sphitdata = ((J << 7) & 0x80) |
								((J << 5) & 0x40) |
								((J << 3) & 0x20) |
								((J << 1) & 0x10) |
								((J >> 1) & 0x08) |
								((J >> 3) & 0x04) |
								((J >> 5) & 0x02) |
								((J >> 7) & 0x01);
			}

			C = sprlinebuf + x;
			VB = (0x10) + ((atr & 3) << 2);

			if (atr & SP_BACK) {
				if (atr & H_FLIP) {
					if (J & 0x80) C[7] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x40) C[6] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x20) C[5] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x10) C[4] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x08) C[3] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x04) C[2] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x02) C[1] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x01) C[极] = READPAL(VB | pixdata) | 0x40;
				} else {
					if (J & 0x80) C[0] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x40) C[1] = READ极AL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x20) C[2] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x10) C[3] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x08) C[4] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x04) C[5] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x02) C[6] = READPAL(VB | (pixdata & 3)) | 0x40;
					pixdata >>= 4;
					if (J & 0x01) C[7] = READPAL(VB | pixdata) | 0x40;
				}
			} else {
				if (atr & H_FLIP) {
					if (J & 0x80) C[7] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x40) C[6] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x20) C[5] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x10) C[4] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x08) C[3] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x04) C[2] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x02) C[1] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x01) C[0] = READPAL(VB | pixdata);
				} else {
					if (J & 0x80) C[0] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x40) C[1] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x20) C[2] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x10) C[3] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x08) C[4] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x04) C[5] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x02) C[6] = READPAL(VB | (pixdata & 3));
					pixdata >>= 4;
					if (J & 0x01) C[7] = READPAL(VB | pixdata);
				}
			}
		}
	}
	SpriteBlurp = 0;
	spork = 1;
}

/**
 * @brief Copies sprite data to the target buffer based on specific conditions.
 *
 * This method iterates over the sprite line buffer and copies sprite data to the target buffer
 * if certain conditions are met. The method first checks if the `spork` flag is set; if not, it exits early.
 * The `spork` flag is then reset to 0. Next, it checks if the `rendersprites` flag is set, which indicates
 * whether the user has requested to display sprites. If not, the method exits. Finally, it checks if the
 * `SpriteON` flag is set. If all conditions are satisfied, the method iterates over the sprite line buffer
 * and copies each sprite pixel to the target buffer if the pixel is not marked as transparent (0x80) and
 * either it is a normal sprite or it is a behind-background sprite and the corresponding pixel in the
 * target buffer is also a behind-background sprite.
 *
 * @param target A pointer to the target buffer where the sprite data will be copied.
 */
static void CopySprites(uint8 *target) {
	uint8 *P = target;

	if (!spork) return;
	spork = 0;

	if (!rendersprites) return;	//User asked to not display sprites.

	if(!SpriteON) return;
	for(int i=0;i<256;i++)
	{
		uint8 t = sprlinebuf[i];
		if(!(t&0x80))
			if (!(t & 0x40) || (P[i] & 0x40))		// Normal sprite || behind bg sprite
				P[i] = t;
	}
}

/**
 * @brief Sets the video system configuration based on the specified parameter.
 *
 * This method configures the video system settings, including the number of scanlines per frame
 * and the first and last visible scanlines. The configuration depends on the value of the input
 * parameter `w`:
 * - If `w` is non-zero, the method sets the video system to a Dendy or PAL configuration. 
 *   The number of scanlines per frame is set to 262 for Dendy or 312 for PAL, and the first
 *   and last visible scanlines are set to the user-defined values for the second configuration.
 * - If `w` is zero, the method sets the video system to an NTSC configuration. The number of
 *   scanlines per frame is set to 262, and the first and last visible scanlines are set to the
 *   user-defined values for the first configuration.
 *
 * @param w An integer flag that determines the video system configuration. 
 *          Non-zero for Dendy/PAL, zero for NTSC.
 */
void FCEUPPU_SetVideoSystem(int w) {
	if (w) {
		scanlines_per_frame = dendy ? 262: 312;
		FSettings.FirstSLine = FSettings.UsrFirstSLine[1];
		FSettings.LastSLine = FSettings.UsrLastSLine[1];
		//paldeemphswap = 1; // dendy has pal ppu, and pal ppu has these swapped
	} else {
		scanlines_per_frame = 262;
		FSettings.FirstSLine = FSettings.UsrFirstSLine[0];
		FSettings.LastSLine = FSettings.UsrLastSLine[0];
		//paldeemphswap = 0;
	}
}

//Initializes the PPU
void FCEUPPU_Init(void) {
	makeppulut();
}

/**
 * @brief Resets the PPU (Picture Processing Unit) read hooks to their default implementation.
 *
 * This method sets the `FFCEUX_PPURead` function pointer to the default PPU read handler,
 * `FFCEUX_PPURead_Default`. This is typically used to restore the original behavior of
 * the PPU read operations after custom hooks or modifications have been applied.
 */
void PPU_ResetHooks() {
	FFCEUX_PPURead = FFCEUX_PPURead_Default;
}

/**
 * @brief Resets the PPU (Picture Processing Unit) state to its initial configuration.
 *
 * This method initializes or resets various PPU-related registers, buffers, and flags
 * to their default values. It is typically called during system reset or when the emulator
 * needs to restart the PPU state. The method ensures that the PPU is in a clean state,
 * ready to begin processing a new frame. Key actions include:
 * - Clearing the VRAM buffer and PPU registers (PPU[0], PPU[1], PPU_status, PPU[3]).
 * - Resetting the PPU sprite latch (PPUSPL) and general latch (PPUGenLatch).
 * - Setting the refresh and temporary addresses (RefreshAddr, TempAddr) to zero.
 * - Resetting internal flags such as vtoggle, ppudead, kook, and idleSynch.
 * - Marking the PPU as ready for a new frame by setting `new_ppu_reset` to true.
 *
 * This reset ensures that the PPU starts from a known state, avoiding inconsistencies
 * or artifacts in rendering.
 */
void FCEUPPU_Reset(void) {
	VRAMBuffer = PPU[0] = PPU[1] = PPU_status = PPU[3] = 0;
	PPUSPL = 0;
	PPUGenLatch = 0;
	RefreshAddr = TempAddr = 0;
	vtoggle = 0;
	ppudead = 2;
	kook = 0;
	idleSynch = 1;

	new_ppu_reset = true; // delay reset of ppur/spr_read until it's ready to start a new frame
}

/**
 * @brief Initializes and powers up the PPU (Picture Processing Unit) for the FCEU emulator.
 *
 * This method performs the following operations:
 * 1. Clears the NTARAM (Name Table Attribute RAM) by setting all bytes to 0x00.
 * 2. Clears the PALRAM (Palette RAM) by setting all bytes to 0x00.
 * 3. Clears the UPALRAM (Universal Palette RAM) by setting all bytes to 0x00.
 * 4. Clears the SPRAM (Sprite RAM) by setting all bytes to 0x00.
 * 5. Resets the PPU to its initial state by calling FCEUPPU_Reset().
 * 6. Sets up read and write handlers for PPU registers in the memory range 0x2000 to 0x3FFF.
 *    Each register in this range is assigned specific read and write handlers (e.g., A200x, B2000, etc.).
 * 7. Sets up a write handler for the OAM DMA register at address 0x4014.
 *
 * This method is typically called during the emulator's initialization or when resetting the PPU.
 */
void FCEUPPU_Power(void) {
	int x;

	memset(NTARAM, 0x00, 0x800);
	memset(PALRAM, 0x00, 0x20);
	memset(UPALRAM, 0x00, 0x03);
	memset(SPRAM, 0x00, 0x100);
	FCEUPPU_Reset();

	for (x = 0x2000; x < 0x4000; x += 8) {
		SetOneReadHandler (x, A200x);
		SetOneWriteHandler(x, B2000);
		SetOneReadHandler (x + 1, A200x);
		SetOneWriteHandler(x + 1, B2001);
		SetOneReadHandler (x + 2, A2002);
		SetOneWriteHandler(x + 2, B2002);
		SetOneReadHandler (x + 3, A200x);
		SetOneWriteHandler(x + 3, B2003);
		SetOneReadHandler (x + 4, A2004);
		SetOneWriteHandler(x + 4, B2004);
		SetOneReadHandler (x + 5, A200x);
		SetOneWriteHandler(x + 5, B2005);
		SetOneReadHandler (x + 6, A200x);
		SetOneWriteHandler(x + 6, B2006);
		SetOneReadHandler (x + 7, A2007);
		SetOneWriteHandler(x + 7, B2007);
	}
	SetOneWriteHandler(0x4014, B4014);
}

/**
 * @brief Executes the PPU (Picture Processing Unit) loop for a single frame.
 *
 * This method handles the PPU operations for rendering a frame, including
 * managing scanlines, handling VBlank, and triggering NMI (Non-Maskable Interrupt)
 * when necessary. It also supports overclocking and various game-specific
 * behaviors, such as handling NSF (NES Sound Format) files and special cases
 * like Knight Rider. The method ensures proper timing and synchronization
 * between the PPU and CPU, and it updates the screen buffer and PPU state
 * accordingly.
 *
 * @param skip A flag indicating whether to skip rendering the current frame
 *             (used for frame skipping during emulation).
 * @return An integer representing the status or result of the PPU loop execution.
 */
int FCEUPPU_Loop(int skip) {
	if ((newppu) && (GameInfo->type != GIT_NSF)) {
		int FCEUX_PPU_Loop(int skip);
		return FCEUX_PPU_Loop(skip);
	}

	//Needed for Knight Rider, possibly others.
	if (ppudead) {
		memset(XBuf, 0x80, 256 * 240);
		X6502_Run(scanlines_per_frame * (256 + 85));
		ppudead--;
	} else {
		X6502_Run(256 + 85);
		PPU_status |= 0x80;

		//Not sure if this is correct.  According to Matt Conte and my own tests, it is.
		//Timing is probably off, though.
		//NOTE:  Not having this here breaks a Super Donkey Kong game.
		PPU[3] = PPUSPL = 0;

		//I need to figure out the true nature and length of this delay.
		X6502_Run(12);
		if (GameInfo->type == GIT_NSF) {
      assert(0);
    } else {
			if (VBlankON)
				TriggerNMI();
		}
		X6502_Run((scanlines_per_frame - 242) * (256 + 85) - 12);
		if (overclock_enabled && vblanksscanlines) {
			if (!DMC_7bit || !skip_7bit_overclocking) {
				overclocking = 1;
				X6502_Run(vblanksscanlines * (256 + 85) - 12);
				overclocking = 0;
			}
		}
		PPU_status &= 0x1f;
		X6502_Run(256);

		{
			int x;

			if (ScreenON || SpriteON) {
				if (GameHBIRQHook && ((PPU[0] & 0x38) != 0x18))
					GameHBIRQHook();
				if (PPU_hook)
					for (x = 0; x < 42; x++) {
						PPU_hook(0x2000); PPU_hook(0);
					}
				if (GameHBIRQHook2)
					GameHBIRQHook2();
			}
			X6502_Run(85 - 16);
			if (ScreenON || SpriteON) {
				RefreshAddr = TempAddr;
				if (PPU_hook) PPU_hook(RefreshAddr & 0x3fff);
			}

			//Clean this stuff up later.
			spork = numsprites = 0;
			ResetRL(XBuf);

			X6502_Run(16 - kook);
			kook ^= 1;
		}
		if (GameInfo->type == GIT_NSF)
			X6502_Run((256 + 85) * normalscanlines);
		#ifdef FRAMESKIP
		else if (skip) {
			int y;

			y = SPRAM[0];
			y++;

			PPU_status |= 0x20;	// Fixes "Bee 52".  Does it break anything?
			if (GameHBIRQHook) {
				X6502_Run(256);
				for (scanline = 0; scanline < 240; scanline++) {
					if (ScreenON || SpriteON)
						GameHBIRQHook();
					if (scanline == y && SpriteON) PPU_status |= 0x40;
					X6502_Run((scanline == 239) ? 85 : (256 + 85));
				}
			} else if (y < 240) {
				X6502_Run((256 + 85) * y);
				if (SpriteON) PPU_status |= 0x40;	// Quick and very dirty hack.
				X6502_Run((256 + 85) * (240 - y));
			} else
				X6502_Run((256 + 85) * 240);
		}
		#endif
		else {
			deemp = PPU[1] >> 5;

			// manual samples can't play correctly with overclocking
			if (DMC_7bit && skip_7bit_overclocking) // 7bit sample started before 240th line
				totalscanlines = normalscanlines;
			else
				totalscanlines = normalscanlines + (overclock_enabled ? postrenderscanlines : 0);

			for (scanline = 0; scanline < totalscanlines; ) {	//scanline is incremented in  DoLine.  Evil. :/
				deempcnt[deemp]++;
				if (scanline < 240)
					DEBUG(FCEUD_UpdatePPUView(scanline, 1));
				DoLine();

				if (scanline < normalscanlines || scanline == totalscanlines)
					overclocking = 0;
				else {
					if (DMC_7bit && skip_7bit_overclocking) // 7bit sample started after 240th line
						break;
					overclocking = 1;
				}
			}
			DMC_7bit = 0;

			if (MMC5Hack) MMC5_hb(scanline);

			//deemph nonsense, kept for complicated reasons (see SetNESDeemph_OldHacky implementation)
			int maxref = 0;
			for (int x = 1, max = 0; x < 7; x++) {
				if (deempcnt[x] > max) {
					max = deempcnt[x];
					maxref = x;
				}
				deempcnt[x] = 0;
			}
			SetNESDeemph_OldHacky(maxref, 0);
		}
	}
}	//else... to if(ppudead)

  ShowFPS();
	#ifdef FRAMESKIP
	if (skip) {
		return(0);
	} else
	#endif
	{
		return(1);
	}
}

int (*PPU_MASTER)(int skip) = FCEUPPU_Loop;

static uint16 TempAddrT, RefreshAddrT;

/**
 * @brief Loads the state of the PPU (Picture Processing Unit) by restoring the temporary and refresh addresses.
 * 
 * This method is typically used during state loading operations to restore the PPU's internal state
 * to a previously saved state. It sets the `TempAddr` and `RefreshAddr` to the values stored in 
 * `TempAddrT` and `RefreshAddrT`, respectively. This ensures that the PPU continues operation with 
 * the correct addresses after a state load.
 * 
 * @param version The version of the state being loaded. This parameter is currently unused but may be 
 *                utilized in future implementations to handle different state formats or versions.
 */
void FCEUPPU_LoadState(int version) {
	TempAddr = TempAddrT;
	RefreshAddr = RefreshAddrT;
}

SFORMAT FCEUPPU_STATEINFO[] = {
	{ NTARAM, 0x800, "NTAR" },
	{ PALRAM, 0x20, "PRAM" },
	{ SPRAM, 0x100, "SPRA" },
	{ PPU, 0x4, "PPUR" },
	{ &kook, 1, "KOOK" },
	{ &ppudead, 1, "DEAD" },
	{ &PPUSPL, 1, "PSPL" },
	{ &XOffset, 1, "XOFF" },
	{ &vtoggle, 1, "VTGL" },
	{ &RefreshAddrT, 2 | FCEUSTATE_RLSB, "RADD" },
	{ &TempAddrT, 2 | FCEUSTATE_RLSB, "TADD" },
	{ &VRAMBuffer, 1, "VBUF" },
	{ &PPUGenLatch, 1, "PGEN" },
	{ 0 }
};

SFORMAT FCEU_NEWPPU_STATEINFO[] = {
	{ &idleSynch, 1, "IDLS" },
	{ &spr_read.num, 4 | FCEUSTATE_RLSB, "SR_0" },
	{ &spr_read.count, 4 | FCEUSTATE_RLSB, "SR_1" },
	{ &spr_read.fetch, 4 | FCEUSTATE_RLSB, "SR_2" },
	{ &spr_read.found, 4 | FCEUSTATE_RLSB, "SR_3" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx0" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx1" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx2" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx3" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx4" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx5" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx6" },
	{ &spr_read.found_pos[0], 4 | FCEUSTATE_RLSB, "SRx7" },
	{ &spr_read.ret, 4 | FCEUSTATE_RLSB, "SR_4" },
	{ &spr_read.last, 4 | FCEUSTATE_RLSB, "SR_5" },
	{ &spr_read.mode, 4 | FCEUSTATE_RLSB, "SR_6" },
	{ &ppur.fv, 4 | FCEUSTATE_RLSB, "PFVx" },
	{ &ppur.v, 4 | FCEUSTATE_RLSB, "PVxx" },
	{ &ppur.h, 4 | FCEUSTATE_RLSB, "PHxx" },
	{ &ppur.vt, 4 | FCEUSTATE_RLSB, "PVTx" },
	{ &ppur.ht, 4 | FCEUSTATE_RLSB, "PHTx" },
	{ &ppur._fv, 4 | FCEUSTATE_RLSB, "P_FV" },
	{ &ppur._v, 4 | FCEUSTATE_RLSB, "P_Vx" },
	{ &ppur._h, 4 | FCEUSTATE_RLSB, "P_Hx" },
	{ &ppur._vt, 4 | FCEUSTATE_RLSB, "P_VT" },
	{ &ppur._ht, 4 | FCEUSTATE_RLSB, "P_HT" },
	{ &ppur.fh, 4 | FCEUSTATE_RLSB, "PFHx" },
	{ &ppur.s, 4 | FCEUSTATE_RLSB, "PSxx" },
	{ &ppur.status.sl, 4 | FCEUSTATE_RLSB, "PST0" },
	{ &ppur.status.cycle, 4 | FCEUSTATE_RLSB, "PST1" },
	{ &ppur.status.end_cycle, 4 | FCEUSTATE_RLSB, "PST2" },
	{ 0 }
};

/**
 * @brief Saves the current state of the PPU (Picture Processing Unit) by storing
 * the values of `TempAddr` and `RefreshAddr` into their respective temporary
 * variables `TempAddrT` and `RefreshAddrT`.
 *
 * This method is typically used during state-saving operations, such as when
 * creating a save state in an emulator. It ensures that the current PPU address
 * values are preserved and can be restored later.
 */
void FCEUPPU_SaveState(void) {
	TempAddrT = TempAddr;
	RefreshAddrT = RefreshAddr;
}

/**
 * @brief Retrieves the current address being accessed by the PPU (Picture Processing Unit).
 *
 * This method checks whether the new PPU implementation is active. If it is, the method returns
 * the address being accessed by the new PPU, masked to 14 bits (0x3FFF). If the new PPU is not active,
 * it returns the refresh address (RefreshAddr) masked to 14 bits. The masking ensures that the
 * returned address is within the valid range for PPU memory access.
 *
 * @return uint32 The 14-bit address being accessed by the PPU.
 */
uint32 FCEUPPU_PeekAddress()
{
	if (newppu)
	{
		return ppur.get_2007access() & 0x3FFF;
	}

	return RefreshAddr & 0x3FFF;
}

//---------------------
int pputime = 0;
int totpputime = 0;
const int kLineTime = 341;
const int kFetchTime = 2;

/**
 * @brief Advances the PPU (Picture Processing Unit) by a specified number of cycles.
 *
 * This method updates the PPU's cycle counter by incrementing it by the given number of cycles (`x`), 
 * wrapping around if it exceeds the end cycle value (`ppur.status.end_cycle`). If the PPU is not in the 
 * process of being reset (`new_ppu_reset` is false), it also runs the CPU for the same number of cycles 
 * by calling `X6502_Run(x)`. This ensures synchronization between the PPU and CPU when the PPU is not 
 * in a reset state.
 *
 * @param x The number of cycles to advance the PPU.
 */
void runppu(int x) {
	ppur.status.cycle = (ppur.status.cycle + x) % ppur.status.end_cycle;
	if (!new_ppu_reset) // if resetting, suspend CPU until the first frame
	{
		X6502_Run(x);
	}
}

//todo - consider making this a 3 or 4 slot fifo to keep from touching so much memory
struct BGData {
	struct Record {
		uint8 nt, pecnt, at, pt[2], qtnt;

		/**
		 * @brief Performs a read operation for the PPU (Picture Processing Unit) during a rendering cycle.
		 * 
		 * This method handles the fetching of data from various PPU memory regions, including the nametable,
		 * attribute table, and pattern table. It also manages the PPU's internal state, such as the refresh
		 * address, scroll counters, and palette shifts. The method supports specific hardware hacks (PEC586Hack
		 * and QTAIHack) that modify the behavior of the PPU during the read operation. Additionally, it updates
		 * the PPU's internal counters and triggers rendering logs if the screen is active.
		 * 
		 * The method performs the following steps:
		 * 1. Fetches data from the nametable and updates the refresh address.
		 * 2. Applies hardware-specific hacks (PEC586Hack or QTAIHack) to modify the fetched data.
		 * 3. Fetches data from the attribute table and adjusts the palette shift based on scroll values.
		 * 4. Increments the horizontal and vertical scroll counters if the PPU is active.
		 * 5. Fetches data from the pattern table, applying hardware-specific hacks if necessary.
		 * 6. Logs rendering data if the screen is active.
		 * 
		 * @note This method is inlined for performance optimization.
		 */
		INLINE void Read() {
					NTRefreshAddr = RefreshAddr = ppur.get_ntread();
					if (PEC586Hack)
						ppur.s = (RefreshAddr & 0x200) >> 9;
					else if (QTAIHack) {
						qtnt = QTAINTRAM[((((RefreshAddr >> 10) & 3) >> ((qtaintramreg >> 1)) & 1) << 10) | (RefreshAddr & 0x3FF)];
						ppur.s = qtnt & 0x3F;
					}
					pecnt = (RefreshAddr & 1) << 3;
					nt = CALL_PPUREAD(RefreshAddr);
					runppu(kFetchTime);
		
					RefreshAddr = ppur.get_atread();
					at = CALL_PPUREAD(RefreshAddr);
		
					//modify at to get appropriate palette shift
					if (ppur.vt & 2) at >>= 4;
					if (ppur.ht & 2) at >>= 2;
					at &= 0x03;
					at <<= 2;
					//horizontal scroll clocked at cycle 3 and then
					//vertical scroll at 251
					runppu(1);
					if (PPUON) {
						ppur.increment_hsc();
						if (ppur.status.cycle == 251)
							ppur.increment_vs();
					}
					runppu(1);
		
					ppur.par = nt;
					RefreshAddr = ppur.get_ptread();
					if (PEC586Hack) {
						pt[0] = CALL_PPUREAD(RefreshAddr | pecnt);
						runppu(kFetchTime);
						pt[1] = CALL_PPUREAD(RefreshAddr | pecnt);
						runppu(kFetchTime);
					} else if (QTAIHack && (qtnt & 0x40)) {
						pt[0] = *(CHRptr[0] + RefreshAddr);
						runppu(kFetchTime);
						RefreshAddr |= 8;
						pt[1] = *(CHRptr[0] + RefreshAddr);
						runppu(kFetchTime);
					} else {
						if (ScreenON)
							RENDER_LOG(RefreshAddr);
						pt[0] = CALL_PPUREAD(RefreshAddr);
						runppu(kFetchTime);
						RefreshAddr |= 8;
						if (ScreenON)
							RENDER_LOG(RefreshAddr);
						pt[1] = CALL_PPUREAD(RefreshAddr);
						runppu(kFetchTime);
					}
				}
	};

	Record main[34];	//one at the end is junk, it can never be rendered
} bgdata;

/**
 * Adjusts the color palette of a given pixel based on the current PPU (Picture Processing Unit) settings.
 * 
 * This method modifies the pixel's color value according to the following rules:
 * - If the PPU's register 1 (PPU[1]) has the most significant 3 bits set to 0x7 (i.e., bits 5-7 are 111), 
 *   the pixel's lower 6 bits are preserved, and the upper 2 bits are set to 0xC0.
 * - If any of the upper 3 bits of PPU[1] (bits 5-7) are set, the pixel's bit 6 is set to 1.
 * - Otherwise, the pixel's lower 6 bits are preserved, and the upper 2 bits are set to 0x80.
 * 
 * @param pixel The original pixel value to be adjusted.
 * @return The adjusted pixel value based on the PPU settings.
 */
static inline int PaletteAdjustPixel(int pixel) {
	if ((PPU[1] >> 5) == 0x7)
		return (pixel & 0x3f) | 0xc0;
	else if (PPU[1] & 0xE0)
		return pixel | 0x40;
	else
		return (pixel & 0x3F) | 0x80;
}

int framectr = 0;
```cpp
/**
 * @brief Emulates the PPU (Picture Processing Unit) loop for a single frame.
 *
 * This method simulates the behavior of the NES PPU for one full frame, including
 * rendering scanlines, handling VBlank, and managing sprite and background rendering.
 * It processes 262 scanlines (or 312 for PAL), initializes the PPU state if a reset
 * has occurred, and manages the timing and sequencing of PPU operations such as
 * fetching tiles, rendering pixels, and handling sprite overflows. The method also
 * triggers NMIs (Non-Maskable Interrupts) during VBlank and updates internal PPU
 * registers and counters.
 *
 * @param skip Unused parameter (reserved for future use or compatibility).
 * @return Always returns 0, indicating successful completion of the PPU loop.
 */
int FCEUX_PPU_Loop(int skip) {

	if (new_ppu_reset) // first frame since reset, time to initialize
	{
		ppur.reset();
		spr_read.reset();
		new_ppu_reset = false;
	}

	//262 scanlines
	if (ppudead) {
		// not quite emulating all the NES power up behavior
		// since it is known that the NES ignores writes to some
		// register before around a full frame, but no games
		// should write to those regs during that time, it needs
		// to wait for vblank
		ppur.status.sl = 241;
		if (PAL)
			runppu(70 * kLineTime);
		else
			runppu(20 * kLineTime);
		ppur.status.sl = 0;
		runppu(242 * kLineTime);
		--ppudead;
		goto finish;
	}

	{
		PPU_status |= 0x80;
		ppuphase = PPUPHASE_VBL;

		//Not sure if this is correct.  According to Matt Conte and my own tests, it is.
		//Timing is probably off, though.
		//NOTE:  Not having this here breaks a Super Donkey Kong game.
		PPU[3] = PPUSPL = 0;
		const int delay = 20;	//fceu used 12 here but I couldnt get it to work in marble madness and pirates.

		ppur.status.sl = 241;	//for sprite reads

		//formerly: runppu(delay);
		for(int dot=0;dot<delay;dot++)
			runppu(1);

		if (VBlankON) TriggerNMI();
		int sltodo = PAL?70:20;

		//formerly: runppu(20 * (kLineTime) - delay);
		for(int S=0;S<sltodo;S++)
		{
			for(int dot=(S==0?delay:0);dot<kLineTime;dot++)
				runppu(1);
			ppur.status.sl++;
		}

		//this seems to run just before the dummy scanline begins
		PPU_status = 0;
		//this early out caused metroid to fail to boot. I am leaving it here as a reminder of what not to do
		//if(!PPUON) { runppu(kLineTime*242); goto finish; }

		//There are 2 conditions that update all 5 PPU scroll counters with the
		//contents of the latches adjacent to them. The first is after a write to
		//2006/2. The second, is at the beginning of scanline 20, when the PPU starts
		//rendering data for the first time in a frame (this update won't happen if
		//all rendering is disabled via 2001.3 and 2001.4).

		//if(PPUON)
		//	ppur.install_latches();

		static uint8 oams[2][64][8];//[7] turned to [8] for faster indexing
		static int oamcounts[2] = { 0, 0 };
		static int oamslot = 0;
		static int oamcount;

		//capture the initial xscroll
		//int xscroll = ppur.fh;
		//render 241/291 scanlines (1 dummy at beginning, dendy's 50 at the end)
		//ignore overclocking!
		for (int sl = 0; sl < normalscanlines; sl++) {
			spr_read.start_scanline();

			g_rasterpos = 0;
			ppur.status.sl = sl;

			linestartts = timestamp * 48 + X.count; // pixel timestamp for debugger

			const int yp = sl - 1;
			ppuphase = PPUPHASE_BG;

			if (sl != 0 && sl < 241) { // ignore the invisible
				DEBUG(FCEUD_UpdatePPUView(scanline = yp, 1));
				DEBUG(FCEUD_UpdateNTView(scanline = yp, 1));
			}

			//hack to fix SDF ship intro screen with split. is it right?
			//well, if we didnt do this, we'd be passing in a negative scanline, so that's a sign something is fishy..
			if(sl != 0)
				if (MMC5Hack) MMC5_hb(yp);


			//twiddle the oam buffers
			const int scanslot = oamslot ^ 1;
			const int renderslot = oamslot;
			oamslot ^= 1;

			oamcount = oamcounts[renderslot];

			//the main scanline rendering loop:
			//32 times, we will fetch a tile and then render 8 pixels.
			//two of those tiles were read in the last scanline.
			for (int xt = 0; xt < 32; xt++) {
				bgdata.main[xt + 2].Read();

				const uint8 blank = (gNoBGFillColor == 0xFF) ? READPAL(0) : gNoBGFillColor;

				//ok, we're also going to draw here.
				//unless we're on the first dummy scanline
				if (sl != 0 && sl < 241) { // cape at 240 for dendy, its PPU does nothing afterwards
					int xstart = xt << 3;
					oamcount = oamcounts[renderslot];
					uint8 * const target = XBuf + (yp << 8) + xstart;
					//uint8 * const dtarget = XDBuf + (yp << 8) + xstart;
					uint8 *ptr = target;
					//uint8 *dptr = dtarget;
					int rasterpos = xstart;

					//check all the conditions that can cause things to render in these 8px
					const bool renderspritenow = SpriteON && (xt > 0 || SpriteLeft8);
					const bool renderbgnow = ScreenON && (xt > 0 || BGLeft8);
					for (int xp = 0; xp < 8; xp++, rasterpos++, g_rasterpos++) {
						//bg pos is different from raster pos due to its offsetability.
						//so adjust for that here
						const int bgpos = rasterpos + ppur.fh;
						const int bgpx = bgpos & 7;
						const int bgtile = bgpos >> 3;

						uint8 pixel = 0;
						uint8 pixelcolor = blank;

						//according to qeed's doc, use palette 0 or $2006's value if it is & 0x3Fxx
						if (!ScreenON && !SpriteON)
						{
							// if there's anything wrong with how we're doing this, someone please chime in
							int addr = ppur.get_2007access();
							if ((addr & 0x3F00) == 0x3F00)
							{
								pixel = addr & 0x1F;
							}
							pixelcolor = READPAL_MOTHEROFALL(pixel);
						}

						//generate the BG data
						if (renderbgnow) {
							uint8* pt = bgdata.main[bgtile].pt;
							pixel = ((pt[0] >> (7 - bgpx)) & 1) | (((pt[1] >> (7 - bgpx)) & 1) << 1) | bgdata.main[bgtile].at;
						}
						if (renderbg)
							pixelcolor = READPAL(pixel);

						//look for a sprite to be drawn
						bool havepixel = false;
						for (int s = 0; s < oamcount; s++) {
							uint8* oam = oams[renderslot][s];
							int x = oam[3];
							if (rasterpos >= x && rasterpos < x + 8) {
								//build the pixel.
								//fetch the LSB of the patterns
								uint8 spixel = oam[4] & 1;
								spixel |= (oam[5] & 1) << 1;

								//shift down the patterns so the next pixel is in the LSB
								oam[4] >>= 1;
								oam[5] >>= 1;

								if (!renderspritenow) continue;

								//bail out if we already have a pixel from a higher priority sprite
								if (havepixel) continue;

								//transparent pixel bailout
								if (spixel == 0) continue;

								//spritehit:
								//1. is it sprite#0?
								//2. is the bg pixel nonzero?
								//then, it is spritehit.
								if (oam[6] == 0 && (pixel & 3) != 0 &&
									rasterpos < 255) {
									PPU_status |= 0x40;
								}
								havepixel = true;

								//priority handling
								if (oam[2] & 0x20) {
									//behind background:
									if ((pixel & 3) != 0) continue;
								}

								//bring in the palette bits and palettize
								spixel |= (oam[2] & 3) << 2;

								if (rendersprites)
									pixelcolor = READPAL(0x10 + spixel);
							}
						}

						*ptr++ = PaletteAdjustPixel(pixelcolor);
						//*dptr++= PPU[1]>>5; //grab deemph
					}
				}
			}

			//look for sprites (was supposed to run concurrent with bg rendering)
			oamcounts[scanslot] = 0;
			oamcount = 0;
			const int spriteHeight = Sprite16 ? 16 : 8;
			for (int i = 0; i < 64; i++) {
				oams[scanslot][oamcount][7] = 0;
				uint8* spr = SPRAM + i * 4;
				if (yp >= spr[0] && yp < spr[0] + spriteHeight) {
					//if we already have maxsprites, then this new one causes an overflow,
					//set the flag and bail out.
					if (oamcount >= 8 && PPUON) {
						PPU_status |= 0x20;
						if (maxsprites == 8)
							break;
					}

					//just copy some bytes into the internal sprite buffer
					for (int j = 0; j < 4; j++)
						oams[scanslot][oamcount][j] = spr[j];
					oams[scanslot][oamcount][7] = 1;

					//note that we stuff the oam index into [6].
					//i need to turn this into a struct so we can have fewer magic numbers
					oams[scanslot][oamcount][6] = (uint8)i;
					oamcount++;
				}
			}
			oamcounts[scanslot] = oamcount;

			//FV is clocked by the PPU's horizontal blanking impulse, and therefore will increment every scanline.
			//well, according to (which?) tests, maybe at the end of hblank.
			//but, according to what it took to get crystalis working, it is at the beginning of hblank.

			//this is done at cycle 251
			//rendering scanline, it doesn't need to be scanline 0,
			//because on the first scanline when the increment is 0, the vs_scroll is reloaded.
			//if(PPUON && sl != 0)
			//	ppur.increment_vs();

			//todo - think about clearing oams to a predefined value to force deterministic behavior

			ppuphase = PPUPHASE_OBJ;

			//fetch sprite patterns
			for (int s = 0; s < maxsprites; s++) {
				//if we have hit our eight sprite pattern and we dont have any more sprites, then bail
				if (s == oamcount && s >= 8)
					break;

				//if this is a real sprite sprite, then it is not above the 8 sprite limit.
				//this is how we support the no 8 sprite limit feature.
				//not that at some point we may need a virtual CALL_PPUREAD which just peeks and doesnt increment any counters
				//this could be handy for the debugging tools also
				const bool realSprite = (s < 8);

				uint8* const oam = oams[scanslot][s];
				uint32 line = yp - oam[0];
				if (oam[2] & 0x80)	//vflip
					line = spriteHeight - line - 1;

				uint32 patternNumber = oam[1];
				uint32 patternAddress;

				//create deterministic dummy fetch pattern
				if (!oam[7]) {
					patternNumber = 0;
					line = 0;
				}

				//8x16 sprite handling:
				if (Sprite16) {
					uint32 bank = (patternNumber & 1) << 12;
					patternNumber = patternNumber & ~1;
					patternNumber |= (line >> 3);
					patternAddress = (patternNumber << 4) | bank;
				} else {
					patternAddress = (patternNumber << 4) | (SpAdrHI << 9);
				}

				//offset into the pattern for the current line.
				//tricky: tall sprites have already had lines>8 taken care of by getting a new pattern number above.
				//so we just need the line offset for the second pattern
				patternAddress += line & 7;

				//garbage nametable fetches
				int garbage_todo = 2;
				if (PPUON)
				{
					if (sl == 0 && ppur.status.cycle == 304)
					{
						runppu(1);
						if (PPUON) ppur.install_latches();
						runppu(1);
						garbage_todo = 0;
					}
					if ((sl != 0 && sl < 241) && ppur.status.cycle == 256)
					{
						runppu(1);
						//at 257: 3d world runner is ugly if we do this at 256
						if (PPUON) ppur.install_h_latches();
						runppu(1);
						garbage_todo = 0;
					}
				}
				if (realSprite) runppu(garbage_todo);

				//Dragon's Lair (Europe version mapper 4)
				//does not set SpriteON in the beginning but it does
				//set the bg on so if using the conditional SpriteON the MMC3 counter
				//the counter will never count and no IRQs will be fired so use PPUON
				if (((PPU[0] & 0x38) != 0x18) && s == 2 && PPUON) {
					//(The MMC3 scanline counter is based entirely on PPU A12, triggered on rising edges (after the line remains low for a sufficiently long period of time))
					//http://nesdevwiki.org/wiki/index.php/Nintendo_MMC3
					//test cases for timing: SMB3, Crystalis
					//crystalis requires deferring this til somewhere in sprite [1,3]
					//kirby requires deferring this til somewhere in sprite [2,5..
					//if (PPUON && GameHBIRQHook) {
					if (GameHBIRQHook) {
						GameHBIRQHook();
					}
				}

				//blind attempt to replicate old ppu functionality
				if(s == 2 && PPUON)
				{
					if (GameHBIRQHook2) {
						GameHBIRQHook2();
					}
				}

				if (realSprite) runppu(kFetchTime);


				//pattern table fetches
				RefreshAddr = patternAddress;
				if (SpriteON)
					RENDER_LOG(RefreshAddr);
				oam[4] = CALL_PPUREAD(RefreshAddr);
				if (realSprite) runppu(kFetchTime);

				RefreshAddr += 8;
				if (SpriteON)
					RENDER_LOG(RefreshAddr);
				oam[5] = CALL_PPUREAD(RefreshAddr);
				if (realSprite) runppu(kFetchTime);

				//hflip
				if (!(oam[2] & 0x40)) {
					oam[4] = bitrevlut[oam[4]];
					oam[5] = bitrevlut[oam[5]];
				}
			}
