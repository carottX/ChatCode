/*
Copyright (C) 2009-2010 DeSmuME team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

//don't use emufile for files bigger than 2GB! you have been warned! some day this will be fixed.

#ifndef EMUFILE_H
#define EMUFILE_H

#include <stdarg.h>
#include "types.h"

#ifndef SEEK_SET
enum {SEEK_SET, SEEK_CUR, SEEK_END};
#endif

/**
 * @brief Checks the state of the failbit flag and optionally unsets it.
 *
 * This method returns the current state of the `failbit` flag, which indicates whether
 * an error has occurred during file operations. If the `unset` parameter is set to `true`,
 * the method will also clear the `failbit` flag by calling the `unfail()` method.
 *
 * @param unset If `true`, the `failbit` flag will be cleared after checking its state.
 * @return `true` if the `failbit` flag is set (indicating an error), `false` otherwise.
 */
bool fail(bool unset=false) { bool ret = failbit; if(unset) unfail(); return ret; }
	/**
	 * @brief Resets the failbit flag to false.
	 * 
	 * This method sets the internal failbit flag to false, indicating that no failure
	 * has occurred. It is typically used to clear the failure state of an object,
	 * allowing subsequent operations to proceed normally.
	 */
	void unfail() { failbit=false; }

	/**
	 * Checks if the current position in the file has reached the end.
	 * This method compares the current file position (obtained using `ftell`)
	 * with the total size of the file (obtained using `size`). If they are equal,
	 * it indicates that the end of the file has been reached.
	 *
	 * @return `true` if the end of the file has been reached, `false` otherwise.
	 */
	bool eof() { return size()==ftell(); }

public:

	virtual bool is_open() = 0;

	virtual int fprintf(const char *format, ...) = 0;

	virtual int fgetc() = 0;
	virtual int fputc(int c) = 0;

	virtual size_t _fread(const void *ptr, size_t bytes) = 0;

	//removing these return values for now so we can find any code that might be using them and make sure
	//they handle the return values correctly

	virtual void fwrite(const void *ptr, size_t bytes) = 0;

	virtual int fseek(int offset, int origin) = 0;

	virtual int ftell() = 0;
	virtual int size() = 0;
	virtual void fflush() = 0;
};

#ifdef __NO_FILE_SYSTEM__

/**
 * Reads a single character from the file data buffer.
 * 
 * This method retrieves the character at the current position in the file data buffer
 * and increments the current position. If the current position is at or beyond the end
 * of the file (EOF), the method prints an error message and returns -1.
 * 
 * @return The character read from the file data buffer as an integer. Returns -1 if the
 *         end of the file is reached.
 */
int fgetc() {
  if (size()==ftell()) {
      printf("%s: Can not read pass EOF\n", __func__);
      return -1;
    }
    int ret = (int)data[curpos];
    curpos ++;
		return ret;
	};

#else

/**
	 * @brief Returns the size of the file in bytes.
	 * 
	 * This method calculates the size of the file by first saving the current file position,
	 * then seeking to the end of the file to determine the total length, and finally restoring
	 * the original file position. This ensures that the file pointer remains unchanged after
	 * the operation.
	 * 
	 * @return int The size of the file in bytes.
	 */
	virtual int size() {
		int oldpos = ftell();
		fseek(0,SEEK_END);
		int len = ftell();
		fseek(oldpos,SEEK_SET);
		return len;
	};

#endif

#endif
