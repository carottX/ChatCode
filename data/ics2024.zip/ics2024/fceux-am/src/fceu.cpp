/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "config.h"
#include "types.h"
#include "x6502.h"
#include "fceu.h"
#include "ppu.h"
#include "sound.h"
#include "file.h"
#include "utils/memory.h"

#include "cart.h"
#include "ines.h"
#include "palette.h"
#include "state.h"
#include "video.h"
#include "input.h"
#include "file.h"
#include "ines.h"

extern void RefreshThrottleFPS();

#include "drivers/sdl/sdl.h"

using namespace std;

//-----------
//overclocking-related
// overclock the console by adding dummy scanlines to PPU loop or to vblank
// disables DMC DMA, WaveHi filling and image rendering for these dummies
// doesn't work with new PPU
bool overclock_enabled = 0;
bool overclocking = 0;
bool skip_7bit_overclocking = 1; // 7-bit samples have priority over overclocking
int normalscanlines;
int totalscanlines;
int postrenderscanlines = 0;
int vblankscanlines = 0;
//------------

//If this is true, frame advance will skip over lag frame (i.e. it will emulate 2 frames instead of 1)
#define frameAdvanceLagSkip false


/**
 * @brief Default constructor for the FCEUGI class.
 * 
 * This constructor initializes an instance of the FCEUGI class. It performs
 * any necessary setup or initialization required for the class to function
 * correctly. The constructor does not take any parameters and does not
 * perform any complex operations by default.
 */
FCEUGI::FCEUGI() { }

/**
 * @brief Destructor for the FCEUGI class.
 *
 * This method is responsible for cleaning up any resources or memory allocations
 * associated with an instance of the FCEUGI class when it is destroyed. It ensures
 * that all dynamically allocated resources are properly released to prevent memory
 * leaks. The destructor is automatically called when an object of the FCEUGI class
 * goes out of scope or is explicitly deleted.
 */
FCEUGI::~FCEUGI() { }

/**
 * @brief Toggles the PPU (Picture Processing Unit) between the new and old versions.
 *
 * This method toggles the state of the PPU by flipping the value of the `newppu` flag.
 * If the `newppu` flag is set to 1 (indicating the new PPU is active), it displays a message
 * indicating that the new PPU is loaded, disables overclocking, and adjusts the number of
 * scanlines accordingly. If the `newppu` flag is set to 0 (indicating the old PPU is active),
 * it displays a message indicating that the old PPU is loaded and adjusts the number of
 * scanlines. The number of scanlines is determined by the `dendy` flag, which specifies
 * whether the system is using Dendy (a PAL-like system) or NTSC.
 */
void FCEU_TogglePPU(void) {
	newppu ^= 1;
	if (newppu) {
		FCEU_DispMessage("New PPU loaded");
		FCEUI_printf("New PPU loaded");
		overclock_enabled = 0;
	} else {
		FCEU_DispMessage("Old PPU loaded");
		FCEUI_printf("Old PPU loaded");
	}
	normalscanlines = (dendy ? 290 : 240)+newppu; // use flag as number!
}

/**
 * @brief Closes the currently loaded game and performs necessary cleanup operations.
 *
 * This method is responsible for safely closing the game that is currently loaded in the emulator.
 * It performs the following steps:
 * - Frees the memory allocated for the game's name and sets the pointer to NULL.
 * - Calls the game interface's close function to handle game-specific cleanup.
 * - Clears the screen buffer to ensure no residual graphics are displayed after the game is closed.
 * - Closes the Game Genie functionality if it is active.
 * - Frees the memory allocated for the GameInfo structure and sets the pointer to NULL.
 *
 * If no game is currently loaded (i.e., GameInfo is NULL), the method does nothing.
 */
static void FCEU_CloseGame(void)
{
	if (GameInfo)
	{
		if (GameInfo->name) {
			free(GameInfo->name);
			GameInfo->name = NULL;
		}

		if (GameInfo->type != GIT_NSF) {
				//FCEU_FlushGameCheats(0, 0);
		}

		GameInterface(GI_CLOSE);

		//FCEUI_StopMovie();

		//ResetExState(0, 0);

		//clear screen when game is closed
		extern uint8 *XBuf;
		if (XBuf)
			memset(XBuf, 0, 256 * 256);

		FCEU_CloseGenie();

		free(GameInfo);
		GameInfo = NULL;
	}
}


uint64 timestampbase;


FCEUGI *GameInfo = NULL;

void (*GameInterface)(GI h);
void (*GameStateRestore)(int version);

#ifdef SIZE_OPT
#ifdef FUNC_IDX_MAX16
#define FUNC_IDX_MAX 16
static uint8 AReadIdx[0x10000 / 2];
static uint8 BWriteIdx[0x10000 / 2];
#else
#define FUNC_IDX_MAX 256
static uint8 AReadIdx[0x10000];
static uint8 BWriteIdx[0x10000];
#endif
static readfunc ARead[FUNC_IDX_MAX];
static writefunc BWrite[FUNC_IDX_MAX];
#else
static readfunc ARead[0x10000];
static writefunc BWrite[0x10000];
#endif

//mbg merge 7/18/06 docs
//bit0 indicates whether emulation is paused
//bit1 indicates whether emulation is in frame step mode
int EmulationPaused = 0;
bool frameAdvanceRequested=false;
int frameAdvance_Delay_count = 0;
int frameAdvance_Delay = FRAMEADVANCE_DELAY_DEFAULT;

int AutosaveQty = 4; // Number of Autosaves to store
int AutosaveFrequency = 256; // Number of frames between autosaves

// Flag that indicates whether the Auto-save option is enabled or not
int EnableAutosave = 0;

/**
 * @brief A static method that serves as a null function pointer placeholder.
 *
 * This method does not perform any operation and is intended to be used as a
 * default or placeholder function pointer in scenarios where a function is
 * expected but no specific action is required. It is marked as static to
 * indicate that it belongs to the class scope rather than an instance of the class.
 *
 * @param DECLFW The macro or parameter list that defines the function signature.
 *               This is typically used to ensure compatibility with the expected
 *               function pointer type.
 */
static DECLFW(BNull) {
}

/**
 * @brief Returns the value of the X.DB member.
 * 
 * This static method is a null function that simply returns the value of the X.DB member.
 * It is typically used as a placeholder or default function in scenarios where a function pointer
 * is required but no actual operation is needed.
 * 
 * @return The value of the X.DB member.
 */
static DECLFR(ANull) {
	return(X.DB);
}

#ifdef SIZE_OPT
/**
 * @brief Registers a read function in the ARead array and returns its index.
 *
 * This method iterates through the ARead array to find the first available slot
 * (i.e., a slot containing NULL) and assigns the provided read function to it.
 * If the function is already registered, it returns the index of the existing slot.
 * If no available slots are found, the method asserts that the index is within the
 * valid range and returns -1 to indicate failure.
 *
 * @param func The read function to be registered.
 * @return The index of the registered function in the ARead array, or -1 if registration fails.
 */
static int RegisterARead(readfunc func) {
  int i;
  for (i = 0; i < FUNC_IDX_MAX; i ++) {
    if (ARead[i] == NULL) ARead[i] = func;
    if (ARead[i] == func) return i;
  }
  assert(i < FUNC_IDX_MAX);
  return -1;
}

/**
 * @brief Registers a write function in the BWrite array.
 *
 * This method iterates through the BWrite array to find the first available slot (NULL) 
 * and assigns the provided write function to that slot. If the function is already 
 * registered in the array, it returns the index of the existing slot. If no available 
 * slot is found and the function is not already registered, the method asserts that 
 * the maximum index (FUNC_IDX_MAX) has not been exceeded and returns -1.
 *
 * @param func The write function to be registered. This function should match the 
 *             writefunc signature.
 * @return The index of the slot where the function is registered, or -1 if the 
 *         function could not be registered due to the array being full.
 */
static int RegisterBWrite(writefunc func) {
  int i;
  for (i = 0; i < FUNC_IDX_MAX; i ++) {
    if (BWrite[i] == NULL) BWrite[i] = func;
    if (BWrite[i] == func) return i;
  }
  assert(i < FUNC_IDX_MAX);
  return -1;
}

/**
 * @brief Retrieves an index from the given array based on the provided address.
 *
 * This method fetches an index from the array using the address as the key. The behavior
 * of the method depends on the presence of the `FUNC_IDX_MAX16` macro:
 * - If `FUNC_IDX_MAX16` is defined, the method interprets the array as containing packed
 *   indices (two 4-bit indices per byte). The address is used to determine which nibble
 *   (4-bit segment) to extract. If the address is odd, the upper nibble is used; if even,
 *   the lower nibble is used.
 * - If `FUNC_IDX_MAX16` is not defined, the method directly uses the address to index into
 *   the array and retrieves the byte at that location.
 *
 * After retrieving the index, the method asserts that the index is less than `FUNC_IDX_MAX`
 * to ensure it is within the valid range.
 *
 * @param array Pointer to the array containing the indices.
 * @param addr The address used to determine which index to retrieve.
 * @return The retrieved index as a uint8 value.
 */
static uint8 GetIdx(uint8 *array, uint32 addr) {
#ifdef FUNC_IDX_MAX16
  uint8 i = array[addr >> 1];
  if (addr & 1) i >>= 4;
  else i &= 0xf;
#else
  uint8 i = array[addr];
#endif
  assert(i < FUNC_IDX_MAX);
  return i;
}

/**
 * @brief Sets the index value in the given array at the specified address.
 *
 * This method sets the index value `i` in the `array` at the address `addr`. 
 * The behavior of the method depends on the presence of the `FUNC_IDX_MAX16` macro:
 * - If `FUNC_IDX_MAX16` is defined, the method treats the array as a packed array of 4-bit values. 
 *   It uses bitwise operations to store the index `i` in the appropriate nibble (4-bit segment) 
 *   of the array element, depending on whether the address is even or odd.
 * - If `FUNC_IDX_MAX16` is not defined, the method directly assigns the index `i` to the array 
 *   element at the specified address.
 *
 * @param array The array in which the index value is to be set.
 * @param addr The address in the array where the index value is to be set.
 * @param i The index value to be set. Must be less than `FUNC_IDX_MAX`.
 * @throws std::invalid_argument If `i` is greater than or equal to `FUNC_IDX_MAX`.
 */
static void SetIdx(uint8 *array, uint32 addr, uint8 i) {
  assert(i < FUNC_IDX_MAX);
#ifdef FUNC_IDX_MAX16
  uint8 mask = 0xf;
  if (addr & 1) {
    mask <<= 4;
    i <<= 4;
  }
  array[addr >> 1] &= ~mask;
  array[addr >> 1] |= i;
#else
  array[addr] = i;
#endif
}
#endif

/**
 * @brief Retrieves the appropriate read handler based on the provided index.
 *
 * This method returns a read handler from the `ARead` array. The behavior of the method
 * depends on whether the `SIZE_OPT` macro is defined:
 * - If `SIZE_OPT` is defined, the method calculates an index using `GetIdx` with `AReadIdx`
 *   and the provided parameter `a`, and then returns the corresponding handler from `ARead`.
 * - If `SIZE_OPT` is not defined, the method directly uses `a` as the index to retrieve the
 *   handler from `ARead`.
 *
 * @param a The index or parameter used to determine the read handler.
 * @return The read handler associated with the calculated or provided index.
 */
readfunc GetReadHandler(int32 a) {
#ifdef SIZE_OPT
  return ARead[GetIdx(AReadIdx, a)];
#else
  return ARead[a];
#endif
}

/**
 * @brief Sets a read handler function for a specific address.
 *
 * This method assigns a read handler function to a specified memory address. If the provided
 * function pointer is null, it defaults to a predefined null handler (ANull). The method
 * handles the assignment differently based on the compilation flag SIZE_OPT:
 * - If SIZE_OPT is defined, it uses the SetIdx function to register the read handler in a
 *   more space-efficient manner.
 * - If SIZE_OPT is not defined, it directly assigns the handler to the corresponding index
 *   in the ARead array.
 *
 * @param addr The memory address for which the read handler is to be set.
 * @param func The read handler function to be assigned. If null, ANull is used as the default.
 */
void SetOneReadHandler(int32 addr, readfunc func) {
  if (!func)
    func = ANull;
#ifdef SIZE_OPT
  SetIdx(AReadIdx, addr, RegisterARead(func));
#else
  ARead[addr] = func;
#endif
}

/**
 * @brief Sets a read handler function for a range of memory addresses.
 *
 * This method assigns a read handler function (`func`) to a specified range of memory addresses
 * from `start` to `end`. If the provided `func` is null, it defaults to a predefined null handler (`ANull`).
 * The method ensures that the read handler is registered and associated with the specified address range.
 *
 * Depending on the compilation flag `SIZE_OPT`, the implementation may differ:
 * - If `SIZE_OPT` is defined, the method registers the read handler once and associates it with the
 *   address range using an index-based lookup mechanism.
 * - If `SIZE_OPT` is not defined, the method directly assigns the read handler to each address in the range.
 *
 * @param start The starting address of the range (inclusive).
 * @param end The ending address of the range (inclusive).
 * @param func The read handler function to be assigned. If null, `ANull` is used as the default handler.
 */
void SetReadHandler(int32 start, int32 end, readfunc func) {
	int32 x;

	if (!func)
		func = ANull;

#ifdef SIZE_OPT
  int idx = RegisterARead(func);
  for (x = end; x >= start; x--)
    SetIdx(AReadIdx, x, idx);
#else
  for (x = end; x >= start; x--)
    ARead[x] = func;
#endif
}

/**
 * @brief Retrieves the appropriate write handler based on the provided index.
 *
 * This method returns a write handler function pointer from the `BWrite` array. 
 * The specific handler is determined by the index `a`. If the `SIZE_OPT` macro 
 * is defined, the index is first mapped using the `GetIdx` function with 
 * `BWriteIdx` and `a` as arguments to retrieve the appropriate index from the 
 * `BWrite` array. If `SIZE_OPT` is not defined, the handler is directly accessed 
 * from the `BWrite` array using the index `a`.
 *
 * @param a The index used to retrieve the write handler.
 * @return A function pointer to the write handler corresponding to the index `a`.
 */
writefunc GetWriteHandler(int32 a) {
#ifdef SIZE_OPT
  return BWrite[GetIdx(BWriteIdx, a)];
#else
  return BWrite[a];
#endif
}

/**
 * @brief Sets a write handler function for a specific memory address.
 *
 * This method assigns a write handler function (`func`) to a specified memory address (`addr`).
 * If the provided function pointer is null (`nullptr`), it assigns a default null handler (`BNull`).
 * Depending on the compilation flag `SIZE_OPT`, the method either registers the function in a 
 * specialized index structure or directly assigns it to the `BWrite` array at the specified address.
 *
 * @param addr The memory address for which the write handler is being set.
 * @param func The write handler function to be assigned. If null, `BNull` is used as the default.
 */
void SetOneWriteHandler(int32 addr, writefunc func) {
  if (!func)
    func = BNull;
#ifdef SIZE_OPT
  SetIdx(BWriteIdx, addr, RegisterBWrite(func));
#else
  BWrite[addr] = func;
#endif
}

/**
 * @brief Sets a write handler function for a range of indices in the BWrite array.
 *
 * This method assigns a write handler function (`func`) to a specified range of indices
 * (`start` to `end`) in the BWrite array. If the provided function pointer (`func`) is null,
 * it defaults to the `BNull` function. Depending on the `SIZE_OPT` compilation flag, the
 * implementation may differ:
 * - If `SIZE_OPT` is defined, the function is registered once using `RegisterBWrite`, and
 *   the resulting index is assigned to the specified range in the BWrite array.
 * - If `SIZE_OPT` is not defined, the function is directly assigned to each index in the range.
 *
 * @param start The starting index of the range (inclusive).
 * @param end The ending index of the range (inclusive).
 * @param func The write handler function to be assigned. If null, `BNull` is used.
 */
void SetWriteHandler(int32 start, int32 end, writefunc func) {
	int32 x;

	if (!func)
		func = BNull;

#ifdef SIZE_OPT
  int idx = RegisterBWrite(func);
  for (x = end; x >= start; x--)
    SetIdx(BWriteIdx, x, idx);
#else
  for (x = end; x >= start; x--)
    BWrite[x] = func;
#endif
}

/**
 * @brief Reads a byte from the specified address using a read handler.
 *
 * This method retrieves a byte from the memory address `a` by invoking the appropriate
 * read handler associated with that address. The read handler is obtained by calling
 * `GetReadHandler(a)`, which returns a function pointer or callable object that performs
 * the actual read operation. The method then calls this handler with the address `a` as
 * the argument and returns the resulting byte.
 *
 * @param a The memory address from which to read the byte.
 * @return The byte read from the specified address.
 */
uint8 readb(int32 a) {
  return GetReadHandler(a)(a);
}

/**
 * @brief Writes a byte value to a specified address using a write handler.
 *
 * This method invokes a write handler associated with the given address to 
 * write the provided byte value. The write handler is retrieved by calling 
 * `GetWriteHandler(a)`, which returns a function or callable object that 
 * handles the actual writing operation. The handler is then invoked with the 
 * address `a` and the byte value `v` as arguments.
 *
 * @param a The address where the byte value should be written. This is passed 
 *          as an argument to the write handler.
 * @param v The byte value to be written at the specified address. This is 
 *          passed as an argument to the write handler.
 */
void writeb(int32 a, uint8 v) {
  GetWriteHandler(a)(a, v);
}

uint8 RAM[0x800];

//------

uint8 PAL = 0;

/**
 * @brief Writes a value to a specific address in the RAM.
 *
 * This static method is used to write the value `V` to the memory location 
 * in the RAM array specified by the address `A`. The RAM array is assumed 
 * to be accessible globally or within the scope of the method.
 *
 * @param A The address in the RAM where the value will be written.
 * @param V The value to be written to the specified RAM address.
 *
 * @note This method does not perform any bounds checking on the address `A`.
 *       It is the caller's responsibility to ensure that `A` is a valid index
 *       within the bounds of the RAM array.
 */
static DECLFW(BRAML) {
	RAM[A] = V;
}

/**
 * @brief Writes a value to the Battery-backed RAM (BRAM) at a specific address.
 *
 * This method writes the given value `V` to the BRAM at the address specified by `A`.
 * The address `A` is masked with `0x7FF` to ensure it falls within the valid range
 * of the BRAM (0x0000 to 0x07FF). This is typically used in memory-mapped I/O
 * operations where the BRAM is accessed through a specific address range.
 *
 * @param A The address where the value will be written. This address is masked with `0x7FF`.
 * @param V The value to be written to the BRAM.
 */
static DECLFW(BRAMH) {
	RAM[A & 0x7FF] = V;
}

/**
 * @brief Reads a value from the RAM array at the specified address.
 *
 * This method is a static function that takes an address `A` and returns the value stored
 * in the RAM array at that address. It is typically used as a memory read function in an
 * emulator or similar system to simulate memory access.
 *
 * @param A The address in the RAM array from which to read the value.
 * @return The value stored in the RAM array at the specified address.
 */
static DECLFR(ARAML) {
    return RAM[A];
}

/**
 * @brief Reads a byte from the ARAM (Auxiliary RAM) memory.
 * 
 * This method is a static function that reads a byte from the ARAM memory at the address specified 
 * by the lower 11 bits of the input parameter `A`. The address is masked with `0x7FF` to ensure it 
 * falls within the valid range of the ARAM memory (0x000 to 0x7FF).
 * 
 * @param A The address to read from. Only the lower 11 bits are used to determine the actual address.
 * @return The byte read from the ARAM memory at the specified address.
 */
static DECLFR(ARAMH) {
	return RAM[A & 0x7FF];
}


/**
 * @brief Resets the game loaded state and associated resources.
 *
 * This method performs a series of cleanup operations to reset the game state and associated resources.
 * It closes the currently loaded game using `FCEU_CloseGame` if `GameInfo` is not null. It also unpauses
 * the emulation by setting `EmulationPaused` to 0, which is necessary to avoid issues when loading games
 * while paused. The method resets various game state variables, including `GameStateRestore`, and clears
 * hooks such as `PPU_hook`, `GameHBIRQHook`, `FFCEUX_PPURead`, and `FFCEUX_PPUWrite`. If the `GameExpSound`
 * object has a `Kill` method, it is invoked to clean up sound resources, and the `GameExpSound` object is
 * zeroed out. Additionally, the method resets other game-specific hacks and configurations, such as
 * `MMC5Hack`, `PEC586Hack`, `QTAIHack`, and `PAL`. Finally, it resets the default palette selection to 0.
 */
void ResetGameLoaded(void) {
	if (GameInfo) FCEU_CloseGame();
	EmulationPaused = 0; //mbg 5/8/08 - loading games while paused was bad news. maybe this fixes it
	GameStateRestore = 0;
	PPU_hook = NULL;
	GameHBIRQHook = NULL;
	FFCEUX_PPURead = NULL;
	FFCEUX_PPUWrite = NULL;
	if (GameExpSound.Kill)
		GameExpSound.Kill();
	memset(&GameExpSound, 0, sizeof(GameExpSound));
	MapIRQHook = NULL;
	MMC5Hack = 0;
	PEC586Hack = 0;
	QTAIHack = 0;
	PAL &= 1;
	default_palette_selection = 0;
}

int iNESLoad(const char *name, FCEUFILE *fp, int OverwriteVidMode);

//name should be UTF-8, hopefully, or else there may be trouble
FCEUGI *FCEUI_LoadGameVirtual(const char *name, int OverwriteVidMode, bool silent)
{
	//----------
	//attempt to open the files
	FCEUFILE *fp;
	char fullname[2048];	// this name contains both archive name and ROM file name
	int lastpal = PAL;
	int lastdendy = dendy;

	const char* romextensions[] = { "nes", "fds", 0 };

	// indicator for if the operaton was canceled by user
	// currently there's only one situation:
	// the user clicked cancel form the open from archive dialog
	int userCancel = 0;
	fp = FCEU_fopen(name, 0, "rb", 0, -1, romextensions, &userCancel);

	if (!fp)
	{
		// Although !fp, if the operation was canceled from archive select dialog box, don't show the error message;
		if (!silent && !userCancel)
			FCEU_PrintError("Error opening \"%s\"!", name);

		return 0;
	}
	else
		strcpy(fullname, name);

	// reset loaded game BEFORE it's loading.
	ResetGameLoaded();
	//file opened ok. start loading.
	FCEU_printf("Loading ...\n\n");

	FCEU_CloseGame();
	GameInfo = (FCEUGI *)malloc(sizeof(FCEUGI));
	memset(GameInfo, 0, sizeof(FCEUGI));

	GameInfo->archiveCount = fp->archiveCount;

	GameInfo->soundchan = 0;
	GameInfo->soundrate = 0;
	GameInfo->name = 0;
	GameInfo->type = GIT_CART;
	GameInfo->vidsys = GIV_USER;
	GameInfo->input[0] = GameInfo->input[1] = SI_UNSET;
	GameInfo->inputfc = SIFC_UNSET;
	GameInfo->cspecial = SIS_NONE;

	//try to load each different format
	bool FCEUXLoad(const char *name, FCEUFILE * fp);

	if (iNESLoad(fullname, fp, OverwriteVidMode))
	{
		if (OverwriteVidMode)
			FCEU_ResetVidSys();

		PowerNES();

		if (GameInfo->type != GIT_NSF)
			FCEU_LoadGamePalette();

		FCEU_ResetPalette();

		if (!lastpal && PAL) {
			FCEU_DispMessage("PAL mode set");
			FCEUI_printf("PAL mode set");
		}
		else if (!lastdendy && dendy) {
			// this won't happen, since we don't autodetect dendy, but maybe someday we will?
			FCEU_DispMessage("Dendy mode set");
			FCEUI_printf("Dendy mode set");
		}
		else if ((lastpal || lastdendy) && !(PAL || dendy)) {
			FCEU_DispMessage("NTSC mode set");
			FCEUI_printf("NTSC mode set");
		}
	}
	else {
		if (!silent)
			FCEU_PrintError("An error occurred while loading the file.");

		free(GameInfo);
		GameInfo = 0;
	}

	FCEU_fclose(fp);
	return GameInfo;
}

/**
 * @brief Loads a game into the emulator.
 *
 * This function is a wrapper for `FCEUI_LoadGameVirtual` and is used to load a game
 * into the emulator. It takes the name of the game file, a flag to determine whether
 * to overwrite the video mode, and a flag to control whether the operation should
 * be silent (i.e., without displaying any messages or prompts).
 *
 * @param name The name of the game file to load.
 * @param OverwriteVidMode A flag indicating whether to overwrite the current video mode.
 * @param silent A flag indicating whether the operation should be performed silently.
 * @return A pointer to the `FCEUGI` structure representing the loaded game, or nullptr
 *         if the game could not be loaded.
 */
FCEUGI *FCEUI_LoadGame(const char *name, int OverwriteVidMode, bool silent)
{
	return FCEUI_LoadGameVirtual(name, OverwriteVidMode, silent);
}


//Return: Flag that indicates whether the function was succesful or not.
bool FCEUI_Initialize() {
	srand(0);

	if (!FCEU_InitVirtualVideo()) {
		return false;
	}

	// Initialize some parts of the settings structure
	//mbg 5/7/08 - I changed the ntsc settings to match pal.
	//this is more for precision emulation, instead of entertainment, which is what fceux is all about nowadays
	memset(&FSettings, 0, sizeof(FSettings));
	//FSettings.UsrFirstSLine[0]=8;
	FSettings.UsrFirstSLine[0] = 0;
	FSettings.UsrFirstSLine[1] = 0;
	//FSettings.UsrLastSLine[0]=231;
	FSettings.UsrLastSLine[0] = 239;
	FSettings.UsrLastSLine[1] = 239;
	FSettings.SoundVolume = 150;      //0-150 scale
	FSettings.TriangleVolume = 256;   //0-256 scale (256 is max volume)
	FSettings.Square1Volume = 256;    //0-256 scale (256 is max volume)
	FSettings.Square2Volume = 256;    //0-256 scale (256 is max volume)
	FSettings.NoiseVolume = 256;      //0-256 scale (256 is max volume)
	FSettings.PCMVolume = 256;        //0-256 scale (256 is max volume)

	FCEUPPU_Init();

	X6502_Init();

	return true;
}

/**
 * @brief Shuts down and cleans up resources used by the FCEUI (FCEUX Interface) module.
 *
 * This method is responsible for terminating and releasing resources associated with
 * the virtual video system and the Game Genie emulation functionality. It calls
 * `FCEU_KillVirtualVideo()` to clean up the virtual video system and `FCEU_KillGenie()`
 * to deactivate and release resources used by the Game Genie emulator. This function
 * should be called when the emulator is shutting down to ensure proper resource cleanup.
 */
void FCEUI_Kill(void) {
	FCEU_KillVirtualVideo();
	FCEU_KillGenie();
}

///Emulates a single frame.

///Skip may be passed in, if FRAMESKIP is #defined, to cause this to emulate more than one frame
void FCEUI_Emulate(uint8 **pXBuf, int32 **SoundBuf, int32 *SoundBufSize, int skip) {
	//skip initiates frame skip if 1, or frame skip and sound skip if 2
  int ssize;

	if (frameAdvanceRequested)
	{
		if (frameAdvance_Delay_count == 0 || frameAdvance_Delay_count >= frameAdvance_Delay)
			EmulationPaused = EMULATIONPAUSED_FA;
		if (frameAdvance_Delay_count < frameAdvance_Delay)
			frameAdvance_Delay_count++;
	}

	if (EmulationPaused & EMULATIONPAUSED_FA)
	{
		// the user is holding Frame Advance key
		// clear paused flag temporarily
		EmulationPaused &= ~EMULATIONPAUSED_PAUSED;
	} else
	{
		if (EmulationPaused & EMULATIONPAUSED_PAUSED)
		{
			// emulator is paused
			//memcpy(XBuf, XBackBuf, 256*256);
			memset(XBuf, 0, 256*256);
			*pXBuf = XBuf;
#if SOUND_CONFIG != SOUND_NONE
      *SoundBuf = WaveFinal;
#else
      *SoundBuf = 0;
#endif
      *SoundBufSize = 0;
			return;
		}
	}

	FCEU_UpdateInput();

	FCEUPPU_Loop(skip);

  if (skip != 2) ssize = FlushEmulateSound();  //If skip = 2 we are skipping sound processing

	timestampbase += timestamp;
	timestamp = 0;
	soundtimestamp = 0;

	*pXBuf = skip ? 0 : XBuf;
  if (skip == 2) { //If skip = 2, then bypass sound
    *SoundBuf = 0;
    *SoundBufSize = 0;
  } else {
#if SOUND_CONFIG != SOUND_NONE
      *SoundBuf = WaveFinal;
#else
      *SoundBuf = 0;
#endif
    *SoundBufSize = ssize;
  }

	if ((EmulationPaused & EMULATIONPAUSED_FA) && (!frameAdvanceLagSkip))
	//Lots of conditions here.  EmulationPaused & EMULATIONPAUSED_FA must be true.  In addition frameAdvanceLagSkip or lagFlag must be false
	// When Frame Advance is held, emulator is automatically paused after emulating one frame (or several lag frames)
	{
		EmulationPaused = EMULATIONPAUSED_PAUSED;		   // restore EMULATIONPAUSED_PAUSED flag and clear EMULATIONPAUSED_FA flag
	}
}

/**
 * @brief Closes the currently loaded game in the FCEUX emulator.
 *
 * This function is responsible for closing the currently active game session
 * within the FCEUX emulator. It calls the `FCEU_CloseGame()` function, which
 * performs the necessary cleanup and deinitialization tasks associated with
 * the game, such as freeing allocated resources, resetting emulator states,
 * and ensuring that the emulator is ready to load a new game or exit safely.
 *
 * @note This function should be called when the user wants to stop the current
 * game session, either to load a new game or to exit the emulator. It ensures
 * that all game-related resources are properly released.
 */
void FCEUI_CloseGame(void) {
	FCEU_CloseGame();
}

#if 0
/**
 * @brief Resets the NES emulator to its initial state.
 *
 * This method performs a soft reset of the NES emulator. It first checks if the `GameInfo` 
 * pointer is valid; if not, the method returns immediately. If valid, it triggers a reset 
 * through the `GameInterface` with the `GI_RESETM2` command. Subsequently, it resets the 
 * sound system (`FCEUSND_Reset`), the PPU (Picture Processing Unit) (`FCEUPPU_Reset`), 
 * and the 6502 CPU (`X6502_Reset`). Optionally, it could clear the back buffer, but this 
 * functionality is currently commented out. Finally, it displays a "Reset" message on the 
 * screen using `FCEU_DispMessage`.
 */
void ResetNES(void) {
	if (!GameInfo) return;
	GameInterface(GI_RESETM2);
	FCEUSND_Reset();
	FCEUPPU_Reset();
	X6502_Reset();

	// clear back baffer
	//extern uint8 *XBackBuf;
	//memset(XBackBuf, 0, 256 * 256);

	FCEU_DispMessage("Reset");
}
#endif

/**
 * Generates the next pseudo-random number in the sequence using the xoroshiro128+ algorithm.
 * This method advances the internal state of the generator and returns a 64-bit unsigned integer.
 * The xoroshiro128+ algorithm is a high-quality, fast, and lightweight pseudo-random number generator.
 * It is suitable for applications requiring high performance and good statistical properties.
 * 
 * @return A 64-bit unsigned integer representing the next pseudo-random number in the sequence.
 */
u64 xoroshiro128plus_next() {
	return 0;
}

/**
 * Fills a block of memory with random values or zeros.
 *
 * This function populates a specified memory block with random data or zeros,
 * depending on the `default_zero` parameter. If `default_zero` is set to `true`,
 * the memory block is filled with zeros. Otherwise, the memory block is filled
 * with random values.
 *
 * @param ptr A pointer to the memory block to be filled.
 * @param size The size of the memory block in bytes.
 * @param default_zero If `true`, the memory block is filled with zeros; if `false`, it is filled with random values.
 */
void FCEU_MemoryRand(uint8 *ptr, uint32 size, bool default_zero) {
}

/**
 * @brief Initializes and powers on the NES emulator system.
 *
 * This method performs a series of operations to reset and initialize the NES emulator's state.
 * It ensures that the GameInfo object is valid before proceeding. The method randomizes the
 * contents of the RAM, sets up read and write handlers for various memory ranges, and initializes
 * input, sound, and PPU (Picture Processing Unit) components. Additionally, it powers on external
 * game hardware and resets the timestamp base. Finally, it displays a message indicating that the
 * system has been powered on.
 *
 * @note This method assumes that the necessary global variables and functions (e.g., GameInfo,
 * FCEU_MemoryRand, SetReadHandler, SetWriteHandler, InitializeInput, FCEUSND_Power, FCEUPPU_Power,
 * GameInterface, X6502_Power, FCEU_DispMessage) are properly defined and initialized.
 */
void PowerNES(void) {
	if (!GameInfo) return;

	//FCEU_CheatResetRAM();
	//FCEU_CheatAddRAM(2, 0, RAM);

	//FCEU_GeniePower();

	FCEU_MemoryRand(RAM, 0x800);

	SetReadHandler(0x0000, 0xFFFF, ANull);
	SetWriteHandler(0x0000, 0xFFFF, BNull);

	SetReadHandler(0, 0x7FF, ARAML);
	SetWriteHandler(0, 0x7FF, BRAML);

	SetReadHandler(0x800, 0x1FFF, ARAMH);	// Part of a little
	SetWriteHandler(0x800, 0x1FFF, BRAMH);	//hack for a small speed boost.

	InitializeInput();
	FCEUSND_Power();
	FCEUPPU_Power();

	//Have the external game hardware "powered" after the internal NES stuff.  Needed for the NSF code and VS System code.
	GameInterface(GI_POWER);

	timestampbase = 0;
	X6502_Power();
	// clear back buffer
	//extern uint8 *XBackBuf;
	//memset(XBackBuf, 0, 256 * 256);

	FCEU_DispMessage("Power on");
}

/**
 * @brief Resets the video system settings based on the current game's video system configuration.
 *
 * This method adjusts various video-related settings such as PAL/NTSC mode, scanlines, and overclocking
 * based on the game's video system (GIV_NTSC, GIV_PAL, or other). It also updates the sound variables
 * to ensure they are in sync with the video system settings.
 *
 * The method performs the following steps:
 * 1. Determines the video system mode (PAL or NTSC) based on the `GameInfo->vidsys` value.
 * 2. Sets the `PAL` flag accordingly and ensures `dendy` is disabled if PAL mode is active.
 * 3. Disables overclocking if the new PPU (Picture Processing Unit) is enabled.
 * 4. Calculates the number of normal scanlines based on the video system and `dendy` flag.
 * 5. Adjusts the total scanlines by adding post-render scanlines if overclocking is enabled.
 * 6. Updates the PPU video system settings using `FCEUPPU_SetVideoSystem`.
 * 7. Synchronizes sound variables with the updated video system settings.
 */
void FCEU_ResetVidSys(void) {
	int w;

	if (GameInfo->vidsys == GIV_NTSC)
		w = 0;
	else if (GameInfo->vidsys == GIV_PAL) {
		w = 1;
		dendy = 0;
	} else
		w = FSettings.PAL;

	PAL = w ? 1 : 0;

	if (PAL)
		dendy = 0;

	if (newppu)
		overclock_enabled = 0;

	normalscanlines = (dendy ? 290 : 240)+newppu; // use flag as number!
	totalscanlines = normalscanlines + (overclock_enabled ? postrenderscanlines : 0);
	FCEUPPU_SetVideoSystem(w || dendy);
  SetSoundVariables();
}

FCEUS FSettings;

/**
 * @brief Sets the rendered scanlines for NTSC and PAL video modes.
 *
 * This method configures the first and last scanlines to be rendered for both NTSC and PAL video modes.
 * The scanlines are stored in the `FSettings` structure, which is used to determine the visible area of the screen.
 * The method updates the `UsrFirstSLine` and `UsrLastSLine` arrays for both NTSC and PAL modes, and then sets the
 * `FirstSLine` and `LastSLine` fields in `FSettings` based on the current video mode (NTSC, PAL, or Dendy).
 *
 * @param ntscf The first scanline to render for NTSC mode.
 * @param ntscl The last scanline to render for NTSC mode.
 * @param palf The first scanline to render for PAL mode.
 * @param pall The last scanline to render for PAL mode.
 */
void FCEUI_SetRenderedLines(int ntscf, int ntscl, int palf, int pall) {
	FSettings.UsrFirstSLine[0] = ntscf;
	FSettings.UsrLastSLine[0] = ntscl;
	FSettings.UsrFirstSLine[1] = palf;
	FSettings.UsrLastSLine[1] = pall;
	if (PAL || dendy) {
		FSettings.FirstSLine = FSettings.UsrFirstSLine[1];
		FSettings.LastSLine = FSettings.UsrLastSLine[1];
	} else {
		FSettings.FirstSLine = FSettings.UsrFirstSLine[0];
		FSettings.LastSLine = FSettings.UsrLastSLine[0];
	}
}

/**
 * @brief Sets the video system to either PAL or NTSC based on the provided parameter.
 *
 * This method updates the video system settings in the global `FSettings` structure.
 * If the provided integer `a` is non-zero, the video system is set to PAL; otherwise,
 * it is set to NTSC. Additionally, if the `GameInfo` object is valid, this method
 * triggers a reset of the video system, a reset of the palette, and notifies the
 * video system that a change has occurred.
 *
 * @param a An integer indicating the desired video system. A non-zero value sets
 *          the system to PAL, while a zero value sets it to NTSC.
 */
void FCEUI_SetVidSystem(int a) {
	FSettings.PAL = a ? 1 : 0;
	if (GameInfo) {
		FCEU_ResetVidSys();
		FCEU_ResetPalette();
		FCEUD_VideoChanged();
	}
}

/**
 * @brief Retrieves the current video system settings and scanline range.
 *
 * This method fetches the current video system configuration and the range of scanlines
 * used for rendering. If the provided pointers `slstart` and `slend` are not null, the
 * method stores the starting and ending scanline values in the respective pointers.
 * The method always returns the video system type, which is hardcoded to `PAL`.
 *
 * @param slstart Pointer to an integer where the starting scanline value will be stored.
 *                If null, the value is not stored.
 * @param slend Pointer to an integer where the ending scanline value will be stored.
 *              If null, the value is not stored.
 * @return int The video system type, which is always `PAL`.
 */
int FCEUI_GetCurrentVidSystem(int *slstart, int *slend) {
	if (slstart)
		*slstart = FSettings.FirstSLine;
	if (slend)
		*slend = FSettings.LastSLine;
	return(PAL);
}

/**
 * @brief Sets the region-specific video system configuration for the emulator.
 *
 * This method configures the emulator's video system based on the specified region.
 * It adjusts the number of scanlines, enables or disables PAL emulation, and sets
 * the Dendy mode accordingly. The method also updates the total number of scanlines
 * based on the overclocking settings and refreshes the throttle FPS.
 *
 * @param region The region code to set:
 *               - 0: NTSC (240 scanlines, no PAL emulation, no Dendy mode)
 *               - 1: PAL (240 scanlines, PAL emulation enabled, no Dendy mode)
 *               - 2: Dendy (290 scanlines, no PAL emulation, Dendy mode enabled)
 * @param notify A flag indicating whether to notify the system of the change.
 *               This parameter is currently unused in the implementation.
 */
void FCEUI_SetRegion(int region, int notify) {
	switch (region) {
		case 0: // NTSC
			normalscanlines = 240;
			pal_emulation = 0;
			dendy = 0;
// until it's fixed on sdl. see issue #740
			break;
		case 1: // PAL
			normalscanlines = 240;
			pal_emulation = 1;
			dendy = 0;
			break;
		case 2: // Dendy
			normalscanlines = 290;
			pal_emulation = 0;
			dendy = 1;
			break;
	}
	normalscanlines += newppu;
	totalscanlines = normalscanlines + (overclock_enabled ? postrenderscanlines : 0);
	FCEUI_SetVidSystem(pal_emulation);
	RefreshThrottleFPS();
}

/**
 * @brief Retrieves the desired frames per second (FPS) based on the current video system.
 * 
 * This function returns the desired FPS for the emulator based on the configured video system.
 * If the video system is set to PAL or Dendy, it returns 50 FPS. Otherwise, it returns 60 FPS,
 * which corresponds to the NTSC video system.
 * 
 * @return int32 The desired FPS as an integer. Returns 50 for PAL/Dendy systems, and 60 for NTSC systems.
 */
int32 FCEUI_GetDesiredFPS(void) {
	if (PAL || dendy)
		return 50;
	else
		return 60;
}

/**
 * @brief Checks if the emulation is currently paused.
 *
 * This method checks the state of the emulation by examining the `EmulationPaused` flag.
 * It returns a non-zero value if the emulation is paused, and zero if it is not.
 * The `EmulationPaused` flag is typically set by other parts of the emulator to indicate
 * that the emulation should be paused, such as when the user requests a pause or when
 * the emulator encounters a breakpoint.
 *
 * @return int Returns a non-zero value if the emulation is paused, otherwise returns zero.
 */
int FCEUI_EmulationPaused(void)
{
	return (EmulationPaused & EMULATIONPAUSED_PAUSED);
}

/**
 * @brief Calculates the text scanline offset based on the first scanline setting.
 *
 * This method returns the offset for the text scanline by multiplying the first scanline 
 * setting (FSettings.FirstSLine) by 256. The result is used to determine the starting 
 * position for rendering text on the screen.
 *
 * @param y The scanline number (unused in this implementation).
 * @return The calculated text scanline offset as an integer.
 */
int FCEU_TextScanlineOffset(int y) {
	return FSettings.FirstSLine * 256;
}
/**
 * @brief Calculates the text scanline offset from the bottom of the screen.
 *
 * This method computes the vertical offset for a given scanline `y` relative to the bottom 
 * of the screen. The offset is calculated by subtracting the scanline `y` from the last 
 * visible scanline (`FSettings.LastSLine`) and then multiplying the result by 256. The 
 * returned value represents the pixel offset in the vertical direction, which can be used 
 * for positioning text or other elements on the screen.
 *
 * @param y The scanline number for which the offset is to be calculated.
 * @return The vertical offset in pixels from the bottom of the screen.
 */
int FCEU_TextScanlineOffsetFromBottom(int y) {
	return (FSettings.LastSLine - y) * 256;
}
