/// \file
/// \brief RFC 1321 compliant MD5 implementation,
/// RFC 1321 compliant MD5 implementation,
/// by Christophe Devine <devine@cr0.net>;
/// this program is licensed under the GPL.

//Modified October 3, 2003, to remove testing code, and add include of "types.h".
//Added simple MD5 to ASCII string conversion function.
// -Xodnizel

#include "../types.h"
#include "md5.h"

#define GET_UINT32(n,b,i)           \
{                 \
    (n) = ( (uint32) (b)[(i) + 3] << 24 )       \
        | ( (uint32) (b)[(i) + 2] << 16 )       \
        | ( (uint32) (b)[(i) + 1] <<  8 )       \
        | ( (uint32) (b)[(i)    ]       );      \
}

#define PUT_UINT32(n,b,i)           \
{                 \
    (b)[(i)    ] = (uint8) ( (n)       );       \
    (b)[(i) + 1] = (uint8) ( (n) >>  8 );       \
    (b)[(i) + 2] = (uint8) ( (n) >> 16 );       \
    (b)[(i) + 3] = (uint8) ( (n) >> 24 );       \
}

/**
 * Initializes the MD5 context structure for a new hashing operation.
 * 
 * This function sets up the initial state of the MD5 context by resetting the 
 * total number of bits processed to zero and initializing the internal state 
 * variables to the standard MD5 initialization constants. These constants are:
 * - state[0] = 0x67452301
 * - state[1] = 0xEFCDAB89
 * - state[2] = 0x98BADCFE
 * - state[3] = 0x10325476
 * 
 * @param ctx Pointer to the MD5 context structure to be initialized.
 */
void md5_starts( struct md5_context *ctx )
{
    ctx->total[0] = 0;
    ctx->total[1] = 0;
    ctx->state[0] = 0x67452301;
    ctx->state[1] = 0xEFCDAB89;
    ctx->state[2] = 0x98BADCFE;
    ctx->state[3] = 0x10325476;
}

```/**
``` * Converts an MD5 digest into a 32-character ASCII string representation.
``` * 
``` * This method takes a 16-byte MD5 digest and converts each byte into a pair of
``` * hexadecimal characters. The resulting string is a 32-character representation
``` * of the MD5 hash in lowercase hexadecimal format. The method uses a static
``` * buffer to store the resulting string, so the caller must use or copy the
``` * result immediately before subsequent calls overwrite it.
``` *
``` * @param md5 Reference to an MD5DATA structure containing the 16-byte MD5 digest.
``` * @return A pointer to a static 33-character buffer containing the hexadecimal
``` *         string representation of the MD5 digest (32 characters + null terminator).
``` *
``` * @note The returned string is stored in a static buffer, so it is not thread-safe
``` *       and should be used or copied immediately after the call.
``` */
```/**
``` * @brief Converts an MD5 digest into a human-readable ASCII string representation.
``` *
``` * This method takes an MD5 digest stored in an `MD5DATA` structure and converts it into a 
``` * 32-character ASCII string. Each byte of the MD5 digest is represented as two hexadecimal 
``` * characters. The resulting string is null-terminated and stored in a static buffer, which 
``` * is returned by the function.
``` *
``` * @param md5 A reference to an `MD5DATA` structure containing the MD5 digest to be converted.
``` * @return A pointer to a static character array containing the 32-character hexadecimal 
``` *         representation of the MD5 digest. The string is null-terminated.
``` */
```char *md5_asciistr(MD5DATA& md5)
```{
```    uint8* digest = md5.data;
```    static char str[33];
```    static char trans[16]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
```    int x;
```
```    for(x=0;x<16;x++)
```    {
```        str[x*2]=trans[digest[x]>>4];
```        str[x*2+1]=trans[digest[x]&0x0F];
```    }
```    return(str);
```}
