#ifndef _VALUEARRAY_H_
#define _VALUEARRAY_H_

template<typename T, int N>
struct ValueArray
{
	T data[N];
	T &operator[](int index) { return data[index]; }
	static const int size = N;
	/**
	 * @brief Checks if the current ValueArray object is not equal to another ValueArray object.
	 *
	 * This method compares the current ValueArray object with another ValueArray object of the same type and size.
	 * It internally uses the equality operator (operator==) and negates its result to determine inequality.
	 *
	 * @tparam T The type of elements stored in the ValueArray.
	 * @tparam N The size of the ValueArray.
	 * @param other The ValueArray object to compare with.
	 * @return true if the two ValueArray objects are not equal, false otherwise.
	 */
	bool operator!=(ValueArray<T,N> &other) { return !operator==(other); }
	/**
	 * @brief Compares two ValueArray objects for equality.
	 * 
	 * This method checks if the current ValueArray object is equal to another ValueArray object
	 * by comparing each element in the arrays. The comparison is done element-wise, and the method
	 * returns `true` if all corresponding elements in both arrays are equal, and `false` otherwise.
	 * 
	 * @tparam T The type of elements stored in the ValueArray.
	 * @tparam N The size of the ValueArray.
	 * @param other The ValueArray object to compare with the current object.
	 * @return `true` if all elements in the current ValueArray are equal to the corresponding elements
	 *         in the `other` ValueArray, `false` otherwise.
	 */
	bool operator==(ValueArray<T,N> &other)
	{
	    for(int i=0;i<size;i++)
	        if(data[i] != other[i])
	            return false;
	    return true;
	}
};

#endif

