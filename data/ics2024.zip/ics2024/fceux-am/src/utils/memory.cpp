/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

/// \file
/// \brief memory management services provided by FCEU core

#include "../types.h"
#include "../fceu.h"
#include "memory.h"

///allocates the specified number of bytes. exits process if this fails
void *FCEU_gmalloc(uint32 size)
{

 void *ret;
 ret=malloc(size);
 if(!ret)
 {
  FCEU_PrintError("Error allocating memory!  Doing a hard exit.");
  assert(0);
 }
 FCEU_MemoryRand((uint8*)ret,size,true); // initialize according to RAMInitOption, default zero
 return ret;
}

///allocates the specified number of bytes. returns null if this fails
void *FCEU_malloc(uint32 size)
{
 void *ret;
 ret=malloc(size);
 if(!ret)
 {
  FCEU_PrintError("Error allocating memory!");
  return(0);
 }
 memset(ret,0,size); // initialize to 0
 return ret;
}

///frees memory allocated with FCEU_gmalloc
void FCEU_gfree(void *ptr)
{
 free(ptr);
}

///frees memory allocated with FCEU_malloc
void FCEU_free(void *ptr)    // Might do something with this and FCEU_malloc later...
{
 free(ptr);
}

/**
 * Allocates a block of memory of the specified size using the standard malloc function.
 * 
 * This function is a wrapper around the standard C library function `malloc`, which allocates
 * a contiguous block of memory of the given size in bytes. The allocated memory is uninitialized,
 * meaning its contents are indeterminate until explicitly set.
 *
 * @param size The size of the memory block to allocate, in bytes.
 * @return A pointer to the beginning of the allocated memory block. If the allocation fails,
 *         the function returns a null pointer.
 *
 * @note The caller is responsible for freeing the allocated memory using `free` to avoid memory leaks.
 * @see free
 */
void *FCEU_dmalloc(uint32 size)
{
    return malloc(size);
}

/**
 * @brief Frees the memory block pointed to by `ptr`.
 * 
 * This function deallocates the memory block previously allocated by a call to `malloc`, `calloc`, or `realloc`.
 * The pointer `ptr` must point to a memory block that was allocated by one of these functions, or be `NULL`.
 * If `ptr` is `NULL`, no action is taken.
 * 
 * @param ptr Pointer to the memory block to be freed. If `ptr` is `NULL`, the function does nothing.
 * 
 * @note After the call, the memory block pointed to by `ptr` is no longer valid and should not be accessed.
 */
void FCEU_dfree(void *ptr)
{
    free(ptr);
}
