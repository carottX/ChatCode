/*
Copyright (C) 2009-2010 DeSmuME team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#include "emufile.h"

#ifdef __NO_FILE_SYSTEM__

#include "roms.h" // from $(AM_HOME)/share/games/nes/gen/

/**
 * @brief Opens a ROM file by searching for it in the available ROMs array.
 *
 * This method searches for a ROM file with the specified name (`fname`) in the `roms` array.
 * If the ROM is found, it initializes the EMUFILE_FILE object with the ROM's data, size, and name.
 * If the ROM is not found, it uses the first ROM in the array as the default and initializes the
 * object with its data, size, and name. The method also sets the file mode and initializes the
 * file position and failbit.
 *
 * @param fname The name of the ROM file to open.
 * @param mode The mode in which to open the file (e.g., "r" for read, "w" for write).
 */
void EMUFILE_FILE::open(const char* fname, const char* mode) {
  struct rom *cur = &roms[0];
  int found = 0;
  for (int i = 0; i < nroms; i++) {
    if (strcmp(roms[i].name, fname) == 0) {
      cur = &roms[i];
      found = 1;
      break;
    }
  }

  if (found) { printf("Found ROM '%s'\n", fname); }
  else { printf("ROM '%s' not found, using default ROM '%s'\n", fname, cur->name); }

  this->data = (u8 *)cur->body;
  this->filesize = (int)*(cur->size);
  this->curpos = 0;
	this->fname = cur->name;
	strcpy(this->mode,mode);
  this->failbit = false;
}

#else

/**
 * @brief Opens a file with the specified filename and mode.
 *
 * This method attempts to open a file using the provided filename and mode. 
 * If the file cannot be opened, the `failbit` flag is set to `true` to indicate 
 * a failure. The filename and mode are stored in the class's internal state 
 * for future reference.
 *
 * @param fname The name of the file to open. This is a null-terminated string 
 *              representing the file path.
 * @param mode  The mode in which to open the file. This is a null-terminated 
 *              string specifying the file access mode (e.g., "r" for read, 
 *              "w" for write, etc.).
 *
 * @note If the file cannot be opened, the `failbit` flag is set to `true`, 
 *       indicating that the operation failed. The method does not throw an 
 *       exception or return an error code; instead, the caller should check 
 *       the `failbit` flag to determine if the operation was successful.
 */
void EMUFILE_FILE::open(const char* fname, const char* mode)
{
	fp = fopen(fname,mode);
	if(!fp)
	{
    failbit = true;
	}
	this->fname = fname;
	strcpy(this->mode,mode);
}

#endif
