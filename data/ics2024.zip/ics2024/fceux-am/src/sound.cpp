/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "types.h"
#include "x6502.h"

#include "fceu.h"
#include "sound.h"
#include "filter.h"
#include "state.h"
#include "config.h"
//#include "wave.h"
//#include "debug.h"

EXPSOUND GameExpSound={0,0,0};

// APU registers:
uint8 PSG[0x10];			// $4000-$400F / Channels 1-4
uint8 DMCFormat=0;			// $4010 / Play mode and frequency
uint8 RawDALatch=0;			// $4011 / 7-bit DAC / 0xxxxxxx
uint8 DMCAddressLatch=0;	// $4012 / Start of DMC waveform is at address $C000 + $40*$xx
uint8 DMCSizeLatch=0;		// $4013 / Length of DMC waveform is $10*$xx + 1 bytes (128*$xx + 8 samples)
uint8 EnabledChannels=0;	// $4015 / Sound channels enable and status
uint8 IRQFrameMode=0;		// $4017 / Frame counter control / xx000000

uint8 InitialRawDALatch=0; // used only for lua
bool DMC_7bit = 0; // used to skip overclocking
ENVUNIT EnvUnits[3];

uint32 soundtsoffs=0;

/* Variables exclusively for low-quality sound. */
int32 nesincsize=0;
uint32 soundtsinc=0;
uint32 soundtsi=0;

#if SOUND_CONFIG != SOUND_NONE

int32 Wave[2048+512];
int32 WaveHi[40000];
int32 WaveFinal[2048+512];

/*static*/ uint8 TriCount=0;
static uint8 TriMode=0;
static int32 tristep=0;
static int32 wlcount[4]={0,0,0,0};	// Wave length counters.
static uint32 wlookup1[32];
static uint32 wlookup2[203];

static const int RectDuties[4]={1,2,4,6};

static int32 RectDutyCount[2];
static uint8 sweepon[2];
/*static*/ int32 curfreq[2];
static uint8 SweepCount[2];
static uint8 SweepReload[2];

static uint16 nreg=0;

static uint8 fcnt=0;
static int32 fhcnt=0;
static int32 fhinc=0;

static int32 sqacc[2];
/* LQ variables segment ends. */

/*static*/ int32 lengthcount[4];
static const uint8 lengthtable[0x20]=
{
  10,254, 20,  2, 40,  4, 80,  6, 160,  8, 60, 10, 14, 12, 26, 14,
  12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30
};


extern const uint32 NoiseFreqTableNTSC[0x10] =
{
  4, 8, 16, 32, 64, 96, 128, 160, 202,
  254, 380, 508, 762, 1016, 2034, 4068
};

extern const uint32 NoiseFreqTablePAL[0x10] =
{
  4, 7, 14, 30, 60, 88, 118, 148, 188,
  236, 354, 472, 708,  944, 1890, 3778
};


static const uint32 NTSCDMCTable[0x10]=
{
  428,380,340,320,286,254,226,214,
  190,160,142,128,106, 84 ,72,54
};

/* Previous values for PAL DMC was value - 1,
 * I am not certain if this is if FCEU handled
 * PAL differently or not, the NTSC values are right,
 * so I am assuming that the current value is handled
 * the same way NTSC is handled. */

static const uint32 PALDMCTable[0x10]=
{
  398, 354, 316, 298, 276, 236, 210, 198,
  176, 148, 132, 118,  98,  78,  66,  50
};

/*static*/ int32 DMCacc=1;
/*static*/ int32 DMCPeriod=0;
/*static*/ uint8 DMCBitCount=0;

static uint32 DMCAddress=0;
static int32 DMCSize=0;
static uint8 DMCShift=0;
static uint8 SIRQStat=0;

static char DMCHaveDMA=0;
static uint8 DMCDMABuf=0;
/*static*/ char DMCHaveSample=0;

static void Dummyfunc(void) {};
static void (*DoNoise)(void)=Dummyfunc;
static void (*DoTriangle)(void)=Dummyfunc;
static void (*DoPCM)(void)=Dummyfunc;
static void (*DoSQ1)(void)=Dummyfunc;
static void (*DoSQ2)(void)=Dummyfunc;

static uint32 ChannelBC[5];

//savestate sync hack stuff
int movieSyncHackOn=0,resetDMCacc=0,movieConvertOffset1,movieConvertOffset2;

#ifdef WIN32
extern volatile int datacount, undefinedcount;
extern int debug_loggingCD;
extern unsigned char *cdloggerdata;
#endif

/**
 * @brief Loads the DMC (Delta Modulation Channel) period based on the given value V.
 *
 * This method sets the DMC period by selecting the appropriate value from either the PAL or NTSC DMC period table,
 * depending on the current system's video standard. If the system is using the PAL standard, the period is taken from
 * the PALDMCTable using the index V. Otherwise, the period is taken from the NTSCDMCTable using the same index.
 *
 * @param V The index used to select the DMC period from the respective table.
 */
static void LoadDMCPeriod(uint8 V)
{
  if(PAL)
    DMCPeriod=PALDMCTable[V];
  else
    DMCPeriod=NTSCDMCTable[V];
}

/**
 * Prepares the DPCM (Delta Pulse Code Modulation) channel for playback by setting up the 
 * DMC (Delta Modulation Channel) address and size registers. 
 *
 * The DMC address is calculated by combining the base address (0x4000) with the 
 * DMCAddressLatch value shifted left by 6 bits. This determines the starting address 
 * of the DPCM sample in memory.
 *
 * The DMC size is calculated by combining the DMCSizeLatch value shifted left by 4 bits 
 * with 1. This determines the length of the DPCM sample in bytes.
 *
 * This method is typically called before initiating DPCM playback to ensure the 
 * DMC channel is properly configured.
 */
static void PrepDPCM()
{
  DMCAddress=0x4000+(DMCAddressLatch<<6);
  DMCSize=(DMCSizeLatch<<4)+1;
}

/* Instantaneous?  Maybe the new freq value is being calculated all of the time... */

/*static*/ int CheckFreq(uint32 cf, uint8 sr)
{
  uint32 mod;
  if(!(sr&0x8))
  {
    mod=cf>>(sr&7);
    if((mod+cf)&0x800)
      return(0);
  }
  return(1);
}

/**
 * @brief Reloads the square wave channel parameters based on the given values.
 *
 * This method updates the length counter, frequency, duty cycle, and envelope
 * parameters for a specific square wave channel (indexed by `x`). The channel
 * must be enabled for the length counter to be updated. The length counter is
 * set using a value derived from the provided parameter `V`. The frequency
 * of the channel is updated by combining the lower 8 bits of the current
 * frequency with the upper 3 bits from `V`. The duty cycle counter is reset
 * to 7, and the envelope unit is marked for reload.
 *
 * @param x The index of the square wave channel to update (0 or 1).
 * @param V The 8-bit value used to update the channel parameters. The upper
 *          3 bits are used to set the frequency, and bits 3-7 are used to
 *          determine the length counter value.
 */
static void SQReload(int x, uint8 V)
{
  if(EnabledChannels&(1<<x))
    lengthcount[x]=lengthtable[(V>>3)&0x1f];

  /* use the low 8 bits data from pulse period
   * instead of from the sweep period */
  /* https://forums.nesdev.com/viewtopic.php?t=219&p=1431 */
  curfreq[x]=(curfreq[x] & 0xff)|((V&7)<<8);
  RectDutyCount[x]=7;
  EnvUnits[x].reloaddec=1;
}

/**
 * @brief Writes a value to the Programmable Sound Generator (PSG) registers.
 *
 * This method handles writing a value to the PSG registers based on the address `A`.
 * The address `A` is masked to ensure it is within the valid range (0x00 to 0x1F).
 * Depending on the address, the method performs specific operations such as updating
 * envelope units, sweep settings, frequency values, and other sound-related parameters.
 * The method also ensures that the value `V` is written to the appropriate PSG register.
 *
 * @param A The address of the PSG register to write to. This value is masked to 0x1F.
 * @param V The value to write to the specified PSG register.
 *
 * @details The method supports the following operations based on the address `A`:
 * - 0x0: Updates the envelope mode and speed for Square Wave 1, optionally swaps duty cycle.
 * - 0x1: Enables or disables sweep for Square Wave 1 and reloads sweep settings.
 * - 0x2: Updates the lower byte of the frequency for Square Wave 1.
 * - 0x3: Reloads Square Wave 1 with the specified value.
 * - 0x4: Updates the envelope mode and speed for Square Wave 2, optionally swaps duty cycle.
 * - 0x5: Enables or disables sweep for Square Wave 2 and reloads sweep settings.
 * - 0x6: Updates the lower byte of the frequency for Square Wave 2.
 * - 0x7: Reloads Square Wave 2 with the specified value.
 * - 0xA: Triggers the Triangle Wave channel.
 * - 0xB: Sets the length counter for the Triangle Wave channel and updates its mode.
 * - 0xC: Updates the envelope mode and speed for the Noise channel.
 * - 0xE: Triggers the Noise channel.
 * - 0xF: Sets the length counter for the Noise channel and reloads the envelope.
 * - 0x10: Updates the PCM channel and handles IRQ status based on the value.
 *
 * After performing the necessary operations, the value `V` is stored in the PSG register at address `A`.
 */
static DECLFW(Write_PSG)
{
  A&=0x1F;
  switch(A)
  {
    case 0x0:
      DoSQ1();
      EnvUnits[0].Mode=(V&0x30)>>4;
      EnvUnits[0].Speed=(V&0xF);
      if (swapDuty)
        V = (V&0x3F)|((V&0x80)>>1)|((V&0x40)<<1);
      break;
    case 0x1:
      DoSQ1();
      sweepon[0]=V&0x80;
      SweepReload[0]=1;
      break;
    case 0x2:
      DoSQ1();
      curfreq[0]&=0xFF00;
      curfreq[0]|=V;
      break;
    case 0x3:
      DoSQ1();
      SQReload(0,V);
      break;
    case 0x4:
      DoSQ2();
      EnvUnits[1].Mode=(V&0x30)>>4;
      EnvUnits[1].Speed=(V&0xF);
      if (swapDuty)
        V = (V&0x3F)|((V&0x80)>>1)|((V&0x40)<<1);
      break;
    case 0x5:
      DoSQ2();
      sweepon[1]=V&0x80;
      SweepReload[1]=1;
      break;
    case 0x6:
      DoSQ2();
      curfreq[1]&=0xFF00;
      curfreq[1]|=V;
      break;
    case 0x7:
      DoSQ2();
      SQReload(1,V);
      break;
    case 0xa:
      DoTriangle();
      break;
    case 0xb:
      DoTriangle();
      if(EnabledChannels&0x4)
        lengthcount[2]=lengthtable[(V>>3)&0x1f];
      TriMode=1;	// Load mode
      break;
    case 0xC:
      DoNoise();
      EnvUnits[2].Mode=(V&0x30)>>4;
      EnvUnits[2].Speed=(V&0xF);
      break;
    case 0xE:
      DoNoise();
      break;
    case 0xF:
      DoNoise();
      if(EnabledChannels&0x8)
        lengthcount[3]=lengthtable[(V>>3)&0x1f];
      EnvUnits[2].reloaddec=1;
      break;
    case 0x10:
      DoPCM();
      LoadDMCPeriod(V&0xF);
      if(SIRQStat&0x80)
      {
        if(!(V&0x80))
        {
          X6502_IRQEnd(FCEU_IQDPCM);
          SIRQStat&=~0x80;
        }
        else X6502_IRQBegin(FCEU_IQDPCM);
      }
      break;
  }
  PSG[A]=V;
}

/**
 * @brief Writes to the Delta Modulation Channel (DMC) registers based on the address `A`.
 *
 * This method handles writing to the DMC registers, which control the behavior of the DMC
 * in an NES emulator. The method processes the value `V` based on the address `A` (masked to 4 bits).
 * The following actions are performed based on the value of `A`:
 * - `0x00`: Configures the DMC period and IRQ settings. If the IRQ flag is set, it either begins or
 *           ends an IRQ based on the value of `V`. The DMC format is also updated.
 * - `0x01`: Updates the initial raw DAC latch value and the current raw DAC latch. If the value is
 *           non-zero, the DMC is set to 7-bit mode.
 * - `0x02`: Updates the DMC address latch. If the value is non-zero, the DMC is set to non-7-bit mode.
 * - `0x03`: Updates the DMC size latch. If the value is non-zero, the DMC is set to non-7-bit mode.
 *
 * @param A The address of the DMC register to write to (masked to 4 bits).
 * @param V The value to write to the specified DMC register.
 */
static DECLFW(Write_DMCRegs)
{
  A&=0xF;

  switch(A)
  {
    case 0x00:
      DoPCM();
      LoadDMCPeriod(V&0xF);

      if(SIRQStat&0x80)
      {
        if(!(V&0x80))
        {
          X6502_IRQEnd(FCEU_IQDPCM);
          SIRQStat&=~0x80;
        }
        else X6502_IRQBegin(FCEU_IQDPCM);
      }
      DMCFormat=V;
      break;
    case 0x01:
      DoPCM();
      InitialRawDALatch=V&0x7F;
      RawDALatch=InitialRawDALatch;
      if (RawDALatch)
        DMC_7bit = 1;
      break;
    case 0x02:
      DMCAddressLatch=V;
      if (V)
        DMC_7bit = 0;
      break;
    case 0x03:
      DMCSizeLatch=V;
      if (V)
        DMC_7bit = 0;
      break;
  }
}

/**
 * @brief Writes the status of the audio channels and updates their state.
 *
 * This method is responsible for updating the state of the audio channels based on the value `V`.
 * It performs the following operations:
 * 1. Calls the necessary functions to update the state of the square wave channels (DoSQ1, DoSQ2),
 *    the triangle wave channel (DoTriangle), the noise channel (DoNoise), and the PCM channel (DoPCM).
 * 2. Iterates through the first four channels and forces their length counters to 0 if the corresponding bit in `V` is not set.
 * 3. Checks if the DPCM (Delta Modulation Channel) is enabled (bit 4 of `V` is set). If enabled and the DPCM size is 0, it prepares the DPCM channel for playback.
 *    If disabled, it sets the DPCM size to 0.
 * 4. Clears the SIRQ (Sound IRQ) status bit and ends the IRQ (Interrupt Request) for the DPCM channel.
 * 5. Updates the enabled channels based on the lower 5 bits of `V`.
 *
 * @param V The value used to determine the state of the audio channels and DPCM.
 */
static DECLFW(StatusWrite)
{
  int x;

  DoSQ1();
  DoSQ2();
  DoTriangle();
  DoNoise();
  DoPCM();

  for(x=0;x<4;x++)
    if(!(V&(1<<x))) lengthcount[x]=0;   /* Force length counters to 0. */

  if(V&0x10)
  {
    if(!DMCSize)
      PrepDPCM();
  }
  else
  {
    DMCSize=0;
  }
  SIRQStat&=~0x80;
  X6502_IRQEnd(FCEU_IQDPCM);
  EnabledChannels=V&0x1F;
}

/**
 * @brief Reads and returns the status of the sound and IRQ (Interrupt Request) registers.
 *
 * This method reads the current status of the sound and IRQ registers and combines them into a single return value.
 * The status is determined by the following:
 * - The current value of the SIRQStat register.
 * - The state of the length counters for each of the four sound channels. If a length counter is non-zero, the corresponding bit in the return value is set.
 * - The state of the DMC (Delta Modulation Channel) size. If the DMC size is non-zero, bit 4 of the return value is set.
 *
 * Additionally, if the code is not running in a debugger (as determined by the FCEUDEF_DEBUGGER macro), the method clears bit 6 of the SIRQStat register and ends the IRQ on the 6502 CPU.
 *
 * @return uint8 The combined status of the sound and IRQ registers.
 */
static DECLFR(StatusRead)
{
  int x;
  uint8 ret;

  ret=SIRQStat;

  for(x=0;x<4;x++) ret|=lengthcount[x]?(1<<x):0;
  if(DMCSize) ret|=0x10;

#ifdef FCEUDEF_DEBUGGER
  if(!fceuindbg)
#endif
  {
    SIRQStat&=~0x40;
    X6502_IRQEnd(FCEU_IQFCOUNT);
  }
  return ret;
}

/**
 * @brief Processes sound-related operations for a single frame in an NES APU (Audio Processing Unit) emulation.
 *
 * This method handles various sound channel updates, including envelope decay, linear counter, length counter, 
 * and frequency sweep operations. It also manages the triangle channel's linear counter and the envelope decay 
 * for the square and noise channels.
 *
 * The method performs the following operations:
 * 1. Calls sound generation functions for the square channels (DoSQ1, DoSQ2), noise channel (DoNoise), 
 *    and triangle channel (DoTriangle).
 * 2. Checks the frame counter value `V` to determine if envelope decay, linear counter, length counter, 
 *    and frequency sweep operations should be performed.
 * 3. Updates length counters for the square and noise channels if their loop flags are not set.
 * 4. Handles frequency sweep operations for the square channels, adjusting their frequencies based on 
 *    the sweep parameters.
 * 5. Manages the triangle channel's linear counter and mode.
 * 6. Processes envelope decay for the square and noise channels, updating their decay volumes and counters.
 *
 * @param V The frame counter value, used to determine which operations to perform (e.g., envelope decay, 
 *          frequency sweep). The least significant bit of `V` controls whether certain operations are executed.
 */
static void FrameSoundStuff(int V)
{
  int P;

  DoSQ1();
  DoSQ2();
  DoNoise();
  DoTriangle();

  if(!(V&1)) /* Envelope decay, linear counter, length counter, freq sweep */
  {
    if(!(PSG[8]&0x80))
      if(lengthcount[2]>0)
        lengthcount[2]--;

    if(!(PSG[0xC]&0x20))  /* Make sure loop flag is not set. */
      if(lengthcount[3]>0)
        lengthcount[3]--;

    for(P=0;P<2;P++)
    {
      if(!(PSG[P<<2]&0x20))  /* Make sure loop flag is not set. */
        if(lengthcount[P]>0)
          lengthcount[P]--;

      /* Frequency Sweep Code Here */
      /* xxxx 0000 */
      /* xxxx = hz.  120/(x+1)*/
      /* http://wiki.nesdev.com/w/index.php/APU_Sweep */
      /* https://forums.nesdev.com/viewtopic.php?t=219&p=1431 */
      if (SweepCount[P] > 0) SweepCount[P]--;
      if (SweepCount[P] <= 0)
      {
        int sweepShift = (PSG[(P << 2) + 0x1] & 7);
        if (sweepon[P] && sweepShift && curfreq[P] >= 8)
        {
          int32 mod = (curfreq[P] >> sweepShift);
          if (PSG[(P << 2) + 0x1] & 0x8)
            curfreq[P] -= (mod + (P ^ 1));
          else if ((mod + curfreq[P]) < 0x800)
            curfreq[P] += mod;
        }

        SweepCount[P] = (((PSG[(P << 2) + 0x1] >> 4) & 7) + 1);
      }

      if (SweepReload[P])
      {
        SweepCount[P] = (((PSG[(P << 2) + 0x1] >> 4) & 7) + 1);
        SweepReload[P] = 0;
      }
    }
  }

  /* Now do envelope decay + linear counter. */

  if(TriMode) // In load mode?
    TriCount=PSG[0x8]&0x7F;
  else if(TriCount)
    TriCount--;

  if(!(PSG[0x8]&0x80))
    TriMode=0;

  for(P=0;P<3;P++)
  {
    if(EnvUnits[P].reloaddec)
    {
      EnvUnits[P].decvolume=0xF;
      EnvUnits[P].DecCountTo1=EnvUnits[P].Speed+1;
      EnvUnits[P].reloaddec=0;
      continue;
    }

    if(EnvUnits[P].DecCountTo1>0) EnvUnits[P].DecCountTo1--;
    if(EnvUnits[P].DecCountTo1==0)
    {
      EnvUnits[P].DecCountTo1=EnvUnits[P].Speed+1;
      if(EnvUnits[P].decvolume || (EnvUnits[P].Mode&0x2))
      {
        EnvUnits[P].decvolume--;
        EnvUnits[P].decvolume&=0xF;
      }
    }
  }
}

/**
 * @brief Updates the frame sound state for the audio processing system.
 * 
 * This method is responsible for handling the frame sound update logic, which includes
 * managing the linear counter, length counter, and IRQ (Interrupt Request) frame mode.
 * It checks the frame counter (fcnt) and performs specific actions based on its value:
 * - If the frame counter is zero and the IRQ frame mode is not active, it sets the SIRQStat
 *   flag and triggers an IRQ using the X6502_IRQBegin function.
 * - If the frame counter is 3 and the IRQ frame mode is set to a specific value, it increments
 *   the frame high counter (fhcnt) by the frame high increment (fhinc).
 * 
 * After handling the frame counter logic, it calls the FrameSoundStuff function to process
 * the current frame counter state. Finally, it increments the frame counter and wraps it
 * around to 0 if it exceeds 3.
 * 
 * @note This method is typically called during the audio processing cycle to ensure proper
 * synchronization of sound effects and music with the frame timing.
 */
void FrameSoundUpdate(void)
{
  // Linear counter:  Bit 0-6 of $4008
  // Length counter:  Bit 4-7 of $4003, $4007, $400b, $400f

  if(!fcnt && !(IRQFrameMode&0x3))
  {
    SIRQStat|=0x40;
    X6502_IRQBegin(FCEU_IQFCOUNT);
  }

  if(fcnt==3)
  {
    if(IRQFrameMode&0x2)
      fhcnt+=fhinc;
  }
  FrameSoundStuff(fcnt);
  fcnt=(fcnt+1)&3;
}


/**
 * @brief Checks the state of DMC (Delta Modulation Channel) bit count and updates 
 *        the sample and DMA buffer accordingly.
 *
 * This method is a static inline function that evaluates the current state of the 
 * DMC bit count. If the bit count is zero, it further checks whether a DMA transfer 
 * is available. If no DMA transfer is available, it sets the `DMCHaveSample` flag to 0, 
 * indicating no sample is available. If a DMA transfer is available, it sets the 
 * `DMCHaveSample` flag to 1, indicating a sample is available, and updates the `DMCShift` 
 * buffer with the DMA data. It also resets the `DMCHaveDMA` flag to 0 to indicate that 
 * the DMA transfer has been processed.
 */
static INLINE void tester(void)
{
  if(DMCBitCount==0)
  {
    if(!DMCHaveDMA)
      DMCHaveSample=0;
    else
    {
      DMCHaveSample=1;
      DMCShift=DMCDMABuf;
      DMCHaveDMA=0;
    }
  }
}

/**
 * @brief Performs Direct Memory Access (DMA) for the Delta Modulation Channel (DMC).
 *
 * This method handles the DMA process for the DMC by reading data from the memory
 * location specified by `DMCAddress` and storing it in the `DMCDMABuf` buffer.
 * The method checks if DMA is needed by verifying that `DMCSize` is non-zero and
 * `DMCHaveDMA` is false. If DMA is required, it reads four bytes from the memory
 * location, updates the `DMCAddress`, decrements `DMCSize`, and sets `DMCHaveDMA`
 * to indicate that DMA has been performed. If `DMCSize` reaches zero, the method
 * checks the `DMCFormat` to determine whether to prepare for DPCM playback or
 * trigger an IRQ (Interrupt Request) if the appropriate flags are set.
 */
static INLINE void DMCDMA(void)
{
  if(DMCSize && !DMCHaveDMA)
  {
    X6502_DMR(0x8000+DMCAddress);
    X6502_DMR(0x8000+DMCAddress);
    X6502_DMR(0x8000+DMCAddress);
    DMCDMABuf=X6502_DMR(0x8000+DMCAddress);
    DMCHaveDMA=1;
    DMCAddress=(DMCAddress+1)&0x7fff;
    DMCSize--;
    if(!DMCSize)
    {
      if(DMCFormat&0x40)
        PrepDPCM();
      else
      {
        SIRQStat|=0x80;
        if(DMCFormat&0x80)
          X6502_IRQBegin(FCEU_IQDPCM);
      }
    }
  }
}

/**
 * @brief Processes sound-related CPU operations for a given number of cycles.
 *
 * This method handles sound processing based on the number of CPU cycles provided.
 * If the sound configuration is not set to high quality (SOUND_HQ), the method
 * immediately returns without performing any operations. Otherwise, it updates
 * the sound frame counter (`fhcnt`) by subtracting the equivalent sound cycles.
 * If the counter reaches or falls below zero, it triggers a frame sound update
 * (`FrameSoundUpdate`) and resets the counter using the increment value (`fhinc`).
 *
 * The method also processes Delta Modulation Channel (DMC) operations:
 * - Decrements the DMC accumulator (`DMCacc`) by the number of cycles.
 * - If the accumulator reaches or falls below zero, it processes a DMC sample:
 *   - Adjusts the sound timestamp offset (`soundtsoffs`) based on the accumulator.
 *   - Performs PCM sound processing (`DoPCM`).
 *   - Updates the raw D/A latch (`RawDALatch`) based on the DMC shift register.
 *   - Resets the accumulator using the DMC period (`DMCPeriod`).
 *   - Updates the DMC bit count and shifts the DMC shift register.
 *   - Calls a tester function (`tester`) for additional processing.
 *
 * @param cycles The number of CPU cycles to process for sound operations.
 */
void FCEU_SoundCPUHook(int cycles)
{
#if SOUND_CONFIG != SOUND_HQ
  return;
#endif

  fhcnt-=cycles*48;
  if(fhcnt<=0)
  {
    FrameSoundUpdate();
    fhcnt+=fhinc;
  }

  DMCDMA();
  DMCacc-=cycles;

  while(DMCacc<=0)
  {
    if(DMCHaveSample)
    {
      uint8 bah=RawDALatch;
      int t=((DMCShift&1)<<2)-2;

      /* Unbelievably ugly hack */
      if(FSettings.SndRate)
      {
        soundtsoffs+=DMCacc;
        DoPCM();
        soundtsoffs-=DMCacc;
      }
      RawDALatch+=t;
      if(RawDALatch&0x80)
        RawDALatch=bah;
    }

    DMCacc+=DMCPeriod;
    DMCBitCount=(DMCBitCount+1)&7;
    DMCShift>>=1;
    tester();
  }
}

/**
 * @brief Processes PCM audio data and updates the WaveHi buffer.
 *
 * This method calculates a PCM audio value based on the current RawDALatch and PCMVolume settings,
 * then applies this value to the WaveHi buffer for a specified range of samples. The method ensures
 * that the audio data is processed only for the current sound time slice (SOUNDTS) and updates the
 * ChannelBC[4] index to reflect the processed samples.
 *
 * The PCM audio value is derived by shifting the RawDALatch left by 16 bits, dividing it by 256,
 * multiplying it by the PCMVolume setting, and masking off the lower 16 bits. This value is then
 * added to the WaveHi buffer for each sample in the range from ChannelBC[4] to SOUNDTS.
 *
 * @note This method assumes that RawDALatch, FSettings.PCMVolume, ChannelBC, SOUNDTS, and WaveHi
 *       are properly initialized and accessible within the scope of the method.
 */
void RDoPCM(void)
{
  uint32 V; //mbg merge 7/17/06 made uint32

  uint32_t val = (((RawDALatch<<16)/256) * FSettings.PCMVolume)&(~0xFFFF);
  for(V=ChannelBC[4];V<SOUNDTS;V++)
    WaveHi[V]+=val;
  ChannelBC[4]=SOUNDTS;
}

/* This has the correct phase.  Don't mess with it. */
static INLINE void RDoSQ(int x)		//Int x decides if this is Square Wave 1 or 2
{
  int32 V;
  int32 amp, ampx;
  int32 rthresh;
  int32 *D;
  int32 currdc;
  int32 cf;
  int32 rc;

  if(curfreq[x]<8 || curfreq[x]>0x7ff)
    goto endit;
  if(!CheckFreq(curfreq[x],PSG[(x<<2)|0x1]))
    goto endit;
  if(!lengthcount[x])
    goto endit;

  if(EnvUnits[x].Mode&0x1)
    amp=EnvUnits[x].Speed;
  else
    amp=EnvUnits[x].decvolume;	//Set the volume of the Square Wave

  //Modify Square wave volume based on channel volume modifiers
  //adelikat: Note: the formulat x = x * y /100 does not yield exact results, but is "close enough" and avoids the need for using double vales or implicit cohersion which are slower (we need speed here)
  ampx = x ? FSettings.Square2Volume : FSettings.Square1Volume; // TODO OPTIMIZE ME!
  if (ampx != 256) amp = (amp * ampx) / 256; // CaH4e3: fixed - setting up maximum volume for square2 caused complete mute square2 channel

  amp<<=24;

  rthresh=RectDuties[(PSG[(x<<2)]&0xC0)>>6];

  D=&WaveHi[ChannelBC[x]];
  V=SOUNDTS-ChannelBC[x];

  currdc=RectDutyCount[x];
  cf=(curfreq[x]+1)*2;
  rc=wlcount[x];

  while(V>0)
  {
    if(currdc<rthresh)
      *D+=amp;
    rc--;
    if(!rc)
    {
      rc=cf;
      currdc=(currdc+1)&7;
    }
    V--;
    D++;
  }

  RectDutyCount[x]=currdc;
  wlcount[x]=rc;

endit:
  ChannelBC[x]=SOUNDTS;
}

/**
 * @brief Executes the RDoSQ function with a predefined parameter value.
 *
 * This static method is a wrapper for the RDoSQ function, which it calls with
 * a fixed parameter value of 0. The purpose of this method is to provide a 
 * simplified interface for invoking RDoSQ with a specific configuration or 
 * default behavior, as determined by the parameter value.
 *
 * @note The exact behavior of RDoSQ is implementation-dependent and should be 
 * documented in the RDoSQ function's documentation.
 */
static void RDoSQ1(void)
{
  RDoSQ(0);
}

/**
 * @brief Executes the RDoSQ algorithm with a fixed parameter value of 1.
 *
 * This method is a static wrapper that calls the `RDoSQ` function, passing the integer value 1 as its argument. 
 * It is typically used to simplify the invocation of `RDoSQ` when the parameter is known to be 1, avoiding the need 
 * to explicitly specify the parameter in the calling code.
 */
static void RDoSQ2(void)
{
  RDoSQ(1);
}

/**
 * @brief Processes and updates the sound wave output for two square wave channels.
 *
 * This method calculates the sound wave output for two square wave channels based on their
 * current frequency, duty cycle, and volume settings. It updates the wave buffer with the
 * combined output of both channels. The method handles the following steps:
 *
 * 1. Determines the start and end positions in the wave buffer to update.
 * 2. Checks the validity of the frequency and envelope settings for each channel.
 * 3. Adjusts the amplitude (volume) of each channel based on global volume settings.
 * 4. Generates a duty cycle table for each channel based on the current duty cycle setting.
 * 5. Combines the output of both channels and updates the wave buffer.
 * 6. Handles the accumulation and wrapping of the duty cycle counters for each channel.
 *
 * The method ensures that the wave buffer is updated efficiently, avoiding unnecessary
 * calculations when both channels are inactive. It also handles edge cases such as
 * invalid frequencies or inactive channels to prevent artifacts in the output.
 */
static void RDoSQLQ(void)
{
  int32 start,end;
  int32 V;
  int32 amp[2], ampx;
  int32 rthresh[2];
  int32 freq[2];
  int x;
  int32 inie[2];

  int32 ttable[2][8];
  int32 totalout;

  start=ChannelBC[0];
  end=(SOUNDTS<<16)/soundtsinc;
  if(end<=start) return;
  ChannelBC[0]=end;

  for(x=0;x<2;x++)
  {
    int y;

    inie[x]=nesincsize;
    if(curfreq[x]<8 || curfreq[x]>0x7ff)
      inie[x]=0;
    if(!CheckFreq(curfreq[x],PSG[(x<<2)|0x1]))
      inie[x]=0;
    if(!lengthcount[x])
      inie[x]=0;

    if(EnvUnits[x].Mode&0x1)
      amp[x]=EnvUnits[x].Speed;
    else
      amp[x]=EnvUnits[x].decvolume;

    //Modify Square wave volume based on channel volume modifiers
    //adelikat: Note: the formulat x = x * y /100 does not yield exact results, but is "close enough" and avoids the need for using double vales or implicit cohersion which are slower (we need speed here)
    ampx = x ? FSettings.Square1Volume : FSettings.Square2Volume;  // TODO OPTIMIZE ME!
    if (ampx != 256) amp[x] = (amp[x] * ampx) / 256; // CaH4e3: fixed - setting up maximum volume for square2 caused complete mute square2 channel

    if(!inie[x]) amp[x]=0;    /* Correct? Buzzing in MM2, others otherwise... */

    rthresh[x]=RectDuties[(PSG[x*4]&0xC0)>>6];

    for(y=0;y<8;y++)
    {
      if(y < rthresh[x])
        ttable[x][y] = amp[x];
      else
        ttable[x][y] = 0;
    }
    freq[x]=(curfreq[x]+1)<<1;
    freq[x]<<=17;
  }

  totalout = wlookup1[ ttable[0][RectDutyCount[0]] + ttable[1][RectDutyCount[1]] ];

  if(!inie[0] && !inie[1])
  {
    for(V=start;V<end;V++)
      Wave[V>>4]+=totalout;
  }
  else
    for(V=start;V<end;V++)
    {
      //int tmpamp=0;
      //if(RectDutyCount[0]<rthresh[0])
      // tmpamp=amp[0];
      //if(RectDutyCount[1]<rthresh[1])
      // tmpamp+=amp[1];
      //tmpamp=wlookup1[tmpamp];
      //tmpamp = wlookup1[ ttable[0][RectDutyCount[0]] + ttable[1][RectDutyCount[1]] ];

      Wave[V>>4]+=totalout; //tmpamp;

      sqacc[0]-=inie[0];
      sqacc[1]-=inie[1];

      if(sqacc[0]<=0)
      {
rea:
        sqacc[0]+=freq[0];
        RectDutyCount[0]=(RectDutyCount[0]+1)&7;
        if(sqacc[0]<=0) goto rea;
        totalout = wlookup1[ ttable[0][RectDutyCount[0]] + ttable[1][RectDutyCount[1]] ];
      }

      if(sqacc[1]<=0)
      {
rea2:
        sqacc[1]+=freq[1];
        RectDutyCount[1]=(RectDutyCount[1]+1)&7;
        if(sqacc[1]<=0) goto rea2;
        totalout = wlookup1[ ttable[0][RectDutyCount[0]] + ttable[1][RectDutyCount[1]] ];
      }
    }
}

/**
 * @brief Renders a triangle wave for the audio channel.
 *
 * This method generates a triangle wave for the audio channel by modifying the `WaveHi` buffer.
 * The triangle wave is generated based on the current state of the triangle wave generator,
 * which is controlled by the `tristep` variable. The volume of the triangle wave is adjusted
 * according to the `FSettings.TriangleVolume` setting.
 *
 * The method handles two scenarios:
 * 1. If the counter is halted (i.e., `lengthcount[2]` or `TriCount` is zero), the method still
 *    outputs the triangle wave by adding the computed volume to the `WaveHi` buffer for the
 *    current sound timestamp (`SOUNDTS`).
 * 2. If the counter is active, the method iterates through the `WaveHi` buffer, updating the
 *    volume based on the current `tristep` value. The `wlcount[2]` variable is decremented
 *    on each iteration, and when it reaches zero, the `tristep` is incremented to generate
 *    the next step of the triangle wave.
 *
 * Finally, the method updates the `ChannelBC[2]` to the current sound timestamp (`SOUNDTS`).
 */
static void RDoTriangle(void)
{
  uint32 V; //mbg merge 7/17/06 made uitn32
  int32 tcout;

  tcout=(tristep&0xF);
  if(!(tristep&0x10)) tcout^=0xF;
  tcout=(tcout*3) << 16;  //(tcout<<1);

  if(!lengthcount[2] || !TriCount)
  {           /* Counter is halted, but we still need to output. */
    /*int32 *start = &WaveHi[ChannelBC[2]];
      int32 count = SOUNDTS - ChannelBC[2];
      while(count--)
      {
    //Modify volume based on channel volume modifiers
     *start += (tcout/256*FSettings.TriangleVolume)&(~0xFFFF);  // TODO OPTIMIZE ME NOW DAMMIT!
     start++;
     }*/
    int32 cout = (tcout/256*FSettings.TriangleVolume)&(~0xFFFF);
    for(V=ChannelBC[2];V<SOUNDTS;V++)
      WaveHi[V]+=cout;
  }
  else
    for(V=ChannelBC[2];V<SOUNDTS;V++)
    {
      //Modify volume based on channel volume modifiers
      WaveHi[V]+=(tcout/256*FSettings.TriangleVolume)&(~0xFFFF);  // TODO OPTIMIZE ME!
      wlcount[2]--;
      if(!wlcount[2])
      {
        wlcount[2]=(PSG[0xa]|((PSG[0xb]&7)<<8))+1;
        tristep++;
        tcout=(tristep&0xF);
        if(!(tristep&0x10)) tcout^=0xF;
        tcout=(tcout*3) << 16;
      }
    }

  ChannelBC[2]=SOUNDTS;
}

/**
 * @brief Generates a combined triangle wave and noise signal using PCM (Pulse Code Modulation) with low-quality (LQ) processing.
 * 
 * This method synthesizes a waveform by combining a triangle wave and a noise signal. The triangle wave is generated based on
 * the frequency and amplitude settings from the PSG (Programmable Sound Generator) registers. The noise signal is generated
 * using a linear feedback shift register (LFSR) with configurable frequency and shift settings. The method processes the waveform
 * in chunks defined by the `start` and `end` parameters, which are derived from the sound timestamp and increment values.
 * 
 * The triangle wave is modulated by the triangle channel's volume settings, and the noise signal is modulated by the noise channel's
 * volume settings. The final output is a combination of the triangle wave and noise signal, which is added to the `Wave` buffer.
 * 
 * The method handles three cases:
 * 1. Both the triangle wave and noise signal are active.
 * 2. Only the triangle wave is active.
 * 3. Only the noise signal is active.
 * 
 * The processing is optimized for speed, with some approximations used in volume calculations to avoid slower floating-point operations.
 * 
 * @note This method is part of a sound synthesis system and is designed to be called periodically to update the sound waveform.
 */
static void RDoTriangleNoisePCMLQ(void)
{
  static uint32 tcout=0;
  static int32 triacc=0;
  static int32 noiseacc=0;

  int32 V;
  int32 start,end;
  int32 freq[2];
  int32 inie[2];
  uint32 amptab[2];
  uint32 noiseout;
  int nshift;

  int32 totalout;

  start=ChannelBC[2];
  end=(SOUNDTS<<16)/soundtsinc;
  if(end<=start) return;
  ChannelBC[2]=end;

  inie[0]=inie[1]=nesincsize;

  freq[0]=(((PSG[0xa]|((PSG[0xb]&7)<<8))+1));

  if(!lengthcount[2] || !TriCount || freq[0]<=4)
    inie[0]=0;

  freq[0]<<=17;
  if(EnvUnits[2].Mode&0x1)
    amptab[0]=EnvUnits[2].Speed;
  else
    amptab[0]=EnvUnits[2].decvolume;

  //Modify Square wave volume based on channel volume modifiers
  //adelikat: Note: the formulat x = x * y /100 does not yield exact results, but is "close enough" and avoids the need for using double vales or implicit cohersion which are slower (we need speed here)
  if (FSettings.TriangleVolume != 256) amptab[0] = (amptab[0] * FSettings.TriangleVolume) / 256;  // TODO OPTIMIZE ME!

  amptab[1]=0;
  amptab[0]<<=1;

  if(!lengthcount[3])
    amptab[0]=inie[1]=0;  /* Quick hack speedup, set inie[1] to 0 */

  noiseout=amptab[(nreg>>0xe)&1];

  if(PSG[0xE]&0x80)
    nshift=8;
  else
    nshift=13;


  totalout = wlookup2[tcout+noiseout+RawDALatch];

  if(inie[0] && inie[1])
  {
    for(V=start;V<end;V++)
    {
      Wave[V>>4]+=totalout;

      triacc-=inie[0];
      noiseacc-=inie[1];

      if(triacc<=0)
      {
rea:
        triacc+=freq[0]; //t;
        tristep=(tristep+1)&0x1F;
        if(triacc<=0) goto rea;
        tcout=(tristep&0xF);
        if(!(tristep&0x10)) tcout^=0xF;
        tcout=tcout*3;
        totalout = wlookup2[tcout+noiseout+RawDALatch];
      }

      if(noiseacc<=0)
      {
rea2:
        //used to added <<(16+2) when the noise table
        //values were half.
        if(PAL)
          noiseacc+=NoiseFreqTablePAL[PSG[0xE]&0xF]<<(16+1);
        else
          noiseacc+=NoiseFreqTableNTSC[PSG[0xE]&0xF]<<(16+1);
        nreg=(nreg<<1)+(((nreg>>nshift)^(nreg>>14))&1);
        nreg&=0x7fff;
        noiseout=amptab[(nreg>>0xe)&1];
        if(noiseacc<=0) goto rea2;
        totalout = wlookup2[tcout+noiseout+RawDALatch];
      } /* noiseacc<=0 */
    } /* for(V=... */
  }
  else if(inie[0])
  {
    for(V=start;V<end;V++)
    {
      Wave[V>>4]+=totalout;

      triacc-=inie[0];

      if(triacc<=0)
      {
area:
        triacc+=freq[0]; //t;
        tristep=(tristep+1)&0x1F;
        if(triacc<=0) goto area;
        tcout=(tristep&0xF);
        if(!(tristep&0x10)) tcout^=0xF;
        tcout=tcout*3;
        totalout = wlookup2[tcout+noiseout+RawDALatch];
      }
    }
  }
  else if(inie[1])
  {
    for(V=start;V<end;V++)
    {
      Wave[V>>4]+=totalout;
      noiseacc-=inie[1];
      if(noiseacc<=0)
      {
area2:
        //used to be added <<(16+2) when the noise table
        //values were half.
        if(PAL)
          noiseacc+=NoiseFreqTablePAL[PSG[0xE]&0xF]<<(16+1);
        else
          noiseacc+=NoiseFreqTableNTSC[PSG[0xE]&0xF]<<(16+1);
        nreg=(nreg<<1)+(((nreg>>nshift)^(nreg>>14))&1);
        nreg&=0x7fff;
        noiseout=amptab[(nreg>>0xe)&1];
        if(noiseacc<=0) goto area2;
        totalout = wlookup2[tcout+noiseout+RawDALatch];
      } /* noiseacc<=0 */
    }
  }
  else
  {
    for(V=start;V<end;V++)
      Wave[V>>4]+=totalout;
  }
}


/**
 * @brief Processes and applies noise channel audio data to the output waveform.
 *
 * This method calculates the noise channel's audio output based on the current state of the noise generator,
 * envelope settings, and volume adjustments. It modifies the output waveform buffer (`WaveHi`) by adding the
 * computed noise signal. The noise signal is generated using a linear feedback shift register (LFSR) to produce
 * pseudo-random values, which are then scaled by the envelope and volume settings.
 *
 * The method handles two types of noise generation:
 * 1. "Short" noise: Uses a specific feedback pattern for the LFSR, producing a higher-pitched noise.
 * 2. Regular noise: Uses a different feedback pattern, producing a lower-pitched noise.
 *
 * The noise frequency is determined by the `NoiseFreqTablePAL` or `NoiseFreqTableNTSC` tables, depending on the
 * system's video standard (PAL or NTSC). The method also checks the length counter to determine if the noise
 * channel should be muted.
 *
 * The volume of the noise channel is adjusted based on the global noise volume setting (`FSettings.NoiseVolume`),
 * which scales the output amplitude. The final output is added to the waveform buffer for each sample in the
 * current audio frame.
 *
 * @note The method avoids using floating-point arithmetic for performance reasons, relying on integer operations
 * and bitwise shifts instead. This ensures efficient execution, which is critical for real-time audio processing.
 */
static void RDoNoise(void)
{
  uint32 V; //mbg merge 7/17/06 made uint32
  int32 outo;
  uint32 amptab[2];

  if(EnvUnits[2].Mode&0x1)
    amptab[0]=EnvUnits[2].Speed;
  else
    amptab[0]=EnvUnits[2].decvolume;

  //Modfiy Noise channel volume based on channel volume setting
  //adelikat: Note: the formulat x = x * y /100 does not yield exact results, but is "close enough" and avoids the need for using double vales or implicit cohersion which are slower (we need speed here)
  if (FSettings.NoiseVolume != 256) amptab[0] = (amptab[0] * FSettings.NoiseVolume) / 256;  // TODO OPTIMIZE ME!
  amptab[0]<<=16;
  amptab[1]=0;

  amptab[0]<<=1;

  outo=amptab[(nreg>>0xe)&1];

  if(!lengthcount[3])
  {
    outo=amptab[0]=0;
  }

  if(PSG[0xE]&0x80)  // "short" noise
    for(V=ChannelBC[3];V<SOUNDTS;V++)
    {
      WaveHi[V]+=outo;
      wlcount[3]--;
      if(!wlcount[3])
      {
        uint8 feedback;
        if(PAL)
          wlcount[3]=NoiseFreqTablePAL[PSG[0xE]&0xF];
        else
          wlcount[3]=NoiseFreqTableNTSC[PSG[0xE]&0xF];
        feedback=((nreg>>8)&1)^((nreg>>14)&1);
        nreg=(nreg<<1)+feedback;
        nreg&=0x7fff;
        outo=amptab[(nreg>>0xe)&1];
      }
    }
  else
    for(V=ChannelBC[3];V<SOUNDTS;V++)
    {
      WaveHi[V]+=outo;
      wlcount[3]--;
      if(!wlcount[3])
      {
        uint8 feedback;
        if(PAL)
          wlcount[3]=NoiseFreqTablePAL[PSG[0xE]&0xF];
        else
          wlcount[3]=NoiseFreqTableNTSC[PSG[0xE]&0xF];
        feedback=((nreg>>13)&1)^((nreg>>14)&1);
        nreg=(nreg<<1)+feedback;
        nreg&=0x7fff;
        outo=amptab[(nreg>>0xe)&1];
      }
    }
  ChannelBC[3]=SOUNDTS;
}

/**
 * @brief Writes to the IRQ frame mode register and updates related state.
 *
 * This method processes the value written to the IRQ frame mode register (V) and updates
 * the internal state of the frame counter and IRQ handling logic. The input value (V) is
 * masked and shifted to extract the relevant bits (0xC0) for determining the IRQ frame mode.
 * The frame counter (fcnt) is reset to 0, and if the second bit of the masked value (V & 0x2)
 * is set, the FrameSoundUpdate() function is called to update the sound state. The frame
 * counter is then set to 1, and the frame counter high byte (fhcnt) is initialized with the
 * frame counter increment value (fhinc). The IRQ handling logic is signaled to end the
 * current IRQ cycle via X6502_IRQEnd(FCEU_IQFCOUNT). The IRQ status (SIRQStat) is updated
 * by clearing the 0x40 bit, and the IRQ frame mode (IRQFrameMode) is set to the processed
 * value of V.
 *
 * @param V The value written to the IRQ frame mode register.
 */
DECLFW(Write_IRQFM)
{
  V=(V&0xC0)>>6;
  fcnt=0;
  if(V&0x2)
    FrameSoundUpdate();
  fcnt=1;
  fhcnt=fhinc;
  X6502_IRQEnd(FCEU_IQFCOUNT);
  SIRQStat&=~0x40;
  IRQFrameMode=V;
}

/**
 * @brief Configures the NES sound map by setting up the appropriate write and read handlers for the sound-related memory addresses.
 *
 * This method sets up the handlers for the Programmable Sound Generator (PSG), the Delta Modulation Channel (DMC) registers,
 * and the IRQ frame counter. It also configures the status register for both write and read operations.
 * Specifically, it assigns:
 * - The PSG write handler to the memory range 0x4000-0x400F.
 * - The DMC registers write handler to the memory range 0x4010-0x4013.
 * - The IRQ frame counter write handler to the memory address 0x4017.
 * - The status register write handler to the memory address 0x4015.
 * - The status register read handler to the memory address 0x4015.
 */
void SetNESSoundMap(void)
{
  SetWriteHandler(0x4000,0x400F,Write_PSG);
  SetWriteHandler(0x4010,0x4013,Write_DMCRegs);
  SetWriteHandler(0x4017,0x4017,Write_IRQFM);

  SetWriteHandler(0x4015,0x4015,StatusWrite);
  SetReadHandler(0x4015,0x4015,StatusRead);
}

static int32 inbuf=0;
/**
 * @brief Flushes the emulated sound buffer and processes the sound data.
 *
 * This method is responsible for flushing the emulated sound buffer, processing the sound data,
 * and preparing it for output. It handles different sound quality settings and applies appropriate
 * filters to the sound data. The method also manages sound synchronization and updates internal
 * sound state variables.
 *
 * The method performs the following steps:
 * 1. Checks if sound processing is necessary based on the sound timestamp.
 * 2. If sound is disabled (FSettings.SndRate is 0), it skips sound processing.
 * 3. Processes sound channels (SQ1, SQ2, Triangle, Noise, PCM) to generate sound data.
 * 4. Depending on the sound quality setting (FSettings.soundq), it applies different processing:
 *    - For high-quality sound (soundq >= 1), it applies a NeoFilterSound and updates the WaveHi buffer.
 *    - For lower quality sound, it applies a SexyFilter and updates the Wave buffer.
 * 5. Updates internal sound state variables (soundtsoffs, ChannelBC, inbuf) based on the processed sound data.
 * 6. Returns the number of sound samples processed.
 *
 * @return int The number of sound samples processed and ready for output.
 */
int FlushEmulateSound(void)
{
  int x;
  int32 end,left;

  if(!soundtimestamp) return(0);

  if(!FSettings.SndRate)
  {
    left=0;
    end=0;
    goto nosoundo;
  }

  DoSQ1();
  DoSQ2();
  DoTriangle();
  DoNoise();
  DoPCM();

  if(FSettings.soundq>=1)
  {
    int32 *tmpo=&WaveHi[soundtsoffs];

    if(GameExpSound.HiFill) GameExpSound.HiFill();

    for(x=soundtimestamp;x;x--)
    {
      uint32 b=*tmpo;
      *tmpo=(b&65535)+wlookup2[(b>>16)&255]+wlookup1[b>>24];
      tmpo++;
    }
    end=NeoFilterSound(WaveHi,WaveFinal,SOUNDTS,&left);

    memmove(WaveHi,WaveHi+SOUNDTS-left,left*sizeof(uint32));
    memset(WaveHi+left,0,sizeof(WaveHi)-left*sizeof(uint32));

    if(GameExpSound.HiSync) GameExpSound.HiSync(left);
    for(x=0;x<5;x++)
      ChannelBC[x]=left;
  }
  else
  {
    end=(SOUNDTS<<16)/soundtsinc;
    if(GameExpSound.Fill)
      GameExpSound.Fill(end&0xF);

    SexyFilter(Wave,WaveFinal,end>>4);

    //if(FSettings.lowpass)
    // SexyFilter2(WaveFinal,end>>4);
    if(end&0xF)
      Wave[0]=Wave[(end>>4)];
    Wave[end>>4]=0;
  }
nosoundo:

  if(FSettings.soundq>=1)
  {
    soundtsoffs=left;
  }
  else
  {
    for(x=0;x<5;x++)
      ChannelBC[x]=end&0xF;
    soundtsoffs = (soundtsinc*(end&0xF))>>16;
    end>>=4;
  }
  inbuf=end;

  //FCEU_WriteWaveData(WaveFinal, end); /* This function will just return
  //                                       if sound recording is off. */
  return(end);
}

#if 0
/**
 * @brief Retrieves the sound buffer and its associated inbuf value.
 *
 * This method assigns the address of the `WaveFinal` buffer to the pointer `W` provided by the caller.
 * It then returns the value of `inbuf`, which is typically used to indicate the size or status of the buffer.
 *
 * @param W A pointer to a pointer of type `int32`. Upon return, `*W` will point to the `WaveFinal` buffer.
 *
 * @return The value of `inbuf`, which could represent the size of the buffer or a status code.
 */
int GetSoundBuffer(int32 **W)
{
  *W = WaveFinal;
  return(inbuf);
}
#endif

/* FIXME:  Find out what sound registers get reset on reset.  I know $4001/$4005 don't,
   due to that whole MegaMan 2 Game Genie thing.
   */

void FCEUSND_Reset(void)
{
  int x;

  IRQFrameMode=0x0;
  fhcnt=fhinc;
  fcnt=0;
  nreg=1;

  for(x=0;x<2;x++)
  {
    wlcount[x]=2048;
    if(nesincsize) // lq mode
      sqacc[x]=((uint32)2048<<17)/nesincsize;
    else
      sqacc[x]=1;
    sweepon[x]=0;
    curfreq[x]=0;
  }

  wlcount[2]=1;  //2048;
  wlcount[3]=2048;

  DMCHaveDMA=DMCHaveSample=0;
  SIRQStat=0x00;

  RawDALatch=0x00;
  TriCount=0;
  TriMode=0;
  tristep=0;
  EnabledChannels=0;
  for(x=0;x<4;x++)
    lengthcount[x]=0;

  DMCAddressLatch=0;
  DMCSizeLatch=0;
  DMCFormat=0;
  DMCAddress=0;
  DMCSize=0;
  DMCShift=0;

  // MAJOR BUG WAS HERE: DMCacc and DMCBitCount never got reset...
  // so, do some ridiculous hackery if a movie's about to play to keep it in sync...


  if(movieSyncHackOn)
  {
    if(resetDMCacc)
    {
      // no value in movie save state
#ifdef WIN32
      // use editbox fields
      DMCacc=movieConvertOffset1;
      DMCBitCount=movieConvertOffset2;
#else
      // no editbox fields, so leave the values alone
      // and print out a warning that says what they are
      FCEU_PrintError("Warning: These variables were not found in the save state and will keep their current value: DMCacc=%d, DMCBitCount=%d\n", DMCacc, DMCBitCount);
#endif
    }
    else
    {
      // keep values loaded from movie save state or reset earlier
    }
  }
  else
  {
    // reset these variables like should have done in the first place
    DMCacc=1;
    DMCBitCount=0;
  }

  //	FCEU_PrintError("DMCacc=%d, DMCBitCount=%d",DMCacc,DMCBitCount);
}

/**
 * @brief Initializes and resets the sound system for the NES emulator.
 *
 * This method performs several key operations to prepare the sound system:
 * 1. Sets up the NES sound mapping by calling `SetNESSoundMap()`.
 * 2. Clears the PSG (Programmable Sound Generator) buffer by setting all its bytes to 0x00.
 * 3. Resets the sound system by calling `FCEUSND_Reset()`.
 * 4. Clears the `Wave` and `WaveHi` buffers, which are used for sound wave data.
 * 5. Resets the envelope units by clearing the `EnvUnits` structure.
 * 6. Initializes the `ChannelBC` array to zero for the first 5 channels.
 * 7. Resets the `soundtsoffs` variable to zero.
 * 8. Loads the DMC (Delta Modulation Channel) period based on the lower 4 bits of `DMCFormat`.
 *
 * This method is typically called when the emulator is powered on or when the sound system needs to be reset.
 */
void FCEUSND_Power(void)
{
  int x;

  SetNESSoundMap();
  memset(PSG,0x00,sizeof(PSG));
  FCEUSND_Reset();

  memset(Wave,0,sizeof(Wave));
  memset(WaveHi,0,sizeof(WaveHi));
  memset(&EnvUnits,0,sizeof(EnvUnits));

  for(x=0;x<5;x++)
    ChannelBC[x]=0;
  soundtsoffs=0;
  LoadDMCPeriod(DMCFormat&0xF);
}

/**
 * @brief Sets up and initializes sound-related variables and configurations for the emulator.
 * 
 * This method configures various sound parameters based on the emulator's settings, including
 * the sound rate, sound quality, and system type (PAL, NTSC, or Dendy). It calculates lookup
 * tables for sound wave generation, sets up sound channel functions, and initializes filters.
 * Additionally, it adjusts the sound increment size based on the system type and sound rate,
 * and ensures proper initialization of sound-related memory and DMC (Delta Modulation Channel)
 * periods. This method is crucial for ensuring accurate sound emulation in the system.
 */
void SetSoundVariables(void)
{
  int x;

  fhinc=PAL?16626:14915;  // *2 CPU clock rate
  fhinc*=24;

  if(FSettings.SndRate)
  {
    wlookup1[0]=0;
    for(x=1;x<32;x++)
    {
      //wlookup1[x]=(double)16*16*16*4*95.52/((double)8128/(double)x+100);
      wlookup1[x]=1565000 * x / (8128 + 100 * x);
      if(!FSettings.soundq) wlookup1[x]>>=4;
    }
    wlookup2[0]=0;
    for(x=1;x<203;x++)
    {
      //wlookup2[x]=(double)16*16*16*4*163.67/((double)24329/(double)x+100);
      wlookup2[x]=2681569 * x / (24329 + 100 * x);
      if(!FSettings.soundq) wlookup2[x]>>=4;
    }
    if(FSettings.soundq>=1)
    {
      DoNoise=RDoNoise;
      DoTriangle=RDoTriangle;
      DoPCM=RDoPCM;
      DoSQ1=RDoSQ1;
      DoSQ2=RDoSQ2;
    }
    else
    {
      DoNoise=DoTriangle=DoPCM=DoSQ1=DoSQ2=Dummyfunc;
      DoSQ1=RDoSQLQ;
      DoSQ2=RDoSQLQ;
      DoTriangle=RDoTriangleNoisePCMLQ;
      DoNoise=RDoTriangleNoisePCMLQ;
      DoPCM=RDoTriangleNoisePCMLQ;
    }
  }
  else
  {
    DoNoise=DoTriangle=DoPCM=DoSQ1=DoSQ2=Dummyfunc;
    return;
  }

  MakeFilters(FSettings.SndRate);

  if(GameExpSound.RChange)
    GameExpSound.RChange();

  //nesincsize=(int64)(((int64)1<<17)*(double)(PAL?PAL_CPU:NTSC_CPU)/(FSettings.SndRate * 16));
  nesincsize=(PAL ? 3405019392u : (dendy ? 3632020412u : 3665454545u))/(FSettings.SndRate / 4);
  memset(sqacc,0,sizeof(sqacc));
  memset(ChannelBC,0,sizeof(ChannelBC));

  LoadDMCPeriod(DMCFormat&0xF);  // For changing from PAL to NTSC

  //soundtsinc=(uint32)((uint64)(PAL?(long double)PAL_CPU*65536:(long double)NTSC_CPU*65536)/(FSettings.SndRate * 16));
  soundtsinc=nesincsize / 2;
}
#else
/**
 * @brief Hooks into the sound CPU to process a specified number of cycles.
 *
 * This method is used to synchronize the sound CPU with the main CPU by processing
 * a given number of cycles. It ensures that the sound CPU executes the correct
 * number of cycles to maintain audio synchronization during emulation.
 *
 * @param cycles The number of cycles to process on the sound CPU.
 */
void FCEU_SoundCPUHook(int cycles) {}
/**
 * @brief Powers on the FCEUSND audio subsystem.
 *
 * This method initializes and starts the FCEUSND audio subsystem, enabling sound playback
 * in the application. It sets up necessary hardware and software components, ensuring
 * that audio processing is ready for use. This function should be called before any
 * audio-related operations to ensure proper functionality.
 *
 * @note This method does not take any parameters or return any value. It assumes that
 * the system is in a state where the audio subsystem can be safely powered on.
 */
void FCEUSND_Power(void) {}
/**
 * @brief Flushes the emulated sound buffer.
 *
 * This method is responsible for flushing the internal buffer used for emulating sound.
 * It ensures that any pending sound data is processed and played, effectively clearing the buffer.
 * The method returns an integer value, typically indicating success or failure, where 0 signifies
 * a successful operation.
 *
 * @return int Returns 0 on success, indicating that the sound buffer was successfully flushed.
 */
int FlushEmulateSound(void) { return 0; }
/**
 * @brief Sets the sound-related variables for the application.
 * 
 * This method initializes and configures the necessary variables that control
 * sound behavior within the application. It may include setting volume levels,
 * enabling or disabling sound effects, and configuring audio channels or
 * buffers. This method should be called during the initialization phase of
 * the application to ensure proper sound functionality.
 */
void SetSoundVariables(void) {}
#endif

/**
 * @brief Sets the sound playback rate and updates sound-related variables.
 *
 * This method updates the sound rate setting in the global `FSettings` structure 
 * to the specified `Rate` and then calls `SetSoundVariables()` to apply the new 
 * sound settings. This is typically used to configure the audio playback rate 
 * for the emulator or application.
 *
 * @param Rate The desired sound playback rate in Hz (e.g., 44100, 48000).
 */
void FCEUI_Sound(int Rate)
{
  FSettings.SndRate=Rate;
  SetSoundVariables();
}

#if 0
/**
 * @brief Sets the low-pass filter setting for the emulator.
 *
 * This method updates the low-pass filter setting in the global emulator settings.
 * The low-pass filter is used to reduce high-frequency noise in the audio output,
 * providing a smoother sound experience. The value of `q` determines the intensity
 * of the filter, with higher values resulting in a stronger filtering effect.
 *
 * @param q The new low-pass filter setting. This value typically ranges from 0 (no filtering)
 *          to a positive integer representing the desired filter intensity.
 */
void FCEUI_SetLowPass(int q)
{
  FSettings.lowpass = q;
}
#endif

/**
 * @brief Sets the sound quality for the emulator.
 *
 * This method updates the sound quality setting in the global FSettings object
 * to the specified value and then applies the new sound settings by calling
 * the SetSoundVariables() function. The sound quality parameter typically
 * controls aspects such as sample rate, buffer size, or other audio processing
 * parameters that affect the overall audio experience in the emulator.
 *
 * @param quality The desired sound quality level. The interpretation of this
 *                value depends on the emulator's implementation, but higher
 *                values generally indicate better quality at the cost of
 *                increased CPU usage.
 */
void FCEUI_SetSoundQuality(int quality)
{
  FSettings.soundq = quality;
  SetSoundVariables();
}

/**
 * @brief Sets the sound volume for the emulator.
 *
 * This method updates the global sound volume setting in the emulator's configuration.
 * The volume parameter is expected to be a value between 0 and the maximum volume level
 * supported by the emulator. A value of 0 typically mutes the sound, while the maximum
 * value represents the highest volume level.
 *
 * @param volume The new sound volume level to set. This value should be within the valid
 *               range supported by the emulator.
 */
void FCEUI_SetSoundVolume(uint32 volume)
{
  FSettings.SoundVolume=volume;
}

/**
 * @brief Sets the volume level for the triangle wave channel in the FCEU emulator.
 *
 * This method updates the volume setting specifically for the triangle wave channel
 * within the FCEU emulator's audio settings. The volume level is specified as an
 * unsigned 32-bit integer, which directly modifies the `TriangleVolume` property
 * in the global `FSettings` structure.
 *
 * @param volume The desired volume level for the triangle wave channel. This value
 *               is expected to be within the valid range supported by the emulator.
 */
void FCEUI_SetTriangleVolume(uint32 volume)
{
  FSettings.TriangleVolume=volume;
}

/**
 * @brief Sets the volume level for Square1 channel in the emulator.
 *
 * This method updates the volume setting for the Square1 channel to the specified value.
 * The volume parameter is expected to be a 32-bit unsigned integer, which represents
 * the desired volume level. The actual effect of this volume setting depends on the
 * emulator's audio processing and how it interprets the volume value.
 *
 * @param volume The new volume level for the Square1 channel, as a 32-bit unsigned integer.
 */
void FCEUI_SetSquare1Volume(uint32 volume)
{
  FSettings.Square1Volume=volume;
}

/**
 * @brief Sets the volume for Square 2 channel in the emulator.
 *
 * This method updates the volume level for the Square 2 channel in the emulator's
 * settings. The volume is specified as a 32-bit unsigned integer, which typically
 * represents a value within the acceptable range for the emulator's audio system.
 * The exact interpretation of the volume value (e.g., linear, logarithmic) depends
 * on the emulator's internal implementation.
 *
 * @param volume The volume level to set for the Square 2 channel. This value is
 *               expected to be within the valid range supported by the emulator.
 */
void FCEUI_SetSquare2Volume(uint32 volume)
{
  FSettings.Square2Volume=volume;
}

/**
 * @brief Sets the noise volume level in the FCEUI settings.
 * 
 * This method updates the noise volume level in the FCEUI settings to the specified value.
 * The noise volume is used to control the amplitude of noise effects in the emulator.
 * 
 * @param volume The new noise volume level to set. This value should be within the valid range
 *               supported by the emulator (e.g., 0 to 100, or any other range depending on the
 *               implementation). Higher values increase the noise volume, while lower values
 *               decrease it.
 */
void FCEUI_SetNoiseVolume(uint32 volume)
{
  FSettings.NoiseVolume=volume;
}

/**
 * @brief Sets the PCM (Pulse Code Modulation) volume level.
 *
 * This method updates the PCM volume setting in the global FSettings object.
 * The volume parameter is expected to be a 32-bit unsigned integer, which
 * represents the desired volume level. The exact interpretation of the volume
 * value (e.g., range, scaling) depends on the implementation of the PCM system.
 *
 * @param volume The new PCM volume level to set. This is a 32-bit unsigned integer.
 */
void FCEUI_SetPCMVolume(uint32 volume)
{
  FSettings.PCMVolume=volume;
}

#if 0
/**
 * @brief Saves the current state of the FCEUSND (FCEUX Sound) system.
 *
 * This method serializes and stores the current state of the sound system, including
 * all relevant audio settings, buffers, and internal states, to a designated location
 * (e.g., a file or memory). This is typically used to save the state of the sound system
 * during emulation, allowing it to be restored later for continued playback or debugging.
 * The saved state can be loaded using a corresponding `FCEUSND_LoadState` method.
 *
 * @note Ensure that the sound system is initialized and active before calling this method.
 * The method does not handle errors related to invalid or uninitialized states.
 */
void FCEUSND_SaveState(void)
{

}

/**
 * @brief Loads the state of the FCEU sound system based on the provided version.
 *
 * This method is responsible for restoring the state of the FCEU sound system
 * by loading the DMC (Delta Modulation Channel) period, adjusting the Raw DA Latch,
 * and updating the DMC address. The method ensures that the DMC period is set
 * based on the lower 4 bits of the DMCFormat, the Raw DA Latch is masked to
 * the lower 7 bits, and the DMC address is masked to the lower 15 bits.
 *
 * @param version The version of the state to be loaded. This parameter is used
 *                to determine the specific state restoration logic if needed.
 */
void FCEUSND_LoadState(int version)
{
  LoadDMCPeriod(DMCFormat&0xF);
  RawDALatch&=0x7F;
  DMCAddress&=0x7FFF;
}
#endif
