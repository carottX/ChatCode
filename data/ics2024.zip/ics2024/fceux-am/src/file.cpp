/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "types.h"
#include "file.h"
#include "utils/memory.h"
#include "utils/md5.h"
#include "driver.h"
#include "types.h"
#include "fceu.h"
#include "state.h"
#include "driver.h"

using namespace std;

/**
 * @brief Opens a file for reading or writing in the specified mode.
 *
 * This function attempts to open a file located at the given path in the specified mode.
 * It supports only two modes: "rb" for reading and "wb" for writing. If the mode is invalid,
 * an error message is printed, and the function returns NULL.
 *
 * If the mode is "rb", the function opens the file for reading. It first attempts to open
 * the file using `FCEUD_UTF8_fstream`. If the file cannot be opened or is not open after
 * the attempt, the function returns NULL. If the file is successfully opened, a new
 * `FCEUFILE` structure is allocated and initialized with the file stream, and the file size
 * is determined by seeking to the end of the file and then back to the beginning.
 *
 * If the mode is "wb", the function currently returns NULL, as writing is not implemented.
 *
 * @param path The path to the file to be opened.
 * @param ipsfn Must be NULL; otherwise, the function will assert.
 * @param mode The mode in which to open the file ("rb" for reading, "wb" for writing).
 * @param ext Unused parameter.
 * @param index Unused parameter.
 * @param extensions Unused parameter.
 * @param userCancel Unused parameter.
 * @return A pointer to the newly allocated `FCEUFILE` structure if the file is successfully
 *         opened for reading, or NULL if the file cannot be opened or if the mode is invalid.
 */
FCEUFILE * FCEU_fopen(const char *path, const char *ipsfn, const char *mode, char *ext, int index, const char** extensions, int* userCancel)
{
	FCEUFILE *fceufp=0;

  assert(ipsfn == NULL);

	bool read = !strcmp(mode, "rb");
	bool write = !strcmp(mode, "wb");
	if((read && write) || (!read && !write))
	{
		FCEU_PrintError("invalid file open mode specified (only wb and rb are supported)");
		return 0;
	}

	if(read)
	{
			//if the archive contained no files, try to open it the old fashioned way
			//EMUFILE* fp = FCEUD_UTF8_fstream(fileToOpen.c_str(),mode);
			EMUFILE_FILE* fp = FCEUD_UTF8_fstream(path,mode);
			if(!fp)
				return 0;
			if (!fp->is_open())
			{
				//fp is new'ed so it has to be deleted
				free(fp);
				return 0;
			}

			//open a plain old file
			fceufp = (FCEUFILE *)malloc(sizeof(FCEUFILE));
			fceufp->archiveIndex = -1;
			fceufp->archiveCount = -1;
			fceufp->stream = fp;
			FCEU_fseek(fceufp,0,SEEK_END);
			fceufp->size = FCEU_ftell(fceufp);
			FCEU_fseek(fceufp,0,SEEK_SET);

		return fceufp;
	}
	return 0;
}

/**
 * @brief Closes and deallocates an FCEUFILE object.
 *
 * This method is responsible for properly closing and deallocating an FCEUFILE object.
 * It first calls the destructor of the FCEUFILE object to ensure any resources managed
 * by the object are properly released. Then, it frees the memory allocated for the
 * FCEUFILE object itself using the `free` function. The method returns 1 to indicate
 * successful completion of the operation.
 *
 * @param fp Pointer to the FCEUFILE object to be closed and deallocated.
 * @return int Always returns 1 to indicate success.
 */
int FCEU_fclose(FCEUFILE *fp)
{
  fp->~FCEUFILE();
  free(fp);
	return 1;
}

/**
 * @brief Reads data from a file stream into a buffer.
 *
 * This function reads a specified number of elements, each with a given size, from the file stream
 * associated with the provided `FCEUFILE` object. The data is stored in the buffer pointed to by `ptr`.
 * The total number of bytes read is the product of `size` and `nmemb`.
 *
 * @param ptr Pointer to the buffer where the read data will be stored.
 * @param size Size in bytes of each element to be read.
 * @param nmemb Number of elements to read.
 * @param fp Pointer to the `FCEUFILE` object representing the file stream.
 * @return The total number of elements successfully read. This value is typically equal to `nmemb`
 *         if the read operation is successful. If an error occurs or the end of the file is reached,
 *         the return value may be less than `nmemb`.
 */
uint64 FCEU_fread(void *ptr, size_t size, size_t nmemb, FCEUFILE *fp)
{
	return fp->stream->_fread((char*)ptr,size*nmemb);
}

/**
 * @brief Moves the file pointer to a specified location within the file.
 *
 * This function adjusts the file pointer associated with the given FCEUFILE object
 * to a new position based on the provided offset and whence parameter. The whence
 * parameter determines the reference point for the offset:
 * - SEEK_SET: The offset is relative to the beginning of the file.
 * - SEEK_CUR: The offset is relative to the current file pointer position.
 * - SEEK_END: The offset is relative to the end of the file.
 *
 * After moving the file pointer, the function returns the new position of the
 * file pointer within the file.
 *
 * @param fp Pointer to the FCEUFILE object representing the file.
 * @param offset The number of bytes to move the file pointer.
 * @param whence The reference point for the offset (SEEK_SET, SEEK_CUR, or SEEK_END).
 * @return The new position of the file pointer within the file, or -1 if an error occurs.
 */
int FCEU_fseek(FCEUFILE *fp, long offset, int whence)
{
	fp->stream->fseek(offset,whence);

	return FCEU_ftell(fp);
}

/**
 * @brief Retrieves the current position of the file pointer in the given file stream.
 *
 * This function returns the current position of the file pointer within the stream associated
 * with the provided FCEUFILE object. The position is represented as an offset in bytes from the
 * beginning of the file. This is useful for determining the current read/write position in the file.
 *
 * @param fp Pointer to an FCEUFILE object representing the file whose stream position is to be retrieved.
 * @return The current position of the file pointer as a 64-bit unsigned integer (uint64).
 */
uint64 FCEU_ftell(FCEUFILE *fp)
{
	return fp->stream->ftell();
}
