/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 creg, preg;
static SFORMAT StateRegs[] =
{
	{ &creg, 1, "CREG" },
	{ &preg, 1, "PREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the PRG (Program ROM) and CHR (Character ROM) banks.
 *
 * This method updates the memory mapping for the PRG and CHR banks in the emulator.
 * It sets the PRG ROM bank at the memory address 0x8000 using the value stored in `preg`.
 * Additionally, it sets the CHR ROM bank using the value stored in `creg`, effectively
 * updating the character graphics memory.
 *
 * @note This method assumes that `preg` and `creg` have been properly initialized
 * with the desired bank numbers before calling this method.
 */
static void Sync(void) {
    setprg32(0x8000, preg);
    setchr8(creg);
}

/**
 * @brief Handles writing to the M79 memory address.
 *
 * This method processes a write operation to the M79 memory address. It checks if the address `A` is below 0x8000 and if the XOR of `A` with 0x4100 equals 0. If both conditions are met, it updates the `preg` variable by shifting the value `V` right by 3 bits and masking it with 1. Additionally, it updates the `creg` variable by masking the value `V` with 7. Finally, it calls the `Sync()` method to synchronize the state.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(M79Write) {
	if ((A < 0x8000) && ((A ^ 0x4100) == 0)) {
		preg = (V >> 3) & 1;
	}
	creg = V & 7;
	Sync();
}

/**
 * @brief Initializes the M79 power state by resetting the internal register, 
 *        synchronizing the system, and setting up memory handlers.
 *
 * This method performs the following operations:
 * 1. Resets the internal register `preg` to its default state (all bits set to 1).
 * 2. Calls `Sync()` to synchronize the system state.
 * 3. Sets up write handlers for the memory ranges 0x4100-0x5FFF and 0x8000-0xFFFF
 *    to use the `M79Write` function for handling write operations.
 * 4. Sets up a read handler for the memory range 0x8000-0xFFFF to use the `CartBR`
 *    function for handling read operations.
 */
static void M79Power(void) {
	preg = ~0;
	Sync();
	SetWriteHandler(0x4100, 0x5FFF, M79Write);
	SetWriteHandler(0x8000, 0xFFFF, M79Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method triggers a synchronization process to ensure that the system's state
 * is restored to the specified version. The `Sync()` function is called internally
 * to handle the actual synchronization logic. This method is typically used in
 * scenarios where the system needs to revert to a known good state after an error
 * or to load a specific state for further processing.
 *
 * @param version The version of the state to restore. This parameter specifies
 *                which state should be loaded or reverted to.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 79 configuration for the provided cartridge information.
 * This function sets up the power function for the mapper and adds the state registers
 * to the emulator's state management system. It also assigns the state restoration
 * function to ensure the game state can be properly restored during emulation.
 *
 * @param info Pointer to the CartInfo structure that holds the cartridge configuration
 *             and state information. This structure is modified to include the Mapper 79
 *             specific settings.
 */
void Mapper79_Init(CartInfo *info) {
	info->Power = M79Power;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
