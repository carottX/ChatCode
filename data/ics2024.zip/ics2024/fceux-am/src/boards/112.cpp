/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * NTDEC, ASDER games
 *
 */

#include "mapinc.h"

static uint8 reg[8];
static uint8 mirror, cmd, bank;
static uint8 *WRAM = NULL;

static SFORMAT StateRegs[] =
{
	{ &cmd, 1, "CMD" },
	{ &mirror, 1, "MIRR" },
	{ &bank, 1, "BANK" },
	{ reg, 8, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the system.
 *
 * This method updates the memory mapping and mirroring configuration based on the current state
 * of the internal registers and the `bank` variable. It performs the following operations:
 * 1. Toggles the mirroring configuration using `setmirror` with the current mirror state XORed with 1.
 * 2. Sets the PRG ROM banks at addresses 0x8000 and 0xA000 using the values from `reg[0]` and `reg[1]`.
 * 3. Sets the CHR ROM banks for the following regions:
 *    - 0x0000 and 0x0800 using the values from `reg[2]` and `reg[3]`, respectively, shifted right by 1.
 *    - 0x1000, 0x1400, 0x1800, and 0x1C00 using a combination of the `bank` variable and the values from
 *      `reg[4]`, `reg[5]`, `reg[6]`, and `reg[7]`, respectively.
 */
static void Sync(void) {
	setmirror(mirror ^ 1);
	setprg8(0x8000, reg[0]);
	setprg8(0xA000, reg[1]);
	setchr2(0x0000, (reg[2] >> 1));
	setchr2(0x0800, (reg[3] >> 1));
	setchr1(0x1000, ((bank & 0x10) << 4) | reg[4]);
	setchr1(0x1400, ((bank & 0x20) << 3) | reg[5]);
	setchr1(0x1800, ((bank & 0x40) << 2) | reg[6]);
	setchr1(0x1C00, ((bank & 0x80) << 1) | reg[7]);
}

/**
 * @brief Handles writes to the M112 memory-mapped I/O register.
 *
 * This method processes write operations to the M112 register by interpreting the address (A) 
 * and the value (V) being written. Depending on the address, it performs the following actions:
 * - If the address is 0xe000, it updates the `mirror` flag based on the least significant bit of V 
 *   and calls `Sync()` to synchronize the state.
 * - If the address is 0x8000, it updates the `cmd` variable with the lower 3 bits of V.
 * - If the address is 0xa000, it writes the value V to the `reg` array at the index specified by `cmd` 
 *   and calls `Sync()` to synchronize the state.
 * - If the address is 0xc000, it updates the `bank` variable with the value V and calls `Sync()` 
 *   to synchronize the state.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M112Write) {
	switch (A) {
	case 0xe000: mirror = V & 1; Sync();; break;
	case 0x8000: cmd = V & 7; break;
	case 0xa000: reg[cmd] = V; Sync(); break;
	case 0xc000: bank = V; Sync(); break;
	}
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) used by the emulator.
 * 
 * This method checks if the WRAM pointer is not null. If it is not null, it 
 * deallocates the memory associated with WRAM using the FCEU_gfree function 
 * to free the allocated memory. After deallocation, the WRAM pointer is set 
 * to null to indicate that no memory is currently allocated for WRAM.
 * 
 * This is typically called during cleanup or reset operations to ensure that 
 * no memory leaks occur and that the WRAM is properly released.
 */
static void M112Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Initializes the memory mapping and handlers for the M112 power state.
 *
 * This method configures the memory mapping and read/write handlers for the M112 power state.
 * It sets the program ROM (PRG) banks and configures the read and write handlers for specific
 * memory ranges. The method also initializes the RAM for cheat functionality.
 *
 * Specifically, it performs the following operations:
 * - Resets the bank to 0.
 * - Sets the PRG ROM bank at address 0xC000 to the last bank (using ~0).
 * - Configures the PRG RAM bank at address 0x6000 using the specified bank number (0x10).
 * - Sets the read handler for the range 0x8000-0xFFFF to CartBR.
 * - Sets the write handler for the range 0x8000-0xFFFF to M112Write.
 * - Sets the write handler for the range 0x4020-0x5FFF to M112Write.
 * - Sets the read handler for the range 0x6000-0x7FFF to CartBR.
 * - Sets the write handler for the range 0x6000-0x7FFF to CartBW.
 * - Adds 8KB of RAM at address 0x6000 for cheat functionality.
 */
static void M112Power(void) {
	bank = 0;
	setprg16(0xC000, ~0);
	setprg8r(0x10, 0x6000, 0);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M112Write);
	SetWriteHandler(0x4020, 0x5FFF, M112Write);
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	FCEU_CheatAddRAM(8, 0x6000, WRAM);
}

/**
 * @brief Restores the state based on the provided version.
 * 
 * This method is responsible for restoring the state of the system to a specific version.
 * It ensures that all necessary data is synchronized before proceeding with the restoration.
 * The synchronization is achieved by calling the `Sync()` method internally.
 * 
 * @param version The version of the state to restore. This parameter determines which state 
 *                should be restored based on the version number.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 112 for the provided cartridge information.
 *
 * This method sets up the necessary function pointers and memory mappings for Mapper 112.
 * It assigns the `Power` and `Close` functions to the corresponding Mapper 112 implementations.
 * Additionally, it allocates 8192 bytes of Work RAM (WRAM) for the cartridge and sets up the
 * PRG mapping for this WRAM. The method also registers the WRAM and state registers for
 * save state functionality, ensuring that the emulator can save and restore the state of the
 * cartridge correctly.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific information.
 */
void Mapper112_Init(CartInfo *info) {
	info->Power = M112Power;
	info->Close = M112Close;
	GameStateRestore = StateRestore;
	WRAM = (uint8*)FCEU_gmalloc(8192);
	SetupCartPRGMapping(0x10, WRAM, 8192, 1);
	AddExState(WRAM, 8192, 0, "WRAM");
	AddExState(&StateRegs, ~0, 0, 0);
}
