/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg[4], IRQa;
static int16 IRQCount, IRQPause;

static int16 Count = 0x0000;

static SFORMAT StateRegs[] =
{
	{ reg, 4, "REGS" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 2, "IRQC" },
	{ 0 }
};

/**
 * @brief Synchronizes the program and character memory banks to their default states.
 *
 * This method sets the program memory bank (PRG) to the default state by calling `setprg32` 
 * with the starting address 0x8000 and bank number 0. It also sets the character memory bank (CHR) 
 * to the default state by calling `setchr8` with bank number 0. This effectively resets the memory 
 * mapping to its initial configuration, ensuring that the program and character data are in their 
 * default locations.
 */
static void Sync(void) {
	setprg32(0x8000, 0);
	setchr8(0);
}

//#define Count 0x1800
#define Pause 0x010

/**
 * @brief Handles writes to specific memory addresses for the UNL3DBlock mapper.
 *
 * This method is a static function that processes write operations to certain memory addresses
 * (0x4800, 0x4900, 0x4a00, and 0x4e00) for the UNL3DBlock mapper. Depending on the address (A) being written to,
 * the method updates internal registers and triggers an IRQ (Interrupt Request) if necessary.
 *
 * @param A The memory address being written to. This method only processes specific addresses:
 *          - 0x4800: Updates register 0 with the value V.
 *          - 0x4900: Updates register 1 with the value V.
 *          - 0x4a00: Updates register 2 with the value V.
 *          - 0x4e00: Updates register 3 with the value V, sets the IRQCount to the current Count,
 *                    sets IRQPause to the current Pause, enables the IRQ (IRQa = 1), and signals
 *                    the end of an external IRQ using X6502_IRQEnd(FCEU_IQEXT).
 * @param V The value being written to the specified memory address.
 */
static DECLFW(UNL3DBlockWrite) {
	switch (A) {
	//4800 32
	//4900 37
	//4a00 01
	//4e00 18
	case 0x4800: reg[0] = V; break;
	case 0x4900: reg[1] = V; break;
	case 0x4a00: reg[2] = V; break;
	case 0x4e00: reg[3] = V; IRQCount = Count; IRQPause = Pause; IRQa = 1; X6502_IRQEnd(FCEU_IQEXT); break;
	}
}

/**
 * @brief Initializes the UNL3DBlock power state by synchronizing the system and setting up memory handlers.
 * 
 * This method performs the following operations:
 * 1. Calls `Sync()` to ensure the system is synchronized.
 * 2. Sets up a read handler for the memory range 0x8000 to 0xFFFF using `CartBR` as the callback function.
 * 3. Sets up a write handler for the memory range 0x4800 to 0x4E00 using `UNL3DBlockWrite` as the callback function.
 * 
 * This configuration is typically used to manage memory access for the UNL3DBlock hardware, ensuring proper read and write operations.
 */
static void UNL3DBlockPower(void) {
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x4800, 0x4E00, UNL3DBlockWrite);
}

/**
 * @brief Resets the 3D block by incrementing the Count variable by 0x10 and printing its new value.
 *
 * This method increments the static variable `Count` by 0x10 (hexadecimal) and then prints the updated value
 * of `Count` in hexadecimal format using the `FCEU_printf` function. The output format is "Count=XXXX", where
 * XXXX is the 4-digit hexadecimal representation of the updated `Count` value.
 *
 * @note This method does not take any parameters and does not return any value. It directly modifies the
 * static `Count` variable and outputs the result to the console or log.
 */
static void UNL3DBlockReset(void) {
	Count += 0x10;
	FCEU_printf("Count=%04x\n", Count);
}

/**
 * @brief Handles the IRQ (Interrupt Request) hook for the UNL3D block.
 *
 * This method manages the IRQ state for the UNL3D block. It decrements the IRQCount or IRQPause
 * based on the input value `a`. If IRQCount reaches zero, it checks if IRQPause is also zero.
 * If IRQPause is positive, it decrements IRQPause and triggers an IRQ begin event. If both
 * IRQCount and IRQPause are zero, it resets IRQCount and IRQPause to their initial values (Count
 * and Pause, respectively) and triggers an IRQ end event.
 *
 * @param a The value to decrement IRQCount or IRQPause by.
 */
static void UNL3DBlockIRQHook(int a) {
	if (IRQa) {
		if (IRQCount > 0) {
			IRQCount -= a;
		} else {
			if (IRQPause > 0) {
				IRQPause -= a;
				X6502_IRQBegin(FCEU_IQEXT);
			} else {
				IRQCount = Count;
				IRQPause = Pause;
				X6502_IRQEnd(FCEU_IQEXT);
			}
		}
	}
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specified version.
 * It ensures that all necessary data and configurations are synchronized to match the
 * desired version. The synchronization is performed by calling the `Sync()` method,
 * which handles the actual restoration process.
 *
 * @param version The version number to which the system state should be restored.
 *                This version number corresponds to a specific state or snapshot
 *                of the system that was previously saved.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the UNL3DBlock cartridge by setting up the necessary function pointers and state.
 *
 * This method configures the provided `CartInfo` structure with the appropriate function pointers
 * for power management, reset behavior, and IRQ handling specific to the UNL3DBlock cartridge.
 * Additionally, it sets up the game state restoration function and adds the state registers
 * to the emulator's state management system.
 *
 * @param info Pointer to the `CartInfo` structure that will be initialized with UNL3DBlock-specific
 *             function pointers and state information.
 */
void UNL3DBlock_Init(CartInfo *info) {
	info->Power = UNL3DBlockPower;
	info->Reset = UNL3DBlockReset;
	MapIRQHook = UNL3DBlockIRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
