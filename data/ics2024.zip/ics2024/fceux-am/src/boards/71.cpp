/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg, mirr;

static SFORMAT StateRegs[] =
{
	{ &preg, 1, "PREG" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping configuration for the emulator.
 * 
 * This method sets up the Program ROM (PRG) and Character ROM (CHR) memory mappings 
 * based on the current configuration. It performs the following operations:
 * - Maps the first 16KB of PRG ROM to the address space starting at 0x8000 using the value of `preg`.
 * - Maps the last 16KB of PRG ROM to the address space starting at 0xC000, using the fixed value ~0 (typically the last bank).
 * - Maps the entire 8KB of CHR ROM to the address space starting at 0x0000, using the value 0.
 * - If the `mirr` variable is set, it configures the mirroring mode for the nametable memory.
 */
static void Sync(void) {
	setprg16(0x8000, preg);
	setprg16(0xC000, ~0);
	setchr8(0);
	if(mirr)
		setmirror(mirr);
}

/**
 * @brief Handles write operations for the M71 mapper.
 *
 * This method processes write operations to the M71 mapper's memory space. 
 * It checks the address `A` to determine the type of write operation:
 * - If the address matches `0x9000` (i.e., `(A & 0xF000) == 0x9000`), it updates the mirroring mode 
 *   based on the value `V`. The mirroring mode is set to `MI_0` if the 4th bit of `V` is 0, or `MI_1` 
 *   if the 4th bit is 1. This supports both hardwired and mapper-selectable mirroring modes.
 * - For all other addresses, it updates the mapper's internal register `preg` with the value `V`.
 *
 * After processing the write operation, it calls `Sync()` to synchronize the mapper's state.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M71Write) {
	if ((A & 0xF000) == 0x9000)
		mirr = MI_0 + ((V >> 4) & 1);   // 2-in-1, some carts are normal hardwire V/H mirror, some uses mapper selectable 0/1 mirror
	else
		preg = V;
	Sync();
}

/**
 * @brief Initializes the M71 power state for the cartridge.
 * 
 * This method sets up the M71 cartridge by performing the following steps:
 * 1. Resets the `mirr` variable to 0, which is likely used for mirroring or some internal state.
 * 2. Calls `Sync()` to synchronize the cartridge state with the system.
 * 3. Sets the read handler for the memory range 0x8000 to 0xFFFF to `CartBR`, which handles cartridge bank reading.
 * 4. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M71Write`, which handles cartridge bank writing.
 * 
 * This method is typically called when the cartridge is powered on or reset.
 */
static void M71Power(void) {
	mirr = 0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M71Write);
}

/**
 * @brief Restores the state of the system to a specific version.
 * 
 * This method is responsible for restoring the system's state to a version 
 * specified by the `version` parameter. It ensures that the system is synchronized 
 * by calling the `Sync()` method before proceeding with the restoration process.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 71 configuration for the provided cartridge information.
 *
 * This method sets up the necessary function pointers and state information for Mapper 71.
 * Specifically, it assigns the `M71Power` function to the `Power` member of the `CartInfo`
 * structure to handle power-related operations. It also sets the `GameStateRestore` function
 * to `StateRestore` for restoring the game state. Additionally, it registers the state
 * registers using `AddExState` to ensure proper state management during emulation.
 *
 * @param info Pointer to the `CartInfo` structure that holds cartridge-specific information
 *             and configuration for the emulator.
 */
void Mapper71_Init(CartInfo *info) {
	info->Power = M71Power;
	GameStateRestore = StateRestore;

	AddExState(&StateRegs, ~0, 0, 0);
}
