/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 bank, preg;
static SFORMAT StateRegs[] =
{
	{ &bank, 1, "BANK" },
	{ &preg, 1, "PREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the emulated system.
 *
 * This method is responsible for configuring the Programmable Read-Only Memory (PRG)
 * and Character Read-Only Memory (CHR) banks based on the current state of the `bank`
 * and `preg` variables. It ensures that the correct memory segments are mapped to the
 * appropriate addresses in the emulated system's memory space.
 *
 * The method calculates the base bank (`bbank`) by combining specific bits from the
 * `bank` variable. This calculation accounts for potential discrepancies in ROM dumps
 * where banks may be swapped. The `setprg16` function is then called twice to map the
 * calculated PRG banks to the memory addresses `0x8000` and `0xC000`. Finally, the
 * `setchr8` function is called to map the CHR bank to the appropriate address.
 *
 * @note This method assumes that `bank` and `preg` are properly initialized before
 *       being used in the calculations.
 */
static void Sync(void) {
//	uint32 bbank = (bank & 0x18) >> 1;
	uint32 bbank = ((bank & 0x10) >> 2) | (bank & 8);	// some dumps have bbanks swapped, if swap commands,
														// then all roms can be played, but with some swapped
														// games in menu. if not, some dumps are unplayable
														// make hard dump for both cart types to check
	setprg16(0x8000, bbank | (preg & 3));
	setprg16(0xC000, bbank | 3);
	setchr8(0);
}

/**
 * @brief Writes a value to the bank register and synchronizes the state.
 *
 * This method updates the internal bank register with the provided value `V`
 * and then calls the `Sync()` function to ensure the system state is consistent
 * with the new bank value. This is typically used in memory-mapped I/O or
 * bank switching scenarios where the active memory bank needs to be changed.
 *
 * @param V The value to be written to the bank register.
 */
static DECLFW(M232WriteBank) {
	bank = V;
	Sync();
}

/**
 * @brief Writes a value to the pre-register (preg) and synchronizes the state.
 *
 * This static method assigns the provided value `V` to the pre-register (`preg`)
 * and then calls the `Sync()` function to ensure the system state is updated
 * accordingly. The pre-register is typically used to temporarily hold data
 * before it is processed or written to a final destination.
 *
 * @param V The value to be written to the pre-register.
 */
static DECLFW(M232WritePreg) {
	preg = V;
	Sync();
}

/**
 * @brief Initializes the M232 power state by resetting the bank and preg values,
 *        synchronizing the system, and setting up the appropriate read and write handlers.
 * 
 * This method performs the following operations:
 * 1. Resets the `bank` and `preg` variables to 0.
 * 2. Calls `Sync()` to synchronize the system state.
 * 3. Sets a write handler for the memory range 0x8000 to 0xBFFF to `M232WriteBank`.
 * 4. Sets a write handler for the memory range 0xC000 to 0xFFFF to `M232WritePreg`.
 * 5. Sets a read handler for the memory range 0x8000 to 0xFFFF to `CartBR`.
 * 
 * This method is typically called during the initialization or reset phase of the M232 system.
 */
static void M232Power(void) {
	bank = preg = 0;
	Sync();
	SetWriteHandler(0x8000, 0xBFFF, M232WriteBank);
	SetWriteHandler(0xC000, 0xFFFF, M232WritePreg);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method synchronizes the current state with the desired version by calling
 * the `Sync()` function. It is typically used to revert the system to a known
 * stable state after an update or change.
 *
 * @param version The version number to which the state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 232 for the provided cartridge information.
 * This method sets up the power function for the mapper and adds the state registers
 * to the emulator's state system. It also assigns the state restoration function
 * to ensure the game state can be properly restored during emulation.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific
 *             information and configuration.
 */
void Mapper232_Init(CartInfo *info) {
	info->Power = M232Power;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
