/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2015 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * BMC F-15 PCB (256+266 MMC3 based, with 16/32Kb banking discrete logic)
 * 150-in-1 Unchaied Melody FIGHT version with system test (START+SELECT)
 *
 * CHR - MMC3 stock regs
 * PRG - MMC3 regs disabled, area 6000-7FFF used instead
 *		 011xxxxxxxxxxxxx addr mask,
 *       ----APPp reg bits mask
 *       A - higher 128K PRG bank select/32K bank mode override
 *       PP - bank number in 32K mode
 *       PPp - bank number in 16K mode
 * initial state of extra regs is undefined, A001 enables/disables the 6000 area
 */

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Configures the PRG ROM banks based on the current mode and bank selection.
 *
 * This method calculates the appropriate PRG ROM bank configuration based on the values
 * stored in `EXPREGS[0]`. The lower 4 bits of `EXPREGS[0]` determine the selected bank,
 * while the 4th bit (bit 3) determines the mode. The mode affects how the bank is mapped
 * to the PRG ROM address space.
 *
 * - If the mode is 0, the same bank is mapped to both 0x8000 and 0xC000.
 * - If the mode is 1, the selected bank is mapped to 0x8000, and the next bank (bank + 1)
 *   is mapped to 0xC000.
 *
 * @param A Unused parameter in this context.
 * @param V Unused parameter in this context.
 */
static void BMCF15PW(uint32 A, uint8 V) {
	uint32 bank = EXPREGS[0] & 0xF;
	uint32 mode = (EXPREGS[0] & 8) >> 3;
	uint32 mask = ~(mode);
	setprg16(0x8000, (bank & mask));
	setprg16(0xC000, (bank & mask) | mode);
}

/**
 * @brief Handles the write operation for the BMCF15 mapper.
 * 
 * This method processes a write operation to the BMCF15 mapper. If the most significant bit (MSB) 
 * of the `A001B` register is set (i.e., `A001B & 0x80` is true), it updates the first entry of the 
 * `EXPREGS` array with the lower 4 bits of the value `V`. After updating the register, it calls 
 * `FixMMC3PRG` with the current `MMC3_cmd` to fix the PRG (Program ROM) banking.
 * 
 * @param A001B The register value to check for the MSB.
 * @param V The value to write to the `EXPREGS` register.
 * @param EXPREGS The array of extended registers to update.
 * @param MMC3_cmd The current MMC3 command used for fixing the PRG banking.
 */
static DECLFW(BMCF15Write) {
	if (A001B & 0x80) {
		EXPREGS[0] = V & 0xF;
		FixMMC3PRG(MMC3_cmd);
	}
}

/**
 * @brief Initializes the power-up state for the BMCF15 mapper.
 *
 * This method is responsible for setting up the BMCF15 mapper's power-up state.
 * It first calls the `GenMMC3Power` function to initialize the base MMC3 functionality.
 * Then, it sets up the write handler for the memory range 0x6000 to 0x7FFF to use the
 * `BMCF15Write` function. This ensures that any writes to this memory range are handled
 * by the BMCF15-specific write logic.
 *
 * @note The write handler is set twice for the same memory range, which may be redundant.
 *       Ensure that this is the intended behavior.
 */
static void BMCF15Power(void) {
	GenMMC3Power();
	SetWriteHandler(0x6000, 0x7FFF, BMCF15Write);
	SetWriteHandler(0x6000, 0x7FFF, BMCF15Write);
}

/**
 * @brief Initializes the BMCF15 mapper for the NES cartridge.
 *
 * This method sets up the BMCF15 mapper by initializing the MMC3 memory management
 * controller with the specified configuration. It also assigns the appropriate
 * power-on and write handlers for the mapper. Additionally, it sets up the state
 * for the extended registers used by the mapper.
 *
 * @param info Pointer to the CartInfo structure that contains cartridge-specific
 *             information and configuration.
 */
void BMCF15_Init(CartInfo *info) {
	GenMMC3_Init(info, 256, 256, 0, 0);
	pwrap = BMCF15PW;
	info->Power = BMCF15Power;
	AddExState(EXPREGS, 1, 0, "EXPR");
}
