/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg, creg[4], mirr, suntoggle = 0;
static uint8 IRQa;
static int16 IRQCount, IRQLatch;

static SFORMAT StateRegs[] =
{
	{ &preg, 1, "PREG" },
	{ &suntoggle, 1, "STOG" },
	{ creg, 4, "CREG" },
	{ &mirr, 1, "MIRR" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 2, "IRQC" },
	{ &IRQLatch, 2, "IRQL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the NES emulator.
 * 
 * This method updates the memory mapping and mirroring settings based on the current state of the emulator.
 * It performs the following operations:
 * 1. Sets the mirroring mode based on the value of `mirr`.
 * 2. Maps the PRG-ROM banks:
 *    - The first 16KB bank is mapped to the address `0x8000` using the value of `preg`.
 *    - The second 16KB bank is mapped to the address `0xC000` with the last bank (value `~0`).
 * 3. Maps the CHR-ROM banks:
 *    - Four 2KB CHR-ROM banks are mapped to the addresses `0x0000`, `0x0800`, `0x1000`, and `0x1800` using the values in `creg`.
 * 4. Sets the mirroring mode again based on the value of `mirr`, which can be one of the following:
 *    - `0`: Vertical mirroring (`MI_V`).
 *    - `1`: Horizontal mirroring (`MI_H`).
 *    - `2`: Single-screen mirroring with the first nametable (`MI_0`).
 *    - `3`: Single-screen mirroring with the second nametable (`MI_1`).
 */
static void Sync(void) {
	setmirror(mirr);
	setprg16(0x8000, preg);
	setprg16(0xC000, ~0);
	setchr2(0x0000, creg[0]);
	setchr2(0x0800, creg[1]);
	setchr2(0x1000, creg[2]);
	setchr2(0x1800, creg[3]);
	switch (mirr) {
	case 0: setmirror(MI_V); break;
	case 1: setmirror(MI_H); break;
	case 2: setmirror(MI_0); break;
	case 3: setmirror(MI_1); break;
	}
}

/**
 * @brief Handles writes to the M67 memory-mapped registers.
 *
 * This method processes writes to the M67 memory-mapped registers based on the address (A) and value (V) provided.
 * The method uses a switch statement to determine which register to update based on the address:
 * - 0x8800: Updates creg[0] and calls Sync().
 * - 0x9800: Updates creg[1] and calls Sync().
 * - 0xA800: Updates creg[2] and calls Sync().
 * - 0xB800: Updates creg[3] and calls Sync().
 * - 0xC000 or 0xC800: Updates IRQCount based on suntoggle and toggles suntoggle.
 * - 0xD800: Resets suntoggle, updates IRQa, and ends external IRQ.
 * - 0xE800: Updates mirr and calls Sync().
 * - 0xF800: Updates preg and calls Sync().
 *
 * @param A The address to write to.
 * @param V The value to write.
 */
static DECLFW(M67Write) {
	switch (A & 0xF800) {
	case 0x8800: creg[0] = V; Sync(); break;
	case 0x9800: creg[1] = V; Sync(); break;
	case 0xA800: creg[2] = V; Sync(); break;
	case 0xB800: creg[3] = V; Sync(); break;
	case 0xC000:
	case 0xC800:
		IRQCount &= 0xFF << (suntoggle << 3);
		IRQCount |= V << ((suntoggle ^ 1) << 3);
		suntoggle ^= 1;
		break;
	case 0xD800:
		suntoggle = 0;
		IRQa = V & 0x10;
		X6502_IRQEnd(FCEU_IQEXT);
		break;
	case 0xE800: mirr = V & 3; Sync(); break;
	case 0xF800: preg = V; Sync(); break;
	}
}

/**
 * @brief Initializes the M67 power state by resetting the suntoggle flag, synchronizing the system,
 *        and setting up the read and write handlers for the specified memory range.
 *
 * This method performs the following operations:
 * 1. Resets the `suntoggle` flag to 0, indicating a specific state change.
 * 2. Calls `Sync()` to ensure the system is in a consistent state.
 * 3. Sets the read handler for the memory range 0x8000 to 0xFFFF to `CartBR`, which handles cartridge bus reads.
 * 4. Sets the write handler for the same memory range to `M67Write`, which handles specific write operations for the M67 power state.
 *
 * This method is typically called during the initialization or reset phase of the M67 power management system.
 */
static void M67Power(void) {
	suntoggle = 0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M67Write);
}

/**
 * @brief Handles the M67 interrupt request (IRQ) logic.
 *
 * This method processes the M67 IRQ by decrementing the IRQCount by the given value `a`.
 * If the IRQCount becomes less than or equal to 0, it triggers an external IRQ by calling
 * X6502_IRQBegin with the FCEU_IQEXT parameter, disables further IRQs by setting IRQa to 0,
 * and resets the IRQCount to -1.
 *
 * @param a The value to decrement the IRQCount by. This is typically a time or cycle value.
 */
void M67IRQ(int a) {
	if (IRQa) {
		IRQCount -= a;
		if (IRQCount <= 0) {
			X6502_IRQBegin(FCEU_IQEXT);
			IRQa = 0;
			IRQCount = -1;
		}
	}
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that the system is synchronized before proceeding with the restoration process.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 67 configuration for the emulator.
 *
 * This function sets up the necessary function pointers and state information for Mapper 67.
 * It assigns the power function, IRQ hook, and game state restoration function to the provided
 * CartInfo structure. Additionally, it adds the state registers to the emulator's state management
 * system to ensure proper state saving and restoring.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific information.
 *             This structure will be populated with the Mapper 67 configuration.
 */
void Mapper67_Init(CartInfo *info) {
	info->Power = M67Power;
	MapIRQHook = M67IRQ;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

