/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2009 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg;
static uint8 *CHRRAM = NULL;
static uint32 CHRRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the PPU and CPU.
 *
 * This method configures the CHR and PRG memory banks for the PPU and CPU respectively.
 * - It sets the first 4KB CHR bank at address 0x0000 to bank 0x10.
 * - It sets the second 4KB CHR bank at address 0x1000 to the lower 4 bits of the `reg` variable.
 * - It sets the first 16KB PRG bank at address 0x8000 to the upper 2 bits of the `reg` variable.
 * - It sets the second 16KB PRG bank at address 0xC000 to the last bank (0xFF).
 *
 * This method is typically used to update the memory mapping based on the current state of the `reg` variable.
 */
static void Sync(void) {
	setchr4r(0x10, 0x0000, 0);
	setchr4r(0x10, 0x1000, reg & 0x0f);
	setprg16(0x8000, reg >> 6);
	setprg16(0xc000, ~0);
}

/**
 * @brief Writes a value to the M168 register and synchronizes the state.
 *
 * This static method assigns the provided value `V` to the `reg` variable, 
 * which represents the M168 register. After updating the register, it calls 
 * the `Sync()` function to ensure that the system state is synchronized 
 * with the new register value.
 *
 * @param V The value to be written to the M168 register.
 */
static DECLFW(M168Write) {
	reg = V;
	Sync();
}

/**
 * @brief Dummy method for M168.
 *
 * This method is a placeholder or dummy implementation that does not perform any specific operation.
 * It is likely used as a default or fallback function in scenarios where a valid function pointer
 * is required but no actual functionality is needed. The method is static and does not modify any
 * state or return any value.
 */
static DECLFW(M168Dummy) {
}

/**
 * @brief Initializes the power-up state for the M168 mapper.
 *
 * This method performs the following operations:
 * 1. Resets the internal register (`reg`) to 0.
 * 2. Synchronizes the state by calling `Sync()`.
 * 3. Configures write handlers for specific memory ranges:
 *    - Writes to 0x4020-0x7FFF are handled by `M168Dummy`.
 *    - Writes to 0xB000 are handled by `M168Write`.
 *    - Writes to 0xF000 and 0xF080 are handled by `M168Dummy`.
 * 4. Configures a read handler for the range 0x8000-0xFFFF, which is handled by `CartBR`.
 *
 * This setup is typically used to initialize the memory mapping and handlers for the M168 mapper
 * during system power-up or reset.
 */
static void M168Power(void) {
	reg = 0;
	Sync();
	SetWriteHandler(0x4020, 0x7fff, M168Dummy);
	SetWriteHandler(0xB000, 0xB000, M168Write);
	SetWriteHandler(0xF000, 0xF000, M168Dummy);
	SetWriteHandler(0xF080, 0xF080, M168Dummy);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Closes and frees the CHRRAM memory if it is allocated.
 *
 * This method checks if the CHRRAM pointer is not null. If it is not null,
 * it frees the memory allocated for CHRRAM using the FCEU_gfree function.
 * After freeing the memory, it sets the CHRRAM pointer to null to indicate
 * that the memory has been released and is no longer in use.
 */
static void M168Close(void) {
	if (CHRRAM)
		FCEU_gfree(CHRRAM);
	CHRRAM = NULL;
}

/**
 * @brief Restores the state based on the provided version.
 *
 * This method is responsible for restoring the state of the system or application
 * to a specific version. It ensures that the system is synchronized before
 * proceeding with the restoration process by calling the `Sync()` method.
 *
 * @param version The version number to which the state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 168 for the given cartridge information.
 * This method sets up the necessary function pointers for power and close operations,
 * configures the game state restoration, and allocates memory for the CHR RAM.
 * It also sets up the CHR RAM mapping for the cartridge.
 *
 * @param info Pointer to the CartInfo structure that holds the cartridge information.
 *             The Power and Close function pointers within this structure are set to
 *             M168Power and M168Close respectively.
 *             The method also sets up the game state restoration and CHR RAM mapping.
 */
void Mapper168_Init(CartInfo *info) {
	info->Power = M168Power;
	info->Close = M168Close;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);

	CHRRAMSIZE = 8192 * 8;
	CHRRAM = (uint8*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CRAM");
}
