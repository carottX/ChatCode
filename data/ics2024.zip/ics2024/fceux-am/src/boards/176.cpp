/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *  Copyright (C) 2012 FCEUX team
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

extern uint32 ROM_size;

static uint8 prg[4], chr, sbw, we_sram;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[]=
{
  {prg, 4, "PRG"},
  {&chr, 1, "CHR"},
  {&sbw, 1, "SBW"},
  {0}
};

/**
 * @brief Synchronizes the PRG (Program ROM) and CHR (Character ROM) memory banks.
 * 
 * This method configures the memory mapping for the PRG and CHR ROMs in an emulator or similar environment.
 * It first sets the PRG ROM bank at address 0x6000 to bank 0x10 using the `setprg8r` function.
 * Then, it maps the first four 8KB PRG ROM banks to the addresses 0x8000, 0xA000, 0xC000, and 0xE000
 * using the `setprg8` function, with the bank numbers specified in the `prg` array.
 * Finally, it sets the CHR ROM bank using the `setchr8` function with the value stored in the `chr` variable.
 */
static void Sync(void)
{
  setprg8r(0x10,0x6000,0);
	setprg8(0x8000,prg[0]);
	setprg8(0xA000,prg[1]);
	setprg8(0xC000,prg[2]);
	setprg8(0xE000,prg[3]);

  setchr8(chr);
}

/**
 * @brief Handles writing to memory address 0x5001 for Mapper 176 (M176).
 *
 * This method is responsible for processing write operations to the memory address 0x5001
 * in the context of Mapper 176. It prints the address and value being written to the console
 * for debugging purposes. If the `sbw` flag is set, it updates the program memory (prg) banks
 * based on the value being written. Specifically, it sets the four consecutive program memory
 * banks to `V*4`, `V*4+1`, `V*4+2`, and `V*4+3`, where `V` is the value being written. Finally,
 * it calls the `Sync()` function to synchronize the state of the mapper.
 *
 * @param A The memory address being written to (0x5001 in this case).
 * @param V The value being written to the memory address.
 */
static DECLFW(M176Write_5001)
{
	printf("%04X = $%02X\n",A,V);
	if(sbw)
	{
		prg[0] = V*4;
		prg[1] = V*4+1;
		prg[2] = V*4+2;
		prg[3] = V*4+3;
	}
  Sync();
}

/**
 * @brief Writes a value to the specified memory address and performs synchronization.
 *
 * This method is a static function that handles writing a value to a specific memory address.
 * It prints the address and the value being written in a formatted string. If the value
 * written is 0x24, it sets the global variable `sbw` to 1. After the write operation,
 * it calls the `Sync()` function to ensure proper synchronization.
 *
 * @param A The memory address where the value is to be written.
 * @param V The value to be written to the memory address.
 */
static DECLFW(M176Write_5010)
{
	printf("%04X = $%02X\n",A,V);
	if(V == 0x24) sbw = 1;
  Sync();
}

/**
 * @brief Handles the write operation for address 0x5011 in mapper 176.
 *
 * This method processes a write operation to the specified address (0x5011) in mapper 176.
 * It prints the address and the value being written to the console. The value is then
 * right-shifted by 1 bit. If the `sbw` flag is set, the method updates the program memory
 * (prg) pointers to point to a new 4KB block of memory based on the shifted value. Finally,
 * it calls the `Sync` function to synchronize the state of the emulator.
 *
 * @param A The address being written to (0x5011).
 * @param V The value being written to the address.
 */
static DECLFW(M176Write_5011)
{
	printf("%04X = $%02X\n",A,V);
	V >>= 1;
	if(sbw)
	{
		prg[0] = V*4;
		prg[1] = V*4+1;
		prg[2] = V*4+2;
		prg[3] = V*4+3;
	}
  Sync();
}

/**
 * @brief Writes a value to the M176 register at address 0x5FF1.
 *
 * This method performs the following operations:
 * 1. Prints the address (A) and value (V) being written in the format "XXXX = $XX".
 * 2. Right-shifts the value (V) by 1 bit.
 * 3. Updates the program memory (prg) array such that:
 *    - prg[0] is set to V * 4
 *    - prg[1] is set to V * 4 + 1
 *    - prg[2] is set to V * 4 + 2
 *    - prg[3] is set to V * 4 + 3
 * 4. Calls the Sync() function to synchronize the changes.
 *
 * @param A The address where the write operation is performed (0x5FF1).
 * @param V The value to be written to the register.
 */
static DECLFW(M176Write_5FF1)
{
	printf("%04X = $%02X\n",A,V);
  V >>= 1;
	prg[0] = V*4;
	prg[1] = V*4+1;
	prg[2] = V*4+2;
	prg[3] = V*4+3;
  Sync();
}

/**
 * @brief Writes a value to the memory address 0x5FF2 and updates the CHR register.
 *
 * This method is a static function that handles writing a value to the memory address 0x5FF2.
 * It prints the address and the value being written in hexadecimal format to the console.
 * After writing the value, it updates the CHR register with the provided value and calls
 * the Sync() function to synchronize the state.
 *
 * @param A The memory address where the value is being written (expected to be 0x5FF2).
 * @param V The value to be written to the memory address.
 */
static DECLFW(M176Write_5FF2)
{
	printf("%04X = $%02X\n",A,V);
  chr = V;
  Sync();
}

/**
 * @brief Writes a value to the A001 register of the M176 mapper.
 *
 * This method updates the `we_sram` variable based on the least significant
 * two bits of the input value `V`. The `we_sram` variable is typically used
 * to control the write enable state of the SRAM in the M176 mapper.
 *
 * @param V The value to be written to the A001 register. Only the least
 *          significant two bits (0x03) are used to update `we_sram`.
 */
static DECLFW(M176Write_A001)
{
	we_sram = V & 0x03;
}

/**
 * @brief Writes data to the SRAM (Static RAM) of the cartridge.
 *
 * This method is responsible for writing a value to the SRAM of the cartridge.
 * It uses the `CartBW` function to perform the actual write operation. The method
 * is static and is typically used in the context of emulating hardware behavior
 * where writes to cartridge SRAM need to be handled.
 *
 * @param A The address in the SRAM where the data will be written.
 * @param V The value to be written to the specified address in the SRAM.
 */
static DECLFW(M176Write_WriteSRAM)
{
//	if(we_sram)
		CartBW(A,V);
}

/**
 * @brief Initializes the memory mapping and state for the M176 mapper.
 *
 * This method sets up the read and write handlers for specific memory ranges
 * to handle cartridge bank switching and SRAM access. It also initializes the
 * PRG (Program ROM) banks and other internal state variables for the M176 mapper.
 *
 * The method performs the following operations:
 * - Sets read handlers for the memory ranges 0x6000-0x7FFF and 0x8000-0xFFFF
 *   to use the `CartBR` function for reading from cartridge banks.
 * - Sets write handlers for specific memory addresses to handle SRAM writes
 *   and mapper-specific control registers:
 *   - 0x6000-0x7FFF: Writes to SRAM are handled by `M176Write_WriteSRAM`.
 *   - 0xA001: Writes are handled by `M176Write_A001`.
 *   - 0x5001: Writes are handled by `M176Write_5001`.
 *   - 0x5010: Writes are handled by `M176Write_5010`.
 *   - 0x5011: Writes are handled by `M176Write_5011`.
 *   - 0x5FF1: Writes are handled by `M176Write_5FF1`.
 *   - 0x5FF2: Writes are handled by `M176Write_5FF2`.
 * - Adds RAM for cheat functionality using `FCEU_CheatAddRAM`.
 * - Initializes internal state variables:
 *   - `we_sram` is set to 0 (SRAM write enable flag).
 *   - `sbw` is set to 0 (unknown purpose, likely mapper-specific).
 *   - PRG banks are initialized to default values:
 *     - `prg[0]` is set to 0.
 *     - `prg[1]` is set to 1.
 *     - `prg[2]` is set to the second-to-last ROM bank.
 *     - `prg[3]` is set to the last ROM bank.
 * - Calls `Sync()` to synchronize the mapper state with the memory mapping.
 */
static void M176Power(void)
{
	SetReadHandler(0x6000,0x7fff,CartBR);
	SetWriteHandler(0x6000,0x7fff,M176Write_WriteSRAM);
	SetReadHandler(0x8000,0xFFFF,CartBR);
	SetWriteHandler(0xA001,0xA001,M176Write_A001);
	SetWriteHandler(0x5001,0x5001,M176Write_5001);
	SetWriteHandler(0x5010,0x5010,M176Write_5010);
	SetWriteHandler(0x5011,0x5011,M176Write_5011);
	SetWriteHandler(0x5ff1,0x5ff1,M176Write_5FF1);
	SetWriteHandler(0x5ff2,0x5ff2,M176Write_5FF2);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);

	we_sram = 0;
	sbw = 0;
	prg[0] = 0;
	prg[1] = 1;
	prg[2] = (ROM_size-2)&63;
	prg[3] = (ROM_size-1)&63;
  Sync();
}


/**
 * @brief Closes and frees the WRAM (Work RAM) memory if it is allocated.
 * 
 * This method checks if the WRAM pointer is not null. If WRAM is allocated,
 * it frees the memory using the FCEU_gfree function. After freeing the memory,
 * it sets the WRAM pointer to null to indicate that no memory is currently allocated.
 * This ensures proper memory management and prevents memory leaks.
 */
static void M176Close(void)
{
  if(WRAM)
    FCEU_gfree(WRAM);
  WRAM = NULL;
}

/**
 * @brief Restores the state of the system based on the provided version.
 * 
 * This method synchronizes the current state of the system with the desired state 
 * corresponding to the specified version. It ensures that the system is updated 
 * to match the state as it was at the time of the given version. The synchronization 
 * process is handled by the `Sync()` method, which is called internally.
 * 
 * @param version The version number representing the state to restore. This version 
 *                should correspond to a previously saved state of the system.
 */
static void StateRestore(int version)
{
  Sync();
}

/**
 * @brief Initializes the Mapper 176 for the emulator.
 *
 * This method sets up the necessary configurations for Mapper 176, which is used in certain NES cartridges.
 * It assigns the power and close functions to the provided CartInfo structure, sets up the game state restore function,
 * allocates memory for the WRAM (Work RAM), and configures the PRG (Program ROM) mapping. Additionally, it adds the WRAM
 * and state registers to the emulator's state system for saving and restoring game states.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific information and function pointers.
 */
void Mapper176_Init(CartInfo *info)
{
  info->Power=M176Power;
  info->Close=M176Close;

  GameStateRestore=StateRestore;

  WRAMSIZE=8192;
  WRAM=(uint8*)FCEU_gmalloc(WRAMSIZE);
  SetupCartPRGMapping(0x10,WRAM,WRAMSIZE,1);
  AddExState(WRAM, WRAMSIZE, 0, "WRAM");
  AddExState(&StateRegs, ~0, 0, 0);
}
