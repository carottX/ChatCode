/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 cregs[4], pregs[2];
static uint8 IRQCount, IRQa;

static SFORMAT StateRegs[] =
{
	{ cregs, 4, "CREG" },
	{ pregs, 2, "PREG" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 1, "IRQC" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping of the program and character ROMs.
 * 
 * This method configures the memory mapping for the NES emulator by setting the 
 * program ROM (PRG) and character ROM (CHR) banks. It uses the following steps:
 * 
 * - Sets the PRG ROM banks at specific memory addresses:
 *   - 0x8000: Uses the value from `pregs[0]` to set the first 8KB PRG bank.
 *   - 0xA000: Uses the value from `pregs[1]` to set the second 8KB PRG bank.
 *   - 0xC000: Sets the third 8KB PRG bank to the second-to-last bank (inverted value of 1).
 *   - 0xE000: Sets the fourth 8KB PRG bank to the last bank (inverted value of 0).
 * 
 * - Sets the CHR ROM banks at specific memory addresses:
 *   - 0x0000: Uses the value from `cregs[0]` to set the first 2KB CHR bank.
 *   - 0x0800: Uses the value from `cregs[1]` to set the second 2KB CHR bank.
 *   - 0x1000: Uses the value from `cregs[2]` to set the third 2KB CHR bank.
 *   - 0x1800: Uses the value from `cregs[3]` to set the fourth 2KB CHR bank.
 * 
 * This method ensures the correct memory mapping for the emulator's execution.
 */
static void Sync(void) {
	setprg8(0x8000, pregs[0]);
	setprg8(0xa000, pregs[1]);
	setprg8(0xc000, ~1);
	setprg8(0xe000, ~0);
	setchr2(0x0000, cregs[0]);
	setchr2(0x0800, cregs[1]);
	setchr2(0x1000, cregs[2]);
	setchr2(0x1800, cregs[3]);
}

/**
 * @brief Writes a value to a specific register and synchronizes the state.
 *
 * This method writes the value `V` to the register indexed by `A & 3` in the `cregs` array.
 * After updating the register, it calls the `Sync()` method to ensure the system state is synchronized.
 *
 * @param A The index used to determine which register to write to. The index is masked with 3
 *          to ensure it is within the bounds of the `cregs` array (i.e., only the lower 2 bits are used).
 * @param V The value to write to the selected register.
 */
static DECLFW(M91Write0) {
	cregs[A & 3] = V;
	Sync();
}

/**
 * @brief Handles write operations for memory address 0x91 in the NES emulator.
 *
 * This method processes write operations to memory address 0x91, which is used to control
 * specific emulator behaviors. The behavior depends on the lower 2 bits of the address (A):
 * - Case 0 and 1: Writes the value V to a register array `pregs` at the index determined by
 *   the lower bit of A. After writing, it calls `Sync()` to synchronize the emulator state.
 * - Case 2: Disables the IRQ (Interrupt Request) by setting `IRQa` and `IRQCount` to 0 and
 *   calling `X6502_IRQEnd(FCEU_IQEXT)` to signal the end of the IRQ.
 * - Case 3: Enables the IRQ by setting `IRQa` to 1 and calling `X6502_IRQEnd(FCEU_IQEXT)`.
 *
 * @param A The memory address being written to (only the lower 2 bits are used).
 * @param V The value being written to the memory address.
 */
static DECLFW(M91Write1) {
	switch (A & 3) {
	case 0:
	case 1: pregs[A & 1] = V; Sync(); break;
	case 2: IRQa = IRQCount = 0; X6502_IRQEnd(FCEU_IQEXT); break;
	case 3: IRQa = 1; X6502_IRQEnd(FCEU_IQEXT); break;
	}
}

/**
 * @brief Initializes the M91 power-up sequence for the emulator.
 *
 * This method performs the following operations:
 * 1. Calls `Sync()` to ensure the emulator is in a consistent state.
 * 2. Sets up write handlers for specific memory ranges:
 *    - `0x6000` to `0x6FFF` is mapped to the `M91Write0` function.
 *    - `0x7000` to `0x7FFF` is mapped to the `M91Write1` function.
 * 3. Sets up a read handler for the memory range `0x8000` to `0xFFFF`, which is mapped to the `CartBR` function.
 * This configuration is typically used to handle memory access for the M91 cartridge during emulation.
 */
static void M91Power(void) {
	Sync();
	SetWriteHandler(0x6000, 0x6fff, M91Write0);
	SetWriteHandler(0x7000, 0x7fff, M91Write1);
	SetReadHandler(0x8000, 0xffff, CartBR);
}

/**
 * @brief Handles the M91 IRQ (Interrupt Request) hook logic.
 *
 * This method is responsible for managing the IRQ count and triggering an external IRQ
 * when the count reaches a specific threshold. It increments the `IRQCount` if it is less
 * than 8 and `IRQa` is enabled. Once the `IRQCount` reaches or exceeds 8, it initiates an
 * external IRQ by calling `X6502_IRQBegin` with the `FCEU_IQEXT` parameter.
 *
 * @note This method is static, meaning it belongs to the class rather than an instance.
 * It assumes the existence of global or class-level variables `IRQCount` and `IRQa`.
 */
static void M91IRQHook(void) {
	if (IRQCount < 8 && IRQa) {
		IRQCount++;
		if (IRQCount >= 8) {
			X6502_IRQBegin(FCEU_IQEXT);
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method ensures that the system is synchronized before restoring the state
 * to the specified version. It calls the `Sync()` method to guarantee that all
 * pending operations are completed and the system is in a consistent state before
 * proceeding with the restoration.
 * 
 * @param version The version of the state to restore. This parameter specifies
 *                which saved state should be loaded back into the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 91 for the emulator.
 * 
 * This function sets up the necessary function pointers and state information for Mapper 91.
 * It assigns the power function (`M91Power`) to the `Power` member of the `CartInfo` structure,
 * which is responsible for handling power-up and reset behavior. Additionally, it sets the 
 * `GameHBIRQHook` to `M91IRQHook`, which is used to handle IRQ (Interrupt Request) events during
 * horizontal blanking intervals. The `GameStateRestore` function is set to `StateRestore`, which
 * is responsible for restoring the game state during emulator state loading. Finally, it adds 
 * the state registers (`StateRegs`) to the emulator's state management system, ensuring that 
 * the mapper's state is saved and restored correctly during emulator state operations.
 * 
 * @param info A pointer to the `CartInfo` structure that holds cartridge-specific information.
 */
void Mapper91_Init(CartInfo *info) {
	info->Power = M91Power;
	GameHBIRQHook = M91IRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
