/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2008 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

// M-022 MMC3 based 830118C T-106 4M + 4M

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Sets the CHR (Character ROM) bank for the specified address.
 *
 * This method configures the CHR bank for the given address `A` by combining the
 * lower 7 bits of the value `V` with bits from the `EXPREGS` array. Specifically,
 * it takes the lower 7 bits of `V` and combines them with bits 2 and 3 of `EXPREGS[0]`
 * (shifted left by 5 positions) to form the final CHR bank value. The resulting value
 * is then used to set the CHR bank for the address `A`.
 *
 * @param A The address for which the CHR bank is being set.
 * @param V The value used to determine the CHR bank, with only the lower 7 bits considered.
 */
static void BMC830118CCW(uint32 A, uint8 V) {
	setchr1(A, (V & 0x7F) | ((EXPREGS[0] & 0x0c) << 5));
}

/**
 * @brief Configures the program memory banks based on the provided address and value.
 *
 * This method is used to set the program memory banks (PRG) in a specific configuration.
 * The behavior depends on the value of `EXPREGS[0]` and the address `A`:
 * - If `EXPREGS[0] & 0x0C` equals `0x0C`, the method performs additional checks on the address `A`:
 *   - If `A` is `0x8000`, it sets the PRG bank at `0x8000` and `0xC000` using the value `V` and `EXPREGS[0]`.
 *   - If `A` is `0xA000`, it sets the PRG bank at `0xA000` and `0xE000` using the value `V` and `EXPREGS[0]`.
 * - Otherwise, it sets the PRG bank at the address `A` using the value `V` and `EXPREGS[0]`.
 *
 * @param A The address where the PRG bank is to be set.
 * @param V The value used to configure the PRG bank.
 */
static void BMC830118CPW(uint32 A, uint8 V) {
	if ((EXPREGS[0] & 0x0C) == 0x0C) {
		if (A == 0x8000) {
			setprg8(A, (V & 0x0F) | ((EXPREGS[0] & 0x0c) << 2));
			setprg8(0xC000, (V & 0x0F) | 0x32);
		} else if (A == 0xA000) {
			setprg8(A, (V & 0x0F) | ((EXPREGS[0] & 0x0c) << 2));
			setprg8(0xE000, (V & 0x0F) | 0x32);
		}
	} else {
		setprg8(A, (V & 0x0F) | ((EXPREGS[0] & 0x0c) << 2));
	}
}

/**
 * @brief Writes a value to the low byte of the BMC830118C register and updates the MMC3 PRG and CHR mappings.
 *
 * This method is responsible for writing the provided value `V` to the low byte of the EXPREGS register array.
 * After updating the register, it calls the `FixMMC3PRG` and `FixMMC3CHR` functions to update the MMC3 program (PRG)
 * and character (CHR) memory mappings based on the current MMC3 command (`MMC3_cmd`).
 *
 * @param V The value to be written to the low byte of the EXPREGS register.
 */
static DECLFW(BMC830118CLoWrite) {
	EXPREGS[0] = V;
	FixMMC3PRG(MMC3_cmd);
	FixMMC3CHR(MMC3_cmd);
}

/**
 * @brief Resets the BMC830118C device by clearing the first entry in the EXPREGS array
 *        and resetting the MMC3 registers.
 *
 * This function performs a reset operation on the BMC830118C device by setting the first
 * entry in the EXPREGS array to 0 and calling the MMC3RegReset function to reset the MMC3
 * registers. This is typically used to initialize the device to a known state.
 */
static void BMC830118CReset(void) {
	EXPREGS[0] = 0;
	MMC3RegReset();
}

/**
 * @brief Initializes the power state for the BMC830118C mapper.
 *
 * This method is responsible for setting up the initial power state of the BMC830118C mapper.
 * It performs the following operations:
 * 1. Clears the first entry in the EXPREGS array by setting it to 0.
 * 2. Calls the GenMMC3Power() function to initialize the MMC3 power state.
 * 3. Sets a write handler for the memory range 0x6800 to 0x68FF, which will handle
 *    write operations using the BMC830118CLoWrite function.
 *
 * This method is typically called during the initialization or reset sequence of the emulator
 * to ensure the mapper is in a known state.
 */
static void BMC830118CPower(void) {
	EXPREGS[0] = 0;
	GenMMC3Power();
	SetWriteHandler(0x6800, 0x68FF, BMC830118CLoWrite);
}

/**
 * Initializes the BMC830118C mapper for the specified cartridge.
 *
 * This function sets up the BMC830118C mapper by initializing the MMC3 chip
 * with specific parameters, configuring the PRG and CHR ROM sizes, and setting
 * up the necessary function pointers for power management and reset operations.
 * It also adds an external state for the mapper's registers.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific
 *             information. This structure is used to configure the mapper and
 *             store relevant data such as power and reset handlers.
 *
 * @note The function initializes the MMC3 chip with 128 KB of PRG ROM, 128 KB
 *       of CHR ROM, and 8 KB of WRAM. It also sets up the PRG and CHR wrappers
 *       specific to the BMC830118C mapper.
 */
void BMC830118C_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 128, 8, 0);
	pwrap = BMC830118CPW;
	cwrap = BMC830118CCW;
	info->Power = BMC830118CPower;
	info->Reset = BMC830118CReset;
	AddExState(EXPREGS, 1, 0, "EXPR");
}
