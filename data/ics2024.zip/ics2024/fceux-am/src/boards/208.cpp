/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "mmc3.h"

static uint8 lut[256] = {
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x49, 0x19, 0x09, 0x59, 0x49, 0x19, 0x09,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x51, 0x41, 0x11, 0x01, 0x51, 0x41, 0x11, 0x01,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x49, 0x19, 0x09, 0x59, 0x49, 0x19, 0x09,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x51, 0x41, 0x11, 0x01, 0x51, 0x41, 0x11, 0x01,
	0x00, 0x10, 0x40, 0x50, 0x00, 0x10, 0x40, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x08, 0x18, 0x48, 0x58, 0x08, 0x18, 0x48, 0x58, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x10, 0x40, 0x50, 0x00, 0x10, 0x40, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x08, 0x18, 0x48, 0x58, 0x08, 0x18, 0x48, 0x58, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x58, 0x48, 0x18, 0x08, 0x58, 0x48, 0x18, 0x08,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x50, 0x40, 0x10, 0x00, 0x50, 0x40, 0x10, 0x00,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x58, 0x48, 0x18, 0x08, 0x58, 0x48, 0x18, 0x08,
	0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x59, 0x50, 0x40, 0x10, 0x00, 0x50, 0x40, 0x10, 0x00,
	0x01, 0x11, 0x41, 0x51, 0x01, 0x11, 0x41, 0x51, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x09, 0x19, 0x49, 0x59, 0x09, 0x19, 0x49, 0x59, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x01, 0x11, 0x41, 0x51, 0x01, 0x11, 0x41, 0x51, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x09, 0x19, 0x49, 0x59, 0x09, 0x19, 0x49, 0x59, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};

/**
 * @brief Sets the Program ROM (PRG) bank for the M208PW mapper.
 *
 * This method configures the PRG ROM bank for the M208PW mapper by setting the
 * 32KB PRG ROM bank at the specified address (0x8000). The bank number is
 * determined by the value stored in the `EXPREGS[5]` register. This method is
 * typically used in emulators or hardware implementations to manage memory
 * mapping for the M208PW mapper.
 *
 * @param A Unused parameter in this context.
 * @param V Unused parameter in this context.
 */
static void M208PW(uint32 A, uint8 V) {
	setprg32(0x8000, EXPREGS[5]);
}

/**
 * @brief Writes a value to the M208 register and updates the MMC3 PRG banking.
 *
 * This method processes the input value `V` to update the fifth element of the `EXPREGS` array.
 * The value is manipulated such that the least significant bit (LSB) of `V` is assigned to the LSB
 * of `EXPREGS[5]`, and the fourth bit of `V` (shifted right by 3) is assigned to the second bit of `EXPREGS[5]`.
 * After updating `EXPREGS[5]`, the method calls `FixMMC3PRG` with the current `MMC3_cmd` to adjust
 * the Program ROM (PRG) banking configuration accordingly.
 *
 * @param V The input value to be written to the M208 register.
 */
static DECLFW(M208Write) {
	EXPREGS[5] = (V & 0x1) | ((V >> 3) & 0x2);
	FixMMC3PRG(MMC3_cmd);
}

/**
 * @brief Writes data to the M208 protection registers based on the address and value provided.
 *
 * This method handles writing to the M208 protection registers. If the address `A` is less than or equal to 0x57FF,
 * the value `V` is directly written to the 5th element of the `EXPREGS` array. Otherwise, the value `V` is XORed with
 * a value from the `lut` array (using the 5th element of `EXPREGS` as the index) and written to one of the first four
 * elements of the `EXPREGS` array, determined by the lower 2 bits of the address `A`.
 *
 * @param A The address to write to. Determines which register is updated.
 * @param V The value to write to the register.
 */
static DECLFW(M208ProtWrite) {
	if (A <= 0x57FF)
		EXPREGS[4] = V;
	else
		EXPREGS[(A & 0x03)] = V ^ lut[EXPREGS[4]];
}

/**
 * @brief Reads a value from the M208 protection register based on the provided address.
 *
 * This method is a static function that reads a value from the EXPREGS array, which represents
 * the M208 protection registers. The specific register to read is determined by the lower 2 bits
 * of the address `A` (i.e., `A & 0x3`). The method returns the value stored in the corresponding
 * register.
 *
 * @param A The address used to determine which register to read. Only the lower 2 bits are used.
 * @return The value stored in the EXPREGS array at the index determined by the lower 2 bits of `A`.
 */
static DECLFR(M208ProtRead) {
	return(EXPREGS[(A & 0x3)]);
}

/**
 * @brief Initializes the M208 mapper's power-up state.
 *
 * This method sets up the M208 mapper by configuring the necessary registers and handlers.
 * It performs the following operations:
 * 1. Sets the value of EXPREGS[5] to 3, which initializes a specific register in the mapper.
 * 2. Calls GenMMC3Power() to initialize the base MMC3 mapper functionality.
 * 3. Sets up write handlers for specific memory ranges:
 *    - 0x4800-0x4FFF and 0x6800-0x6FFF are mapped to M208Write.
 *    - 0x5000-0x5FFF is mapped to M208ProtWrite.
 * 4. Sets up read handlers for specific memory ranges:
 *    - 0x5800-0x5FFF is mapped to M208ProtRead.
 *    - 0x8000-0xFFFF is mapped to CartBR, which handles cartridge bank reading.
 */
static void M208Power(void) {
	EXPREGS[5] = 3;
	GenMMC3Power();
	SetWriteHandler(0x4800, 0x4fff, M208Write);
	SetWriteHandler(0x6800, 0x6fff, M208Write);
	SetWriteHandler(0x5000, 0x5fff, M208ProtWrite);
	SetReadHandler(0x5800, 0x5fff, M208ProtRead);
	SetReadHandler(0x8000, 0xffff, CartBR);
}

/**
 * @brief Initializes the Mapper 208 for the given cartridge information.
 *
 * This function sets up the Mapper 208, which is a variant of the MMC3 mapper.
 * It initializes the MMC3 with 128 KB of PRG-ROM, 256 KB of CHR-ROM, and no
 * WRAM or battery-backed RAM. The function also sets the PRG-ROM write handler
 * to the M208PW function and assigns the M208Power function to handle power
 * cycles. Additionally, it adds the state of the expansion registers (EXPREGS)
 * to the save state system.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void Mapper208_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 256, 0, 0);
	pwrap = M208PW;
	info->Power = M208Power;
	AddExState(EXPREGS, 6, 0, "EXPR");
}
