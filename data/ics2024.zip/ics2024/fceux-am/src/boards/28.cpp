/*
	Copyright (C) 2012-2017 FCEUX team

	This file is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This file is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with the this software.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "mapinc.h"

// http://wiki.nesdev.com/w/index.php/INES_Mapper_028

//config
static int prg_mask_16k;

// state
uint8 reg;
uint8 chr;
uint8 prg;
uint8 mode;
uint8 outer;

/**
 * @brief Synchronizes the mirroring mode based on the current mode setting.
 *
 * This method evaluates the lower two bits of the `mode` variable to determine
 * the appropriate mirroring mode. It then calls the `setmirror` function with
 * the corresponding mirroring mode constant:
 * - If the lower two bits are `00`, it sets the mirroring mode to `MI_0`.
 * - If the lower two bits are `01`, it sets the mirroring mode to `MI_1`.
 * - If the lower two bits are `10`, it sets the mirroring mode to `MI_V` (vertical mirroring).
 * - If the lower two bits are `11`, it sets the mirroring mode to `MI_H` (horizontal mirroring).
 */
void SyncMirror()
{
	switch (mode & 3)
	{
		case 0: setmirror(MI_0); break;
		case 1: setmirror(MI_1); break;
		case 2: setmirror(MI_V); break;
		case 3: setmirror(MI_H); break;
	}
}

/**
 * @brief Mirrors the given value based on the current mode and updates the mirroring state.
 *
 * This method checks if the second bit of the `mode` variable is not set (i.e., `mode & 2` is 0).
 * If this condition is met, it clears the least significant bit of `mode` and then sets it to
 * the fifth bit of the provided `value`. After updating the `mode`, it calls `SyncMirror()` to
 * synchronize the mirroring state.
 *
 * @param value The 8-bit value used to update the mirroring state. The fifth bit of this value
 *              determines the new state of the least significant bit in `mode`.
 */
void Mirror(uint8 value)
{
	if ((mode & 2) == 0)
	{
		mode &= 0xfe;
		mode |= value >> 4 & 1;
	}
	SyncMirror();
}


/**
 * @brief Synchronizes the PRG and CHR memory mappings based on the current mode and configuration.
 *
 * This method updates the Programmable Read-Only Memory (PRG) and Character Read-Only Memory (CHR)
 * mappings based on the current mode and configuration settings. The mode is determined by the
 * lower 6 bits of the `mode` variable, and the PRG mapping is adjusted accordingly. The method
 * calculates the low and high PRG bank values (`prglo` and `prghi`) based on the mode and the
 * current PRG bank (`prg`). The `outer` variable is shifted left by 1 bit to form the base for
 * the PRG bank calculations.
 *
 * The method supports various modes, including 32K modes, bottom fixed modes, and top fixed modes,
 * each of which affects how the PRG banks are determined. After calculating the PRG bank values,
 * the method applies a 16K mask (`prg_mask_16k`) to ensure the values are within the valid range.
 *
 * Finally, the method sets the PRG memory mappings using the `setprg16` function for the specified
 * memory addresses (0x8000 and 0xC000) and updates the CHR memory mapping using the `setchr8`
 * function with the current `chr` value.
 *
 * @note The method contains a switch statement that handles different modes, and the logic for
 *       calculating the PRG bank values is complex. The method is designed to be tested thoroughly
 *       before any optimizations are applied.
 */
static void Sync()
{
	int prglo = 0;
	int prghi = 0;

	int outb = outer << 1;
	//this can probably be rolled up, but i have no motivation to do so
	//until it's been tested
	switch (mode & 0x3c)
	{
		//32K modes
	case 0x00:
	case 0x04:
		prglo = outb;
		prghi = outb | 1;
		break;
	case 0x10:
	case 0x14:
		prglo = (outb & ~2) | ((prg << 1) & 2);
		prghi = (outb & ~2) | ((prg << 1) & 2) | 1;
		break;
	case 0x20:
	case 0x24:
		prglo = (outb & ~6) | ((prg << 1) & 6);
		prghi = (outb & ~6) | ((prg << 1) & 6) | 1;
		break;
	case 0x30:
	case 0x34:
		prglo = (outb & ~14) | ((prg << 1) & 14);
		prghi = (outb & ~14) | ((prg << 1) & 14) | 1;
		break;
		//bottom fixed modes
	case 0x08:
		prglo = outb;
		prghi = outb | (prg & 1);
		break;
	case 0x18:
		prglo = outb;
		prghi = (outb & ~2) | (prg & 3);
		break;
	case 0x28:
		prglo = outb;
		prghi = (outb & ~6) | (prg & 7);
		break;
	case 0x38:
		prglo = outb;
		prghi = (outb & ~14) | (prg & 15);
		break;
		//top fixed modes
	case 0x0c:
		prglo = outb | (prg & 1);
		prghi = outb | 1;
		break;
	case 0x1c:
		prglo = (outb & ~2) | (prg & 3);
		prghi = outb | 1;
		break;
	case 0x2c:
		prglo = (outb & ~6) | (prg & 7);
		prghi = outb | 1;
		break;
	case 0x3c:
		prglo = (outb & ~14) | (prg & 15);
		prghi = outb | 1;
		break;
	}
	prglo &= prg_mask_16k;
	prghi &= prg_mask_16k;

	setprg16(0x8000, prglo);
	setprg16(0xC000, prghi);
	setchr8(chr);
}

/**
 * @brief Writes a value to the EXP register.
 *
 * This method takes an 8-bit value `V` and writes it to the EXP register.
 * Only the least significant bit (LSB) and the most significant bit (MSB)
 * of the value are preserved in the register. Specifically, the value
 * is masked with `0x81` (binary `10000001`), ensuring that only the LSB
 * and MSB are written to the register.
 *
 * @param V The 8-bit value to be written to the EXP register.
 */
static DECLFW(WriteEXP)
{
	uint8 value = V;
	reg = value & 0x81;
}

/**
 * @brief Writes to the PRG (Program ROM) register based on the specified register address.
 * 
 * This method handles writing to different registers that control various aspects of the emulator's
 * memory mapping and mirroring behavior. The specific action taken depends on the value of the `reg`
 * parameter:
 * 
 * - If `reg` is 0x00, the CHR (Character ROM) bank is updated with the lower 2 bits of the input value,
 *   and the mirroring mode is set based on the value. The state is then synchronized.
 * 
 * - If `reg` is 0x01, the PRG (Program ROM) bank is updated with the lower 4 bits of the input value,
 *   and the mirroring mode is set based on the value. The state is then synchronized.
 * 
 * - If `reg` is 0x80, the mode is updated with the lower 6 bits of the input value, and both the mirroring
 *   and state are synchronized.
 * 
 * - If `reg` is 0x81, the outer bank is updated with the lower 6 bits of the input value, and the state
 *   is synchronized.
 * 
 * @param reg The register address to write to. Determines which register is updated.
 * @param V The value to write to the specified register.
 */
static DECLFW(WritePRG)
{
	uint8 value = V;
	switch (reg)
	{
	case 0x00:
		chr = value & 3;
		Mirror(value);
		Sync();
		break;
	case 0x01:
		prg = value & 15;
		Mirror(value);
		Sync();
		break;
	case 0x80:
		mode = value & 63;
		SyncMirror();
		Sync();
		break;
	case 0x81:
		outer = value & 63;
		Sync();
		break;
	}
}



/**
 * @brief Resets the M28 module to its default state.
 *
 * This method initializes the M28 module by setting the 'outer' variable to 63 
 * and the 'prg' variable to 15. After updating these variables, it calls the 
 * 'Sync()' function to ensure that the module's state is synchronized with 
 * the current configuration. This is typically used to restore the module to 
 * a known state during initialization or after a system reset.
 */
static void M28Reset(void)
{
	outer = 63;
	prg = 15;
	Sync();
}


/**
 * @brief Initializes the memory mapping and handlers for the M28 Power state.
 *
 * This method sets up the memory mapping and handlers for the M28 Power state in an emulator or similar system.
 * It configures the Program ROM (PRG) mask, sets up write and read handlers for the expansion (EXP) region,
 * the PRG region, and the Work RAM (WRAM) region. Finally, it calls the M28Reset method to complete the
 * initialization process.
 *
 * The specific memory regions and their handlers are configured as follows:
 * - PRG mask is set based on the size of the first PRG ROM bank.
 * - EXP region (0x5000-0x5FFF) is configured with a custom write handler.
 * - PRG region (0x8000-0xFFFF) is configured with both write and read handlers.
 * - WRAM region (0x6000-0x7FFF) is configured with both read and write handlers.
 *
 * This method is typically called during the initialization or reset phase of the emulator to ensure
 * proper memory mapping and handling for the M28 Power state.
 */
static void M28Power(void)
{
	prg_mask_16k = PRGsize[0] - 1;

	//EXP
	SetWriteHandler(0x5000,0x5FFF,WriteEXP);

	//PRG
	SetWriteHandler(0x8000,0xFFFF,WritePRG);
	SetReadHandler(0x8000,0xFFFF,CartBR);

	//WRAM
  SetReadHandler(0x6000,0x7FFF,CartBR);
  SetWriteHandler(0x6000,0x7FFF,CartBW);

	M28Reset();
}

/**
 * @brief Closes the M28 interface or resource.
 *
 * This method is responsible for performing the necessary operations to safely
 * close or release the M28 interface or resource. It ensures that any active
 * connections, handles, or resources associated with M28 are properly terminated
 * and cleaned up to prevent resource leaks or undefined behavior.
 *
 * @note This method is static and should be called when the M28 interface is no
 * longer needed or before the application exits to ensure proper cleanup.
 */
static void M28Close(void)
{
}

static SFORMAT StateRegs[]=
{
	{&reg, 1, "REG"},
	{&chr, 1, "CHR"},
	{&prg, 1, "PRG"},
	{&mode, 1, "MODE"},
	{&outer, 1, "OUTR"},
	{0}
};

/**
 * @brief Restores the state of the system based on the provided version.
 *
 * This method is responsible for restoring the system's state to a specific version. 
 * It first ensures synchronization of all relevant components by calling the `Sync()` method, 
 * which guarantees that all data is consistent before proceeding with the restoration process.
 *
 * @param version The version of the state to restore. This parameter specifies which 
 *                state should be loaded or applied to the system.
 */
static void StateRestore(int version)
{
	Sync();
}

/**
 * @brief Initializes the Mapper 28 for the provided cartridge information.
 *
 * This method sets up the necessary function pointers for the Mapper 28, including
 * the power, reset, and close handlers. It also registers the game state restoration
 * function and adds the state registers to the emulator's state management system.
 *
 * @param info Pointer to the CartInfo structure that holds the cartridge's
 *             configuration and function pointers.
 */
void Mapper28_Init(CartInfo* info)
{
	info->Power=M28Power;
	info->Reset=M28Reset;
	info->Close=M28Close;
	GameStateRestore=StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
