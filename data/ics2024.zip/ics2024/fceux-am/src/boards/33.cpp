/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 is48;
static uint8 regs[8], mirr;
static uint8 IRQa;
static int16 IRQCount, IRQLatch;

static SFORMAT StateRegs[] =
{
	{ regs, 8, "PREG" },
	{ &mirr, 1, "MIRR" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 2, "IRQC" },
	{ &IRQLatch, 2, "IRQL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping configuration for the emulator.
 * 
 * This method updates the memory mapping settings for the emulator by configuring the Program ROM (PRG) 
 * and Character ROM (CHR) banks, as well as the mirroring mode. It performs the following operations:
 * 
 * 1. Sets the mirroring mode using the global `mirr` variable.
 * 2. Configures the PRG ROM banks:
 *    - Maps the first 8KB PRG bank to the address range 0x8000-0x9FFF using `regs[0]`.
 *    - Maps the second 8KB PRG bank to the address range 0xA000-0xBFFF using `regs[1]`.
 *    - Maps the third 8KB PRG bank to the address range 0xC000-0xDFFF using the fixed value `~1`.
 *    - Maps the fourth 8KB PRG bank to the address range 0xE000-0xFFFF using the fixed value `~0`.
 * 3. Configures the CHR ROM banks:
 *    - Maps the first 2KB CHR bank to the address range 0x0000-0x07FF using `regs[2]`.
 *    - Maps the second 2KB CHR bank to the address range 0x0800-0x0FFF using `regs[3]`.
 *    - Maps four 1KB CHR banks to the address ranges 0x1000-0x13FF, 0x1400-0x17FF, 0x1800-0x1BFF, 
 *      and 0x1C00-0x1FFF using `regs[4]`, `regs[5]`, `regs[6]`, and `regs[7]` respectively.
 * 
 * This method is typically called whenever the memory mapping configuration needs to be updated, 
 * such as during initialization or when handling mapper-specific operations.
 */
static void Sync(void) {
	setmirror(mirr);
	setprg8(0x8000, regs[0]);
	setprg8(0xA000, regs[1]);
	setprg8(0xC000, ~1);
	setprg8(0xE000, ~0);
	setchr2(0x0000, regs[2]);
	setchr2(0x0800, regs[3]);
	setchr1(0x1000, regs[4]);
	setchr1(0x1400, regs[5]);
	setchr1(0x1800, regs[6]);
	setchr1(0x1C00, regs[7]);
}

/**
 * @brief Handles write operations to specific memory-mapped registers.
 *
 * This method processes write operations to a set of memory-mapped registers
 * based on the provided address `A` and value `V`. The address `A` is masked
 * with `0xF003` to ensure only relevant bits are considered. Depending on the
 * masked address, the method updates the corresponding register in the `regs`
 * array and triggers a synchronization operation via `Sync()`.
 *
 * The following addresses are supported:
 * - `0x8000`: Updates `regs[0]` with the lower 6 bits of `V`. If `is48` is false,
 *             it also updates the `mirr` flag based on the 7th bit of `V`.
 * - `0x8001`: Updates `regs[1]` with the lower 6 bits of `V`.
 * - `0x8002`: Updates `regs[2]` with the full value of `V`.
 * - `0x8003`: Updates `regs[3]` with the full value of `V`.
 * - `0xA000`: Updates `regs[4]` with the full value of `V`.
 * - `0xA001`: Updates `regs[5]` with the full value of `V`.
 * - `0xA002`: Updates `regs[6]` with the full value of `V`.
 * - `0xA003`: Updates `regs[7]` with the full value of `V`.
 *
 * After each register update, the `Sync()` method is called to ensure the
 * system state is synchronized.
 */
static DECLFW(M33Write) {
	A &= 0xF003;
	switch(A) {
	case 0x8000: regs[0] = V & 0x3F; if(!is48) mirr = ((V >> 6) & 1) ^ 1; Sync(); break;
	case 0x8001: regs[1] = V & 0x3F; Sync(); break;
	case 0x8002: regs[2] = V; Sync(); break;
	case 0x8003: regs[3] = V; Sync(); break;
	case 0xA000: regs[4] = V; Sync(); break;
	case 0xA001: regs[5] = V; Sync(); break;
	case 0xA002: regs[6] = V; Sync(); break;
	case 0xA003: regs[7] = V; Sync(); break;
	}
}

/**
 * @brief Handles write operations to specific memory addresses for the M48 mapper.
 * 
 * This method processes write operations to memory addresses that are mapped to the M48 mapper.
 * It updates internal state variables based on the address and value written. The method
 * supports the following operations:
 * 
 * - Writing to address 0xC000: Updates the IRQ latch value with the provided data.
 * - Writing to address 0xC001: Sets the IRQ counter to the current IRQ latch value.
 * - Writing to address 0xC003: Disables IRQ generation and signals the end of an external IRQ.
 * - Writing to address 0xC002: Enables IRQ generation.
 * - Writing to address 0xE000: Updates the mirroring configuration based on the provided data
 *   and synchronizes the mapper state.
 * 
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(M48Write) {
	switch (A & 0xF003) {
	case 0xC000: IRQLatch = V; break;
	case 0xC001: IRQCount = IRQLatch; break;
	case 0xC003: IRQa = 0; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0xC002: IRQa = 1; break;
	case 0xE000: mirr = ((V >> 6) & 1) ^ 1; Sync(); break;
	}
}

/**
 * @brief Configures the memory mapping for the M33 Power functionality.
 *
 * This method synchronizes the system state by calling `Sync()`, then sets up
 * the read and write handlers for the memory range 0x8000 to 0xFFFF. Specifically,
 * it assigns `CartBR` as the read handler and `M33Write` as the write handler
 * for this memory range. This setup is typically used to manage cartridge-based
 * memory access in an emulator or similar system.
 */
static void M33Power(void) {
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M33Write);
}

/**
 * @brief Initializes the memory mapping for the M48 power configuration.
 *
 * This method sets up the read and write handlers for specific memory ranges
 * to configure the M48 power mode. It performs the following operations:
 * 1. Calls `Sync()` to ensure synchronization before modifying memory handlers.
 * 2. Sets a read handler for the memory range 0x8000 to 0xFFFF using `CartBR`.
 * 3. Sets a write handler for the memory range 0x8000 to 0xBFFF using `M33Write`.
 * 4. Sets a write handler for the memory range 0xC000 to 0xFFFF using `M48Write`.
 *
 * This configuration is typically used to manage memory access for a specific
 * hardware or emulation scenario, such as cartridge-based systems.
 */
static void M48Power(void) {
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xBFFF, M33Write);
	SetWriteHandler(0xC000, 0xFFFF, M48Write);
}

/**
 * @brief Handles the M48 interrupt request (IRQ).
 *
 * This method is responsible for managing the M48 IRQ. It checks if the IRQ is enabled (IRQa).
 * If the IRQ is enabled, it increments the IRQ counter (IRQCount). When the IRQ counter reaches
 * the value 0x100, it triggers an external IRQ on the 6502 processor by calling X6502_IRQBegin
 * with the FCEU_IQEXT parameter, and then disables the IRQ by setting IRQa to 0.
 *
 * This method is typically used in emulation contexts to simulate hardware interrupt behavior.
 */
static void M48IRQ(void) {
	if (IRQa) {
		IRQCount++;
		if (IRQCount == 0x100) {
			X6502_IRQBegin(FCEU_IQEXT);
			IRQa = 0;
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method ensures that the system's state is synchronized with the desired version 
 * by calling the `Sync()` method. The `Sync()` method is responsible for aligning the 
 * current state with the specified version, ensuring consistency and correctness.
 * 
 * @param version The version number to which the system's state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 33 (Taito TC0190) for the provided cartridge information.
 *
 * This method sets up the necessary configurations for Mapper 33, which is used in certain NES games.
 * It initializes the `is48` flag to 0, assigns the `M33Power` function to the `Power` pointer in the
 * `CartInfo` structure, sets the `GameStateRestore` function to `StateRestore`, and adds the state
 * registers to the emulator's state management system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific information.
 */
void Mapper33_Init(CartInfo *info) {
	is48 = 0;
	info->Power = M33Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * @brief Initializes the Mapper 48 configuration for the emulator.
 *
 * This method sets up the necessary configurations for Mapper 48, which is used in some NES ROMs.
 * It enables Mapper 48 by setting the global flag `is48` to 1. It also assigns the appropriate
 * power function (`M48Power`) to the `Power` member of the `CartInfo` structure. Additionally,
 * it sets the HBI (Horizontal Blank Interrupt) IRQ hook to `M48IRQ` and the game state restore
 * function to `StateRestore`. Finally, it adds the state registers to the emulator's state
 * management system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure that holds cartridge-specific information.
 */
void Mapper48_Init(CartInfo *info) {
	is48 = 1;
	info->Power = M48Power;
	GameHBIRQHook = M48IRQ;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

