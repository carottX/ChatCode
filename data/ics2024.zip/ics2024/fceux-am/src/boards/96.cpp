/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 1998 BERO
 *  Copyright (C) 2002 Xodnizel
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg, ppulatch;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REG" },
	{ &ppulatch, 1, "PPUL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the NES.
 *
 * This method configures the memory mapping and mirroring for the NES by performing the following operations:
 * 1. Sets the mirroring mode to `MI_0` (horizontal mirroring).
 * 2. Maps the 32KB PRG ROM to the address `0x8000` using the lower 2 bits of the `reg` register.
 * 3. Maps the first 4KB of CHR ROM to the address `0x0000` using a combination of the `reg` register's third bit and the `ppulatch` value.
 * 4. Maps the second 4KB of CHR ROM to the address `0x1000` using the `reg` register's third bit and a fixed value of `3`.
 *
 * This method is typically called to update the memory mapping and mirroring configuration during runtime.
 */
static void Sync(void) {
	setmirror(MI_0);
	setprg32(0x8000, reg & 3);
	setchr4(0x0000, (reg & 4) | ppulatch);
	setchr4(0x1000, (reg & 4) | 3);
}

/**
 * @brief Writes a value to the M96 register and synchronizes the state.
 *
 * This method assigns the provided value `V` to the `reg` variable, which represents
 * the M96 register. After updating the register, it calls the `Sync()` function to
 * ensure that the system state is synchronized with the new register value. This
 * is typically used in emulation or hardware abstraction contexts where precise
 * control over register states is required.
 *
 * @param V The value to be written to the M96 register.
 */
static DECLFW(M96Write) {
	reg = V;
	Sync();
}

/**
 * @brief Processes a memory-mapped I/O write to the M96 register.
 *
 * This method is a static hook that handles writes to the M96 register. It checks if the
 * provided address `A` matches the specific condition `(A & 0x3000) == 0x2000`. If the condition
 * is met, it extracts the value from bits 8 and 9 of the address and stores it in the global
 * variable `ppulatch`. After updating `ppulatch`, it calls the `Sync()` function to ensure
 * proper synchronization with the system.
 *
 * @param A The 32-bit address being written to the M96 register.
 */
static void M96Hook(uint32 A) {
	if ((A & 0x3000) == 0x2000) {
		ppulatch = (A >> 8) & 3;
		Sync();
	}
}

/**
 * @brief Initializes the M96 Power state for the emulator.
 *
 * This method resets the internal registers and latches to their default state,
 * synchronizes the emulator's state, and sets up the memory handlers for the
 * specified address range (0x8000 to 0xFFFF). Specifically, it assigns a read
 * handler (`CartBR`) and a write handler (`M96Write`) to this range.
 *
 * @details The method performs the following steps:
 * 1. Resets the `reg` and `ppulatch` variables to 0.
 * 2. Calls `Sync()` to synchronize the emulator's state.
 * 3. Sets the read handler for the address range 0x8000 to 0xFFFF to `CartBR`.
 * 4. Sets the write handler for the address range 0x8000 to 0xFFFF to `M96Write`.
 */
static void M96Power(void) {
	reg = ppulatch = 0;
	Sync();
	SetReadHandler(0x8000, 0xffff, CartBR);
	SetWriteHandler(0x8000, 0xffff, M96Write);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that the system is synchronized before proceeding with the restoration process.
 * 
 * @param version The version number of the state to be restored. This typically corresponds
 *                to a specific snapshot or checkpoint in the system's history.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 96 for the provided cartridge information.
 * This function sets up the necessary function pointers and state restoration
 * mechanisms for Mapper 96. Specifically, it assigns the power function,
 * PPU hook, and game state restoration function. Additionally, it adds
 * the state registers to the emulator's state management system.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific
 *             information and function pointers.
 */
void Mapper96_Init(CartInfo *info) {
	info->Power = M96Power;
	PPU_hook = M96Hook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

