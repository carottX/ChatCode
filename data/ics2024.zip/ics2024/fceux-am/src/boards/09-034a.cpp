/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * FDS Conversions
 *
 * Super Mario Bros 2j (Alt Full) is a BAD incomplete dump, should be mapper 43
 *
 * Both Voleyball and Zanac by Whirlind Manu shares the same PCB, but with
 * some differences: Voleyball has 8K CHR ROM and 8K ROM at 6000K, Zanac
 * have 8K CHR RAM and banked 16K ROM mapper at 6000 as two 8K banks.
*
 * Super Mario Bros 2j (Alt Small) uses additionally IRQ timer to drive framerate
 *
 * PCB for this mapper is "09-034A"
 */

#include "mapinc.h"

static uint8 prg;
static uint32 IRQCount, IRQa;

static SFORMAT StateRegs[] =
{
	{ &IRQCount, 4, "IRQC" },
	{ &IRQa, 4, "IRQA" },
	{ &prg, 1, "PRG" },
	{ 0 }
};

/**
 * Synchronizes the memory mapping of the program and character ROMs.
 * This method configures the memory mapping for the NES system by:
 * - Setting the 8KB PRG-ROM bank at address 0x6000 using the specified PRG index.
 * - Setting the 32KB PRG-ROM bank starting at address 0x8000 to bank 0.
 * - Setting the 8KB CHR-ROM bank to bank 0.
 * This ensures the correct memory layout for the program and character data.
 */
static void Sync(void) {
	setprg8r(1, 0x6000, prg);
	setprg32(0x8000, 0);
	setchr8(0);
}

/**
 * @brief Writes a value to the PRG register and synchronizes the state.
 *
 * This method updates the PRG register with the least significant bit of the provided value `V`.
 * After updating the PRG register, it calls the `Sync()` function to ensure the system state is
 * synchronized with the new PRG value.
 *
 * @param V The input value whose least significant bit is used to update the PRG register.
 */
static DECLFW(UNLSMB2JWrite1) {
	prg = V & 1;
	Sync();
}

/**
 * @brief Writes a value to the UNLSMB2J hardware register and updates the IRQ state.
 *
 * This method is responsible for handling writes to the UNLSMB2J hardware register. 
 * It sets the IRQa flag based on the least significant bit of the input value `V`. 
 * Additionally, it resets the IRQCount to 0 and signals the end of an external IRQ 
 * by calling `X6502_IRQEnd(FCEU_IQEXT)`.
 *
 * @param V The value to be written to the register. The least significant bit determines 
 *          the state of the IRQa flag.
 */
static DECLFW(UNLSMB2JWrite2) {
	IRQa = V & 1;
	IRQCount = 0;
	X6502_IRQEnd(FCEU_IQEXT);
}

/**
 * @brief Reads a fixed value from the UNLSMB2J device.
 *
 * This method is a static function that simulates a read operation from the UNLSMB2J device.
 * It always returns the value 0xFF, which could represent a default or dummy value
 * in the context of the device's memory or register read operation.
 *
 * @return The fixed value 0xFF, indicating a successful read operation or a default state.
 */
static DECLFR(UNLSMB2JRead) {
	return 0xFF;
}

/**
 * @brief Initializes the memory mapping and handlers for the UNLSMB2J Power functionality.
 * 
 * This method sets up the necessary configurations for the UNLSMB2J Power operation. It performs the following steps:
 * 1. Resets the program counter (`prg`) to 0.
 * 2. Synchronizes the system state by calling `Sync()`.
 * 3. Sets up a read handler for the memory range 0x6000 to 0xFFFF to use the `CartBR` function.
 * 4. Sets up a read handler for the memory range 0x4042 to 0x4055 to use the `UNLSMB2JRead` function.
 * 5. Sets up a write handler for the memory address 0x4068 to use the `UNLSMB2JWrite2` function.
 * 6. Sets up a write handler for the memory address 0x4027 to use the `UNLSMB2JWrite1` function.
 * 
 * This method is typically called during the initialization or reset phase to configure the memory mapping and handlers
 * for the UNLSMB2J Power functionality.
 */
static void UNLSMB2JPower(void) {
	prg = 0;
	Sync();
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetReadHandler(0x4042, 0x4055, UNLSMB2JRead);
	SetWriteHandler(0x4068, 0x4068, UNLSMB2JWrite2);
	SetWriteHandler(0x4027, 0x4027, UNLSMB2JWrite1);
}

/**
 * @brief Handles the IRQ (Interrupt Request) hook for the UNLSMB2J mapper.
 *
 * This method is responsible for managing the IRQ count and triggering an IRQ
 * when the count reaches a specific threshold. The IRQ is triggered by calling
 * `X6502_IRQBegin` with the `FCEU_IQEXT` parameter. The threshold is set to 5750,
 * which is determined empirically. If the IRQ is active (`IRQa` is true), the
 * method increments the `IRQCount` by the provided value `a`. Once the `IRQCount`
 * exceeds the threshold, the IRQ is triggered, and the `IRQa` flag is reset to 0.
 *
 * @param a The value to add to the IRQ count. This typically represents the number
 *          of CPU cycles or a similar unit that has elapsed since the last update.
 */
static void UNLSMB2JIRQHook(int a) {
	if (IRQa)
	{
		if (IRQCount < 5750)	// completely by guess
			IRQCount += a;
		else {
			IRQa = 0;
			X6502_IRQBegin(FCEU_IQEXT);
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that the system is synchronized before proceeding with the restoration process by calling
 * the `Sync()` method. This synchronization step is crucial to maintain consistency and avoid potential
 * conflicts or data corruption during the restoration.
 *
 * @param version The version number of the state to be restored. This parameter helps identify the
 *                specific state snapshot that needs to be loaded.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the UNLSMB2J cartridge by setting up the necessary function pointers
 * and state restoration mechanisms. This method configures the cartridge's power
 * function, IRQ hook, and game state restoration function. Additionally, it adds
 * the state registers to the emulator's state management system, ensuring that
 * the cartridge's state can be saved and restored properly.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific
 *             information and function pointers.
 */
void UNLSMB2J_Init(CartInfo *info) {
	info->Power = UNLSMB2JPower;
	MapIRQHook = UNLSMB2JIRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
