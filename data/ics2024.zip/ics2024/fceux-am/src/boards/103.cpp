/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg0, reg1, reg2;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &reg0, 1, "REG0" },
	{ &reg1, 1, "REG1" },
	{ &reg2, 1, "REG2" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory and mirroring configuration of the emulated system.
 * 
 * This method configures the memory layout and mirroring settings based on the current state
 * of the emulated system. It performs the following operations:
 * - Sets the CHR bank to 0 using `setchr8(0)`.
 * - Configures PRG banks at addresses 0x8000 and 0xE000 to banks 0xC and 0xF respectively using `setprg8`.
 * - Checks the state of `reg2` to determine the memory layout:
 *   - If `reg2 & 0x10` is true, it configures PRG banks at addresses 0x6000, 0xA000, and 0xC000 to
 *     banks specified by `reg0`, 0xD, and 0xE respectively using `setprg8`.
 *   - If `reg2 & 0x10` is false, it configures a more complex memory layout using a combination of
 *     `setprg8r`, `setprg4`, `setprg2`, and `setprg2r` to map specific banks to various memory regions.
 * - Sets the mirroring mode based on the value of `reg1` using `setmirror`, toggling the mirroring
 *   configuration by XORing `reg1` with 1.
 */
static void Sync(void) {
	setchr8(0);
	setprg8(0x8000, 0xc);
	setprg8(0xe000, 0xf);
	if (reg2 & 0x10) {
		setprg8(0x6000, reg0);
		setprg8(0xa000, 0xd);
		setprg8(0xc000, 0xe);
	} else {
		setprg8r(0x10, 0x6000, 0);
		setprg4(0xa000, (0xd << 1));
		setprg2(0xb000, (0xd << 2) + 2);
		setprg2r(0x10, 0xb800, 4);
		setprg2r(0x10, 0xc000, 5);
		setprg2r(0x10, 0xc800, 6);
		setprg2r(0x10, 0xd000, 7);
		setprg2(0xd800, (0xe << 2) + 3);
	}
	setmirror(reg1 ^ 1);
}

/**
 * @brief Writes a value to the WRAM (Work RAM) at a specific address.
 *
 * This method writes the value `V` to the WRAM at the address `A` masked with `0x1FFF`.
 * The masking ensures that the address is within the bounds of the WRAM, which is typically
 * 8 KB in size (0x1FFF = 8191). This is a static method and is typically used in emulator
 * implementations to handle memory writes to the WRAM.
 *
 * @param A The address in WRAM where the value will be written. The address is masked with 0x1FFF.
 * @param V The value to be written to the WRAM.
 */
static DECLFW(M103RamWrite0) {
	WRAM[A & 0x1FFF] = V;
}

/**
 * @brief Writes a value to a specific address in the WRAM memory region.
 *
 * This method is responsible for writing a value `V` to a calculated address
 * within the WRAM memory region. The address is derived from the input address `A`
 * by subtracting `0xB800` and masking the result with `0x1FFF` to ensure it falls
 * within the valid range of the WRAM region. The final address is then offset by
 * `0x2000` to map it to the correct location in WRAM.
 *
 * @param A The input address from which the target WRAM address is calculated.
 * @param V The value to be written to the calculated WRAM address.
 */
static DECLFW(M103RamWrite1) {
	WRAM[0x2000 + ((A - 0xB800) & 0x1FFF)] = V;
}

/**
 * @brief Writes a value to register 0 and synchronizes the state.
 *
 * This method takes an input value `V`, masks it to the lower 4 bits (0xf), 
 * and stores the result in `reg0`. After updating `reg0`, it calls the `Sync()` 
 * function to ensure the system state is synchronized with the new register value.
 *
 * @param V The input value to be written to register 0. Only the lower 4 bits 
 *          of this value are used.
 */
static DECLFW(M103Write0) {
	reg0 = V & 0xf;
	Sync();
}

/**
 * @brief Writes a value to the M103 register and updates the internal state.
 * 
 * This method processes the input value `V` by extracting the third bit (from the right) 
 * and storing it in the global variable `reg1`. After updating `reg1`, the method 
 * calls the `Sync()` function to synchronize the internal state or hardware 
 * with the new value of `reg1`.
 * 
 * @param V The input value to be written to the M103 register.
 */
static DECLFW(M103Write1) {
	reg1 = (V >> 3) & 1;
	Sync();
}

/**
 * @brief Writes a value to the register `reg2` and synchronizes the state.
 *
 * This method assigns the provided value `V` to the register `reg2` and then
 * calls the `Sync()` function to ensure that the system state is updated
 * accordingly. The `Sync()` function is typically used to apply changes or
 * refresh the system state based on the new value in `reg2`.
 *
 * @param V The value to be written to the register `reg2`.
 */
static DECLFW(M103Write2) {
	reg2 = V;
	Sync();
}

/**
 * @brief Initializes the M103 memory mapper by resetting registers and setting up read/write handlers.
 *
 * This method performs the following operations:
 * 1. Resets registers `reg0`, `reg1`, and `reg2` to 0.
 * 2. Synchronizes the system state by calling `Sync()`.
 * 3. Configures read and write handlers for specific memory ranges:
 *    - Sets a read handler for the memory range `0x6000` to `0x7FFF` to `CartBR`.
 *    - Sets a write handler for the memory range `0x6000` to `0x7FFF` to `M103RamWrite0`.
 *    - Sets a read handler for the memory range `0x8000` to `0xFFFF` to `CartBR`.
 *    - Sets a write handler for the memory range `0xB800` to `0xD7FF` to `M103RamWrite1`.
 *    - Sets a write handler for the memory range `0x8000` to `0x8FFF` to `M103Write0`.
 *    - Sets a write handler for the memory range `0xE000` to `0xEFFF` to `M103Write1`.
 *    - Sets a write handler for the memory range `0xF000` to `0xFFFF` to `M103Write2`.
 *
 * This setup is typically used to configure memory mapping for a specific cartridge or hardware configuration.
 */
static void M103Power(void) {
	reg0 = reg1 = 0; reg2 = 0;
	Sync();
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, M103RamWrite0);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0xB800, 0xD7FF, M103RamWrite1);
	SetWriteHandler(0x8000, 0x8FFF, M103Write0);
	SetWriteHandler(0xE000, 0xEFFF, M103Write1);
	SetWriteHandler(0xF000, 0xFFFF, M103Write2);
}

/**
 * @brief Closes and frees the memory allocated for the WRAM (Work RAM) used by the emulator.
 *
 * This method checks if the WRAM pointer is not null. If WRAM is allocated, it frees the memory
 * using the `FCEU_gfree` function and sets the WRAM pointer to null to indicate that the memory
 * has been released. This ensures that there are no memory leaks and the WRAM is properly
 * deallocated when it is no longer needed.
 */
static void M103Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method is responsible for restoring the system's state by synchronizing
 * with the saved state corresponding to the provided version number. It calls
 * the `Sync()` method to ensure that the current state is updated to match the
 * state at the specified version.
 *
 * @param version The version number of the state to restore. This version
 *                corresponds to a previously saved state in the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 103 for the given cartridge information.
 * This method sets up the necessary function pointers for power and close operations,
 * configures the game state restoration, and allocates and maps the Work RAM (WRAM) for the cartridge.
 * 
 * @param info Pointer to the CartInfo structure that holds cartridge-specific information.
 *             The Power and Close function pointers are set to M103Power and M103Close respectively.
 *             The GameStateRestore function pointer is set to StateRestore.
 * 
 * The method also allocates 16 KB of WRAM using FCEU_gmalloc and maps it to the cartridge's PRG space.
 * Additionally, it sets up the external state for WRAM and the state registers.
 */
void Mapper103_Init(CartInfo *info) {
	info->Power = M103Power;
	info->Close = M103Close;
	GameStateRestore = StateRestore;

	WRAMSIZE = 16384;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	AddExState(&StateRegs, ~0, 0, 0);
}
