/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 bank, mode;
static SFORMAT StateRegs[] =
{
	{ &bank, 1, "BANK" },
	{ &mode, 1, "MODE" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current mode and bank settings.
 * 
 * This method updates the Programmable Read-Only Memory (PRG) and Character Read-Only Memory (CHR) mappings,
 * as well as the mirroring mode, depending on the values of the `mode` and `bank` variables.
 * 
 * If the `mode` variable has the second bit set (i.e., `mode & 2` is true), the PRG ROM is configured as follows:
 * - PRG ROM bank at 0x6000 is set to `((bank & 7) << 2) | 0x23`.
 * - PRG ROM banks at 0x8000 and 0xC000 are set to `(bank << 1) | 0` and `(bank << 1) | 1`, respectively.
 * 
 * Otherwise, the PRG ROM is configured as follows:
 * - PRG ROM bank at 0x6000 is set to `((bank & 4) << 2) | 0x2F`.
 * - PRG ROM banks at 0x8000 and 0xC000 are set to `(bank << 1) | (mode >> 4)` and `((bank & 0xC) << 1) | 7`, respectively.
 * 
 * The mirroring mode is set to horizontal (`MI_H`) if `mode` is 0x12, otherwise it is set to vertical (`MI_V`).
 * 
 * Finally, the CHR ROM is set to bank 0.
 */
static void Sync(void) {
	if (mode & 2) {
		setprg8(0x6000, ((bank & 7) << 2) | 0x23);
		setprg16(0x8000, (bank << 1) | 0);
		setprg16(0xC000, (bank << 1) | 1);
	} else {
		setprg8(0x6000, ((bank & 4) << 2) | 0x2F);
		setprg16(0x8000, (bank << 1) | (mode >> 4));
		setprg16(0xC000, ((bank & 0xC) << 1) | 7);
	}
	if (mode == 0x12)
		setmirror(MI_H);
	else
		setmirror(MI_V);
	setchr8(0);
}

/**
 * @brief Writes the mode value to the internal mode variable and synchronizes the state.
 * 
 * This method takes a value `V`, extracts the relevant bits (0x12), and assigns it to the 
 * internal `mode` variable. After updating the mode, it calls the `Sync()` method to ensure 
 * the system state is synchronized with the new mode value.
 * 
 * @param V The input value from which the mode is extracted.
 */
static DECLFW(M51WriteMode) {
	mode = V & 0x12;
	Sync();
}

/**
 * @brief Writes to the bank register and updates the mode based on the input values.
 *
 * This method updates the bank register with the lower 4 bits of the input value `V`.
 * If the address `A` has the 0x4000 bit set, it also updates the mode register. The mode
 * is updated by preserving the second bit of the current mode and setting the first bit
 * based on the 0x10 bit of `V`. After updating the bank and mode, the method calls `Sync()`
 * to synchronize the internal state with the updated values.
 *
 * @param A The address being written to, used to determine if the mode should be updated.
 * @param V The value being written, used to update the bank and potentially the mode.
 */
static DECLFW(M51WriteBank) {
	bank = V & 0x0F;
	if (A & 0x4000)
		mode = (mode & 2) | (V & 0x10);
	Sync();
}

/**
 * @brief Initializes the M51 memory mapper configuration.
 *
 * This method sets up the M51 memory mapper by configuring the bank, mode, and memory handlers.
 * Specifically, it performs the following operations:
 * 1. Sets the current bank to 0.
 * 2. Sets the memory mode to 2.
 * 3. Synchronizes the memory configuration by calling `Sync()`.
 * 4. Assigns the write handler `M51WriteMode` to the memory range 0x6000-0x7FFF.
 * 5. Assigns the write handler `M51WriteBank` to the memory range 0x8000-0xFFFF.
 * 6. Assigns the read handler `CartBR` to the memory range 0x6000-0xFFFF.
 *
 * This configuration is typically used to manage memory mapping for a specific cartridge or hardware setup.
 */
static void M51Power(void) {
	bank = 0;
	mode = 2;
	Sync();
	SetWriteHandler(0x6000, 0x7FFF, M51WriteMode);
	SetWriteHandler(0x8000, 0xFFFF, M51WriteBank);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
}

/**
 * @brief Resets the M51 module to its default state.
 *
 * This method sets the `bank` variable to 0 and the `mode` variable to 2, 
 * effectively resetting the module to its initial configuration. 
 * After updating these variables, the `Sync()` method is called to ensure 
 * that the module's state is synchronized with the new settings.
 */
static void M51Reset(void) {
	bank = 0;
	mode = 2;
	Sync();
}

/**
 * @brief Restores the state based on the provided version.
 *
 * This method is responsible for restoring the system or application state
 * to a specific version. It ensures that all necessary data is synchronized
 * before proceeding with the restoration process by calling the `Sync()` method.
 *
 * @param version The version number to which the state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 51 for the given cartridge information.
 *
 * This function sets up the necessary function pointers and state information
 * for Mapper 51. Specifically, it assigns the `Power` and `Reset` functions
 * to `M51Power` and `M51Reset` respectively. Additionally, it adds the state
 * registers to the emulator's state system and sets the `GameStateRestore`
 * function to `StateRestore`.
 *
 * @param info Pointer to the CartInfo structure that holds the cartridge
 *             information and function pointers.
 */
void Mapper51_Init(CartInfo *info) {
	info->Power = M51Power;
	info->Reset = M51Reset;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
