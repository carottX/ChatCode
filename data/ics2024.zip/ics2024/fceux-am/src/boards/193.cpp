/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2009 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg[8];
static uint8 mirror, cmd, bank;

static SFORMAT StateRegs[] =
{
	{ &cmd, 1, "CMD" },
	{ &mirror, 1, "MIRR" },
	{ &bank, 1, "BANK" },
	{ reg, 8, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration for the emulator.
 *
 * This method updates the memory mapping and mirroring settings based on the current state
 * of the internal registers. It performs the following operations:
 * 1. Toggles the mirroring mode by XORing the current mirroring state with 1.
 * 2. Sets the PRG-ROM banks for the specified memory ranges:
 *    - 0x8000-0x9FFF to the value in `reg[3]`.
 *    - 0xA000-0xBFFF to the fixed value 0xD.
 *    - 0xC000-0xDFFF to the fixed value 0xE.
 *    - 0xE000-0xFFFF to the fixed value 0xF.
 * 3. Sets the CHR-ROM banks for the specified memory ranges:
 *    - 0x0000-0x0FFF to the value in `reg[0] >> 2`.
 *    - 0x1000-0x17FF to the value in `reg[1] >> 1`.
 *    - 0x1800-0x1FFF to the value in `reg[2] >> 1`.
 *
 * This method is typically called to update the memory mapping whenever the internal
 * registers or mirroring configuration changes.
 */
static void Sync(void) {
	setmirror(mirror ^ 1);
	setprg8(0x8000, reg[3]);
	setprg8(0xA000, 0xD);
	setprg8(0xC000, 0xE);
	setprg8(0xE000, 0xF);
	setchr4(0x0000, reg[0] >> 2);
	setchr2(0x1000, reg[1] >> 1);
	setchr2(0x1800, reg[2] >> 1);
}

/**
 * @brief Writes a value to a specific register and synchronizes the state.
 * 
 * This method writes the value `V` to the register indexed by the lower 2 bits of `A`.
 * The register is accessed using `reg[A & 3]`, ensuring only the first four registers
 * (indexed 0-3) are accessible. After writing the value, the `Sync()` function is called
 * to update or synchronize the state of the system.
 * 
 * @param A The address used to determine the register index (only the lower 2 bits are used).
 * @param V The value to be written to the selected register.
 */
static DECLFW(M193Write) {
	reg[A & 3] = V;
	Sync();
}

/**
 * @brief Initializes the power state for M193 hardware configuration.
 *
 * This method sets up the initial state and memory handlers for the M193 hardware.
 * It performs the following operations:
 * 1. Resets the bank value to 0.
 * 2. Synchronizes the state with the hardware.
 * 3. Sets a custom write handler for the memory range 0x6000 to 0x6003 using M193Write.
 * 4. Sets a read handler for the memory range 0x8000 to 0xFFFF using CartBR.
 * 5. Sets a write handler for the memory range 0x8000 to 0xFFFF using CartBW.
 */
static void M193Power(void) {
	bank = 0;
	Sync();
	SetWriteHandler(0x6000, 0x6003, M193Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, CartBW);
}

/**
 * @brief Resets the M193 module to its initial state.
 *
 * This method performs a reset operation on the M193 module, restoring all internal
 * states, configurations, and variables to their default values. It is typically used
 * to ensure the module starts in a known state before any operations are performed.
 * After calling this method, the module should be ready for reinitialization or
 * subsequent operations.
 */
static void M193Reset(void) {
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that all necessary data and configurations are synchronized to match the state of the
 * specified version. The method internally calls the `Sync()` function to perform the synchronization
 * process, ensuring consistency across the system.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 193 for the given cartridge information.
 *
 * This method sets up the necessary function pointers and state restoration
 * mechanisms for Mapper 193. Specifically, it assigns the reset and power
 * functions to the corresponding pointers in the `CartInfo` structure.
 * Additionally, it sets up the game state restoration function and adds
 * the state registers to the external state management system.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge
 *             information and function pointers to be initialized.
 */
void Mapper193_Init(CartInfo *info) {
	info->Reset = M193Reset;
	info->Power = M193Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
