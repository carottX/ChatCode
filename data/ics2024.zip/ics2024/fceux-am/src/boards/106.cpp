/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg[16], IRQa;
static uint32 IRQCount;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 4, "IRQC" },
	{ reg, 16, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the CHR and PRG memory banks and mirroring configuration.
 *
 * This method updates the CHR (Character) and PRG (Program) memory banks based on the values
 * stored in the `reg` array. It also sets the mirroring mode for the memory layout.
 *
 * - For CHR memory:
 *   - Sets CHR banks at specific addresses (0x0000, 0x0400, 0x0800, 0x0C00, 0x1000, 0x1400, 0x1800, 0x1C00)
 *     using values from `reg[0]` to `reg[7]`, with some bits masked or set for specific configurations.
 *
 * - For PRG memory:
 *   - Sets PRG banks at specific addresses (0x6000, 0x8000, 0xA000, 0xC000, 0xE000) using values from
 *     `reg[8]`, `reg[9]`, `reg[10]`, and `reg[11]`, with some bits masked or set for specific configurations.
 *
 * - For mirroring:
 *   - Sets the mirroring mode based on the value in `reg[0xC]`, toggling the least significant bit.
 *
 * This method is typically called to apply changes to the memory layout after updating the `reg` array.
 */
static void Sync(void) {
	setchr1(0x0000, reg[0] & 0xfe);
	setchr1(0x0400, reg[1] | 1);
	setchr1(0x0800, reg[2] & 0xfe);
	setchr1(0x0c00, reg[3] | 1);
	setchr1(0x1000, reg[4]);
	setchr1(0x1400, reg[5]);
	setchr1(0x1800, reg[6]);
	setchr1(0x1c00, reg[7]);
	setprg8r(0x10, 0x6000, 0);
	setprg8(0x8000, (reg[0x8] & 0xf) | 0x10);
	setprg8(0xA000, (reg[0x9] & 0x1f));
	setprg8(0xC000, (reg[0xa] & 0x1f));
	setprg8(0xE000, (reg[0xb] & 0xf) | 0x10);
	setmirror((reg[0xc] & 1) ^ 1);
}

/**
 * @brief Handles write operations to the M106 memory-mapped register.
 *
 * This method processes write operations to the M106 register, which is used to control
 * interrupt-related functionality. The method takes the lower 4 bits of the address (A)
 * and the value (V) to be written, and performs different actions based on the address:
 * - If the address is 0xD: Disables the IRQ by setting IRQa to 0, resets IRQCount to 0,
 *   and signals the end of an external interrupt (X6502_IRQEnd).
 * - If the address is 0xE: Updates the lower byte of IRQCount with the value V.
 * - If the address is 0xF: Updates the upper byte of IRQCount with the value V, and
 *   enables the IRQ by setting IRQa to 1.
 * - For other addresses: Writes the value V to the corresponding register in the `reg`
 *   array and calls the `Sync` method to synchronize the state.
 *
 * @param A The lower 4 bits of the address indicating the specific register to write to.
 * @param V The value to be written to the register.
 */
static DECLFW(M106Write) {
	A &= 0xF;
	switch (A) {
	case 0xD: IRQa = 0; IRQCount = 0; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0xE: IRQCount = (IRQCount & 0xFF00) | V; break;
	case 0xF: IRQCount = (IRQCount & 0x00FF) | (V << 8); IRQa = 1; break;
	default: reg[A] = V; Sync(); break;
	}
}

/**
 * @brief Initializes the power state for the M106 mapper.
 *
 * This method sets up the initial state for the M106 mapper by performing the following operations:
 * 1. Resets specific registers (reg[8], reg[9], reg[0xa], reg[0xb]) to -1.
 * 2. Synchronizes the state using the Sync() function.
 * 3. Configures memory read handlers for the address ranges 0x6000-0x7FFF and 0x8000-0xFFFF to use the CartBR function.
 * 4. Configures memory write handlers for the address ranges 0x6000-0x7FFF to use the CartBW function and 0x8000-0xFFFF to use the M106Write function.
 *
 * This setup ensures that the mapper is properly initialized and ready for operation.
 */
static void M106Power(void) {
	reg[8] = reg[9] = reg[0xa] = reg[0xb] = -1;
	Sync();
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetWriteHandler(0x8000, 0xFFFF, M106Write);
}

/**
 * @brief Resets the M106 system to its default state.
 *
 * This method performs a reset operation on the M106 system, restoring all
 * internal configurations and states to their initial values. It is typically
 * used to clear any previous settings or errors and ensure the system is in
 * a known, default state before starting a new operation or process.
 *
 * @note This method does not take any parameters and does not return any value.
 *       It is a static method, meaning it can be called without an instance of
 *       the class.
 */
static void M106Reset(void) {
}

/**
 * @brief Closes and frees the WRAM (Work RAM) memory.
 *
 * This method checks if the WRAM pointer is not null. If it is not null,
 * it frees the memory allocated for WRAM using the FCEU_gfree function.
 * After freeing the memory, it sets the WRAM pointer to null to indicate
 * that the memory has been released and is no longer in use.
 */
static void M106Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Handles the M106 CPU hook logic for IRQ (Interrupt Request) processing.
 *
 * This method is responsible for managing the IRQ count and triggering an IRQ
 * when the count exceeds a specified threshold. If the IRQ flag (`IRQa`) is set,
 * the method increments the `IRQCount` by the provided value `a`. If the `IRQCount`
 * exceeds 0x10000, an external IRQ is triggered using `X6502_IRQBegin` with the
 * `FCEU_IQEXT` parameter, and the IRQ flag (`IRQa`) is reset to 0.
 *
 * @param a The value to add to the IRQ count. This typically represents the
 *          number of CPU cycles or a similar metric that affects IRQ timing.
 */
void M106CpuHook(int a) {
	if (IRQa) {
		IRQCount += a;
		if (IRQCount > 0x10000) {
			X6502_IRQBegin(FCEU_IQEXT);
			IRQa = 0;
		}
	}
}

/**
 * @brief Restores the state based on the provided version.
 * 
 * This method is responsible for restoring the state of the system to a specific version. 
 * It ensures that the system is synchronized before proceeding with the restoration process. 
 * The synchronization is achieved by calling the `Sync()` method, which guarantees that all 
 * pending operations are completed and the system is in a consistent state.
 * 
 * @param version The version of the state to restore. This parameter specifies which state 
 *                should be restored, allowing for version control and state management.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 106 for the emulated NES cartridge.
 * This method sets up the necessary function pointers and memory mappings
 * required for the emulator to correctly handle the cartridge's behavior.
 * Specifically, it assigns the reset, power, and close handlers, sets up
 * the IRQ hook for CPU interactions, and prepares the game state restoration.
 * Additionally, it allocates and maps 8KB of Work RAM (WRAM) for the cartridge
 * and sets up the state saving and loading for the WRAM and other internal
 * state registers.
 *
 * @param info A pointer to the CartInfo structure that holds the cartridge's
 *             configuration and state information.
 */
void Mapper106_Init(CartInfo *info) {
	info->Reset = M106Reset;
	info->Power = M106Power;
	info->Close = M106Close;
	MapIRQHook = M106CpuHook;
	GameStateRestore = StateRestore;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	AddExState(&StateRegs, ~0, 0, 0);
}
