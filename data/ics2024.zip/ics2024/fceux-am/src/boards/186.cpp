/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Family Study Box by Fukutake Shoten
 *
 * REG[0] R dddddddd / W ww---sss
 *  ddd - TAPE DATA BYTE (ready when IRQ occurs)
 *  sss - BRAM hi-bank
 *  ww  - PRAM bank
 * REG[1] R 0123---- / W ----PPPP
 *  0   - ?
 *  1   - ?
 *  2   - ?
 *  3   - ?
 *  PPPP- PROM bank
 * REG[2] R -?--R--- / W A-BC-DEF
 *  4   - ?
 *  R   - sb4x power supply status (active low)
 *  A   - ?
 *  B   - ?
 *  C   - ?
 *  D   - ?
 *  E   - ?
 *  F   - ?
 *
 * BRAM0	4400-4FFF, 3K bank  0   (32K SWRAM)	 [hardwired]
 * BRAMB	5000-5FFF, 4K banks 1-7 (32K SWRAM)	 [REG[0] W -----sss]
 * PRAMB	6000-7FFF, 8K banks 1-3 (32K PRAM) 	 [REG[0] W ww------]
 * PROMB    8000-BFFF, 16K banks 1-15 (256K PROM)[REG[1] W ----PPPP]
 * PROM0	C000-FFFF, 16K bank 0   (256K PROM)  [hardwired]
 *
 */

#include "mapinc.h"

static uint8 SWRAM[3072];
static uint8 *WRAM = NULL;
static uint8 regs[4];

static SFORMAT StateRegs[] =
{
	{ regs, 4, "DREG" },
	{ SWRAM, 3072, "SWRM" },
	{ 0 }
};

/**
 * Synchronizes the memory mapping of the program ROM (PRG) and character ROM (CHR)
 * by configuring the memory banks based on the values stored in the `regs` array.
 * 
 * This method performs the following operations:
 * 1. Sets the PRG ROM bank at address 0x6000 using the value from `regs[0] >> 6` 
 *    with a fixed bank number of 0x10.
 * 2. Sets the PRG ROM bank at address 0x8000 using the value from `regs[1]`.
 * 3. Sets the PRG ROM bank at address 0xC000 to bank 0.
 * 
 * This is typically used in emulators or systems that require dynamic memory 
 * bank switching to manage larger ROMs or specific memory layouts.
 */
static void Sync(void) {
	setprg8r(0x10, 0x6000, regs[0] >> 6);
	setprg16(0x8000, regs[1]);
	setprg16(0xc000, 0);
}

/**
 * @brief Writes a value to a specific register based on the address and value provided.
 *
 * This method checks if the address `A` has the specific bit pattern `0x4203` set. If the condition is met,
 * it writes the value `V` to the register indexed by the lower 2 bits of `A` (i.e., `A & 3`). After the write operation,
 * it calls the `Sync()` method to synchronize the state.
 *
 * @param A The address used to determine the target register.
 * @param V The value to be written to the register.
 */
static DECLFW(M186Write) {
	if (A & 0x4203) regs[A & 3] = V;
	Sync();
}

/**
 * @brief Reads data from specific memory addresses related to the M186 hardware.
 *
 * This method is a static function that handles read operations for the M186 hardware.
 * It takes a memory address `A` as input and returns a specific value based on the address.
 * The method is typically used in an emulator or low-level hardware interaction context.
 *
 * The following addresses are handled:
 * - 0x4200: Returns 0x00.
 * - 0x4201: Returns 0x00.
 * - 0x4202: Returns 0x40.
 * - 0x4203: Returns 0x00.
 *
 * For any other address, the method returns 0xFF, which is likely a default or error value.
 *
 * @param A The memory address to read from.
 * @return The value associated with the given address or 0xFF if the address is not recognized.
 */
static DECLFR(M186Read) {
	switch (A) {
	case 0x4200: return 0x00; break;
	case 0x4201: return 0x00; break;
	case 0x4202: return 0x40; break;
	case 0x4203: return 0x00; break;
	}
	return 0xFF;
}

/**
 * @brief Reads a value from the specified address in the SRAM (Static RAM) memory region.
 * 
 * This method is a static function that takes a memory address `A` and returns the value stored
 * in the SRAM at the corresponding location. The address `A` is expected to be within the SRAM
 * region, which is mapped starting from 0x4400. The method calculates the effective address by
 * subtracting 0x4400 from `A` and uses it to index into the `SWRAM` array.
 * 
 * @param A The memory address to read from. It must be within the SRAM region (0x4400 and above).
 * @return The value stored in the SRAM at the calculated address (A - 0x4400).
 */
static DECLFR(ASWRAM) {
	return(SWRAM[A - 0x4400]);
}
/**
 * @brief Writes a value to the battery-backed SRAM (BSWRAM) at the specified address.
 *
 * This method is responsible for writing a given value (`V`) to the battery-backed SRAM (BSWRAM) 
 * at the address calculated by subtracting `0x4400` from the provided address (`A`). The result 
 * is used as an index into the `SWRAM` array, where the value is stored.
 *
 * @param A The address in the memory map where the value should be written. The actual SRAM 
 *          address is derived by subtracting `0x4400` from this value.
 * @param V The value to be written to the SRAM.
 */
static DECLFW(BSWRAM) {
	SWRAM[A - 0x4400] = V;
}

/**
 * @brief Initializes the memory mapping and hardware registers for the M186 Power state.
 *
 * This method sets up the memory handlers and initializes the hardware registers for the M186 Power state.
 * It performs the following operations:
 * - Sets the CHR (Character ROM) bank to 0 using `setchr8(0)`.
 * - Configures read and write handlers for the memory range 0x6000 to 0xFFFF using `CartBR` and `CartBW`.
 * - Configures specific read and write handlers for the memory range 0x4200 to 0x43FF using `M186Read` and `M186Write`.
 * - Configures read and write handlers for the memory range 0x4400 to 0x4FFF using `ASWRAM` and `BSWRAM`.
 * - Adds 32 bytes of RAM to the cheat system at the base address 0x6000 using `FCEU_CheatAddRAM`.
 * - Initializes the hardware registers (`regs[0]`, `regs[1]`, `regs[2]`) to the value of `regs[3]`.
 * - Synchronizes the state using `Sync()`.
 */
static void M186Power(void) {
	setchr8(0);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0xFFFF, CartBW);
	SetReadHandler(0x4200, 0x43FF, M186Read);
	SetWriteHandler(0x4200, 0x43FF, M186Write);
	SetReadHandler(0x4400, 0x4FFF, ASWRAM);
	SetWriteHandler(0x4400, 0x4FFF, BSWRAM);
	FCEU_CheatAddRAM(32, 0x6000, WRAM);
	regs[0] = regs[1] = regs[2] = regs[3];
	Sync();
}

/**
 * @brief Closes and frees the memory allocated for the WRAM (Work RAM).
 *
 * This method checks if the WRAM pointer is not null. If it is not null, it frees
 * the memory allocated for WRAM using the FCEU_gfree function. After freeing the
 * memory, it sets the WRAM pointer to null to indicate that no memory is currently
 * allocated for WRAM.
 */
static void M186Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the system state to a specific version by synchronizing data.
 *
 * This method is responsible for restoring the system state to a specified version. 
 * It achieves this by calling the `Sync()` function, which ensures that all data 
 * is synchronized and consistent with the desired version. This is typically used 
 * in scenarios where a rollback or restoration to a previous state is required.
 *
 * @param version The version number to which the system state should be restored.
 */
static void M186Restore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 186 for the given cartridge information.
 *
 * This method sets up the necessary function pointers and memory allocations
 * for Mapper 186. It assigns the `Power` and `Close` functions to the respective
 * handlers (`M186Power` and `M186Close`). It also sets the `GameStateRestore`
 * function to `M186Restore`. Additionally, it allocates 32KB of Work RAM (WRAM)
 * using `FCEU_gmalloc` and sets up the cartridge PRG mapping for this WRAM.
 * Finally, it adds the WRAM and state registers to the emulator's state system
 * for saving and restoring the game state.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void Mapper186_Init(CartInfo *info) {
	info->Power = M186Power;
	info->Close = M186Close;
	GameStateRestore = M186Restore;
	WRAM = (uint8*)FCEU_gmalloc(32768);
	SetupCartPRGMapping(0x10, WRAM, 32768, 1);
	AddExState(WRAM, 32768, 0, "WRAM");
	AddExState(StateRegs, ~0, 0, 0);
}
