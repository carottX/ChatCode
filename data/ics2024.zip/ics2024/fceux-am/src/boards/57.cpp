/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "mapinc.h"

static uint8 prg_reg;
static uint8 chr_reg;
static uint8 hrd_flag;

static SFORMAT StateRegs[] =
{
	{ &hrd_flag, 1, "DPSW" },
	{ &prg_reg, 1, "PRG" },
	{ &chr_reg, 1, "CHR" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current state of the program and character registers.
 *
 * This method updates the program ROM (PRG) and character ROM (CHR) memory mappings, as well as the mirroring mode, based on the values of `prg_reg` and `chr_reg`.
 * 
 * - If the most significant bit (0x80) of `prg_reg` is set, it configures a 32KB PRG ROM at address 0x8000 using the upper bits of `prg_reg`.
 * - Otherwise, it configures two 16KB PRG ROM banks at addresses 0x8000 and 0xC000, using the same bank index derived from `prg_reg`.
 * - The mirroring mode is set based on bit 3 (0x08) of `prg_reg`.
 * - The CHR ROM is configured using a combination of bits from `chr_reg` and `prg_reg`.
 */
static void Sync(void) {
	if (prg_reg & 0x80)
		setprg32(0x8000, prg_reg >> 6);
	else{
		setprg16(0x8000, (prg_reg >> 5) & 3);
		setprg16(0xC000, (prg_reg >> 5) & 3);
	}
	setmirror((prg_reg & 8) >> 3);
	setchr8((chr_reg & 3) | (prg_reg & 7) | ((prg_reg & 0x10) >> 1));
}

/**
 * @brief Reads the current state of the hrd_flag.
 *
 * This static method is designed to return the value of the hrd_flag, which is likely a global or static variable 
 * that represents some state or condition within the system. The method does not take any parameters and simply 
 * returns the current value of the hrd_flag. This can be used to check the status of the flag in a thread-safe 
 * manner or to provide a consistent way to access the flag's value.
 *
 * @return The current value of the hrd_flag.
 */
static DECLFR(M57Read) {
	return hrd_flag;
}

/**
 * @brief Writes a value to either the program register (prg_reg) or the character register (chr_reg)
 *        based on the address (A) provided.
 *
 * This method checks the address (A) to determine whether to write the value (V) to the program
 * register or the character register. If the address matches the condition (A & 0x8800) == 0x8800,
 * the value is written to the program register (prg_reg). Otherwise, the value is written to the
 * character register (chr_reg). After updating the appropriate register, the method calls the
 * Sync() function to synchronize the state.
 *
 * @param A The address used to determine the target register.
 * @param V The value to be written to the target register.
 */
static DECLFW(M57Write) {
	if ((A & 0x8800) == 0x8800)
		prg_reg = V;
	else
		chr_reg = V;
	Sync();
}

/**
 * @brief Initializes the M57 power state by resetting registers and setting up memory handlers.
 *
 * This method resets the program register (`prg_reg`), character register (`chr_reg`), and hardware flag (`hrd_flag`) to 0.
 * It then configures the memory handlers for the specified address ranges:
 * - Sets a read handler for the range `0x8000` to `0xFFFF` to use `CartBR`.
 * - Sets a write handler for the range `0x8000` to `0xFFFF` to use `M57Write`.
 * - Sets a read handler for the address `0x6000` to use `M57Read`.
 * Finally, it calls `Sync()` to synchronize the state.
 */
static void M57Power(void) {
	prg_reg = 0;
	chr_reg = 0;
	hrd_flag = 0;
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M57Write);
	SetReadHandler(0x6000, 0x6000, M57Read);
	Sync();
}

/**
 * @brief Increments and resets the hrd_flag within a range of 0 to 3.
 *
 * This method increments the value of the global variable hrd_flag and then
 * ensures it stays within the range of 0 to 3 by performing a bitwise AND operation
 * with 3. After updating the hrd_flag, it prints the current value of hrd_flag
 * using the FCEU_printf function.
 *
 * @note The hrd_flag is assumed to be a global variable that is modified by this method.
 * The FCEU_printf function is used to output the current value of hrd_flag.
 */
static void M57Reset() {
	hrd_flag++;
	hrd_flag &= 3;
	FCEU_printf("Select Register = %02x\n", hrd_flag);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method synchronizes the current state with the desired version by calling
 * the `Sync()` function. It is typically used to revert the system to a known
 * state after a version change or to recover from an inconsistent state.
 *
 * @param version The version number to which the state should be restored.
 *                This version should correspond to a previously saved state.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 57 for the provided cartridge information.
 *
 * This function sets up the necessary function pointers and state restoration
 * mechanisms for Mapper 57. It assigns the `Power` and `Reset` functions to
 * `M57Power` and `M57Reset` respectively, ensuring proper power-up and reset
 * behavior. Additionally, it sets the `GameStateRestore` function to
 * `StateRestore` and adds the state registers to the emulator's state
 * management system using `AddExState`.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper57_Init(CartInfo *info) {
	info->Power = M57Power;
	info->Reset = M57Reset;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
