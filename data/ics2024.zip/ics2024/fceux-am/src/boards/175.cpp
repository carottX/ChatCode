/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg, delay, mirr;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REG" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current state of the registers.
 * 
 * This method updates the CHR and PRG memory banks and the mirroring configuration based on the values stored in the `reg` and `mirr` variables.
 * - It first sets the CHR memory bank using the value in `reg` via `setchr8(reg)`.
 * - If the `delay` flag is not set, it configures the PRG memory banks:
 *   - Sets the first 16 KB PRG bank at address 0x8000 using `setprg16(0x8000, reg)`.
 *   - Sets the first 8 KB PRG bank at address 0xC000 using the value `reg << 1`.
 * - It then sets the second 8 KB PRG bank at address 0xE000 using the value `(reg << 1) + 1`.
 * - Finally, it updates the mirroring configuration based on the value of `mirr` using `setmirror(((mirr & 4) >> 2) ^ 1)`.
 */
static void Sync(void) {
	setchr8(reg);
	if (!delay) {
		setprg16(0x8000, reg);
		setprg8(0xC000, reg << 1);
	}
	setprg8(0xE000, (reg << 1) + 1);
	setmirror(((mirr & 4) >> 2) ^ 1);
}

/**
 * @brief Writes a value to the M175 register and triggers synchronization.
 *
 * This method updates the `mirr` variable with the provided value `V` and sets the `delay` flag to 1.
 * After updating these variables, it calls the `Sync()` method to synchronize the state or perform
 * any necessary updates based on the new value. This is typically used in emulation or hardware
 * simulation contexts where register writes need to be processed and synchronized with the system state.
 *
 * @param V The value to be written to the M175 register.
 */
static DECLFW(M175Write1) {
	mirr = V;
	delay = 1;
	Sync();
}

/**
 * @brief Writes a value to the M175 register and synchronizes the system.
 *
 * This method updates the M175 register with the lower 4 bits of the provided value `V`.
 * It also sets a delay flag to 1 and calls the `Sync()` function to ensure the system
 * state is synchronized after the write operation.
 *
 * @param V The value to be written to the M175 register. Only the lower 4 bits are used.
 */
static DECLFW(M175Write2) {
	reg = V & 0x0F;
	delay = 1;
	Sync();
}

/**
 * @brief Reads data from the specified memory address and handles a special case for address 0xFFFC.
 * 
 * This method is responsible for reading data from the memory address `A`. If the address is 0xFFFC,
 * it resets the `delay` variable to 0 and calls the `Sync()` function to synchronize the system state.
 * After handling the special case (if applicable), it reads and returns the data from the memory address
 * using the `CartBR(A)` function.
 * 
 * @param A The memory address to read from.
 * @return The data read from the memory address `A`.
 */
static DECLFR(M175Read) {
	if (A == 0xFFFC) {
		delay = 0;
		Sync();
	}
	return CartBR(A);
}

/**
 * @brief Initializes the M175 power state by resetting internal registers and setting up memory handlers.
 *
 * This method performs the following operations:
 * 1. Resets the internal registers `reg`, `mirr`, and `delay` to 0.
 * 2. Sets up a read handler for the memory range 0x8000 to 0xFFFF using the `M175Read` function.
 * 3. Sets up a write handler for the memory address 0x8000 using the `M175Write1` function.
 * 4. Sets up a write handler for the memory address 0xA000 using the `M175Write2` function.
 * 5. Synchronizes the internal state by calling the `Sync` function.
 *
 * This method is typically called during the initialization or reset phase of the M175 module.
 */
static void M175Power(void) {
	reg = mirr = delay = 0;
	SetReadHandler(0x8000, 0xFFFF, M175Read);
	SetWriteHandler(0x8000, 0x8000, M175Write1);
	SetWriteHandler(0xA000, 0xA000, M175Write2);
	Sync();
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the system's state to a specific version 
 * by synchronizing the current state with the desired version. It ensures that all 
 * necessary data and configurations are updated to match the state of the system 
 * at the specified version.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 175 for the given cartridge information.
 *
 * This method sets up the necessary configurations for Mapper 175, which is used in certain NES cartridges.
 * It assigns the power function (`M175Power`) to the `Power` member of the `CartInfo` structure, allowing
 * the cartridge to handle power-related operations. Additionally, it sets the `GameStateRestore` function
 * to `StateRestore`, which is responsible for restoring the game state when needed. Finally, it adds the
 * state registers (`StateRegs`) to the emulator's state management system using `AddExState`, ensuring that
 * the emulator can save and restore the state of the cartridge during emulation.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific information.
 */
void Mapper175_Init(CartInfo *info) {
	info->Power = M175Power;
	GameStateRestore = StateRestore;

	AddExState(&StateRegs, ~0, 0, 0);
}
