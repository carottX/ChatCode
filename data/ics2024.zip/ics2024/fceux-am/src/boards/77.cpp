/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 latche;

static uint8 *CHRRAM=NULL;
static uint32 CHRRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &latche, 1, "LATC" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the NES emulator.
 * 
 * This method configures the Programmable Read-Only Memory (PRG) and 
 * Character Read-Only Memory (CHR) banks based on the current state of 
 * the `latche` variable. It sets the PRG bank at address 0x8000 using 
 * the lower 3 bits of `latche`. Additionally, it configures the CHR 
 * banks at different memory regions: the first 2 KB CHR bank at 0x0000 
 * using the upper 4 bits of `latche`, a second 2 KB CHR bank at 0x0800 
 * using a fixed value, and a 4 KB CHR bank at 0x1000 using another fixed 
 * value. This ensures proper memory mapping for the emulated NES system.
 */
static void Sync(void) {
	setprg32(0x8000, latche & 7);
	setchr2(0x0000, latche >> 4);
	setchr2r(0x10, 0x0800, 2);
	setchr4r(0x10, 0x1000, 0);
}

/**
 * @brief Writes a value to the M77 latch and synchronizes the state.
 *
 * This method updates the internal latch with the provided value `V` and 
 * immediately triggers a synchronization operation. The synchronization 
 * ensures that the system state is consistent with the new latch value.
 *
 * @param V The value to be written to the latch. This is typically an 8-bit 
 *          value representing the data to be stored.
 */
static DECLFW(M77Write) {
	latche = V;
	Sync();
}

/**
 * @brief Initializes the M77 power state by resetting the latch, synchronizing the system, 
 *        and setting up the read and write handlers for the specified memory range.
 *
 * This method performs the following operations:
 * 1. Resets the `latche` variable to 0.
 * 2. Calls the `Sync()` function to synchronize the system state.
 * 3. Sets the read handler for the memory range 0x8000 to 0xFFFF to use `CartBR`.
 * 4. Sets the write handler for the memory range 0x8000 to 0xFFFF to use `M77Write`.
 *
 * This is typically called during system initialization or when the M77 power state needs to be reset.
 */
static void M77Power(void) {
	latche = 0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M77Write);
}

/**
 * @brief Closes and frees the CHRRAM memory if it is allocated.
 * 
 * This method checks if the CHRRAM pointer is not null. If CHRRAM is allocated,
 * it frees the memory using the FCEU_gfree function and then sets the CHRRAM
 * pointer to null to indicate that the memory has been released. This ensures
 * proper memory management and prevents memory leaks.
 */
static void M77Close(void)
{
	if (CHRRAM)
		FCEU_gfree(CHRRAM);
	CHRRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method is responsible for restoring the system state based on the provided version.
 * It ensures that all necessary data and configurations are synchronized by calling the
 * `Sync()` method, which handles the actual restoration process.
 *
 * @param version The version of the state to restore. This parameter specifies which
 *                saved state should be loaded and applied to the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 77 (Irem 74161/32) for the emulated NES cartridge.
 *
 * This method sets up the necessary function pointers and memory mappings for Mapper 77.
 * It assigns the `Power` and `Close` function pointers to the corresponding Mapper 77
 * implementations (`M77Power` and `M77Close`). Additionally, it initializes the CHR RAM
 * memory with a size of 6 KB and sets up the CHR memory mapping for the cartridge.
 * The method also registers the CHR RAM and state registers for saving and restoring
 * the emulator state.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge information.
 */
void Mapper77_Init(CartInfo *info) {
	info->Power = M77Power;
	info->Close = M77Close;
	GameStateRestore = StateRestore;

	CHRRAMSIZE = 6 * 1024;
	CHRRAM = (uint8*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CRAM");

	AddExState(&StateRegs, ~0, 0, 0);
}
