/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 prgreg[4], chrreg[8], mirror;
static uint8 IRQa, IRQCount, IRQLatch;

static SFORMAT StateRegs[] =
{
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 1, "IRQC" },
	{ &IRQLatch, 1, "IRQL" },
	{ prgreg, 4, "PREG" },
	{ chrreg, 8, "CREG" },
	{ &mirror, 1, "MREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the system.
 *
 * This method updates the Program ROM (PRG) and Character ROM (CHR) mappings, as well as the mirroring
 * configuration of the system. It performs the following operations:
 * - Maps the PRG ROM banks to specific memory addresses using the `setprg8` function:
 *   - 0x8000 to the value in `prgreg[0]`
 *   - 0xA000 to the value in `prgreg[1]`
 *   - 0xC000 to the value in `prgreg[2]`
 *   - 0xE000 to the value in `prgreg[3]`
 * - Maps the CHR ROM banks to specific memory addresses using the `setchr1` function:
 *   - Each of the 8 CHR banks is mapped to the corresponding value in `chrreg` array.
 * - Updates the mirroring configuration using the `setmirror` function, toggling the current mirroring mode.
 */
static void Sync(void) {
	setprg8(0x8000, prgreg[0]);
	setprg8(0xa000, prgreg[1]);
	setprg8(0xc000, prgreg[2]);
	setprg8(0xe000, prgreg[3]);
	int i;
	for (i = 0; i < 8; i++)
		setchr1(i << 10, chrreg[i]);
	setmirror(mirror ^ 1);
}

/**
 * @brief Handles write operations to specific memory addresses for the M117 mapper.
 * 
 * This method processes write requests to various memory addresses and performs
 * corresponding actions based on the address and the value being written.
 * 
 * - If the address (A) is less than 0x8004, the value (V) is written to the 
 *   corresponding register in `prgreg` and a synchronization operation is performed.
 * - If the address is between 0xA000 and 0xA007 (inclusive), the value is written 
 *   to the corresponding register in `chrreg` and a synchronization operation is performed.
 * - For specific addresses, the following actions are taken:
 *   - 0xC001: Sets the IRQ latch value.
 *   - 0xC003: Sets the IRQ counter to the latch value and enables IRQ.
 *   - 0xE000: Modifies the IRQ enable flags and ends the IRQ.
 *   - 0xC002: Ends the IRQ.
 *   - 0xD000: Sets the mirroring mode based on the value.
 * 
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(M117Write) {
	if (A < 0x8004) {
		prgreg[A & 3] = V;
		Sync();
	} else if ((A >= 0xA000) && (A <= 0xA007)) {
		chrreg[A & 7] = V;
		Sync();
	} else switch (A) {
		case 0xc001: IRQLatch = V; break;
		case 0xc003: IRQCount = IRQLatch; IRQa |= 2; break;
		case 0xe000: IRQa &= ~1; IRQa |= V & 1; X6502_IRQEnd(FCEU_IQEXT); break;
		case 0xc002: X6502_IRQEnd(FCEU_IQEXT); break;
		case 0xd000: mirror = V & 1;
		}
}

/**
 * @brief Initializes the M117 power state by configuring the PRG registers and setting up memory handlers.
 * 
 * This method performs the following operations:
 * 1. Sets the PRG registers (prgreg[0] to prgreg[3]) to specific values:
 *    - prgreg[0] is set to the bitwise NOT of 3 (~3).
 *    - prgreg[1] is set to the bitwise NOT of 2 (~2).
 *    - prgreg[2] is set to the bitwise NOT of 1 (~1).
 *    - prgreg[3] is set to the bitwise NOT of 0 (~0).
 * 2. Calls the Sync() function to synchronize the state of the PRG registers.
 * 3. Sets a read handler for the memory range 0x8000 to 0xFFFF using the CartBR function.
 * 4. Sets a write handler for the memory range 0x8000 to 0xFFFF using the M117Write function.
 * 
 * This method is typically used during the initialization or reset phase of the M117 device.
 */
static void M117Power(void) {
	prgreg[0] = ~3; prgreg[1] = ~2; prgreg[2] = ~1; prgreg[3] = ~0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M117Write);
}

/**
 * @brief Handles the M117 interrupt request (IRQ) hook.
 *
 * This method is responsible for managing the IRQ hook for the M117 event. It checks if the
 * IRQ state (IRQa) is set to 3 and if the IRQ counter (IRQCount) is non-zero. If both conditions
 * are met, it decrements the IRQ counter. When the IRQ counter reaches zero, it updates the IRQ
 * state by clearing the second bit (setting IRQa to 1) and triggers an external IRQ using the
 * X6502_IRQBegin function with the FCEU_IQEXT flag.
 */
static void M117IRQHook(void) {
	if (IRQa == 3 && IRQCount) {
		IRQCount--;
		if (!IRQCount) {
			IRQa &= 1;
			X6502_IRQBegin(FCEU_IQEXT);
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state to a specific version
 * by synchronizing the current state with the saved state. It internally calls the
 * `Sync()` method to ensure that all necessary data and configurations are updated
 * to match the desired version.
 * 
 * @param version The version number of the state to which the system should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 117 for the emulated cartridge.
 * 
 * This function sets up the necessary function pointers and state information
 * for Mapper 117, which is used in certain NES cartridges. Specifically, it:
 * - Assigns the `M117Power` function to the `Power` member of the `CartInfo` structure,
 *   which handles power-up initialization for the mapper.
 * - Sets the `GameHBIRQHook` to `M117IRQHook`, which is responsible for handling
 *   horizontal blanking interrupt (HBI) requests specific to this mapper.
 * - Assigns the `StateRestore` function to `GameStateRestore`, which is used to
 *   restore the emulator state when loading a saved game.
 * - Adds the state registers (`StateRegs`) to the emulator's state management system
 *   using `AddExState`, ensuring that the mapper's state is saved and restored
 *   correctly during emulation.
 * 
 * @param info A pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper117_Init(CartInfo *info) {
	info->Power = M117Power;
	GameHBIRQHook = M117IRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

