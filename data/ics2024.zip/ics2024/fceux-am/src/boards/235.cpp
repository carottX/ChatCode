/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint16 cmdreg;
static SFORMAT StateRegs[] =
{
	{ &cmdreg, 2, "CREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the internal state of the memory mapper based on the command register (`cmdreg`).
 *
 * This method performs the following operations:
 * 1. Sets the mirroring mode based on the value of `cmdreg`:
 *    - If bit 10 (0x400) is set, it sets the mirroring mode to `MI_0`.
 *    - Otherwise, it sets the mirroring mode based on bit 13 (0x2000) of `cmdreg`, XORed with 1.
 * 2. Configures the PRG ROM banks based on the value of `cmdreg`:
 *    - If bit 11 (0x800) is set, it sets two 16 KB PRG ROM banks at addresses 0x8000 and 0xC000.
 *      The bank index is calculated using bits 8-9 (0x300), bits 0-4 (0x1F), and bit 12 (0x1000) of `cmdreg`.
 *    - Otherwise, it sets a single 32 KB PRG ROM bank at address 0x8000.
 *      The bank index is calculated using bits 8-9 (0x300) and bits 0-4 (0x1F) of `cmdreg`.
 */
static void Sync(void) {
	if (cmdreg & 0x400)
		setmirror(MI_0);
	else
		setmirror(((cmdreg >> 13) & 1) ^ 1);
	if (cmdreg & 0x800) {
		setprg16(0x8000, ((cmdreg & 0x300) >> 3) | ((cmdreg & 0x1F) << 1) | ((cmdreg >> 12) & 1));
		setprg16(0xC000, ((cmdreg & 0x300) >> 3) | ((cmdreg & 0x1F) << 1) | ((cmdreg >> 12) & 1));
	} else
		setprg32(0x8000, ((cmdreg & 0x300) >> 4) | (cmdreg & 0x1F));
}

/**
 * @brief Writes a value to the command register and synchronizes the system.
 * 
 * This static method writes the value passed in the accumulator (A) to the command register (cmdreg).
 * After writing the value, it calls the Sync() function to ensure that the system is synchronized
 * with the new command register value. This method is typically used in low-level hardware
 * or emulation contexts where direct manipulation of registers is required.
 * 
 * @param A The value to be written to the command register.
 */
static DECLFW(M235Write) {
	cmdreg = A;
	Sync();
}

/**
 * @brief Configures the M235 power settings for the emulated system.
 * 
 * This method initializes the M235 power state by performing the following operations:
 * 1. Sets the CHR (Character ROM) bank to 0 using `setchr8(0)`.
 * 2. Configures the write handler for the memory range 0x8000 to 0xFFFF to use the `M235Write` function.
 * 3. Configures the read handler for the memory range 0x8000 to 0xFFFF to use the `CartBR` function.
 * 4. Resets the command register (`cmdreg`) to 0.
 * 5. Synchronizes the internal state using the `Sync()` function.
 * 
 * This method is typically called during system initialization or reset to ensure the M235 hardware
 * is in a known state.
 */
static void M235Power(void) {
	setchr8(0);
	SetWriteHandler(0x8000, 0xFFFF, M235Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	cmdreg = 0;
	Sync();
}

/**
 * @brief Restores the system state to a specific version.
 *
 * This method is responsible for restoring the system state to a version specified by the `version` parameter.
 * It ensures that all pending operations are synchronized before proceeding with the restoration process.
 * The synchronization is achieved by calling the `Sync()` method, which guarantees that any ongoing
 * operations are completed before the restoration begins.
 *
 * @param version The version number to which the system state should be restored. This version
 *                should correspond to a previously saved state in the system.
 */
static void M235Restore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 235 for the emulator by setting up the necessary
 * function pointers and state registers. This method configures the cartridge
 * information structure (`info`) to use the Mapper 235 power function (`M235Power`)
 * for handling power cycles. It also sets the game state restoration function
 * to `M235Restore` for saving and restoring the emulator state. Additionally,
 * it adds the state registers to the emulator's state management system using
 * `AddExState`, ensuring that the state is preserved across save/load operations.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific
 *             information and function pointers.
 */
void Mapper235_Init(CartInfo *info) {
	info->Power = M235Power;
	GameStateRestore = M235Restore;
	AddExState(&StateRegs, ~0, 0, 0);
}
