/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2006 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Dragon Ball Z 2 - Gekishin Freeza! (C)
 * Dragon Ball Z Gaiden - Saiya Jin Zetsumetsu Keikaku (C)
 * San Guo Zhi 2 (C)
 *
 */

#include "mapinc.h"
#include "mmc3.h"

static uint8 *CHRRAM = NULL;
static uint32 CHRRAMSIZE;

/**
 * @brief Configures the Programmable Read-Only Memory (PRG) banks for the M199PW mapper.
 *
 * This method sets up the PRG banks for the M199PW mapper by configuring three distinct memory regions:
 * 1. The PRG bank at the address specified by `A` is set to the value `V`.
 * 2. The PRG bank at the fixed address 0xC000 is set to the value stored in `EXPREGS[0]`.
 * 3. The PRG bank at the fixed address 0xE000 is set to the value stored in `EXPREGS[1]`.
 *
 * @param A The address of the first PRG bank to configure.
 * @param V The value to set for the PRG bank at address `A`.
 */
static void M199PW(uint32 A, uint8 V) {
	setprg8(A, V);
	setprg8(0xC000, EXPREGS[0]);
	setprg8(0xE000, EXPREGS[1]);
}

/**
 * @brief Configures CHR ROM banks for a specific memory mapping scheme.
 *
 * This method sets up the CHR ROM banks based on the provided parameters and internal state.
 * It uses the `setchr1r` function to configure the CHR ROM banks at specific addresses.
 * The configuration is determined by comparing the values of `V`, `DRegBuf`, and `EXPREGS`
 * with the threshold value 8. If the value is less than 8, the CHR ROM bank is set with
 * a base value of 0x10; otherwise, it is set with a base value of 0x00.
 *
 * @param A The address where the CHR ROM bank will be configured.
 * @param V The value used to determine the CHR ROM bank configuration at address `A`.
 */
static void M199CW(uint32 A, uint8 V) {
	setchr1r((V < 8) ? 0x10 : 0x00, A, V);
	setchr1r((DRegBuf[0] < 8) ? 0x10 : 0x00, 0x0000, DRegBuf[0]);
	setchr1r((EXPREGS[2] < 8) ? 0x10 : 0x00, 0x0400, EXPREGS[2]);
	setchr1r((DRegBuf[1] < 8) ? 0x10 : 0x00, 0x0800, DRegBuf[1]);
	setchr1r((EXPREGS[3] < 8) ? 0x10 : 0x00, 0x0c00, EXPREGS[3]);
}

/**
 * @brief Sets the mirroring mode for the Mapper 199 (M199) based on the provided value.
 *
 * This method interprets the lower 2 bits of the input value `V` to determine the mirroring mode
 * and sets the corresponding mirroring mode using the `setmirror` function. The mirroring modes
 * are as follows:
 * - 0: Vertical mirroring (MI_V)
 * - 1: Horizontal mirroring (MI_H)
 * - 2: Single-screen mirroring with the first screen (MI_0)
 * - 3: Single-screen mirroring with the second screen (MI_1)
 *
 * @param V An 8-bit unsigned integer whose lower 2 bits determine the mirroring mode.
 */
static void M199MW(uint8 V) {
//	FCEU_printf("%02x\n",V);
	switch (V & 3) {
	case 0: setmirror(MI_V); break;
	case 1: setmirror(MI_H); break;
	case 2: setmirror(MI_0); break;
	case 3: setmirror(MI_1); break;
	}
}

/**
 * @brief Handles writes to the M199 register for MMC3 emulation.
 *
 * This method processes write operations to the M199 register, which is part of the MMC3 mapper.
 * It performs different actions based on the address (`A`) and the current MMC3 command (`MMC3_cmd`):
 * - If the address is `0x8001` and the MMC3 command has the 4th bit set (`MMC3_cmd & 8`), it updates
 *   the expansion registers (`EXPREGS`) based on the lower 2 bits of the MMC3 command, and then
 *   calls `FixMMC3PRG` and `FixMMC3CHR` to update the PRG and CHR banks accordingly.
 * - If the address is below `0xC000`, it delegates the write operation to `MMC3_CMDWrite`.
 * - If the address is `0xC000` or above, it delegates the write operation to `MMC3_IRQWrite`.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M199Write) {
	if ((A == 0x8001) && (MMC3_cmd & 8)) {
		EXPREGS[MMC3_cmd & 3] = V;
		FixMMC3PRG(MMC3_cmd);
		FixMMC3CHR(MMC3_cmd);
	} else
	if (A < 0xC000)
		MMC3_CMDWrite(A, V);
	else
		MMC3_IRQWrite(A, V);
}

/**
 * @brief Initializes the power state for the M199 mapper.
 *
 * This method sets up the initial values for the EXPREGS array, which is used to configure
 * the mapper's behavior. Specifically, it initializes the EXPREGS array with the following values:
 * - EXPREGS[0] is set to the bitwise NOT of 1 (i.e., 0xFFFFFFFE).
 * - EXPREGS[1] is set to the bitwise NOT of 0 (i.e., 0xFFFFFFFF).
 * - EXPREGS[2] is set to 1.
 * - EXPREGS[3] is set to 3.
 *
 * After setting up the EXPREGS array, the method calls GenMMC3Power() to initialize the MMC3
 * mapper's power state. Finally, it sets the write handler for the memory range 0x8000 to 0xFFFF
 * to M199Write, which handles write operations specific to the M199 mapper.
 */
static void M199Power(void) {
	EXPREGS[0] = ~1;
	EXPREGS[1] = ~0;
	EXPREGS[2] = 1;
	EXPREGS[3] = 3;
	GenMMC3Power();
	SetWriteHandler(0x8000, 0xFFFF, M199Write);
}

/**
 * @brief Closes and frees the CHRRAM memory if it is allocated.
 *
 * This method checks if the CHRRAM pointer is not null. If it is not null, 
 * the memory allocated for CHRRAM is freed using the FCEU_gfree function. 
 * After freeing the memory, the CHRRAM pointer is set to null to indicate 
 * that it no longer points to any allocated memory.
 */
static void M199Close(void) {
	if (CHRRAM)
		FCEU_gfree(CHRRAM);
	CHRRAM = NULL;
}

/**
 * @brief Initializes the Mapper 199 for the NES emulator.
 *
 * This method sets up the Mapper 199, which is a variant of the MMC3 mapper. It initializes the memory
 * management for the cartridge, including the CHR RAM and the expansion registers. The method also
 * configures the specific wrap functions for CHR, PRG, and memory mappings, as well as the power and
 * close handlers for the cartridge.
 *
 * @param info A pointer to the CartInfo structure that contains information about the cartridge.
 *             This structure is used to store various settings and pointers related to the cartridge's
 *             memory and behavior.
 *
 * The method performs the following steps:
 * 1. Initializes the MMC3 mapper with specific parameters for PRG and CHR sizes.
 * 2. Sets up the custom wrap functions for CHR, PRG, and memory mappings.
 * 3. Assigns the power and close handlers to the cartridge.
 * 4. Allocates memory for the CHR RAM and sets up the CHR mapping.
 * 5. Adds the CHR RAM and expansion registers to the save state system.
 */
void Mapper199_Init(CartInfo *info) {
	GenMMC3_Init(info, 512, 256, 8, info->battery);
	cwrap = M199CW;
	pwrap = M199PW;
	mwrap = M199MW;
	info->Power = M199Power;
	info->Close = M199Close;

	CHRRAMSIZE = 8192;
	CHRRAM = (uint8*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CHRR");

	AddExState(EXPREGS, 4, 0, "EXPR");
}
