/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007-2008 Mad Dumper, CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Panda prince pirate.
 * MK4, MK6, A9711/A9713 board
 * 6035052 seems to be the same too, but with prot array in reverse
 * A9746  seems to be the same too, check
 * 187 seems to be the same too, check (A98402 board)
 *
 */

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Synchronizes the state of the system based on the value of EXPREGS[5].
 *
 * This method examines the lower 6 bits of EXPREGS[5] and performs specific actions
 * depending on the value. It updates various registers in the EXPREGS array based on
 * the value of EXPREGS[6] and the specific case matched. If no case matches, it resets
 * EXPREGS[5] to 0.
 *
 * The behavior is as follows:
 * - For cases 0x20, 0x29, 0x2B, 0x3C, and 0x3F: Sets EXPREGS[7] to 1 and copies EXPREGS[6] to EXPREGS[0].
 * - For case 0x26: Sets EXPREGS[7] to 0 and copies EXPREGS[6] to EXPREGS[0].
 * - For case 0x2C: Sets EXPREGS[7] to 1 and copies EXPREGS[6] to EXPREGS[0] if EXPREGS[6] is non-zero.
 * - For case 0x28: Sets EXPREGS[7] to 0 and copies EXPREGS[6] to EXPREGS[1].
 * - For case 0x2A: Sets EXPREGS[7] to 0 and copies EXPREGS[6] to EXPREGS[2].
 * - For case 0x2F: No action is taken.
 * - For all other cases: Resets EXPREGS[5] to 0.
 */
static void Sync() {
	switch (EXPREGS[5] & 0x3F) {
	case 0x20: EXPREGS[7] = 1; EXPREGS[0] = EXPREGS[6]; break;
	case 0x29: EXPREGS[7] = 1; EXPREGS[0] = EXPREGS[6]; break;
	case 0x26: EXPREGS[7] = 0; EXPREGS[0] = EXPREGS[6]; break;
	case 0x2B: EXPREGS[7] = 1; EXPREGS[0] = EXPREGS[6]; break;
	case 0x2C: EXPREGS[7] = 1; if (EXPREGS[6]) EXPREGS[0] = EXPREGS[6]; break;
	case 0x3C:
	case 0x3F: EXPREGS[7] = 1; EXPREGS[0] = EXPREGS[6]; break;
	case 0x28: EXPREGS[7] = 0; EXPREGS[1] = EXPREGS[6]; break;
	case 0x2A: EXPREGS[7] = 0; EXPREGS[2] = EXPREGS[6]; break;
	case 0x2F: break;
	default:   EXPREGS[5] = 0; break;
	}
}

/**
 * @brief Handles the CHR ROM bank switching logic for the M121CW mapper.
 *
 * This method is responsible for selecting and setting the appropriate CHR ROM bank
 * based on the provided address `A` and value `V`. The behavior of this method
 * depends on the sizes of the PRG and CHR ROMs, as well as the state of the MMC3 command
 * register (`MMC3_cmd`).
 *
 * If the sizes of the PRG ROM and CHR ROM are equal, it applies a specific hack
 * (likely for the A9713 multigame extension) by modifying the value `V` with an
 * additional bit derived from `EXPREGS[3]`.
 *
 * If the sizes are not equal, it checks the address `A` against a condition derived
 * from the MMC3 command register. If the condition is met, it modifies the value `V`
 * by setting an additional bit (0x100). Otherwise, it sets the CHR ROM bank directly
 * using the unmodified value `V`.
 *
 * @param A The address used to determine the CHR ROM bank selection.
 * @param V The value to be written to the CHR ROM bank.
 */
static void M121CW(uint32 A, uint8 V) {
	if (PRGsize[0] == CHRsize[0]) {	// A9713 multigame extension hack!
		setchr1(A, V | ((EXPREGS[3] & 0x80) << 1));
	} else {
		if ((A & 0x1000) == ((MMC3_cmd & 0x80) << 5))
			setchr1(A, V | 0x100);
		else
			setchr1(A, V);
	}
}

/**
 * @brief Configures the program memory (PRG) banks based on the provided address and value.
 *
 * This method sets the PRG banks for the emulated system. Depending on the value of `EXPREGS[5] & 0x3F`,
 * it either configures multiple PRG banks in a specific pattern or sets a single PRG bank.
 *
 * If `EXPREGS[5] & 0x3F` is non-zero, the method configures four PRG banks:
 * - The bank at address `A` is set to `(V & 0x1F) | ((EXPREGS[3] & 0x80) >> 2)`.
 * - The bank at address `0xE000` is set to `EXPREGS[0] | ((EXPREGS[3] & 0x80) >> 2)`.
 * - The bank at address `0xC000` is set to `EXPREGS[1] | ((EXPREGS[3] & 0x80) >> 2)`.
 * - The bank at address `0xA000` is set to `EXPREGS[2] | ((EXPREGS[3] & 0x80) >> 2)`.
 *
 * If `EXPREGS[5] & 0x3F` is zero, the method only sets the PRG bank at address `A` to `(V & 0x1F) | ((EXPREGS[3] & 0x80) >> 2)`.
 *
 * @param A The address of the PRG bank to configure.
 * @param V The value used to determine the bank configuration.
 */
static void M121PW(uint32 A, uint8 V) {
	if (EXPREGS[5] & 0x3F) {
//		FCEU_printf("prot banks: %02x %02x %02x %02x\n",V,EXPREGS[2],EXPREGS[1],EXPREGS[0]);
		setprg8(A, (V & 0x1F) | ((EXPREGS[3] & 0x80) >> 2));
		setprg8(0xE000, (EXPREGS[0]) | ((EXPREGS[3] & 0x80) >> 2));
		setprg8(0xC000, (EXPREGS[1]) | ((EXPREGS[3] & 0x80) >> 2));
		setprg8(0xA000, (EXPREGS[2]) | ((EXPREGS[3] & 0x80) >> 2));
	} else {
//		FCEU_printf("gen banks: %04x %02x\n",A,V);
		setprg8(A, (V & 0x1F) | ((EXPREGS[3] & 0x80) >> 2));
	}
}

/**
 * @brief Handles write operations for the M121 mapper.
 *
 * This method processes write operations to specific memory addresses associated with the M121 mapper.
 * It performs different actions based on the address and value provided:
 * - For address 0x8000: Writes the value to the MMC3 command register and updates the PRG ROM banks.
 * - For address 0x8001: Updates the EXPREGS[6] register based on the provided value, synchronizes the mapper if necessary,
 *   writes the value to the MMC3 command register, and updates the PRG ROM banks.
 * - For address 0x8003: Updates the EXPREGS[5] register, synchronizes the mapper, writes the value to the MMC3 command register,
 *   and updates the PRG ROM banks.
 *
 * @param A The address to write to.
 * @param V The value to write.
 */
static DECLFW(M121Write) {
//	FCEU_printf("write: %04x:%04x\n",A&0xE003,V);
	switch (A & 0xE003) {
	case 0x8000:
//		EXPREGS[5] = 0;
//		FCEU_printf("gen: %02x\n",V);
		MMC3_CMDWrite(A, V);
		FixMMC3PRG(MMC3_cmd);
		break;
	case 0x8001:
		EXPREGS[6] = ((V & 1) << 5) | ((V & 2) << 3) | ((V & 4) << 1) | ((V & 8) >> 1) | ((V & 0x10) >> 3) | ((V & 0x20) >> 5);
//		FCEU_printf("bank: %02x (%02x)\n",V,EXPREGS[6]);
		if (!EXPREGS[7]) Sync();
		MMC3_CMDWrite(A, V);
		FixMMC3PRG(MMC3_cmd);
		break;
	case 0x8003:
		EXPREGS[5] = V;
//		EXPREGS[7] = 0;
//		FCEU_printf("prot: %02x\n",EXPREGS[5]);
		Sync();
		MMC3_CMDWrite(0x8000, V);
		FixMMC3PRG(MMC3_cmd);
		break;
	}
}

static uint8 prot_array[16] = { 0x83, 0x83, 0x42, 0x00 };
/**
 * @brief Handles low writes for M121 memory mapping.
 *
 * This method processes low write operations for the M121 memory mapper. It updates the 
 * EXPREGS array based on the provided address (A) and value (V). Specifically, it sets 
 * EXPREGS[4] to a value from the prot_array based on the lower 2 bits of V. Additionally, 
 * if the address matches the condition (A & 0x5180) == 0x5180, it updates EXPREGS[3] with 
 * the value V and calls FixMMC3PRG and FixMMC3CHR functions to fix the MMC3 program and 
 * character ROM mappings.
 *
 * @param A The address where the write operation is performed.
 * @param V The value to be written to the specified address.
 */
static DECLFW(M121LoWrite) {
	EXPREGS[4] = prot_array[V & 3];	// 0x100 bit in address seems to be switch arrays 0, 2, 2, 3 (Contra Fighter)
	if ((A & 0x5180) == 0x5180) {	// A9713 multigame extension
		EXPREGS[3] = V;
		FixMMC3PRG(MMC3_cmd);
		FixMMC3CHR(MMC3_cmd);
	}
//	FCEU_printf("write: %04x:%04x\n",A,V);
}

/**
 * @brief Reads a value from the EXPREGS array at index 4.
 * 
 * This static method is designed to retrieve a specific value stored in the EXPREGS array at index 4.
 * It is typically used in contexts where memory-mapped I/O or similar operations are being emulated.
 * The method does not modify any state and simply returns the value at the specified index.
 * 
 * @return The value stored in EXPREGS[4].
 */
static DECLFR(M121Read) {
//	FCEU_printf("read:  %04x->\n",A,EXPREGS[0]);
	return EXPREGS[4];
}

/**
 * @brief Initializes the M121 mapper's power-up state.
 * 
 * This method sets up the initial state of the M121 mapper by configuring specific 
 * registers and setting up read and write handlers. It performs the following actions:
 * - Sets the value of EXPREGS[3] to 0x80.
 * - Resets the value of EXPREGS[5] to 0.
 * - Calls GenMMC3Power() to initialize the MMC3 mapper's power-up state.
 * - Sets a read handler for the address range 0x5000-0x5FFF to M121Read.
 * - Sets a low write handler for the address range 0x5000-0x5FFF to M121LoWrite.
 * - Sets a write handler for the address range 0x8000-0x9FFF to M121Write.
 */
static void M121Power(void) {
	EXPREGS[3] = 0x80;
	EXPREGS[5] = 0;
	GenMMC3Power();
	SetReadHandler(0x5000, 0x5FFF, M121Read);
	SetWriteHandler(0x5000, 0x5FFF, M121LoWrite);
	SetWriteHandler(0x8000, 0x9FFF, M121Write);
}

/**
 * @brief Initializes the Mapper 121 for the NES emulator.
 *
 * This method sets up the Mapper 121, which is a variant of the MMC3 mapper.
 * It initializes the memory mapping for PRG and CHR banks, configures the
 * appropriate wrapper functions for PRG and CHR banking, and sets the power
 * function for the mapper. Additionally, it adds the external state for
 * the mapper's registers.
 *
 * @param info A pointer to the CartInfo structure that holds cartridge
 *             information and configuration details.
 */
void Mapper121_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 256, 8, 0);
	pwrap = M121PW;
	cwrap = M121CW;
	info->Power = M121Power;
	AddExState(EXPREGS, 8, 0, "EXPR");
}
