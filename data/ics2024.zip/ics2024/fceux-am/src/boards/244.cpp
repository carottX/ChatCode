/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg, creg;
static SFORMAT StateRegs[] =
{
	{ &preg, 1, "PREG" },
	{ &creg, 1, "CREG" },
	{ 0 }
};

static uint8 prg_perm[4][4] = {
	{ 0, 1, 2, 3, },
	{ 3, 2, 1, 0, },
	{ 0, 2, 1, 3, },
	{ 3, 1, 2, 0, },
};

static uint8 chr_perm[8][8] = {
	{ 0, 1, 2, 3, 4, 5, 6, 7, },
	{ 0, 2, 1, 3, 4, 6, 5, 7, },
	{ 0, 1, 4, 5, 2, 3, 6, 7, },
	{ 0, 4, 1, 5, 2, 6, 3, 7, },
	{ 0, 4, 2, 6, 1, 5, 3, 7, },
	{ 0, 2, 4, 6, 1, 3, 5, 7, },
	{ 7, 6, 5, 4, 3, 2, 1, 0, },
	{ 7, 6, 5, 4, 3, 2, 1, 0, },
};

/**
 * @brief Synchronizes the PRG and CHR banks with the current register values.
 * 
 * This method updates the Program ROM (PRG) and Character ROM (CHR) banks 
 * to reflect the values stored in the `preg` and `creg` registers, respectively.
 * Specifically, it sets the PRG bank starting at address 0x8000 using the value 
 * in `preg` and sets the entire CHR bank using the value in `creg`.
 * 
 * @note This method assumes that `preg` and `creg` have been properly initialized 
 * with the desired bank values before calling this function.
 */
static void Sync(void) {
	setprg32(0x8000, preg);
	setchr8(creg);
}

/**
 * @brief Writes data to the M244 register and updates the corresponding CHR or PRG banks.
 *
 * This method processes the input value `V` to determine whether to update the CHR or PRG bank registers.
 * If the 3rd bit of `V` is set (i.e., `V & 8` is true), the CHR register `creg` is updated using the `chr_perm`
 * lookup table, which is indexed by the upper 3 bits of `V` (shifted right by 4) and the lower 3 bits of `V`.
 * Otherwise, the PRG register `preg` is updated using the `prg_perm` lookup table, which is indexed by the upper
 * 2 bits of `V` (shifted right by 4) and the lower 2 bits of `V`. After updating the appropriate register, the
 * `Sync()` function is called to synchronize the changes with the system.
 *
 * @param V The input value used to determine the new CHR or PRG bank configuration.
 */
static DECLFW(M244Write) {
	if (V & 8)
		creg = chr_perm[(V >> 4) & 7][V & 7];
	else
		preg = prg_perm[(V >> 4) & 3][V & 3];
	Sync();
}

/**
 * @brief Initializes the M244 power state for the emulator.
 *
 * This method resets the internal registers `preg` and `creg` to 0, ensuring a clean state.
 * It then synchronizes the emulator's state by calling `Sync()`. Additionally, it sets up
 * the memory handlers for the address range 0x8000 to 0xFFFF. Specifically, it assigns
 * `M244Write` as the write handler and `CartBR` as the read handler for this range.
 * This configuration is typically used to map cartridge memory access in an emulator.
 */
static void M244Power(void) {
	preg = creg = 0;
	Sync();
	SetWriteHandler(0x8000, 0xFFFF, M244Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state to a specific version
 * by synchronizing the current state with the saved state. The synchronization
 * process ensures that all necessary data and configurations are correctly
 * restored to match the specified version.
 * 
 * @param version The version number of the state to restore. This version
 *                corresponds to a previously saved state that needs to be
 *                restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 244 for the provided cartridge information.
 *
 * This method sets up the necessary configurations for Mapper 244 by assigning
 * the power function to `M244Power` and adding the state registers to the emulator's
 * state management system. It also sets the game state restore function to `StateRestore`.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 */
void Mapper244_Init(CartInfo *info) {
	info->Power = M244Power;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
