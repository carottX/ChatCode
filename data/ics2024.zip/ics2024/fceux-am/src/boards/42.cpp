/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * FDS Conversion
 *
 */

#include "mapinc.h"

static uint8 preg, creg, mirr;
static uint32 IRQCount, IRQa;

static SFORMAT StateRegs[] =
{
	{ &preg, 1, "PREG" },
	{ &creg, 1, "CREG" },
	{ &mirr, 1, "MIRR" },
	{ &IRQCount, 4, "IRQC" },
	{ &IRQa, 4, "IRQA" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the NES emulator.
 *
 * This method updates the memory mapping and mirroring settings for the NES emulator.
 * It performs the following operations:
 * - Sets the PRG ROM bank at address 0x6000 to the value stored in `preg`.
 * - Sets the PRG ROM banks at address 0x8000 to the last 32KB bank (indicated by ~0).
 * - Sets the CHR ROM bank to the value stored in `creg`.
 * - Configures the mirroring mode based on the value stored in `mirr`.
 */
static void Sync(void) {
	setprg8(0x6000, preg);
	setprg32(0x8000, ~0);
	setchr8(creg);
	setmirror(mirr);
}

/**
 * @brief Handles write operations to specific memory-mapped registers in the M42 mapper.
 *
 * This method processes write operations to the M42 mapper's registers based on the address `A` and the value `V`.
 * The address `A` is masked with `0xE003` to determine the specific register being accessed. The following
 * actions are performed based on the masked address:
 *
 * - **0x8000**: Updates the `creg` register with the value `V` and calls `Sync()` to synchronize the state.
 * - **0xE000**: Updates the `preg` register with the lower 4 bits of `V` and calls `Sync()` to synchronize the state.
 * - **0xE001**: Updates the `mirr` register based on the 4th bit of `V` (inverted) and calls `Sync()` to synchronize the state.
 * - **0xE002**: Updates the `IRQa` register based on the 2nd bit of `V`. If `IRQa` is cleared (0), the `IRQCount` is reset to 0,
 *               and an IRQ end signal is sent using `X6502_IRQEnd(FCEU_IQEXT)`.
 *
 * @param A The address being written to, masked with `0xE003` to determine the specific register.
 * @param V The value being written to the register.
 */
static DECLFW(M42Write) {
	switch (A & 0xE003) {
	case 0x8000: creg = V; Sync(); break;
	case 0xE000: preg = V & 0x0F; Sync(); break;
	case 0xE001: mirr = ((V >> 3) & 1 ) ^ 1; Sync(); break;
	case 0xE002: IRQa = V & 2; if (!IRQa) IRQCount = 0; X6502_IRQEnd(FCEU_IQEXT); break;
	}
}

/**
 * @brief Initializes the M42 Power configuration for the emulator.
 * 
 * This method sets up the necessary configurations for the M42 Power mapper. 
 * It initializes the program register (`preg`) to 0 and the mirroring register (`mirr`) to 1. 
 * Although the Ai Senshi Nicol game has fixed mirroring, this method forces the mapper to use its default value.
 * The `Sync()` function is called to synchronize the internal state with the new configuration.
 * Additionally, it sets the read handler for the memory range 0x6000 to 0xFFFF to `CartBR` and the write handler 
 * for the same range to `M42Write`.
 */
static void M42Power(void) {
	preg = 0;
	mirr = 1;   // Ai Senshi Nicol actually has fixed mirroring, but mapper forcing it's default value now
	Sync();
	SetReadHandler(0x6000, 0xffff, CartBR);
	SetWriteHandler(0x6000, 0xffff, M42Write);
}

/**
 * @brief Handles the M42 IRQ (Interrupt Request) hook logic.
 *
 * This method is responsible for managing the IRQ state based on the provided parameter `a`.
 * If the IRQ is active (`IRQa` is true), it increments the `IRQCount` by `a`. If `IRQCount`
 * exceeds or equals 32768, it wraps around by subtracting 32768. Depending on the value of
 * `IRQCount`, it either triggers an IRQ begin or end event. Specifically, if `IRQCount` is
 * greater than or equal to 24576, it calls `X6502_IRQBegin` with the `FCEU_IQEXT` flag to
 * initiate an IRQ. Otherwise, it calls `X6502_IRQEnd` with the same flag to terminate the IRQ.
 *
 * @param a The value to add to the IRQCount, influencing the IRQ state.
 */
static void M42IRQHook(int a) {
	if (IRQa) {
		IRQCount += a;
		if (IRQCount >= 32768) IRQCount -= 32768;
		if (IRQCount >= 24576)
			X6502_IRQBegin(FCEU_IQEXT);
		else
			X6502_IRQEnd(FCEU_IQEXT);
	}
}

/**
 * @brief Restores the state of the system to a specific version.
 * 
 * This method ensures that the system is synchronized before restoring the state.
 * It calls the `Sync()` method to guarantee that all pending operations are
 * completed and the system is in a consistent state before proceeding with
 * the restoration process.
 * 
 * @param version The version of the state to which the system should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 42 for the provided cartridge information.
 *
 * This function sets up the necessary function pointers and state restoration
 * mechanisms for Mapper 42. It assigns the power function (`M42Power`) to the
 * `Power` member of the `CartInfo` structure, sets the IRQ hook function
 * (`M42IRQHook`) to the global `MapIRQHook`, and assigns the state restoration
 * function (`StateRestore`) to the global `GameStateRestore`. Additionally, it
 * adds the state registers (`StateRegs`) to the emulator's state management
 * system using `AddExState`, ensuring that the state is preserved and restored
 * during save/load operations.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper42_Init(CartInfo *info) {
	info->Power = M42Power;
	MapIRQHook = M42IRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
