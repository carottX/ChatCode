/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 mainreg, chrreg, mirror;

static SFORMAT StateRegs[] =
{
	{ &mainreg, 1, "MREG" },
	{ &chrreg, 1, "CREG" },
	{ &mirror, 1, "MIRR" },
	{ 0 }
};

/**
 * Synchronizes the memory mapping and mirroring settings of the NES emulator.
 * This method updates the Program ROM (PRG) and Character ROM (CHR) banks,
 * as well as the mirroring mode, based on the current values of the internal
 * registers `mainreg`, `chrreg`, and `mirror`.
 * 
 * Specifically, it performs the following operations:
 * 1. Sets the PRG ROM bank at address 0x8000 using the lower 3 bits of `mainreg`.
 * 2. Sets the CHR ROM bank to the value stored in `chrreg`.
 * 3. Configures the mirroring mode based on the value in `mirror`.
 */
static void Sync(void) {
	setprg32(0x8000, mainreg & 7);
	setchr8(chrreg);
	setmirror(mirror);
}

/**
 * @brief Writes data to the M41 register and updates related registers.
 *
 * This method processes the value in the accumulator (A) and updates several internal registers:
 * - `mainreg` is set to the lower 8 bits of the accumulator (A & 0xFF).
 * - `mirror` is updated based on the 6th bit of the accumulator. It is set to the inverse of the 6th bit ((A >> 5) & 1) ^ 1.
 * - `chrreg` is updated by preserving its lower 2 bits and setting the upper 2 bits based on the 2nd bit of the accumulator ((A >> 1) & 0xC).
 * After updating these registers, the `Sync()` method is called to synchronize the state.
 *
 * @param A The accumulator value used to update the registers.
 */
static DECLFW(M41Write0) {
	mainreg = A & 0xFF;
	mirror = ((A >> 5) & 1) ^ 1;
	chrreg = (chrreg & 3) | ((A >> 1) & 0xC);
	Sync();
}

/**
 * @brief Writes to the M41 register and updates the CHR register if the specified condition is met.
 *
 * This method checks if the `mainreg` has the 0x4 bit set. If it does, the lower 2 bits of the `chrreg`
 * are updated with the lower 2 bits of the value `A`. The `Sync()` method is then called to synchronize
 * the state with the updated `chrreg` value.
 *
 * @param A The input value whose lower 2 bits are used to update `chrreg`.
 */
static DECLFW(M41Write1) {
	if (mainreg & 0x4) {
		chrreg = (chrreg & 0xC) | (A & 3);
		Sync();
	}
}

/**
 * @brief Initializes the M41 power state by resetting relevant registers and setting up memory handlers.
 * 
 * This method performs the following operations:
 * 1. Resets the `mainreg` and `chrreg` registers to 0.
 * 2. Synchronizes the system state by calling `Sync()`.
 * 3. Sets up a read handler for the memory range 0x8000 to 0xFFFF to use the `CartBR` function.
 * 4. Sets up a write handler for the memory range 0x6000 to 0x67FF to use the `M41Write0` function.
 * 5. Sets up a write handler for the memory range 0x8000 to 0xFFFF to use the `M41Write1` function.
 * 
 * This method is typically called during system initialization or reset to configure the memory mapping
 * and ensure proper handling of read and write operations for the specified memory ranges.
 */
static void M41Power(void) {
	mainreg = chrreg = 0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x67FF, M41Write0);
	SetWriteHandler(0x8000, 0xFFFF, M41Write1);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method synchronizes the current state with the saved state corresponding 
 * to the specified version. It ensures that all data and configurations are 
 * aligned with the state at the time of the save. The synchronization process 
 * is handled by the `Sync()` method.
 * 
 * @param version The version of the state to restore. This should correspond 
 *                to a previously saved state in the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 41 for the NES cartridge.
 *
 * This function sets up the necessary function pointers and state information for Mapper 41.
 * It assigns the `M41Power` function to the `Power` member of the `CartInfo` structure,
 * which is responsible for handling power-up initialization for the mapper. Additionally,
 * it sets the `GameStateRestore` function pointer to `StateRestore`, which is used to
 * restore the game state. Finally, it adds the state registers to the emulator's state
 * management system using `AddExState`, ensuring that the mapper's state is properly
 * saved and restored during emulation.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge information.
 */
void Mapper41_Init(CartInfo *info) {
	info->Power = M41Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
