/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2009 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 chrlo[8], chrhi[8], prg[2], mirr, vlock;
static int32 IRQa, IRQCount, IRQLatch, IRQClock;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;
static uint8 *CHRRAM = NULL;
static uint32 CHRRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ chrlo, 8, "CHRL" },
	{ chrhi, 8, "CHRH" },
	{ prg, 2, "PRGR" },
	{ &mirr, 1, "MIRR" },
	{ &vlock, 1, "VLCK" },
	{ &IRQa, 4, "IRQA" },
	{ &IRQCount, 4, "IRQC" },
	{ &IRQLatch, 4, "IRQL" },
	{ &IRQClock, 4, "IRQK" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration for the emulator.
 *
 * This method configures the Programmable Read-Only Memory (PRG) and Character Read-Only Memory (CHR)
 * banks, as well as the mirroring mode for the emulator. It performs the following operations:
 * - Sets the PRG-ROM banks at specific memory addresses (0x6000, 0x8000, 0xA000, 0xC000, 0xE000).
 * - Configures the CHR-ROM banks for each of the 8 CHR banks, using the values from `chrlo` and `chrhi`.
 *   If the lower byte of the CHR bank (`chrlo[i]`) is 4 or 5 and `vlock` is false, it uses a specific
 *   memory region (0x10) for the CHR bank.
 * - Sets the mirroring mode based on the value of `mirr`, which can be vertical (MI_V), horizontal (MI_H),
 *   single-screen (MI_0), or single-screen alternate (MI_1).
 */
static void Sync(void) {
	uint8 i;
	setprg8r(0x10, 0x6000, 0);
	setprg8(0x8000, prg[0]);
	setprg8(0xa000, prg[1]);
	setprg8(0xc000, ~1);
	setprg8(0xe000, ~0);
	for (i = 0; i < 8; i++) {
		uint32 chr = chrlo[i] | (chrhi[i] << 8);
		if (((chrlo[i] == 4) || (chrlo[i] == 5)) && !vlock)
			setchr1r(0x10, i << 10, chr & 1);
		else
			setchr1(i << 10, chr);
	}
	switch (mirr) {
	case 0: setmirror(MI_V); break;
	case 1: setmirror(MI_H); break;
	case 2: setmirror(MI_0); break;
	case 3: setmirror(MI_1); break;
	}
}

/**
 * @brief Handles write operations to the Mapper 253 memory-mapped registers.
 * 
 * This method processes write operations to specific memory addresses associated with Mapper 253.
 * It updates internal state based on the address (A) and value (V) provided. The method handles
 * two main address ranges:
 * 
 * 1. For addresses in the range 0xB000 to 0xE00C:
 *    - Computes an index (ind) based on the address.
 *    - Updates the low byte of the CHR ROM (chrlo) based on the computed index and the value (V).
 *    - If the index is 0, checks for specific values to update the vlock flag.
 *    - Updates the high byte of the CHR ROM (chrhi) if the address indicates a high byte write.
 *    - Calls Sync() to synchronize the internal state with the emulator.
 * 
 * 2. For specific addresses outside the above range:
 *    - Updates the program ROM (prg) for addresses 0x8010 and 0xA010.
 *    - Updates the mirroring mode (mirr) for address 0x9400.
 *    - Handles IRQ-related updates for addresses 0xF000, 0xF004, and 0xF008, including
 *      ending IRQs, updating the IRQ latch, and setting the IRQ clock and count.
 * 
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(M253Write) {
	if ((A >= 0xB000) && (A <= 0xE00C)) {
		uint8 ind = ((((A & 8) | (A >> 8)) >> 3) + 2) & 7;
		uint8 sar = A & 4;
		uint8 clo = (chrlo[ind] & (0xF0 >> sar)) | ((V & 0x0F) << sar);
		chrlo[ind] = clo;
		if (ind == 0) {
			if (clo == 0xc8)
				vlock = 0;
			else if (clo == 0x88)
				vlock = 1;
		}
		if (sar)
			chrhi[ind] = V >> 4;
		Sync();
	} else
		switch (A) {
		case 0x8010: prg[0] = V; Sync(); break;
		case 0xA010: prg[1] = V; Sync(); break;
		case 0x9400: mirr = V & 3; Sync(); break;
		case 0xF000: X6502_IRQEnd(FCEU_IQEXT); IRQLatch &= 0xF0; IRQLatch |= V & 0xF; break;
		case 0xF004: X6502_IRQEnd(FCEU_IQEXT); IRQLatch &= 0x0F; IRQLatch |= V << 4; break;
		case 0xF008: X6502_IRQEnd(FCEU_IQEXT); IRQClock = 0; IRQCount = IRQLatch; IRQa = V & 2; break;
		}
}

/**
 * @brief Initializes the memory mapping and power-up state for the M253 mapper.
 *
 * This method sets up the memory handlers for the M253 mapper, which is used in certain NES ROMs.
 * It performs the following operations:
 * 1. Resets the `vlock` variable to 0, ensuring the mapper starts in a known state.
 * 2. Calls `Sync()` to synchronize internal state or configurations.
 * 3. Sets read and write handlers for the memory range 0x6000-0x7FFF to `CartBR` and `CartBW`, respectively,
 *    which handle cartridge bank reading and writing.
 * 4. Sets read and write handlers for the memory range 0x8000-0xFFFF to `CartBR` and `M253Write`, respectively,
 *    where `M253Write` is a custom handler for this mapper.
 * 5. Adds RAM to the cheat system using `FCEU_CheatAddRAM`, specifying the size of the work RAM (WRAMSIZE >> 10),
 *    the base address (0x6000), and the RAM array (WRAM).
 */
static void M253Power(void) {
	vlock = 0;
	Sync();
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M253Write);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and frees the memory allocated for WRAM and CHRRAM.
 *
 * This method checks if the WRAM and CHRRAM pointers are not null. If they are not null,
 * it calls the FCEU_gfree function to free the allocated memory for each. After freeing
 * the memory, it sets both WRAM and CHRRAM pointers to NULL to indicate that the memory
 * has been released and to prevent any further access to the freed memory.
 */
static void M253Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	if (CHRRAM)
		FCEU_gfree(CHRRAM);
	WRAM = CHRRAM = NULL;
}

/**
 * @brief Handles the M253 IRQ (Interrupt Request) logic.
 *
 * This method processes the IRQ for the M253 chip. It increments the IRQ clock
 * based on the input parameter `a` and checks if the clock exceeds the predefined
 * cycle count (LCYCS). If the clock exceeds LCYCS, it decrements the clock by LCYCS
 * and increments the IRQ count. If the IRQ count reaches a specific threshold
 * (0x100), it triggers an external IRQ (X6502_IRQBegin) and resets the IRQ count
 * to the value stored in IRQLatch. This method is only executed if the IRQ is
 * enabled (IRQa is true).
 *
 * @param a The input value used to increment the IRQ clock. Typically represents
 *          the number of cycles to advance the IRQ clock.
 */
static void M253IRQ(int a) {
	#define LCYCS 341
	if (IRQa) {
		IRQClock += a * 3;
		if (IRQClock >= LCYCS) {
			while (IRQClock >= LCYCS) {
				IRQClock -= LCYCS;
				IRQCount++;
				if (IRQCount & 0x100) {
					X6502_IRQBegin(FCEU_IQEXT);
					IRQCount = IRQLatch;
				}
			}
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state to a specific version.
 * It ensures that the system is synchronized before proceeding with the restoration.
 * The `version` parameter specifies the version of the state to be restored.
 * 
 * @param version The version of the state to restore.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 253 for the given cartridge information.
 *
 * This method sets up the necessary function pointers and memory mappings for Mapper 253.
 * It initializes the Power and Close function pointers in the CartInfo structure to
 * M253Power and M253Close respectively. It also sets the MapIRQHook to M253IRQ and
 * the GameStateRestore to StateRestore.
 *
 * The method allocates memory for CHR RAM and PRG RAM, and sets up the corresponding
 * memory mappings. It also adds the CHR RAM and PRG RAM to the state save system.
 * If the cartridge has a battery backup, it configures the SaveGame and SaveGameLen
 * fields in the CartInfo structure to save the PRG RAM state.
 *
 * Finally, it adds the state registers to the state save system.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void Mapper253_Init(CartInfo *info) {
	info->Power = M253Power;
	info->Close = M253Close;
	MapIRQHook = M253IRQ;
	GameStateRestore = StateRestore;

	CHRRAMSIZE = 2048;
	CHRRAM = (uint8*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CRAM");

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}

	AddExState(&StateRegs, ~0, 0, 0);
}
