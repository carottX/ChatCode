/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * (VRC4 mapper)
 *
 */

#include "mapinc.h"

static uint8 IRQCount;
static uint8 IRQa;
static uint8 prg_reg[2];
static uint8 chr_reg[8];
static uint8 mirr;

static SFORMAT StateRegs[] =
{
	{ &IRQCount, 1, "IRQC" },
	{ &IRQa, 1, "IRQA" },
	{ prg_reg, 2, "PRG" },
	{ chr_reg, 8, "CHR" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Handles the M222 IRQ (Interrupt Request) logic.
 * 
 * This method is responsible for managing the IRQ logic for the M222 chip. 
 * It checks if the IRQ is active (IRQa is true) and increments the IRQCount.
 * If the IRQCount reaches or exceeds the threshold of 238, it triggers an external IRQ
 * by calling X6502_IRQBegin with the FCEU_IQEXT parameter. The IRQ flag (IRQa) is not
 * automatically cleared after triggering the IRQ, allowing for further processing if needed.
 */
static void M222IRQ(void) {
	if (IRQa) {
		IRQCount++;
		if (IRQCount >= 238) {
			X6502_IRQBegin(FCEU_IQEXT);
//			IRQa=0;
		}
	}
}

/**
 * @brief Synchronizes the memory mapping for the emulator.
 * 
 * This method updates the Program ROM (PRG) and Character ROM (CHR) banks 
 * based on the current values stored in the `prg_reg` and `chr_reg` arrays. 
 * It also sets the mirroring mode for the nametable.
 * 
 * Specifically, it:
 * - Maps the first 8KB PRG bank to the address range 0x8000-0x9FFF using `prg_reg[0]`.
 * - Maps the second 8KB PRG bank to the address range 0xA000-0xBFFF using `prg_reg[1]`.
 * - Maps 1KB CHR banks to the address range 0x0000-0x1FFF using the values in `chr_reg`.
 * - Sets the mirroring mode by toggling the value of `mirr` (0 for horizontal, 1 for vertical).
 */
static void Sync(void) {
	setprg8(0x8000, prg_reg[0]);
	setprg8(0xA000, prg_reg[1]);
	int i;
	for (i = 0; i < 8; i++)
		setchr1(i << 10, chr_reg[i]);
	setmirror(mirr ^ 1);
}

/**
 * @brief Handles write operations to memory-mapped registers for the M222 mapper.
 *
 * This method is responsible for processing write operations to specific memory addresses
 * associated with the M222 mapper. It updates internal registers based on the address (`A`)
 * and the value (`V`) provided. The method supports various operations, including:
 * - Updating program (PRG) registers (`prg_reg[0]` and `prg_reg[1]`).
 * - Updating mirroring configuration (`mirr`).
 * - Updating character (CHR) registers (`chr_reg[0]` to `chr_reg[7]`).
 * - Handling IRQ (Interrupt Request) related operations, including setting IRQ flags and counters.
 *
 * The method uses a switch statement to determine the appropriate action based on the masked address
 * (`A & 0xF003`). After processing the write operation, it calls `Sync()` to ensure the mapper's
 * internal state is synchronized with the changes made.
 *
 * @param A The memory address being written to, masked with `0xF003` to determine the specific operation.
 * @param V The value being written to the specified address.
 */
static DECLFW(M222Write) {
	switch (A & 0xF003) {
	case 0x8000: prg_reg[0] = V; break;
	case 0x9000: mirr = V & 1; break;
	case 0xA000: prg_reg[1] = V; break;
	case 0xB000: chr_reg[0] = V; break;
	case 0xB002: chr_reg[1] = V; break;
	case 0xC000: chr_reg[2] = V; break;
	case 0xC002: chr_reg[3] = V; break;
	case 0xD000: chr_reg[4] = V; break;
	case 0xD002: chr_reg[5] = V; break;
	case 0xE000: chr_reg[6] = V; break;
	case 0xE002: chr_reg[7] = V; break;
	case 0xF000: IRQa = IRQCount = V; if (scanline < 240) IRQCount -= 8; else IRQCount += 4; X6502_IRQEnd(FCEU_IQEXT); break;
	}
	Sync();
}

/**
 * @brief Initializes the power-on state for the M222 mapper.
 *
 * This method configures the memory mapping and read/write handlers for the M222 mapper.
 * It sets the PRG ROM bank at address 0xC000 to the last bank by writing ~0 (which typically
 * represents the highest bank number). It also sets up the read handler for the address range
 * 0x8000 to 0xFFFF to use the `CartBR` function, which handles reading from cartridge memory.
 * Additionally, it sets up the write handler for the same address range to use the `M222Write`
 * function, which handles writing to the mapper's registers or memory.
 */
static void M222Power(void) {
	setprg16(0xC000, ~0);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M222Write);
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method synchronizes the current state of the system with a specified version 
 * by calling the `Sync()` method. It ensures that the system's state is consistent 
 * with the version provided as an argument. This is typically used in scenarios 
 * where state rollback or recovery is required.
 * 
 * @param version The version of the state to restore. This parameter specifies 
 *                the target state version to which the system should be synchronized.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 222 for the given cartridge information.
 * This function sets up the necessary function pointers and state restoration
 * for the Mapper 222. Specifically, it assigns the power function, IRQ hook,
 * and state restoration function to the appropriate handlers. Additionally,
 * it adds the state registers to the emulator's state management system.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific
 *             information and function pointers.
 */
void Mapper222_Init(CartInfo *info) {
	info->Power = M222Power;
	GameHBIRQHook = M222IRQ;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
