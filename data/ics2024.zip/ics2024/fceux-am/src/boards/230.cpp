/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *  Copyright (C) 2009 qeed
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * 22 + Contra Reset based custom mapper...
 *
 */

#include "mapinc.h"

static uint8 latche, reset;
static SFORMAT StateRegs[] =
{
	{ &reset, 1, "RST" },
	{ &latche, 1, "LATC" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current state of the latch.
 *
 * This method adjusts the Program ROM (PRG) and Character ROM (CHR) memory mappings, as well as the mirroring mode,
 * based on the value of the `latche` variable and the `reset` flag. The behavior is as follows:
 *
 * - If the `reset` flag is set:
 *   - Maps the first 16KB PRG ROM bank to address 0x8000 using the lower 3 bits of `latche`.
 *   - Maps the last 16KB PRG ROM bank to address 0xC000 as bank 7.
 *   - Sets the mirroring mode to vertical (MI_V).
 *
 * - If the `reset` flag is not set:
 *   - Calculates the PRG ROM bank based on the lower 5 bits of `latche`, offset by 8.
 *   - If bit 5 of `latche` is set, maps the calculated bank to both 0x8000 and 0xC000.
 *   - Otherwise, maps a 32KB PRG ROM block starting at 0x8000 using the calculated bank divided by 2.
 *   - Sets the mirroring mode based on bit 6 of `latche` (0 for horizontal, 1 for vertical).
 *
 * - Regardless of the `reset` flag, this method always maps the first 8KB CHR ROM bank to address 0x0000.
 */
static void Sync(void) {
	if(reset) {
		setprg16(0x8000, latche & 7);
		setprg16(0xC000, 7);
		setmirror(MI_V);
	} else {
		uint32 bank = (latche & 0x1F) + 8;
		if (latche & 0x20) {
			setprg16(0x8000, bank);
			setprg16(0xC000, bank);
		} else
			setprg32(0x8000, bank >> 1);
		setmirror((latche >> 6) & 1);
	}
	setchr8(0);
}

/**
 * @brief Writes a value to the M230 register and synchronizes the system.
 *
 * This static method is responsible for updating the internal latch with the provided value
 * and then triggering a synchronization process. The latch is typically used to store
 * a temporary value that will be processed or applied during the synchronization phase.
 * The Sync() function is called immediately after updating the latch to ensure that
 * the system state is consistent with the new value.
 *
 * @param V The value to be written to the M230 register. This value is stored in the
 *          internal latch and used during the synchronization process.
 */
static DECLFW(M230Write) {
	latche = V;
	Sync();
}

/**
 * @brief Toggles the reset flag and synchronizes the system state.
 *
 * This method toggles the value of the `reset` flag by performing a bitwise XOR operation with 1.
 * After toggling the reset flag, it calls the `Sync()` method to ensure the system state is
 * synchronized with the updated reset flag. This can be used to trigger a reset or to clear
 * a reset condition depending on the current state of the `reset` flag.
 */
static void M230Reset(void) {
	reset ^= 1;
	Sync();
}

/**
 * @brief Initializes the M230 power state by resetting the latch and reset flags,
 *        synchronizing the system, and setting up the read and write handlers
 *        for the memory range 0x8000 to 0xFFFF.
 * 
 * This method performs the following operations:
 * 1. Resets the `latche` and `reset` flags to 0.
 * 2. Calls `Sync()` to synchronize the system state.
 * 3. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M230Write`.
 * 4. Sets the read handler for the memory range 0x8000 to 0xFFFF to `CartBR`.
 */
static void M230Power(void) {
	latche = reset = 0;
	Sync();
	SetWriteHandler(0x8000, 0xFFFF, M230Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Restores the state to a previous version by synchronizing the current state.
 * 
 * This method is responsible for restoring the state to a specific version by invoking
 * the `Sync()` method, which ensures that the current state is synchronized with the
 * desired version. The version parameter specifies the target state version to restore.
 * 
 * @param version The version of the state to restore to.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 230 for the given cartridge information.
 * This method sets up the necessary function pointers for power and reset operations,
 * and adds the state registers to the emulator's state management system.
 * It also assigns the state restore function to handle game state restoration.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 *             This structure is modified to include the Mapper 230's power and reset handlers,
 *             and the state registers are added to the emulator's state management.
 */
void Mapper230_Init(CartInfo *info) {
	info->Power = M230Power;
	info->Reset = M230Reset;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
