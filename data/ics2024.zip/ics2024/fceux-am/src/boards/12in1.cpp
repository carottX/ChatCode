/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2009 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * 7-in-1  Darkwing Duck, Snake, MagicBlock (PCB marked as "12 in 1")
 * 12-in-1 1991 New Star Co. Ltd.
 *
 */

#include "mapinc.h"

static uint8 prgchr[2], ctrl;
static SFORMAT StateRegs[] =
{
	{ prgchr, 2, "REGS" },
	{ &ctrl, 1, "CTRL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping configuration based on the current control settings.
 * 
 * This method updates the CHR and PRG memory banks and the mirroring mode based on the value of the `ctrl` register.
 * 
 * - The CHR memory banks are configured using the lower 3 bits of `ctrl` (shifted to form a bank index) and the `prgchr` array.
 * - The PRG memory banks are configured differently depending on the value of bit 3 of `ctrl`:
 *   - If bit 3 is set, the PRG banks are configured with specific values to handle switching between two registers.
 *   - If bit 3 is not set, the PRG banks are configured using the lower 3 bits of `ctrl` and the `prgchr` array.
 * - The mirroring mode is set based on bit 2 of `ctrl`.
 * 
 * This method ensures that the memory mapping is consistent with the current state of the `ctrl` register.
 */
static void Sync(void) {
	uint8 bank = (ctrl & 3) << 3;
	setchr4(0x0000, (prgchr[0] >> 3) | (bank << 2));
	setchr4(0x1000, (prgchr[1] >> 3) | (bank << 2));
	if (ctrl & 8) {
		setprg16(0x8000, bank | (prgchr[0] & 6) | 0);   // actually, both 0 and 1 registers used, but they will switch each PA12 transition
		setprg16(0xc000, bank | (prgchr[0] & 6) | 1);   // if bits are different for both registers, so they must be programmed strongly the same!
	} else {
		setprg16(0x8000, bank | (prgchr[0] & 7));
		setprg16(0xc000, bank | 7 );
	}
	setmirror(((ctrl & 4) >> 2) ^ 1);
}

/**
 * @brief Handles write operations for the BMC12IN1 mapper.
 * 
 * This method processes write requests to specific memory addresses associated with the BMC12IN1 mapper.
 * Depending on the address (A) and the value (V) provided, it updates the corresponding internal state:
 * - If the address is in the range 0xA000, it updates the first PRG/CHR register (prgchr[0]) and triggers a synchronization.
 * - If the address is in the range 0xC000, it updates the second PRG/CHR register (prgchr[1]) and triggers a synchronization.
 * - If the address is in the range 0xE000, it updates the control register (ctrl) with the lower 4 bits of the value and triggers a synchronization.
 * 
 * @param A The address to which the write operation is directed.
 * @param V The value to be written to the specified address.
 */
static DECLFW(BMC12IN1Write) {
	switch (A & 0xE000) {
	case 0xA000: prgchr[0] = V; Sync(); break;
	case 0xC000: prgchr[1] = V; Sync(); break;
	case 0xE000: ctrl = V & 0x0F; Sync(); break;
	}
}

/**
 * @brief Initializes the BMC12IN1 power state for the emulator.
 *
 * This method resets the program character (prgchr) and control (ctrl) variables to 0,
 * synchronizes the emulator state, and sets up the read and write handlers for the memory
 * range 0x8000 to 0xFFFF. Specifically, it assigns `CartBR` as the read handler and
 * `BMC12IN1Write` as the write handler for this memory range.
 */
static void BMC12IN1Power(void) {
	prgchr[0] = prgchr[1] = ctrl = 0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, BMC12IN1Write);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that all necessary data and configurations are synchronized before proceeding with
 * the restoration process. The actual restoration logic is handled by the `Sync()` method, which
 * is called internally to perform the synchronization.
 * 
 * @param version The version number of the state to be restored. This version should correspond
 *                to a previously saved state in the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the BMC12IN1 mapper for the provided cartridge information.
 *
 * This function sets up the necessary configurations for the BMC12IN1 mapper by assigning
 * the appropriate power function to the cartridge's `Power` field. It also registers the
 * state restoration function and adds the state registers to the emulator's state system.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 *             The `Power` field of this structure will be set to the BMC12IN1Power function.
 */
void BMC12IN1_Init(CartInfo *info) {
	info->Power = BMC12IN1Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

