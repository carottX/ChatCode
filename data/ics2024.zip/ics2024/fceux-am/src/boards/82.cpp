/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Taito X1-017 board, battery backed
 *
 */

#include "mapinc.h"

static uint8 regs[9], ctrl;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ regs, 9, "REGS" },
	{ &ctrl, 1, "CTRL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the emulated system.
 * 
 * This method updates the CHR (Character) and PRG (Program) memory mappings based on the current
 * values in the `ctrl` register and the `regs` array. It also sets the mirroring mode for the
 * emulated system.
 * 
 * The method performs the following operations:
 * 1. Calculates a swap value based on the second bit of the `ctrl` register.
 * 2. Updates the CHR memory mappings for different address ranges using the `setchr2` and `setchr1`
 *    functions, applying the swap value to the base addresses.
 * 3. Updates the PRG memory mappings for different address ranges using the `setprg8r` and `setprg8`
 *    functions, using values from the `regs` array.
 * 4. Sets the mirroring mode using the `setmirror` function, based on the first bit of the `ctrl`
 *    register.
 * 
 * This method is typically called whenever the memory mapping or mirroring configuration needs to
 * be updated, such as after a write to the `ctrl` register or the `regs` array.
 */
static void Sync(void) {
	uint32 swap = ((ctrl & 2) << 11);
	setchr2(0x0000 ^ swap, regs[0] >> 1);
	setchr2(0x0800 ^ swap, regs[1] >> 1);
	setchr1(0x1000 ^ swap, regs[2]);
	setchr1(0x1400 ^ swap, regs[3]);
	setchr1(0x1800 ^ swap, regs[4]);
	setchr1(0x1c00 ^ swap, regs[5]);
	setprg8r(0x10, 0x6000, 0);
	setprg8(0x8000, regs[6]);
	setprg8(0xA000, regs[7]);
	setprg8(0xC000, regs[8]);
	setprg8(0xE000, ~0);
	setmirror(ctrl & 1);
}

/**
 * @brief Writes a value to a specific memory-mapped register or control register.
 *
 * This method handles writing a value to either a general-purpose register or a specific control register
 * based on the address provided. If the address (A) is less than or equal to 0x7ef5, the value (V) is written
 * to one of the general-purpose registers (regs) indexed by the lower 3 bits of the address. If the address
 * is one of the specific control registers (0x7ef6, 0x7efa, 0x7efb, or 0x7efc), the value is written to the
 * corresponding control register or shifted and written to a specific general-purpose register. After the
 * write operation, the Sync() function is called to ensure synchronization.
 *
 * @param A The memory address to write to. Determines which register or control register is updated.
 * @param V The value to write to the specified register or control register.
 */
static DECLFW(M82Write) {
	if (A <= 0x7ef5)
		regs[A & 7] = V;
	else
		switch (A) {
		case 0x7ef6: ctrl = V & 3; break;
		case 0x7efa: regs[6] = V >> 2; break;
		case 0x7efb: regs[7] = V >> 2; break;
		case 0x7efc: regs[8] = V >> 2; break;
		}
	Sync();
}

/**
 * @brief Initializes the M82 cartridge power-up sequence.
 *
 * This method sets up the necessary read and write handlers for the M82 cartridge
 * memory mapping. It synchronizes the system, configures the read handler for the
 * address range 0x6000 to 0xFFFF to use the CartBR function, and sets up write handlers
 * for the address ranges 0x6000 to 0x7FFF (using CartBW) and 0x7EF0 to 0x7EFC (using M82Write).
 * Additionally, it adds RAM for cheat functionality, mapping WRAM to the address 0x6000
 * with a size of WRAMSIZE >> 10.
 */
static void M82Power(void) {
	Sync();
	SetReadHandler(0x6000, 0xffff, CartBR);
	SetWriteHandler(0x6000, 0x7fff, CartBW);
	SetWriteHandler(0x7ef0, 0x7efc, M82Write);  // external WRAM might end at $73FF
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and frees the WRAM (Work RAM) resource.
 *
 * This method checks if the WRAM pointer is not null. If WRAM is allocated,
 * it frees the memory associated with WRAM using the `FCEU_gfree` function.
 * After freeing the memory, it sets the WRAM pointer to null to indicate
 * that the resource is no longer allocated.
 */
static void M82Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state by synchronizing
 * with the saved state corresponding to the specified version. It calls the 
 * `Sync()` method to ensure that the current state is updated to match the 
 * desired version.
 * 
 * @param version The version number of the state to restore. This version 
 *                should correspond to a previously saved state.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 82 configuration for the given cartridge information.
 *
 * This method sets up the necessary functions and memory mappings for Mapper 82, which is used
 * in certain NES cartridges. It assigns the `Power` and `Close` functions to the appropriate
 * handlers (`M82Power` and `M82Close`). It also allocates 8KB of Work RAM (WRAM) and sets up
 * the PRG mapping for this memory. If the cartridge supports battery-backed saves, the WRAM
 * is designated as the save game memory. Additionally, it registers the state restoration
 * function (`StateRestore`) and adds the state registers to the emulator's state system.
 *
 * @param info Pointer to the `CartInfo` structure containing the cartridge configuration.
 */
void Mapper82_Init(CartInfo *info) {
	info->Power = M82Power;
	info->Close = M82Close;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
