/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
//#define DEBUG90

// Mapper 090 is simpliest mapper hardware and have not extended nametable control and latched chr banks in 4k mode
// Mapper 209 much compicated hardware with decribed above features disabled by default and switchable by command
// Mapper 211 the same mapper 209 but with forced nametable control

static int is209;
static int is211;

static uint8 IRQMode;        // from $c001
static uint8 IRQPre;         // from $c004
static uint8 IRQPreSize;     // from $c007
static uint8 IRQCount;       // from $c005
static uint8 IRQXOR;         // Loaded from $C006
static uint8 IRQa;           // $c002, $c003, and $c000

static uint8 mul[2];
static uint8 regie;

static uint8 tkcom[4];
static uint8 prgb[4];
static uint8 chrlow[8];
static uint8 chrhigh[8];

static uint8 chr[2];

static uint16 names[4];
static uint8 tekker;

static SFORMAT Tek_StateRegs[] = {
	{ &IRQMode, 1, "IRQM" },
	{ &IRQPre, 1, "IRQP" },
	{ &IRQPreSize, 1, "IRQR" },
	{ &IRQCount, 1, "IRQC" },
	{ &IRQXOR, 1, "IRQX" },
	{ &IRQa, 1, "IRQA" },
	{ mul, 2, "MUL" },
	{ &regie, 1, "REGI" },
	{ tkcom, 4, "TKCO" },
	{ prgb, 4, "PRGB" },
	{ chr, 2, "CLTC" },
	{ chrlow, 4, "CHRL" },
	{ chrhigh, 8, "CHRH" },
	{ &names[0], 2 | FCEUSTATE_RLSB, "NMS0" },
	{ &names[1], 2 | FCEUSTATE_RLSB, "NMS1" },
	{ &names[2], 2 | FCEUSTATE_RLSB, "NMS2" },
	{ &names[3], 2 | FCEUSTATE_RLSB, "NMS3" },
	{ &tekker, 1, "TEKR" },
	{ 0 }
};

/**
 * @brief Configures the mirroring or name table memory layout based on the values in `tkcom` and `is209`/`is211`.
 *
 * This method determines how the name tables or mirroring should be set up based on the control flags in `tkcom` and the state of `is209`/`is211`.
 * - If `tkcom[0]` has the 0x20 bit set and `is209` is true, or if `is211` is true, the method configures the name table memory layout.
 *   - If `tkcom[0]` has the 0x40 bit set, the name tables are treated as ROM-only, and the memory is set up using `CHRptr[0]` and `CHRmask1[0]`.
 *   - Otherwise, the name tables can be either RAM or ROM, and the method checks `tkcom[1]` to determine the appropriate memory source (RAM or ROM) for each name table.
 * - If the above conditions are not met, the method configures the mirroring mode based on the lower 2 bits of `tkcom[1]`:
 *   - 0: Vertical mirroring (`MI_V`).
 *   - 1: Horizontal mirroring (`MI_H`).
 *   - 2: Single-screen mirroring using the first screen (`MI_0`).
 *   - 3: Single-screen mirroring using the second screen (`MI_1`).
 */
static void mira(void)
{
  if((tkcom[0]&0x20&&is209)||is211)
  {
    int x;
    if(tkcom[0]&0x40)        // Name tables are ROM-only
    {
      for(x=0;x<4;x++)
         setntamem(CHRptr[0]+(((names[x])&CHRmask1[0])<<10),0,x);
    }
    else                        // Name tables can be RAM or ROM.
    {
      for(x=0;x<4;x++)
      {
        if((tkcom[1]&0x80)==(names[x]&0x80))        // RAM selected.
          setntamem(NTARAM+((names[x]&0x1)<<10),1,x);
        else
          setntamem(CHRptr[0]+(((names[x])&CHRmask1[0])<<10),0,x);
      }
    }
  }
  else
  {
    switch(tkcom[1]&3)
    {
      case 0: setmirror(MI_V); break;
      case 1: setmirror(MI_H); break;
      case 2: setmirror(MI_0); break;
      case 3: setmirror(MI_1); break;
    }
  }
}

/**
 * @brief Configures the program memory (PRG) banks based on the values in the `tkcom` and `prgb` arrays.
 *
 * This method sets up the PRG memory banks for different configurations depending on the value of `tkcom[0] & 7`.
 * The method uses the `setprg8` and `setprg16` functions to configure the memory banks at specific addresses.
 * The `bankmode` is derived from `tkcom[3] & 6` and is used to modify the bank selection.
 *
 * The method handles the following cases:
 * - Case 00: Configures a 32 KB PRG bank at 0x8000 and optionally an 8 KB PRG bank at 0x6000.
 * - Case 01: Configures two 16 KB PRG banks at 0x8000 and 0xC000, and optionally an 8 KB PRG bank at 0x6000.
 * - Case 02/03: Configures four 8 KB PRG banks at 0x8000, 0xA000, 0xC000, and 0xE000, and optionally an 8 KB PRG bank at 0x6000.
 * - Case 04: Configures a 32 KB PRG bank at 0x8000 and optionally an 8 KB PRG bank at 0x6000.
 * - Case 05: Configures two 16 KB PRG banks at 0x8000 and 0xC000, and optionally an 8 KB PRG bank at 0x6000.
 * - Case 06/07: Configures four 8 KB PRG banks at 0x8000, 0xA000, 0xC000, and 0xE000, and optionally an 8 KB PRG bank at 0x6000.
 *
 * The specific bank numbers are derived from the `prgb` array and modified by the `bankmode`.
 */
static void tekprom(void)
{
  uint32 bankmode=((tkcom[3]&6)<<5);
  switch(tkcom[0]&7)
  {
    case 00: if(tkcom[0]&0x80)
               setprg8(0x6000,(((prgb[3]<<2)+3)&0x3F)|bankmode);
             setprg32(0x8000,0x0F|((tkcom[3]&6)<<3));
             break;
    case 01: if(tkcom[0]&0x80)
               setprg8(0x6000,(((prgb[3]<<1)+1)&0x3F)|bankmode);
             setprg16(0x8000,(prgb[1]&0x1F)|((tkcom[3]&6)<<4));
             setprg16(0xC000,0x1F|((tkcom[3]&6)<<4));
             break;
    case 03: // bit reversion
    case 02: if(tkcom[0]&0x80)
               setprg8(0x6000,(prgb[3]&0x3F)|bankmode);
             setprg8(0x8000,(prgb[0]&0x3F)|bankmode);
             setprg8(0xa000,(prgb[1]&0x3F)|bankmode);
             setprg8(0xc000,(prgb[2]&0x3F)|bankmode);
             setprg8(0xe000,0x3F|bankmode);
             break;
    case 04: if(tkcom[0]&0x80)
               setprg8(0x6000,(((prgb[3]<<2)+3)&0x3F)|bankmode);
             setprg32(0x8000,(prgb[3]&0x0F)|((tkcom[3]&6)<<3));
             break;
    case 05: if(tkcom[0]&0x80)
               setprg8(0x6000,(((prgb[3]<<1)+1)&0x3F)|bankmode);
             setprg16(0x8000,(prgb[1]&0x1F)|((tkcom[3]&6)<<4));
             setprg16(0xC000,(prgb[3]&0x1F)|((tkcom[3]&6)<<4));
             break;
    case 07: // bit reversion
    case 06: if(tkcom[0]&0x80)
               setprg8(0x6000,(prgb[3]&0x3F)|bankmode);
             setprg8(0x8000,(prgb[0]&0x3F)|bankmode);
             setprg8(0xa000,(prgb[1]&0x3F)|bankmode);
             setprg8(0xc000,(prgb[2]&0x3F)|bankmode);
             setprg8(0xe000,(prgb[3]&0x3F)|bankmode);
             break;
  }
}

/**
 * @brief Configures the CHR ROM (Character Read-Only Memory) banking for a NES emulator.
 * 
 * This method adjusts the CHR ROM banking based on the values stored in the `tkcom` array.
 * It determines the bank size (8KB, 4KB, 2KB, or 1KB) and the corresponding mask and bank offset
 * by examining specific bits in `tkcom[0]` and `tkcom[3]`. The method then sets the CHR ROM banks
 * using the `setchr8`, `setchr4`, `setchr2`, or `setchr1` functions, depending on the bank size.
 * 
 * The `tkcom` array is used to control the banking logic:
 * - `tkcom[0]` bits 3 and 4 determine the bank size.
 * - `tkcom[3]` bits 0, 3, and 4 determine the bank offset and whether banking is enabled.
 * 
 * The `chrlow` and `chrhigh` arrays are used to store the low and high bytes of the CHR ROM addresses,
 * which are combined with the mask and bank offset to set the final CHR ROM banks.
 */
static void tekvrom(void)
{
  int x, bank=0, mask=0xFFFF;
  if(!(tkcom[3]&0x20))
  {
    bank=(tkcom[3]&1)|((tkcom[3]&0x18)>>2);
    switch (tkcom[0]&0x18)
    {
      case 0x00: bank<<=5; mask=0x1F; break;
      case 0x08: bank<<=6; mask=0x3F; break;
      case 0x10: bank<<=7; mask=0x7F; break;
      case 0x18: bank<<=8; mask=0xFF; break;
    }
  }
  switch(tkcom[0]&0x18)
  {
    case 0x00:      // 8KB
         setchr8(((chrlow[0]|(chrhigh[0]<<8))&mask)|bank);
         break;
    case 0x08:      // 4KB
//         for(x=0;x<8;x+=4)
//            setchr4(x<<10,((chrlow[x]|(chrhigh[x]<<8))&mask)|bank);
         setchr4(0x0000,((chrlow[chr[0]]|(chrhigh[chr[0]]<<8))&mask)|bank);
         setchr4(0x1000,((chrlow[chr[1]]|(chrhigh[chr[1]]<<8))&mask)|bank);
         break;
    case 0x10:      // 2KB
         for(x=0;x<8;x+=2)
            setchr2(x<<10,((chrlow[x]|(chrhigh[x]<<8))&mask)|bank);
         break;
    case 0x18:      // 1KB
         for(x=0;x<8;x++)
            setchr1(x<<10,((chrlow[x]|(chrhigh[x]<<8))&mask)|bank);
         break;
  }
}

/**
 * @brief Writes data to specific registers based on the provided address.
 *
 * This method is a static function that handles writing data to different registers
 * based on the address `A` and the value `V`. The address is masked with `0x5C03` to
 * determine which register to write to. The following actions are performed based on
 * the masked address:
 * - If the masked address is `0x5800`, the value `V` is written to `mul[0]`.
 * - If the masked address is `0x5801`, the value `V` is written to `mul[1]`.
 * - If the masked address is `0x5803`, the value `V` is written to `regie`.
 *
 * @param A The address used to determine the target register.
 * @param V The value to be written to the determined register.
 */
static DECLFW(M90TekWrite)
{
  switch(A&0x5C03)
  {
    case 0x5800: mul[0]=V; break;
    case 0x5801: mul[1]=V; break;
    case 0x5803: regie=V; break;
  }
}

/**
 * @brief Reads data from the M90Tek memory mapper based on the provided address.
 *
 * This method reads data from the M90Tek memory mapper by interpreting the address `A`
 * and returning the appropriate value based on the address pattern. The method supports
 * the following address patterns:
 * - 0x5800: Returns the product of `mul[0]` and `mul[1]`.
 * - 0x5801: Returns the product of `mul[0]` and `mul[1]` shifted right by 8 bits.
 * - 0x5803: Returns the value of `regie`.
 * - Default: Returns the value of `tekker`.
 *
 * If none of the above patterns match, the method returns 0xFF as a default value.
 *
 * @param A The address to read from. This is typically a 16-bit value.
 * @return The data read from the M90Tek memory mapper based on the address pattern.
 */
static DECLFR(M90TekRead)
{
  switch(A&0x5C03)
  {
    case 0x5800: return (mul[0]*mul[1]);
    case 0x5801: return((mul[0]*mul[1])>>8);
    case 0x5803: return (regie);
    default: return tekker;
  }
  return(0xff);
}

/**
 * @brief Writes a value to the specified Program ROM (PRG) bank register.
 *
 * This method updates the value of the PRG bank register indexed by the lower 2 bits of the address `A`.
 * After updating the register, it calls the `tekprom()` function, which is likely responsible for
 * applying the changes to the emulated system's memory mapping or other related functionality.
 *
 * @param A The address used to determine the PRG bank register index. Only the lower 2 bits are used.
 * @param V The value to be written to the selected PRG bank register.
 */
static DECLFW(M90PRGWrite)
{
//  FCEU_printf("bs %04x %02x\n",A,V);
  prgb[A&3]=V;
  tekprom();
}

/**
 * @brief Writes a value to the low CHR ROM bank.
 *
 * This method is used to write a value (`V`) to the specified low CHR ROM bank 
 * based on the address (`A`). The address is masked with `0x7` to ensure it 
 * falls within the range of the first 8 CHR banks. After writing the value, 
 * the `tekvrom()` function is called to update the video memory state.
 *
 * @param A The address within the low CHR ROM bank to write to. Only the lower 
 *          3 bits of the address are used (masked with `0x7`).
 * @param V The value to write to the specified CHR ROM bank.
 */
static DECLFW(M90CHRlowWrite)
{
//  FCEU_printf("bs %04x %02x\n",A,V);
  chrlow[A&7]=V;
  tekvrom();
}

/**
 * @brief Writes a value to the CHR high register and updates the VROM.
 *
 * This method is responsible for writing a given value (`V`) to the CHR high register
 * at the specified address (`A`). The address is masked with `0x7` to ensure it falls
 * within the range of the CHR high register array. After updating the register, the
 * method calls `tekvrom()` to update the VROM (Video ROM) based on the new CHR high
 * register value.
 *
 * @param A The address to write to, masked with `0x7` to ensure it is within bounds.
 * @param V The value to write to the CHR high register.
 */
static DECLFW(M90CHRhiWrite)
{
//  FCEU_printf("bs %04x %02x\n",A,V);
  chrhigh[A&7]=V;
  tekvrom();
}

/**
 * @brief Writes a value to the specified address in the M90 NT memory.
 * 
 * This method handles writing a byte value to a specific address in the M90 NT memory.
 * Depending on the address, the value is written to either the lower or upper byte of the 
 * corresponding entry in the `names` array. If the address has the 4th bit set (A & 4), 
 * the value is written to the upper byte of the entry. Otherwise, it is written to the lower byte.
 * After the write operation, the `mira()` function is called to update the memory state.
 * 
 * @param A The address where the value is to be written.
 * @param V The byte value to be written.
 */
static DECLFW(M90NTWrite)
{
//  FCEU_printf("bs %04x %02x\n",A,V);
  if(A&4)
  {
    names[A&3]&=0x00FF;
    names[A&3]|=V<<8;
  }
  else
  {
    names[A&3]&=0xFF00;
    names[A&3]|=V;
  }
  mira();
}

/**
 * @brief Handles writes to the M90 IRQ control registers.
 *
 * This method processes writes to the M90 IRQ control registers, which are used to configure
 * and control the interrupt request (IRQ) behavior in the emulator. The method interprets the
 * address (`A`) and value (`V`) parameters to determine which register is being written to
 * and updates the corresponding IRQ state or configuration.
 *
 * The address (`A`) is masked with 7 to determine the specific register being accessed:
 * - Case 00: Enables or disables the IRQ based on the value of `V`. If disabled, the IRQ is ended.
 * - Case 02: Disables the IRQ and ends any pending IRQ.
 * - Case 03: Enables the IRQ.
 * - Case 01: Sets the IRQ mode, which determines the counting method, prescaler size, and other
 *            configuration options.
 * - Case 04: Loads the pre-counter value, XORed with the current XOR value (`IRQXOR`).
 * - Case 05: Loads the main counter value, XORed with the current XOR value (`IRQXOR`).
 * - Case 06: Updates the XOR value used for loading the pre-counter and main counter.
 * - Case 07: Updates the prescaler size if the IRQ mode allows it.
 *
 * @param A The address of the IRQ control register being written to.
 * @param V The value being written to the IRQ control register.
 */
static DECLFW(M90IRQWrite)
{
//  FCEU_printf("bs %04x %02x\n",A,V);
  switch(A&7)
  {
    case 00: //FCEU_printf("%s IRQ (C000)\n",V&1?"Enable":"Disable");
             IRQa=V&1;if(!(V&1)) X6502_IRQEnd(FCEU_IQEXT);break;
    case 02: //FCEU_printf("Disable IRQ (C002) scanline=%d\n", scanline);
             IRQa=0;X6502_IRQEnd(FCEU_IQEXT);break;
    case 03: //FCEU_printf("Enable IRQ (C003) scanline=%d\n", scanline);
             IRQa=1;break;
    case 01: IRQMode=V;
             //  FCEU_printf("IRQ Count method: ");
             //  switch (IRQMode&3)
             //  {
             //    case 00: FCEU_printf("M2 cycles\n");break;
             //    case 01: FCEU_printf("PPU A12 toggles\n");break;
             //    case 02: FCEU_printf("PPU reads\n");break;
             //    case 03: FCEU_printf("Writes to CPU space\n");break;
             //  }
             //  FCEU_printf("Counter prescaler size: %s\n",(IRQMode&4)?"3 bits":"8 bits");
             //  FCEU_printf("Counter prescaler size adjust: %s\n",(IRQMode&8)?"Used C007":"Normal Operation");
             //  if((IRQMode>>6)==2) FCEU_printf("Counter Down\n");
             //   else if((IRQMode>>6)==1) FCEU_printf("Counter Up\n");
             //   else FCEU_printf("Counter Stopped\n");
              break;
    case 04: //FCEU_printf("Pre Counter Loaded and Xored wiht C006: %d\n",V^IRQXOR);
             IRQPre=V^IRQXOR;break;
    case 05: //FCEU_printf("Main Counter Loaded and Xored wiht C006: %d\n",V^IRQXOR);
             IRQCount=V^IRQXOR;break;
    case 06: //FCEU_printf("Xor Value: %d\n",V);
             IRQXOR=V;break;
    case 07: //if(!(IRQMode&8)) FCEU_printf("C001 is clear, no effect applied\n");
             //     else if(V==0xFF) FCEU_printf("Prescaler is changed for 12bits\n");
             //     else FCEU_printf("Counter Stopped\n");
             IRQPreSize=V;break;
  }
}

/**
 * @brief Writes a value to the M90 mode register and updates the corresponding memory mappings.
 *
 * This method is responsible for handling writes to the M90 mode register. It updates the internal
 * state of the M90 mapper by storing the provided value in the `tkcom` array at the index determined
 * by the address `A` (masked with 0x03). After updating the register, it calls the `tekprom()`,
 * `tekvrom()`, and `mira()` functions to update the PRG ROM, CHR ROM, and mirroring configurations,
 * respectively.
 *
 * In debug mode (when `DEBUG90` is defined), this method also prints detailed information about the
 * register being written to, including the current state of the PGR banking mode, CHR banking mode,
 * nametable control, mirroring mode, and other relevant settings.
 *
 * @param A The address being written to. Only the lower 2 bits are used to determine the register index.
 * @param V The value being written to the register.
 */
static DECLFW(M90ModeWrite)
{
//    FCEU_printf("bs %04x %02x\n",A,V);
    tkcom[A&3]=V;
    tekprom();
    tekvrom();
    mira();

#ifdef DEBUG90
  switch (A&3)
  {
   case 00: FCEU_printf("Main Control Register:\n");
            FCEU_printf("  PGR Banking mode: %d\n",V&7);
            FCEU_printf("  CHR Banking mode: %d\n",(V>>3)&3);
            FCEU_printf("  6000-7FFF addresses mapping: %s\n",(V&0x80)?"Yes":"No");
            FCEU_printf("  Nametable control: %s\n",(V&0x20)?"Enabled":"Disabled");
            if(V&0x20)
               FCEU_printf("  Nametable can be: %s\n",(V&0x40)?"ROM Only":"RAM or ROM");
            break;
   case 01: FCEU_printf("Mirroring mode: ");
            switch (V&3)
            {
             case 0: FCEU_printf("Vertical\n");break;
             case 1: FCEU_printf("Horizontal\n");break;
             case 2: FCEU_printf("Nametable 0 only\n");break;
             case 3: FCEU_printf("Nametable 1 only\n");break;
            }
            FCEU_printf("Mirroring flag: %s\n",(V&0x80)?"On":"Off");
            break;
   case 02: if((((tkcom[0])>>5)&3)==1)
              FCEU_printf("Nametable ROM/RAM select mode: %d\n",V>>7);
            break;
   case 03:
            FCEU_printf("CHR Banking mode: %s\n",(V&0x20)?"Entire CHR ROM":"256Kb Switching mode");
            if(!(V&0x20)) FCEU_printf("256K CHR bank number: %02x\n",(V&1)|((V&0x18)>>2));
            FCEU_printf("512K PRG bank number: %d\n",(V&6)>>1);
            FCEU_printf("CHR Bank mirroring: %s\n",(V&0x80)?"Swapped":"Normal operate");
  }
#endif
}

/**
 * @brief Dummy write method for M90 mapper.
 *
 * This method is a placeholder for write operations in the M90 mapper. It does not perform any
 * actual write operation or modify any state. It is typically used to handle write requests
 * that do not require any action or to prevent unintended writes to certain memory addresses.
 *
 * @param A The address where the write operation is intended.
 * @param V The value that is intended to be written.
 */
static DECLFW(M90DummyWrite)
{
//    FCEU_printf("bs %04x %02x\n",A,V);
}

/**
 * @brief Handles the counting logic for the IRQ (Interrupt Request) mechanism.
 *
 * This method checks the current IRQ mode and adjusts the IRQCount accordingly.
 * If the IRQ mode is set to "Count Up" (IRQMode >> 6 == 1), it increments the IRQCount.
 * If the IRQ mode is set to "Count Down" (IRQMode >> 6 == 2), it decrements the IRQCount.
 * When the IRQCount reaches a specific threshold (0 for count up or 0xFF for count down)
 * and the IRQa flag is set, it triggers an external IRQ by calling X6502_IRQBegin with FCEU_IQEXT.
 */
static void CCL(void)
{
  if((IRQMode>>6) == 1) // Count Up
  {
    IRQCount++;
    if((IRQCount == 0) && IRQa)
    {
      X6502_IRQBegin(FCEU_IQEXT);
    }
  }
  else if((IRQMode>>6) == 2) // Count down
  {
    IRQCount--;
    if((IRQCount == 0xFF) && IRQa)
    {
      X6502_IRQBegin(FCEU_IQEXT);
    }
  }
}

/**
 * @brief Handles the clock counter logic based on the current IRQ mode.
 *
 * This method increments or decrements the `IRQPre` counter based on the 
 * configuration in `IRQMode`. The behavior depends on the following:
 * - If the 3rd bit of `IRQMode` is set (0x4), the `premask` is set to 0x7, 
 *   otherwise, it is set to 0xFF.
 * - If the 7th bit of `IRQMode` is set (shifted right by 6), the counter 
 *   increments (`IRQPre++`). If the counter wraps around (i.e., `IRQPre & premask` 
 *   equals 0), the `CCL()` function is called.
 * - If the 8th bit of `IRQMode` is set (shifted right by 6), the counter 
 *   decrements (`IRQPre--`). If the counter wraps around (i.e., `IRQPre & premask` 
 *   equals `premask`), the `CCL()` function is called.
 *
 * @note This method is static and does not return any value.
 */
static void ClockCounter(void)
{
  uint8 premask;

  if(IRQMode & 0x4)
    premask = 0x7;
  else
    premask = 0xFF;
  if((IRQMode>>6) == 1) // Count up
  {
    IRQPre++;
    if((IRQPre & premask) == 0) CCL();
  }
  else if((IRQMode>>6) == 2) // Count down
  {
    IRQPre--;
    if((IRQPre & premask) == premask) CCL();
  }
}

/**
 * @brief Executes a series of clock cycles based on the provided parameter.
 *
 * This method checks the current IRQ mode and, if the mode is 0 (i.e., (IRQMode & 3) == 0),
 * it iterates 'a' times, calling the ClockCounter() method in each iteration. This effectively
 * simulates 'a' clock cycles of the CPU. If the IRQ mode is not 0, the method does nothing.
 *
 * @param a The number of clock cycles to simulate. This parameter determines how many times
 *          the ClockCounter() method will be called.
 */
void CPUWrap(int a)
{
    int x;
    if((IRQMode&3)==0) for(x=0;x<a;x++) ClockCounter();
}

/**
 * @brief Executes a sequence of clock counter increments based on the current IRQ mode.
 *
 * This method checks the current IRQ mode by examining the least significant two bits of `IRQMode`.
 * If the IRQ mode is set to 1 (i.e., `IRQMode & 3 == 1`), it iterates 8 times, calling the `ClockCounter()`
 * function in each iteration. This method is typically used to synchronize or advance the clock state
 * in specific interrupt handling scenarios.
 *
 * @note The method does not return any value and operates on the global or static state, particularly
 *       the `IRQMode` and the clock counter.
 */
static void SLWrap(void)
{
  int x;
  if((IRQMode&3)==1) for(x=0;x<8;x++) ClockCounter();
}

static uint32 lastread;
/**
 * @brief Handles memory-mapped I/O operations for the M90PPU.
 *
 * This method processes the memory address `A` to perform specific operations based on the current state of the PPU.
 * 
 * - If the IRQ mode is set to 2, it checks if the address `A` differs from the last read address (`lastread`). If so,
 *   it increments the clock counter twice and updates `lastread` to the current address `A`.
 * 
 * - If the `is209` flag is true, it processes the address `A` to determine if it falls within a specific range and matches
 *   certain patterns. If the address matches the criteria, it updates the CHR (Character ROM) bank and triggers a VROM
 *   update via `tekvrom()`.
 * 
 * - If the `is209` flag is false, it resets the CHR banks to default values (0 and 4).
 *
 * @param A The memory address being accessed, used to determine the operation to perform.
 */
static void M90PPU(uint32 A)
{
  if((IRQMode&3)==2)
  {
    if(lastread!=A)
    {
      ClockCounter();
      ClockCounter();
    }
    lastread=A;
  }

  if(is209)
  {
    uint8 l,h;
    h=A>>8;
    if(h<0x20&&((h&0x0F)==0xF))
    {
      l=A&0xF0;
      if(l==0xD0)
      {
        chr[(h&0x10)>>4]=((h&0x10)>>2);
        tekvrom();
      }
      else if(l==0xE0)
      {
        chr[(h&0x10)>>4]=((h&0x10)>>2)|2;
        tekvrom();
      }
    }
  }
  else
  {
    chr[0]=0;
    chr[1]=4;
  }
}

/**
 * @brief Toggles the internal state of the emulator by modifying the `tekker` variable
 *        and updating related memory and components.
 *
 * This method performs the following operations:
 * 1. Increments the `tekker` variable by 0x40.
 * 2. Masks the `tekker` variable to ensure it only retains the upper 2 bits (0xC0 mask).
 * 3. Prints the updated value of `tekker` using `FCEU_printf`.
 * 4. Clears the `tkcom` array by setting all its elements to 0x00.
 * 5. Sets all elements of the `prgb` array to 0xff.
 * 6. Calls `tekprom()` to update the program ROM based on the new `tekker` state.
 * 7. Calls `tekvrom()` to update the video ROM based on the new `tekker` state.
 *
 * This method is typically used to switch between different memory or ROM configurations
 * in the emulator, ensuring that the relevant components are updated accordingly.
 */
static void togglie()
{
  tekker+=0x40;
  tekker&=0xC0;
  FCEU_printf("tekker=%02x\n",tekker);
  memset(tkcom,0x00,sizeof(tkcom));
  memset(prgb,0xff,sizeof(prgb));
  tekprom();
  tekvrom();
}

/**
 * @brief Restores the system to a previous state by invoking specific restoration functions.
 *
 * This method is responsible for restoring the system to a state corresponding to the given version.
 * It sequentially calls three functions:
 * 1. `tekprom()` - Restores the TEK PROM (Programmable Read-Only Memory) to its previous state.
 * 2. `tekvrom()` - Restores the TEK VROM (Volatile Read-Only Memory) to its previous state.
 * 3. `mira()` - Performs additional system restoration tasks as defined by the MIRA function.
 *
 * @param version The version of the system state to restore. This parameter specifies which
 *                historical state should be restored, allowing for version-specific restoration logic.
 */
static void M90Restore(int version)
{
  tekprom();
  tekvrom();
  mira();
}

/**
 * @brief Initializes the memory handlers and state for the M90 Power functionality.
 *
 * This method sets up the write and read handlers for specific memory ranges to handle
 * various operations such as PRG, CHR, NT, IRQ, and mode writes. It also initializes
 * internal state variables, including multipliers, registers, and memory buffers.
 * Additionally, it configures the Tekker and Tekprom/Tekvrom states based on the `is211`
 * flag. The method ensures that all relevant memory regions and state variables are
 * properly initialized for the M90 Power functionality.
 */
static void M90Power(void)
{
  SetWriteHandler(0x5000,0x5fff,M90TekWrite);
  SetWriteHandler(0x8000,0x8ff0,M90PRGWrite);
  SetWriteHandler(0x9000,0x9fff,M90CHRlowWrite);
  SetWriteHandler(0xA000,0xAfff,M90CHRhiWrite);
  SetWriteHandler(0xB000,0xBfff,M90NTWrite);
  SetWriteHandler(0xC000,0xCfff,M90IRQWrite);
  SetWriteHandler(0xD000,0xD5ff,M90ModeWrite);
  SetWriteHandler(0xE000,0xFfff,M90DummyWrite);


  SetReadHandler(0x5000,0x5fff,M90TekRead);
  SetReadHandler(0x6000,0xffff,CartBR);

  mul[0]=mul[1]=regie=0xFF;

  memset(tkcom,0x00,sizeof(tkcom));
  memset(prgb,0xff,sizeof(prgb));
  memset(chrlow,0xff,sizeof(chrlow));
  memset(chrhigh,0xff,sizeof(chrhigh));
  memset(names,0x00,sizeof(names));

  if(is211)
    tekker=0xC0;
  else
    tekker=0x00;

  tekprom();
  tekvrom();
}


/**
 * @brief Initializes the Mapper 90 for the emulator.
 *
 * This method sets up the initial state and configuration for Mapper 90, which is used
 * in the emulator to handle specific cartridge behaviors. It initializes various flags,
 * hooks, and state restoration functions to ensure proper emulation of the cartridge's
 * behavior. The method also sets up the power function, reset function, and PPU hooks
 * specific to Mapper 90. Additionally, it adds the state registers for the cartridge
 * to the emulator's state management system.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific information
 *             and configuration. This structure is used to set up the reset, power, and
 *             other hooks for the cartridge.
 */
void Mapper90_Init(CartInfo *info)
{
  is211=0;
  is209=0;
  info->Reset=togglie;
  info->Power=M90Power;
  PPU_hook=M90PPU;
  MapIRQHook=CPUWrap;
  GameHBIRQHook2=SLWrap;
  GameStateRestore=M90Restore;
  AddExState(Tek_StateRegs, ~0, 0, 0);
}

/**
 * Initializes the Mapper 209 configuration for the emulated cartridge.
 * This method sets up the necessary hooks and state for the Mapper 209, which is used to emulate
 * specific cartridge behavior in the NES/Famicom system. It configures the following:
 * - Sets `is209` to 1 to indicate Mapper 209 is active and `is211` to 0 to deactivate Mapper 211.
 * - Assigns the `Reset` function pointer in the `CartInfo` structure to `togglie`.
 * - Assigns the `Power` function pointer in the `CartInfo` structure to `M90Power`.
 * - Sets the PPU hook to `M90PPU` for handling PPU-related events.
 * - Sets the IRQ hook to `CPUWrap` for handling CPU interrupts.
 * - Sets the HBlank IRQ hook to `SLWrap` for handling scanline-specific interrupts.
 * - Assigns the `GameStateRestore` function pointer to `M90Restore` for restoring the game state.
 * - Adds the state registers for the Tek cartridge using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific configuration.
 */
void Mapper209_Init(CartInfo *info)
{
  is211=0;
  is209=1;
  info->Reset=togglie;
  info->Power=M90Power;
  PPU_hook=M90PPU;
  MapIRQHook=CPUWrap;
  GameHBIRQHook2=SLWrap;
  GameStateRestore=M90Restore;
  AddExState(Tek_StateRegs, ~0, 0, 0);
}

/**
 * @brief Initializes the Mapper 211 for the emulator.
 *
 * This method sets up the necessary configurations and hooks for Mapper 211,
 * which is used in certain NES ROMs. It initializes various function pointers
 * and state variables to ensure proper emulation of the mapper's behavior.
 * Specifically, it sets the `is211` flag to indicate the use of Mapper 211,
 * assigns the reset and power functions, configures PPU and IRQ hooks, and
 * sets up the game state restoration function. Additionally, it adds the
 * state registers for the mapper to the emulator's state management system.
 *
 * @param info A pointer to the CartInfo structure that holds cartridge-specific
 *             information and function pointers for the emulator.
 */
void Mapper211_Init(CartInfo *info)
{
  is211=1;
  info->Reset=togglie;
  info->Power=M90Power;
  PPU_hook=M90PPU;
  MapIRQHook=CPUWrap;
  GameHBIRQHook2=SLWrap;
  GameStateRestore=M90Restore;
  AddExState(Tek_StateRegs, ~0, 0, 0);
}
