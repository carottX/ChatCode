/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "mapinc.h"

static uint8 *DummyCHR = NULL;
static uint8 datareg;
static void (*Sync)(void);


static SFORMAT StateRegs[] =
{
	{ &datareg, 1, "DREG" },
	{ 0 }
};

//   on    off
//1  0x0F, 0xF0 - Bird Week
//2  0x33, 0x00 - B-Wings
//3  0x11, 0x00 - Mighty Bomb Jack
//4  0x22, 0x20 - Sansuu 1 Nen, Sansuu 2 Nen
//5  0xFF, 0x00 - Sansuu 3 Nen
//6  0x21, 0x13 - Spy vs Spy
//7  0x20, 0x21 - Seicross

static void Sync185(void) {
	// little dirty eh? ;_)
	if ((datareg & 3) && (datareg != 0x13)) // 1, 2, 3, 4, 5, 6
		setchr8(0);
	else
		setchr8r(0x10, 0);
}

/**
 * @brief Synchronizes the CHR (Character ROM) bank based on the value of `datareg`.
 *
 * This method checks the least significant bit (LSB) of the `datareg` variable. 
 * If the LSB is 0, it sets the CHR bank to 0 using `setchr8(0)`. 
 * If the LSB is 1, it sets the CHR bank to a specific range starting at 0x10 using `setchr8r(0x10, 0)`.
 * This is typically used to manage the mapping of CHR memory in NES emulation or similar contexts.
 */
static void Sync181(void) {
	if (!(datareg & 1))                   // 7
		setchr8(0);
	else
		setchr8r(0x10, 0);
}

/**
 * @brief Writes a value to the data register and synchronizes the state.
 *
 * This static method assigns the provided value `V` to the `datareg` variable, 
 * which is assumed to be a data register. After updating the data register, 
 * the method calls the `Sync()` function to ensure that the system state 
 * is synchronized with the new value in the register.
 *
 * @param V The value to be written to the data register.
 */
static DECLFW(MWrite) {
	datareg = V;
	Sync();
}

/**
 * @brief Initializes the memory mapping and handlers for the MPower functionality.
 * 
 * This method performs the following operations:
 * 1. Resets the `datareg` to 0.
 * 2. Calls `Sync()` to synchronize the state.
 * 3. Sets the program ROM (PRG) banks:
 *    - Maps the first 16KB of PRG ROM to the address range 0x8000-0xBFFF.
 *    - Maps the last 16KB of PRG ROM to the address range 0xC000-0xFFFF.
 * 4. Configures the write handler for the address range 0x8000-0xFFFF to use `MWrite`.
 * 5. Configures the read handler for the address range 0x8000-0xFFFF to use `CartBR`.
 */
static void MPower(void) {
	datareg = 0;
	Sync();
	setprg16(0x8000, 0);
	setprg16(0xC000, ~0);
	SetWriteHandler(0x8000, 0xFFFF, MWrite);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Closes and releases resources associated with the DummyCHR.
 * 
 * This method checks if the DummyCHR pointer is not null. If it is not null,
 * it frees the memory allocated for DummyCHR using the FCEU_gfree function.
 * After freeing the memory, it sets the DummyCHR pointer to null to indicate
 * that the resource has been released and is no longer in use.
 */
static void MClose(void) {
	if (DummyCHR)
		FCEU_gfree(DummyCHR);
	DummyCHR = NULL;
}

/**
 * @brief Restores the system to a specific version by synchronizing the state.
 * 
 * This method triggers a synchronization process to restore the system to the 
 * state corresponding to the provided version. The synchronization ensures 
 * that all components are aligned with the desired version.
 * 
 * @param version The version number to which the system should be restored.
 */
static void MRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 185 for the emulated cartridge.
 *
 * This function sets up the necessary configurations for Mapper 185, including
 * synchronization, power management, and state restoration. It also allocates
 * and initializes a dummy CHR (Character ROM) memory block, which is then mapped
 * to the cartridge's CHR space. Additionally, it registers the state variables
 * for save state functionality.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific
 *             information and configuration.
 */
void Mapper185_Init(CartInfo *info) {
	Sync = Sync185;
	info->Power = MPower;
	info->Close = MClose;
	GameStateRestore = MRestore;
	DummyCHR = (uint8*)FCEU_gmalloc(8192);
	int x;
	for (x = 0; x < 8192; x++)
		DummyCHR[x] = 0xff;
	SetupCartCHRMapping(0x10, DummyCHR, 8192, 0);
	AddExState(StateRegs, ~0, 0, 0);
}

/**
 * @brief Initializes the Mapper 181 for the NES cartridge.
 *
 * This function sets up the necessary configurations for Mapper 181, which is used to manage
 * the memory mapping and state handling for an NES cartridge. It performs the following tasks:
 * - Assigns the synchronization function `Sync181` to the `Sync` pointer.
 * - Assigns the power function `MPower` to the `info->Power` pointer.
 * - Assigns the close function `MClose` to the `info->Close` pointer.
 * - Assigns the restore function `MRestore` to the `GameStateRestore` pointer.
 * - Allocates 8192 bytes of memory for the `DummyCHR` array and initializes it with 0xFF values.
 * - Sets up the CHR (Character ROM) mapping for the cartridge using the `DummyCHR` array.
 * - Adds the state registers to the emulator's state management system.
 *
 * @param info Pointer to the `CartInfo` structure that contains cartridge-specific information.
 */
void Mapper181_Init(CartInfo *info) {
	Sync = Sync181;
	info->Power = MPower;
	info->Close = MClose;
	GameStateRestore = MRestore;
	DummyCHR = (uint8*)FCEU_gmalloc(8192);
	int x;
	for (x = 0; x < 8192; x++)
		DummyCHR[x] = 0xff;
	SetupCartCHRMapping(0x10, DummyCHR, 8192, 0);
	AddExState(StateRegs, ~0, 0, 0);
}
