/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2006 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * TXC mappers, originally much complex banksitching
 *
 * P/N           PRG            MAP, UNIF     Name
 * 01-22111-000 (05-00002-010) (132, 22211) - MGC-001 Qi Wang
 * 01-22110-000 (52S         )              - MGC-002 2-in-1 Gun
 * 01-22111-100 (02-00002-010) (173       ) - MGC-008 Mahjong Block
 *                             (079       ) - MGC-012 Poke Block
 * 01-22110-200 (05-00002-010) (036       ) - MGC-014 Strike Wolf
 * 01-22000-400 (05-00002-010) (036       ) - MGC-015 Policeman
 * 01-22017-000 (05-PT017-080) (189       ) - MGC-017 Thunder Warrior
 * 01-11160-000 (04-02310-000) (   , 11160) - MGC-023 6-in-1
 * 01-22026-000 (05-04010-090) (          ) - MGC-026 4-in-1
 * 01-22270-000 (05-00002-010) (132, 22211) - MGC-xxx Creatom
 * 01-22200-400 (------------) (079       ) - ET.03   F-15 City War
 *                             (172       ) -         1991 Du Ma Racing
 *
 */

#include "mapinc.h"

static uint8 reg[4], cmd, is172, is173;
static SFORMAT StateRegs[] =
{
	{ reg, 4, "REGS" },
	{ &cmd, 1, "CMD" },
	{ 0 }
};

/**
 * @brief Synchronizes the PRG and CHR banks based on the current state of the registers.
 *
 * This method updates the Program ROM (PRG) and Character ROM (CHR) banks by setting
 * their respective bank values. The PRG bank is set to the value derived from the
 * second register (reg[2]) shifted right by 2 bits and masked with 1. The CHR bank
 * is set differently depending on the `is172` flag:
 * - If `is172` is true, the CHR bank is determined by a combination of the XOR result
 *   of the command (cmd) and the second register (reg[2]), shifted and masked to
 *   produce the correct bank index. This logic is specific to the 1991 DU MA Racing
 *   game, which may have an unconventional CHR bank sequence.
 * - If `is172` is false, the CHR bank is set directly from the lower 2 bits of the
 *   second register (reg[2] & 3).
 *
 * This method is typically called to ensure that the PRG and CHR banks are correctly
 * mapped according to the current state of the emulator or hardware.
 */
static void Sync(void) {
	setprg32(0x8000, (reg[2] >> 2) & 1);
	if (is172)
		setchr8((((cmd ^ reg[2]) >> 3) & 2) | (((cmd ^ reg[2]) >> 5) & 1));	// 1991 DU MA Racing probably CHR bank sequence is WRONG, so it is possible to
																			// rearrange CHR banks for normal UNIF board and mapper 172 is unneccessary
	else
		setchr8(reg[2] & 3);
}

/**
 * @brief Writes a value to the lower byte of a specified register in the UNL22211 memory mapper.
 *
 * This method is a static function that writes the provided value `V` to the lower byte of the register 
 * specified by the address `A` in the UNL22211 memory mapper. The register index is determined by masking 
 * the address `A` with 3 (i.e., `A & 3`), ensuring that only the first four registers (0-3) are accessible.
 *
 * @param A The address of the register to write to. Only the lower 2 bits of the address are used to 
 *          determine the register index.
 * @param V The value to write to the specified register.
 */
static DECLFW(UNL22211WriteLo) {
//	FCEU_printf("bs %04x %02x\n",A,V);
	reg[A & 3] = V;
}

/**
 * @brief Writes a value to the high byte of the command register for the UNL22211 mapper.
 *
 * This method is responsible for updating the command register with the provided value
 * and then synchronizing the mapper state. The command register is typically used to
 * control the behavior of the mapper, such as bank switching or other memory mapping
 * operations. After updating the command register, the `Sync()` method is called to
 * ensure that the mapper's internal state is consistent with the new command value.
 *
 * @param A The address where the write operation is performed (unused in this method).
 * @param V The value to be written to the command register.
 */
static DECLFW(UNL22211WriteHi) {
	//	FCEU_printf("bs %04x %02x\n",A,V);
	cmd = V;
	Sync();
}

/**
 * @brief Reads the lower byte of the UNL22211 register based on the current state of the registers.
 *
 * This method returns the result of a bitwise XOR operation between `reg[1]` and `reg[2]`, 
 * combined with a bitwise OR operation with a conditional value. If `is173` is true, the 
 * result is ORed with `0x01`; otherwise, it is ORed with `0x40`. This method is used to 
 * simulate the behavior of reading from a specific hardware register in the UNL22211 chip.
 *
 * @return The computed value based on the current state of the registers and the `is173` flag.
 */
static DECLFR(UNL22211ReadLo) {
	return (reg[1] ^ reg[2]) | (is173 ? 0x01 : 0x40);
//	if(reg[3])
//		return reg[2];
//	else
//		return X.DB;
}

/**
 * @brief Initializes the power-on state for the UNL22211 mapper.
 *
 * This method sets up the necessary read and write handlers for the UNL22211 mapper
 * when the system is powered on. It ensures synchronization with the system and
 * configures the following handlers:
 * - A read handler for the address range 0x8000-0xFFFF to handle cartridge bank reads.
 * - A read handler for the address 0x4100 to handle low byte reads.
 * - A write handler for the address range 0x4100-0x4103 to handle low byte writes.
 * - A write handler for the address range 0x8000-0xFFFF to handle high byte writes.
 */
static void UNL22211Power(void) {
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetReadHandler(0x4100, 0x4100, UNL22211ReadLo);
	SetWriteHandler(0x4100, 0x4103, UNL22211WriteLo);
	SetWriteHandler(0x8000, 0xFFFF, UNL22211WriteHi);
}

/**
 * @brief Restores the state of the system to a specific version.
 * 
 * This method ensures that the system's state is synchronized with the desired version 
 * by invoking the `Sync()` method. The `Sync()` method is responsible for aligning the 
 * current state of the system with the state corresponding to the provided version.
 * 
 * @param version The version number to which the system's state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the UNL22211 mapper for the emulator.
 *
 * This method sets up the UNL22211 mapper by initializing its internal state
 * and configuring the necessary callbacks and state restoration mechanisms.
 * Specifically, it:
 * - Resets the internal flags `is172` and `is173` to 0.
 * - Assigns the `UNL22211Power` function to the `Power` callback in the `CartInfo` structure.
 * - Sets the `GameStateRestore` callback to `StateRestore`.
 * - Adds the state registers to the emulator's state management system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific information.
 */
void UNL22211_Init(CartInfo *info) {
	is172 = 0;
	is173 = 0;
	info->Power = UNL22211Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * @brief Initializes the mapper 172 for the given cartridge information.
 *
 * This method sets up the necessary configurations for mapper 172. It sets the
 * `is172` flag to 1 and the `is173` flag to 0, indicating that mapper 172 is active.
 * It assigns the `UNL22211Power` function to the `Power` member of the `CartInfo`
 * structure, which is responsible for handling power-related operations. Additionally,
 * it sets the `GameStateRestore` function to `StateRestore` for restoring the game state.
 * Finally, it adds the state registers to the emulator's state management system using
 * `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge information.
 */
void Mapper172_Init(CartInfo *info) {
	is172 = 1;
	is173 = 0;
	info->Power = UNL22211Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * Initializes the Mapper 173 for the provided cartridge information.
 * 
 * This method sets up the necessary configurations for Mapper 173, which is used in certain NES cartridges.
 * It sets the flags `is172` to 0 and `is173` to 1 to indicate the active mapper type. The `Power` function pointer
 * in the `CartInfo` structure is assigned to `UNL22211Power`, which handles the power-up behavior for this mapper.
 * Additionally, the `GameStateRestore` function is set to `StateRestore` to manage state restoration during emulation.
 * Finally, the method adds the state registers to the emulator's state management system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific information.
 */
void Mapper173_Init(CartInfo *info) {
	is172 = 0;
	is173 = 1;
	info->Power = UNL22211Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

