/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright (C) 2017 FCEUX Team
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Magic Kid GooGoo
 */

#include "mapinc.h"

static uint8 prgr, chrr[4];
static uint8 *WRAM = NULL;

/**
 * @brief Synchronizes the memory mapping for Mapper 190.
 *
 * This method configures the Program ROM (PRG) and Character ROM (CHR) banks
 * for Mapper 190, which is used in certain NES games. It sets up the PRG ROM
 * banks at specific memory addresses and configures the CHR ROM banks for
 * different segments of the pattern tables. The method uses the following
 * functions to achieve this:
 * - `setprg8r`: Sets an 8KB PRG ROM bank with a specific RAM bank at a given address.
 * - `setprg16`: Sets a 16KB PRG ROM bank at a given address.
 * - `setchr2`: Sets a 2KB CHR ROM bank at a given address.
 *
 * The method performs the following operations:
 * 1. Sets an 8KB PRG ROM bank with RAM bank 0x10 at address 0x6000.
 * 2. Sets a 16KB PRG ROM bank at address 0x8000 using the value of `prgr`.
 * 3. Sets a 16KB PRG ROM bank at address 0xC000 to bank 0.
 * 4. Sets 2KB CHR ROM banks at addresses 0x0000, 0x0800, 0x1000, and 0x1800
 *    using the values from the `chrr` array.
 */
static void Mapper190_Sync(void) {
	setprg8r(0x10, 0x6000, 0);

	setprg16(0x8000, prgr);
	setprg16(0xC000, 0);
	setchr2(0x0000, chrr[0]);
	setchr2(0x0800, chrr[1]);
	setchr2(0x1000, chrr[2]);
	setchr2(0x1800, chrr[3]);
}

/**
 * @brief Writes a value to the specified memory address and updates the PRG ROM bank.
 * 
 * This method is a static function that handles the write operation for the Mapper 190.
 * It updates the PRG ROM bank by setting it to the lower 3 bits of the provided value (V).
 * After updating the PRG ROM bank, it calls the Mapper190_Sync() function to synchronize
 * the mapper state with the new PRG ROM bank setting.
 * 
 * @param V The value to be written to the memory address.
 */
static DECLFW(Mapper190_Write89) { prgr = V&7; Mapper190_Sync(); }
/**
 * @brief Writes a value to the PRG register for Mapper 190 and synchronizes the mapper.
 *
 * This method sets the PRG register to a value that is a combination of a fixed bit pattern (8)
 * and the lower 3 bits of the input value `V`. After updating the PRG register, it calls
 * `Mapper190_Sync()` to ensure the mapper's state is synchronized with the new PRG value.
 *
 * @param V The input value whose lower 3 bits are used to update the PRG register.
 */
static DECLFW(Mapper190_WriteCD) { prgr = 8|(V&7); Mapper190_Sync(); }

/**
 * @brief Writes a value to the specified CHR bank for Mapper 190.
 *
 * This method is responsible for updating the CHR (Character ROM) bank based on the provided address and value.
 * The address `A` is used to determine which of the four CHR banks (0-3) to update. The value `V` is masked with 63
 * to ensure it fits within the 6-bit range, and then written to the selected CHR bank. After updating the CHR bank,
 * the method calls `Mapper190_Sync()` to synchronize the mapper's state with the updated CHR bank configuration.
 *
 * @param A The address used to select the CHR bank. Only the lower 2 bits are used to determine the bank (0-3).
 * @param V The value to write to the selected CHR bank. Only the lower 6 bits are used.
 */
static DECLFW(Mapper190_WriteAB) {
	int bank = A&3;
	chrr[bank] = V&63;
	Mapper190_Sync();
}


/**
 * @brief Initializes the memory mapping and configuration for Mapper 190.
 *
 * This method sets up the necessary memory handlers and configurations for Mapper 190,
 * which is used in certain NES ROMs. It performs the following operations:
 * 1. Adds RAM to the emulator's memory space using `FCEU_CheatAddRAM`.
 * 2. Sets the read handler for the memory range `0x6000` to `0xFFFF` to `CartBR`,
 *    allowing the emulator to read from the cartridge ROM.
 * 3. Sets specific write handlers for different memory ranges:
 *    - `0x6000` to `0x7FFF` to `CartBW` for general cartridge writes.
 *    - `0x8000` to `0x9FFF` to `Mapper190_Write89` for handling writes to this range.
 *    - `0xA000` to `0xBFFF` to `Mapper190_WriteAB` for handling writes to this range.
 *    - `0xC000` to `0xDFFF` to `Mapper190_WriteCD` for handling writes to this range.
 * 4. Synchronizes the mapper's state by calling `Mapper190_Sync`.
 * 5. Sets the mirroring mode to vertical (`MI_V`), which is typical for many NES games.
 *
 * This method is typically called during the initialization or reset of the emulator
 * when a ROM using Mapper 190 is loaded.
 */
static void Mapper190_Power(void) {
	FCEU_CheatAddRAM(0x2000 >> 10, 0x6000, WRAM);

	SetReadHandler(0x6000, 0xFFFF, CartBR);

	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetWriteHandler(0x8000, 0x9FFF, Mapper190_Write89);
	SetWriteHandler(0xA000, 0xBFFF, Mapper190_WriteAB);
	SetWriteHandler(0xC000, 0xDFFF, Mapper190_WriteCD);
	Mapper190_Sync();

	setmirror(MI_V);
}

/**
 * @brief Closes and frees the memory associated with the WRAM (Work RAM) used by Mapper 190.
 *
 * This method deallocates the memory allocated for the WRAM by calling `FCEU_gfree` and then
 * sets the WRAM pointer to `NULL` to indicate that the memory has been released. This is typically
 * called when the emulator is shutting down or when the mapper is being unloaded to ensure that
 * all associated resources are properly cleaned up.
 */
static void Mapper190_Close(void) {
	FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of Mapper 190 by synchronizing its internal state.
 *
 * This method is responsible for restoring the state of Mapper 190 by calling
 * the `Mapper190_Sync()` function, which ensures that the mapper's internal
 * state is properly synchronized with the current system state. It is typically
 * used after a state change or reset to ensure consistency.
 *
 * @param unused An integer parameter that is currently unused. This parameter
 *               may be reserved for future use or compatibility purposes.
 */
static void Mapper190_Restore(int) {
	Mapper190_Sync();
}


/**
 * Initializes the Mapper 190 for the provided cartridge information.
 * This function sets up the necessary function pointers for power, close, and restore operations.
 * It also allocates memory for the WRAM (Work RAM) and configures the PRG (Program ROM) mapping.
 * Additionally, it initializes the CHR (Character ROM) and PRG registers to zero and adds their state
 * to the emulator's save state system for persistence across save/load operations.
 *
 * @param info A pointer to the CartInfo structure that holds the cartridge's configuration and state.
 *             This structure is modified to include the mapper-specific function pointers and memory mappings.
 */
void Mapper190_Init(CartInfo *info) {
	info->Power = Mapper190_Power;
	info->Close = Mapper190_Close;
	GameStateRestore = Mapper190_Restore;

	WRAM = (uint8*)FCEU_gmalloc(0x2000);
	SetupCartPRGMapping(0x10, WRAM, 0x2000, 1);

	chrr[0] = chrr[1] = chrr[2] = chrr[3] = prgr = 0;

	AddExState(&prgr, 1, 0, "PRGR");
	AddExState(chrr, 4, 0, "CHRR");
	AddExState(WRAM, 0x2000, 0, "WRAM");
}
