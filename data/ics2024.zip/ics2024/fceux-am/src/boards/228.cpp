/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 mram[4], vreg;
static uint16 areg;

static SFORMAT StateRegs[] =
{
	{ mram, 4, "MRAM" },
	{ &areg, 2, "AREG" },
	{ &vreg, 1, "VREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration for the emulated system.
 *
 * This method calculates and sets the appropriate Program ROM (PRG) and Character ROM (CHR) 
 * memory mappings based on the current values of the `areg` and `vreg` registers. It also 
 * configures the mirroring mode for the system.
 *
 * The method performs the following steps:
 * 1. Determines the current memory page by extracting bits from the `areg` register.
 * 2. Adjusts the page value if it falls within a specific range.
 * 3. Calculates the low and high PRG bank values based on the adjusted page and `areg` bits.
 * 4. Sets the mirroring mode using the `setmirror` function.
 * 5. Configures the PRG memory banks using the `setprg16` function.
 * 6. Sets the CHR memory bank using the `setchr8` function.
 *
 * This method is typically called to update the memory mapping and mirroring configuration 
 * when the `areg` or `vreg` registers change.
 */
static void Sync(void) {
	uint32 prgl, prgh, page = (areg >> 7) & 0x3F;
	if ((page & 0x30) == 0x30)
		page -= 0x10;
	prgl = prgh = (page << 1) + (((areg >> 6) & 1) & ((areg >> 5) & 1));
	prgh += ((areg >> 5) & 1) ^ 1;

	setmirror(((areg >> 13) & 1) ^ 1);
	setprg16(0x8000,prgl);
	setprg16(0xc000,prgh);
	setchr8(((vreg & 0x3) | ((areg & 0xF) << 2)));
}

/**
 * @brief Writes a value to the specified memory location in the MRAM array.
 *
 * This method writes the lower 4 bits of the value `V` to the MRAM array at the index 
 * determined by the lower 2 bits of the address `A`. The address `A` is masked with 0x3 
 * to ensure it is within the range of 0 to 3, and the value `V` is masked with 0x0F to 
 * ensure only the lower 4 bits are written.
 *
 * @param A The address used to determine the index in the MRAM array.
 * @param V The value to be written to the MRAM array.
 */
static DECLFW(M228RamWrite) {
	mram[A & 3] = V & 0x0F;
}

/**
 * @brief Reads a value from the MRAM (Memory RAM) based on the provided address.
 *
 * This method is a static function that takes an address `A`, masks it with `3` (to ensure it is within the range of 0-3),
 * and then uses the resulting index to access and return the corresponding value from the `mram` array.
 *
 * @param A The address to be read from the MRAM. Only the lowest 2 bits of `A` are used (i.e., `A & 3`).
 * @return The value stored in the `mram` array at the index derived from `A & 3`.
 */
static DECLFR(M228RamRead) {
	return mram[A & 3];
}

/**
 * @brief Writes a value to a specific address in the emulated memory or hardware register.
 * 
 * This method is a static function that handles the write operation to a memory address or 
 * hardware register in an emulated system. It assigns the address (`A`) to the `areg` variable 
 * and the value (`V`) to the `vreg` variable. After updating these variables, it calls the 
 * `Sync()` method to ensure that the changes are synchronized with the emulated system.
 * 
 * @param A The address where the value will be written.
 * @param V The value to be written to the specified address.
 */
static DECLFW(M228Write) {
	areg = A;
	vreg = V;
	Sync();
}

/**
 * @brief Resets the M228 module to its initial state.
 * 
 * This method performs a reset operation on the M228 module by:
 * - Setting the `areg` register to the initial value of 0x8000.
 * - Clearing the `vreg` register by setting it to 0.
 * - Clearing the entire MRAM memory by setting all its bytes to 0.
 * - Synchronizing the module state by calling the `Sync()` function.
 * 
 * This is typically used to initialize the module or restore it to a known state.
 */
static void M228Reset(void) {
	areg = 0x8000;
	vreg = 0;
	memset(mram, 0, sizeof(mram));
	Sync();
}

/**
 * @brief Initializes and configures the M228 hardware module.
 *
 * This method performs the following operations:
 * 1. Resets the M228 module by calling `M228Reset()`.
 * 2. Sets up read and write handlers for the memory range `0x5000` to `0x5FFF`:
 *    - `M228RamRead` is assigned as the read handler.
 *    - `M228RamWrite` is assigned as the write handler.
 * 3. Sets up read and write handlers for the memory range `0x8000` to `0xFFFF`:
 *    - `CartBR` is assigned as the read handler.
 *    - `M228Write` is assigned as the write handler.
 *
 * This method is typically called during the power-on initialization sequence
 * to prepare the M228 module for operation.
 */
static void M228Power(void) {
	M228Reset();
	SetReadHandler(0x5000,0x5FFF,M228RamRead);
	SetWriteHandler(0x5000,0x5FFF,M228RamWrite);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M228Write);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system state based on the provided version number.
 * It ensures that all necessary components are synchronized before proceeding with the restoration.
 * 
 * @param version The version number of the state to be restored. This version corresponds to a previously saved state.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 228 configuration for the given cartridge.
 *
 * This method sets up the necessary function pointers and state restoration 
 * mechanisms for Mapper 228. It assigns the reset and power functions to the 
 * provided `CartInfo` structure and registers the state restoration function 
 * for the game state. Additionally, it adds the state registers to the 
 * emulator's state management system.
 *
 * @param info Pointer to the `CartInfo` structure representing the cartridge 
 *             for which Mapper 228 is being initialized.
 */
void Mapper228_Init(CartInfo *info) {
	info->Reset = M228Reset;
	info->Power = M228Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
