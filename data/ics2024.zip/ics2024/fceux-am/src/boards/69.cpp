/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 cmdreg, preg[4], creg[8], mirr;
static uint8 IRQa;
static int32 IRQCount;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &cmdreg, 1, "CMDR" },
	{ preg, 4, "PREG" },
	{ creg, 8, "CREG" },
	{ &mirr, 1, "MIRR" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 4, "IRQC" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the emulated system.
 *
 * This method updates the Programmable Read-Only Memory (PRG) and Character Read-Only Memory (CHR)
 * mappings based on the current values in the `preg` and `creg` arrays. It also sets the mirroring
 * mode for the nametables based on the value in `mirr`.
 *
 * The method performs the following operations:
 * 1. Configures the PRG ROM at address 0x6000 based on the value in `preg[3]`. If the high bits of
 *    `preg[3]` are set, it uses a specific memory region (`0x10`), otherwise, it uses the default
 *    PRG ROM mapping.
 * 2. Updates the PRG ROM mappings for addresses 0x8000, 0xA000, 0xC000, and 0xE000 using the values
 *    in `preg[0]`, `preg[1]`, `preg[2]`, and a fixed value (`~0`) respectively.
 * 3. Configures the CHR ROM for 8 separate 1KB regions using the values in the `creg` array.
 * 4. Sets the nametable mirroring mode based on the value in `mirr`, which can be vertical (`MI_V`),
 *    horizontal (`MI_H`), single-screen A (`MI_0`), or single-screen B (`MI_1`).
 */
static void Sync(void) {
	uint8 i;
	if ((preg[3] & 0xC0) == 0xC0)
		setprg8r(0x10, 0x6000, preg[3] & 0x3F);
	else
		setprg8(0x6000, preg[3] & 0x3F);
	setprg8(0x8000, preg[0]);
	setprg8(0xA000, preg[1]);
	setprg8(0xC000, preg[2]);
	setprg8(0xE000, ~0);
	for (i = 0; i < 8; i++)
		setchr1(i << 10, creg[i]);
	switch (mirr & 3) {
	case 0: setmirror(MI_V); break;
	case 1: setmirror(MI_H); break;
	case 2: setmirror(MI_0); break;
	case 3: setmirror(MI_1); break;
	}
}

/**
 * @brief Writes a value to the WRAM (Work RAM) based on the condition of the preg[3] register.
 *
 * This method checks if the two most significant bits (bits 7 and 6) of the preg[3] register are set (i.e., both are 1).
 * If this condition is met, the method writes the value `V` to the WRAM at the address `A` using the `CartBW` function.
 * Otherwise, the method does nothing.
 *
 * @param A The address in the WRAM where the value should be written.
 * @param V The value to be written to the WRAM.
 */
static DECLFW(M69WRAMWrite) {
	if ((preg[3] & 0xC0) == 0xC0)
		CartBW(A, V);
}

/**
 * @brief Reads data from the WRAM (Work RAM) based on the value of preg[3].
 * 
 * This method checks the value of the third element in the preg array (preg[3]). 
 * If the most significant two bits of preg[3] are set to '01' (i.e., 0x40), the method 
 * returns the value of the DB register (X.DB). Otherwise, it reads and returns the 
 * value from the cartridge bus using the address A via the CartBR function.
 * 
 * @return The value read from WRAM or the cartridge bus, depending on the condition.
 */
static DECLFR(M69WRAMRead) {
	if ((preg[3] & 0xC0) == 0x40)
		return X.DB;
	else
		return CartBR(A);
}

/**
 * @brief Writes a value to the command register (cmdreg) based on the provided input.
 *
 * This method takes an input value `V`, masks it with `0xF` to ensure only the lower 4 bits are used,
 * and assigns the result to the command register `cmdreg`. This is typically used to set or update
 * the command register with a specific 4-bit value.
 *
 * @param V The input value to be written to the command register. Only the lower 4 bits of this value are used.
 */
static DECLFW(M69Write0) {
	cmdreg = V & 0xF;
}

/**
 * @brief Handles writing to the M69 mapper's registers based on the provided command register (`cmdreg`).
 * 
 * This method is responsible for updating the internal state of the M69 mapper by writing the value `V`
 * to the appropriate register or control field based on the value of `cmdreg`. The method performs the
 * following actions depending on the value of `cmdreg`:
 * 
 * - `0x0` to `0x7`: Writes `V` to the corresponding `creg` register and calls `Sync()` to synchronize the state.
 * - `0x8`: Writes `V` to `preg[3]` and calls `Sync()`.
 * - `0x9` to `0xB`: Writes `V` to `preg[0]`, `preg[1]`, or `preg[2]` respectively and calls `Sync()`.
 * - `0xC`: Updates the mirroring mode (`mirr`) based on the lower 2 bits of `V` and calls `Sync()`.
 * - `0xD`: Updates the IRQ enable flag (`IRQa`) and ends any pending external IRQ using `X6502_IRQEnd(FCEU_IQEXT)`.
 * - `0xE`: Updates the lower byte of the IRQ counter (`IRQCount`) with `V`.
 * - `0xF`: Updates the upper byte of the IRQ counter (`IRQCount`) with `V` shifted left by 8 bits.
 * 
 * @param cmdreg The command register that determines which internal register or control field to update.
 * @param V The value to write to the selected register or control field.
 */
static DECLFW(M69Write1) {
	switch (cmdreg) {
	case 0x0: creg[0] = V; Sync(); break;
	case 0x1: creg[1] = V; Sync(); break;
	case 0x2: creg[2] = V; Sync(); break;
	case 0x3: creg[3] = V; Sync(); break;
	case 0x4: creg[4] = V; Sync(); break;
	case 0x5: creg[5] = V; Sync(); break;
	case 0x6: creg[6] = V; Sync(); break;
	case 0x7: creg[7] = V; Sync(); break;
	case 0x8: preg[3] = V; Sync(); break;
	case 0x9: preg[0] = V; Sync(); break;
	case 0xA: preg[1] = V; Sync(); break;
	case 0xB: preg[2] = V; Sync(); break;
	case 0xC: mirr = V & 3; Sync();break;
	case 0xD: IRQa = V; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0xE: IRQCount &= 0xFF00; IRQCount |= V; break;
	case 0xF: IRQCount &= 0x00FF; IRQCount |= V << 8; break;
	}
}

// SUNSOFT-5/FME-7 Sound

static void AYSound(int Count);
static void AYSoundHQ(void);
static void DoAYSQ(int x);
static void DoAYSQHQ(int x);

static uint8 sndcmd, sreg[14];
static int32 vcount[3];
static int32 dcount[3];
static int CAYBC[3];

static SFORMAT SStateRegs[] =
{
	{ &sndcmd, 1, "SCMD" },
	{ sreg, 14, "SREG" },
	{ 0 }
};

/**
 * @brief Writes a value to the sound command register.
 *
 * This method updates the sound command register (`sndcmd`) with the result of
 * the modulo operation of the input value `V` with 14. The purpose of this
 * operation is to ensure that the sound command remains within a specific range,
 * likely corresponding to the number of available sound commands or channels.
 *
 * @param V The input value to be processed and written to the sound command register.
 */
static DECLFW(M69SWrite0) {
	sndcmd = V % 14;
}

/**
 * @brief Handles the writing operation for sound command processing in the M69S module.
 *
 * This method processes sound commands based on the provided `sndcmd` value and updates the sound
 * output accordingly. It supports both standard and high-quality sound processing depending on the
 * configured sound quality settings (`FSettings.soundq`). The method also updates the internal sound
 * register (`sreg`) with the provided value `V`.
 *
 * The method performs the following operations:
 * - Sets the `Fill` and `HiFill` properties of `GameExpSound` to `AYSound` and `AYSoundHQ` respectively.
 * - Checks if the sound rate (`FSettings.SndRate`) is non-zero before processing the sound command.
 * - Processes the sound command (`sndcmd`) using either `DoAYSQHQ` (for high-quality sound) or `DoAYSQ`
 *   (for standard sound) based on the configured sound quality.
 * - For certain commands (e.g., `sndcmd == 7`), it processes multiple sound channels in a loop.
 * - Updates the internal sound register `sreg[sndcmd]` with the provided value `V`.
 *
 * @param sndcmd The sound command to process. Determines the specific sound operation to perform.
 * @param V The value to write to the sound register `sreg[sndcmd]`.
 */
static DECLFW(M69SWrite1) {
	int x;
	GameExpSound.Fill = AYSound;
	GameExpSound.HiFill = AYSoundHQ;
	if (FSettings.SndRate)
		switch (sndcmd) {
		case 0:
		case 1:
		case 8: if (FSettings.soundq >= 1) DoAYSQHQ(0); else DoAYSQ(0); break;
		case 2:
		case 3:
		case 9: if (FSettings.soundq >= 1) DoAYSQHQ(1); else DoAYSQ(1); break;
		case 4:
		case 5:
		case 10: if (FSettings.soundq >= 1) DoAYSQHQ(2); else DoAYSQ(2); break;
		case 7:
			for (x = 0; x < 2; x++)
				if (FSettings.soundq >= 1) DoAYSQHQ(x); else DoAYSQ(x);
			break;
		}
	sreg[sndcmd] = V;
}

/**
 * @brief Processes audio synthesis for a specific channel in the AYSQ (Audio Synthesis Queue) system.
 *
 * This method generates audio samples for a given channel `x` based on the current sound configuration.
 * It calculates the frequency and amplitude of the audio signal using values from the `sreg` array.
 * The method then updates the audio buffer (`Wave`) with the synthesized samples, taking into account
 * the current time step (`SOUNDTS`) and the frequency modulation.
 *
 * The method performs the following steps:
 * 1. Calculates the frequency (`freq`) and amplitude (`amp`) of the audio signal.
 * 2. Adjusts the amplitude by adding half of its value to itself for a more dynamic range.
 * 3. Determines the start and end positions in the audio buffer for the current time step.
 * 4. If the amplitude is non-zero and the channel is enabled (based on `sreg[0x7]`), it synthesizes
 *    the audio samples by iterating through the buffer and applying the frequency modulation.
 * 5. Updates the `dcount` and `vcount` variables to track the state of the audio synthesis.
 *
 * @param x The channel index for which the audio synthesis is performed.
 *
 * @note This method is conditionally compiled based on the `SOUND_CONFIG` macro. It will only be
 *       included in the build if `SOUND_CONFIG` is not set to `SOUND_NONE`.
 */
static void DoAYSQ(int x) {
#if SOUND_CONFIG != SOUND_NONE
	int32 freq = ((sreg[x << 1] | ((sreg[(x << 1) + 1] & 15) << 8)) + 1) << (4 + 17);
	int32 amp = (sreg[0x8 + x] & 15) << 2;
	int32 start, end;
	int V;

	amp += amp >> 1;

	start = CAYBC[x];
	end = (SOUNDTS << 16) / soundtsinc;
	if (end <= start) return;
	CAYBC[x] = end;

	if (amp && !(sreg[0x7] & (1 << x)))
		for (V = start; V < end; V++) {
			if (dcount[x])
				Wave[V >> 4] += amp;
			vcount[x] -= nesincsize;
			while (vcount[x] <= 0) {
				dcount[x] ^= 1;
				vcount[x] += freq;
			}
		}
#endif
}

/**
 * @brief Processes the audio signal for a specific channel in the AYSQHQ sound system.
 *
 * This method calculates the frequency and amplitude of the audio signal for the given channel `x`.
 * The frequency is derived from the sound register values, and the amplitude is adjusted based on
 * the sound register configuration. If the channel is enabled (as indicated by the sound register),
 * the method updates the waveform buffer (`WaveHi`) by adding the calculated amplitude to the buffer
 * at the appropriate positions. The method also manages the duty cycle and frequency counters to
 * ensure the waveform is generated correctly.
 *
 * @param x The channel index for which the audio signal is processed.
 *
 * @note This method is only active if `SOUND_CONFIG` is not set to `SOUND_NONE`. If `SOUND_CONFIG`
 * is `SOUND_NONE`, the method does nothing.
 */
static void DoAYSQHQ(int x) {
#if SOUND_CONFIG != SOUND_NONE
	uint32 V;
	int32 freq = ((sreg[x << 1] | ((sreg[(x << 1) + 1] & 15) << 8)) + 1) << 4;
	int32 amp = (sreg[0x8 + x] & 15) << 6;

	amp += amp >> 1;

	if (!(sreg[0x7] & (1 << x))) {
		for (V = CAYBC[x]; V < SOUNDTS; V++) {
			if (dcount[x])
				WaveHi[V] += amp;
			vcount[x]--;
			if (vcount[x] <= 0) {
				dcount[x] ^= 1;
				vcount[x] = freq;
			}
		}
	}
	CAYBC[x] = SOUNDTS;
#endif
}

/**
 * @brief Generates sound using the AY-3-8910 sound chip by processing three sound channels.
 * 
 * This method initializes sound generation for the AY-3-8910 chip by calling `DoAYSQ` for each
 * of the three sound channels (0, 1, and 2). After initializing the channels, it sets the 
 * `CAYBC` buffer for each channel to the specified `Count` value, which likely represents
 * a control parameter for the sound generation (e.g., volume, frequency, or duration).
 * 
 * @param Count The value to be assigned to the `CAYBC` buffer for each sound channel.
 */
static void AYSound(int Count) {
	int x;
	DoAYSQ(0);
	DoAYSQ(1);
	DoAYSQ(2);
	for (x = 0; x < 3; x++)
		CAYBC[x] = Count;
}

/**
 * @brief Executes high-quality sound processing for all three AY sound channels.
 *
 * This method sequentially invokes the `DoAYSQHQ` function for each of the three AY sound channels
 * (channel 0, channel 1, and channel 2). It is responsible for processing and enhancing the sound
 * quality for each channel individually, ensuring high-quality audio output.
 */
static void AYSoundHQ(void) {
	DoAYSQHQ(0);
	DoAYSQHQ(1);
	DoAYSQHQ(2);
}

/**
 * @brief Synchronizes the timestamp across the CAYBC array.
 *
 * This static method assigns the provided timestamp `ts` to each element
 * in the global array `CAYBC`. The array `CAYBC` is assumed to have at least
 * 3 elements, as the method iterates over the first 3 indices (0, 1, and 2)
 * and sets their values to `ts`.
 *
 * @param ts The timestamp value to be assigned to each element in the CAYBC array.
 */
static void AYHiSync(int32 ts) {
	int x;

	for (x = 0; x < 3; x++)
		CAYBC[x] = ts;
}

/**
 * @brief Initializes the Mapper 69 ESI (External Sound Interface) for the game.
 *
 * This method sets up the necessary configurations for the Mapper 69 ESI, which is responsible
 * for managing external sound processing in the game. It assigns the appropriate function pointers
 * for sound handling, initializes various counters and buffers to zero, and adds the state registers
 * to the emulator's state management system.
 *
 * Specifically, the method:
 * - Assigns the `Mapper69_ESI` function to `GameExpSound.RChange` to handle sound changes.
 * - Assigns `AYHiSync` to `GameExpSound.HiSync` for high synchronization of sound processing.
 * - Initializes the `dcount`, `vcount`, and `CAYBC` arrays to zero using `memset`.
 * - Adds the state registers (`SStateRegs`) to the emulator's state management system using `AddExState`.
 */
void Mapper69_ESI(void) {
	GameExpSound.RChange = Mapper69_ESI;
	GameExpSound.HiSync = AYHiSync;
	memset(dcount, 0, sizeof(dcount));
	memset(vcount, 0, sizeof(vcount));
	memset(CAYBC, 0, sizeof(CAYBC));
	AddExState(&SStateRegs, ~0, 0, 0);
}

// SUNSOFT-5/FME-7 Sound

static void M69Power(void) {
	cmdreg = sndcmd = 0;
	IRQCount = 0xFFFF;
	IRQa = 0;
	Sync();
	SetReadHandler(0x6000, 0x7FFF, M69WRAMRead);
	SetWriteHandler(0x6000, 0x7FFF, M69WRAMWrite);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0x9FFF, M69Write0);
	SetWriteHandler(0xA000, 0xBFFF, M69Write1);
	SetWriteHandler(0xC000, 0xDFFF, M69SWrite0);
	SetWriteHandler(0xE000, 0xFFFF, M69SWrite1);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and frees the WRAM (Work RAM) memory.
 *
 * This method checks if the WRAM pointer is not null. If it is not null,
 * it frees the memory allocated for WRAM using the FCEU_gfree function.
 * After freeing the memory, the WRAM pointer is set to NULL to indicate
 * that the memory has been released and is no longer in use.
 */
static void M69Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Handles the M69 IRQ (Interrupt Request) hook.
 *
 * This method is responsible for managing the IRQ countdown and triggering an IRQ
 * when the countdown reaches zero. It decrements the IRQ count by the specified value `a`.
 * If the IRQ count falls to or below zero, it triggers an IRQ by calling `X6502_IRQBegin`
 * with the `FCEU_IQEXT` parameter, resets the IRQ state (`IRQa` to 0), and sets the IRQ count
 * to the maximum value (0xFFFF).
 *
 * @param a The value by which the IRQ count is decremented.
 */
static void M69IRQHook(int a) {
	if (IRQa) {
		IRQCount -= a;
		if (IRQCount <= 0) {
			X6502_IRQBegin(FCEU_IQEXT); IRQa = 0; IRQCount = 0xFFFF;
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that the system is synchronized before proceeding with the restoration process.
 * 
 * @param version The version number of the state to be restored. This version corresponds 
 *                to a previously saved state that needs to be loaded back into the system.
 * 
 * @note The method internally calls the `Sync()` function to ensure that all pending operations 
 *       are completed before the state restoration begins.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 69 (Sunsoft FME-7) for the given cartridge information.
 * This method sets up the necessary function pointers for power, close, and IRQ handling,
 * configures the WRAM (Work RAM) size based on the cartridge's iNES 2.0 header information,
 * and allocates memory for WRAM. It also sets up PRG (Program ROM) mapping and adds WRAM
 * to the save state system. If the cartridge has battery-backed RAM, it configures the
 * save game data. Finally, it initializes the mapper's extended state information (ESI)
 * and adds the state registers to the save state system.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void Mapper69_Init(CartInfo *info) {
	info->Power = M69Power;
	info->Close = M69Close;
	MapIRQHook = M69IRQHook;
	if(info->ines2)
		WRAMSIZE = info->wram_size + info->battery_wram_size;
	else
		WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	GameStateRestore = StateRestore;
	Mapper69_ESI();
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * @brief Initializes the NSFAY mapper.
 *
 * This method sets up the NSFAY mapper by initializing the sound command (`sndcmd`) to 0,
 * configuring write handlers for specific memory ranges, and setting up the mapper's ESI (External Sound Interface).
 * Specifically:
 * - `sndcmd` is reset to 0 to clear any previous sound command state.
 * - A write handler `M69SWrite0` is assigned to the memory range 0xC000 to 0xDFFF.
 * - A write handler `M69SWrite1` is assigned to the memory range 0xE000 to 0xFFFF.
 * - The `Mapper69_ESI` function is called to initialize the External Sound Interface for the mapper.
 */
void NSFAY_Init(void) {
	sndcmd = 0;
	SetWriteHandler(0xC000, 0xDFFF, M69SWrite0);
	SetWriteHandler(0xE000, 0xFFFF, M69SWrite1);
	Mapper69_ESI();
}
