/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg;

static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the NES emulator.
 *
 * This method updates the CHR (Character) and PRG (Program) ROM banks, as well as the mirroring mode
 * based on the current value of the `reg` register. It performs the following operations:
 * 1. Sets the CHR bank to 0 using `setchr8(0)`.
 * 2. Maps the PRG ROM bank 0x10 to the memory address 0x6000 using `setprg8r(0x10, 0x6000, 0)`.
 * 3. Maps the PRG ROM bank specified by the lower 5 bits of `reg` to the memory address 0x8000 using `setprg32(0x8000, reg & 0x1f)`.
 * 4. Sets the mirroring mode based on the 6th bit of `reg` using `setmirror(((reg & 0x20) >> 5) ^ 1)`.
 */
static void Sync(void) {
	setchr8(0);
	setprg8r(0x10, 0x6000, 0);
	setprg32(0x8000, reg & 0x1f);
	setmirror(((reg & 0x20) >> 5) ^ 1);
}

/**
 * @brief Writes a value to the M177 register and synchronizes the state.
 *
 * This static method is responsible for updating the M177 register with the provided value 
 * and then calling the `Sync()` function to ensure that the system state is synchronized 
 * with the new register value. The method is typically used in scenarios where the M177 
 * register needs to be updated and the system needs to immediately reflect this change.
 *
 * @param V The value to be written to the M177 register.
 */
static DECLFW(M177Write) {
	reg = V;
	Sync();
}

/**
 * @brief Initializes the power state for the M177 mapper.
 *
 * This method sets up the memory mapping and handlers for the M177 mapper. It performs the following steps:
 * 1. Resets the internal register (`reg`) to 0.
 * 2. Synchronizes the state of the emulator using `Sync()`.
 * 3. Sets the read and write handlers for the memory range 0x6000-0x7FFF to `CartBR` and `CartBW`, respectively.
 * 4. Sets the read handler for the memory range 0x8000-0xFFFF to `CartBR` and the write handler to `M177Write`.
 * 5. Adds WRAM (Work RAM) to the cheat system using `FCEU_CheatAddRAM`, with the size of WRAM specified by `WRAMSIZE`.
 *
 * This method is typically called during the initialization or reset of the emulator to configure the M177 mapper.
 */
static void M177Power(void) {
	reg = 0;
	Sync();
	SetReadHandler(0x6000, 0x7fff, CartBR);
	SetWriteHandler(0x6000, 0x7fff, CartBW);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M177Write);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and frees the WRAM (Work RAM) memory if it is allocated.
 *
 * This method checks if the WRAM pointer is not null. If WRAM is allocated,
 * it frees the memory using the FCEU_gfree function and then sets the WRAM
 * pointer to null to indicate that the memory has been released.
 */
static void M177Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the system state based on the provided version number.
 * It ensures synchronization of the system by calling the `Sync()` method, which guarantees that
 * all components are properly aligned and updated to the desired state.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 177 for the given cartridge information.
 * This function sets up the necessary callbacks and configurations for the mapper,
 * including power and close handlers, game state restoration, and WRAM allocation.
 * 
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 *             This structure is used to configure the mapper and handle save game data.
 * 
 * The function performs the following operations:
 * 1. Assigns the power and close handlers to the respective functions (M177Power and M177Close).
 * 2. Sets up the game state restoration function (StateRestore).
 * 3. Allocates 8192 bytes of WRAM (Work RAM) for the cartridge.
 * 4. Configures the PRG mapping for the allocated WRAM.
 * 5. Adds the WRAM to the external state for save/restore operations.
 * 6. If the cartridge has a battery backup, it configures the save game data in the CartInfo structure.
 * 7. Adds the state registers to the external state for save/restore operations.
 */
void Mapper177_Init(CartInfo *info) {
	info->Power = M177Power;
	info->Close = M177Close;
	GameStateRestore = StateRestore;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}

	AddExState(&StateRegs, ~0, 0, 0);
}
