/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2011 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the NES emulator.
 *
 * This method configures the Program ROM (PRG) and Character ROM (CHR) memory banks
 * for the NES emulator. It performs the following operations:
 * - Maps the first 16KB PRG ROM bank to the memory address range 0x8000-0xBFFF.
 * - Maps the last 16KB PRG ROM bank to the memory address range 0xC000-0xFFFF.
 * - Maps the first 8KB CHR ROM bank to the CHR memory space.
 * This ensures that the emulator's memory is correctly configured for the current
 * state of the game or application being emulated.
 */
static void Sync(void) {
	setprg16(0x8000, 0);
	setprg16(0xc000, ~0);
	setchr8(0);
}

/**
 * @brief Writes a value to the M170 protection register.
 *
 * This method processes the input value `V` by shifting it left by one bit and
 * masking it with 0x80. The result is stored in the `reg` variable, which represents
 * the M170 protection register. The operation effectively isolates the 7th bit of `V`
 * and sets it as the most significant bit in `reg`.
 *
 * @param V The input value to be written to the protection register.
 */
static DECLFW(M170ProtW) {
	reg = V << 1 & 0x80;
}

/**
 * @brief Reads the value from the M170 protection register.
 *
 * This method combines the value of the `reg` register with the lower 7 bits of the `X.DB` register.
 * The result is a bitwise OR operation between `reg` and `(X.DB & 0x7F)`, effectively preserving the
 * upper bit of `reg` and merging it with the lower 7 bits of `X.DB`.
 *
 * @return The combined value of `reg` and the lower 7 bits of `X.DB`.
 */
static DECLFR(M170ProtR) {
	return reg | (X.DB & 0x7F);
}

/**
 * @brief Initializes the power-up state for the M170 mapper.
 *
 * This method sets up the necessary read and write handlers for the M170 mapper.
 * It first synchronizes the state by calling `Sync()`. Then, it configures the
 * write handlers for specific memory addresses (0x6502 and 0x7000) to use the
 * `M170ProtW` function. Additionally, it sets up read handlers for memory
 * addresses 0x7001, 0x7777, and the range 0x8000-0xFFFF to use the `M170ProtR`
 * and `CartBR` functions, respectively. This ensures that the correct memory
 * access behavior is established for the M170 mapper during power-up.
 */
static void M170Power(void) {
	Sync();
	SetWriteHandler(0x6502, 0x6502, M170ProtW);
	SetWriteHandler(0x7000, 0x7000, M170ProtW);
	SetReadHandler(0x7001, 0x7001, M170ProtR);
	SetReadHandler(0x7777, 0x7777, M170ProtR);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specified version.
 * It ensures that all necessary synchronization operations are performed before
 * proceeding with the state restoration. The synchronization is handled by the
 * `Sync()` method, which is called internally.
 *
 * @param version The version number to which the system's state should be restored.
 *                This parameter is used to identify the specific state snapshot
 *                that needs to be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 170 for the NES emulator.
 *
 * This function sets up the necessary configurations for Mapper 170 by assigning
 * the power function, restoring the game state, and adding the state registers
 * to the emulator's state management system.
 *
 * @param info A pointer to the CartInfo structure that holds cartridge-specific
 *             information, including the power function and state registers.
 */
void Mapper170_Init(CartInfo *info) {
	info->Power = M170Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
