/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * FDS Conversion
 *
 */

#include "mapinc.h"

static uint8 reg;
static uint32 IRQCount, IRQa;

static SFORMAT StateRegs[] =
{
	{ &IRQCount, 4, "IRQC" },
	{ &IRQa, 4, "IRQA" },
	{ &reg, 1, "REG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the emulator by configuring the PRG and CHR banks.
 *
 * This method sets up the Program ROM (PRG) and Character ROM (CHR) banks for the emulator.
 * It configures the PRG banks at specific memory addresses:
 * - 0x6000: Sets PRG bank to 0xF.
 * - 0x8000: Sets PRG bank to 0x8.
 * - 0xA000: Sets PRG bank to 0x9.
 * - 0xC000: Sets PRG bank to the value stored in the `reg` variable.
 * - 0xE000: Sets PRG bank to 0xB.
 * Additionally, it sets the CHR bank to 0.
 * This method is typically used to ensure the correct memory mapping is in place during emulation.
 */
static void Sync(void) {
	setprg8(0x6000, 0xF);
	setprg8(0x8000, 0x8);
	setprg8(0xa000, 0x9);
	setprg8(0xc000, reg);
	setprg8(0xe000, 0xB);
	setchr8(0);
}

/**
 * @brief Handles write operations for the M50 mapper.
 *
 * This method processes write operations to specific memory addresses associated with the M50 mapper.
 * It performs different actions based on the address being written to:
 * - If the address is 0x4120, it updates the IRQ enable flag (IRQa) based on the least significant bit of the value (V).
 *   If IRQa is cleared (set to 0), it resets the IRQ counter (IRQCount) and ends any pending IRQ.
 * - If the address is 0x4020, it updates the internal register (reg) based on the value (V) and synchronizes the mapper state.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the address.
 */
static DECLFW(M50Write) {
	switch (A & 0xD160) {
	case 0x4120: IRQa = V & 1; if (!IRQa) IRQCount = 0; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0x4020: reg = ((V & 1) << 2) | ((V & 2) >> 1) | ((V & 4) >> 1) | (V & 8); Sync(); break;
	}
}

/**
 * @brief Configures the power state and memory mapping for the M50 hardware.
 *
 * This method initializes the M50 hardware by performing the following steps:
 * 1. Resets the internal register to 0.
 * 2. Synchronizes the hardware state using the `Sync()` function.
 * 3. Sets the read handler for the memory range 0x6000 to 0xFFFF to use the `CartBR` function.
 * 4. Sets the write handler for the memory range 0x4020 to 0x5FFF to use the `M50Write` function.
 *
 * This configuration is typically used during power-up or reset scenarios to ensure
 * the hardware is in a known state and ready for operation.
 */
static void M50Power(void) {
	reg = 0;
	Sync();
	SetReadHandler(0x6000, 0xffff, CartBR);
	SetWriteHandler(0x4020, 0x5fff, M50Write);
}

/**
 * @brief Resets the M50 module to its initial state.
 *
 * This method performs a reset operation on the M50 module, restoring it to its default
 * configuration and clearing any internal state or data. It is typically used to ensure
 * the module is in a known state before starting a new operation or after an error has
 * occurred. The reset process may involve reinitializing hardware registers, clearing
 * buffers, and resetting any internal flags or counters.
 *
 * @note This method is static and does not require an instance of the class to be called.
 * It should be used with caution as it may interrupt ongoing operations or discard
 * unsaved data.
 */
static void M50Reset(void) {
}

/**
 * @brief Handles the M50 IRQ (Interrupt Request) hook logic.
 *
 * This method is responsible for managing the IRQ count and triggering an IRQ when the count reaches a threshold.
 * If the IRQ is active (IRQa is true), the method increments the IRQCount by the specified amount `a`.
 * When the IRQCount exceeds or equals 4096, the IRQ is deactivated (IRQa is set to 0), and an external IRQ is triggered
 * using `X6502_IRQBegin` with the `FCEU_IQEXT` parameter.
 *
 * @param a The amount by which the IRQCount is incremented.
 */
static void M50IRQHook(int a) {
	if (IRQa) {
		if (IRQCount < 4096)
			IRQCount += a;
		else{
			IRQa = 0;
			X6502_IRQBegin(FCEU_IQEXT);
		}
	}
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specific version
 * by synchronizing the current state with the desired version. It internally calls
 * the `Sync()` method to ensure that all components are aligned with the specified
 * version.
 *
 * @param version The version number to which the system's state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 50 configuration for the given cartridge information.
 * This method sets up the necessary function pointers and state management
 * for Mapper 50, which is used in certain NES games. Specifically, it assigns
 * the reset, power, and IRQ hook functions to the provided `CartInfo` structure.
 * Additionally, it sets up the game state restoration function and adds the
 * state registers to the emulator's state management system.
 *
 * @param info Pointer to the `CartInfo` structure representing the cartridge
 *             information. This structure will be populated with the appropriate
 *             function pointers and state management configurations for Mapper 50.
 */
void Mapper50_Init(CartInfo *info) {
	info->Reset = M50Reset;
	info->Power = M50Power;
	MapIRQHook = M50IRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
