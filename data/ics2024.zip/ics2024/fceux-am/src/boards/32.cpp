/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg[2], creg[8], mirr;

static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ preg, 4, "PREG" },
	{ creg, 8, "CREG" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the emulated system.
 * 
 * This method performs the following operations:
 * 1. Calculates a swap value based on the `mirr` variable to determine the memory mapping offset.
 * 2. Sets the mirroring mode using the `setmirror` function, toggling the least significant bit of `mirr`.
 * 3. Configures the Program ROM (PRG) banks using the `setprg8r` and `setprg8` functions:
 *    - Maps the first PRG bank to address 0x6000 with a specific flag (0x10).
 *    - Maps the second and third PRG banks to addresses 0x8000 and 0xA000, respectively, applying the swap offset.
 *    - Maps the fourth and fifth PRG banks to addresses 0xC000 and 0xE000, respectively, with fixed values.
 * 4. Configures the Character ROM (CHR) banks using the `setchr1` function, mapping each of the 8 CHR banks to their respective addresses.
 * 
 * This method ensures that the memory mapping and mirroring are updated according to the current state of the emulated system.
 */
static void Sync(void) {
	uint16 swap = ((mirr & 2) << 13);
	setmirror((mirr & 1) ^ 1);
	setprg8r(0x10, 0x6000, 0);
	setprg8(0x8000 ^ swap, preg[0]);
	setprg8(0xA000, preg[1]);
	setprg8(0xC000 ^ swap, ~1);
	setprg8(0xE000, ~0);
	uint8 i;
	for (i = 0; i < 8; i++)
		setchr1(i << 10, creg[i]);
}

/**
 * @brief Writes a value to the first register (preg[0]) and synchronizes the state.
 *
 * This static method is used to update the value of the first register (preg[0]) 
 * with the provided value `V`. After updating the register, it calls the `Sync()` 
 * method to ensure that the system state is synchronized with the new register value.
 *
 * @param V The value to be written to the first register.
 * @note This method is typically used in low-level hardware or emulator code where 
 *       direct register manipulation is required.
 */
static DECLFW(M32Write0) {
	preg[0] = V;
	Sync();
}

/**
 * @brief Writes a value to the mirror register and synchronizes the state.
 *
 * This static method updates the mirror register (`mirr`) with the provided value (`V`).
 * After updating the mirror register, it calls the `Sync()` method to ensure that the
 * system state is synchronized with the new value. This method is typically used in
 * memory-mapped I/O operations where changes to the mirror register need to be
 * immediately reflected in the system.
 *
 * @param V The value to be written to the mirror register.
 */
static DECLFW(M32Write1) {
	mirr = V;
	Sync();
}

/**
 * @brief Writes a value to the second register and synchronizes the state.
 *
 * This method updates the value of the second register (`preg[1]`) with the provided value `V`.
 * After updating the register, it calls the `Sync()` method to ensure that the system state is
 * synchronized with the new register value. This is typically used in scenarios where changes
 * to the register need to be immediately reflected in the system's behavior or state.
 *
 * @param V The value to be written to the second register.
 */
static DECLFW(M32Write2) {
	preg[1] = V;
	Sync();
}

/**
 * @brief Writes a value to a specific register and synchronizes the state.
 *
 * This method writes the value `V` to the register indexed by the lower 3 bits of `A`
 * in the `creg` array. After updating the register, it calls the `Sync()` method to
 * ensure that the system state is synchronized with the new register value.
 *
 * @param A The address used to determine the register index. Only the lower 3 bits are used.
 * @param V The value to be written to the register.
 */
static DECLFW(M32Write3) {
	creg[A & 7] = V;
	Sync();
}

/**
 * @brief Initializes the memory mapping and handlers for the M32 power state.
 *
 * This method sets up the read and write handlers for specific memory ranges to
 * manage cartridge behavior. It first synchronizes the system state using `Sync()`,
 * then assigns the `CartBR` read handler to the memory ranges 0x6000-0x7FFF and
 * 0x8000-0xFFFF. Write handlers are assigned as follows:
 * - `CartBW` for the range 0x6000-0x7FFF.
 * - `M32Write0` for the range 0x8000-0x8FFF.
 * - `M32Write1` for the range 0x9000-0x9FFF.
 * - `M32Write2` for the range 0xA000-0xAFFF.
 * - `M32Write3` for the range 0xB000-0xBFFF.
 * Finally, it adds RAM for cheat functionality using `FCEU_CheatAddRAM`.
 */
static void M32Power(void) {
	Sync();
	SetReadHandler(0x6000,0x7fff,CartBR);
	SetWriteHandler(0x6000,0x7fff,CartBW);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0x8FFF, M32Write0);
	SetWriteHandler(0x9000, 0x9FFF, M32Write1);
	SetWriteHandler(0xA000, 0xAFFF, M32Write2);
	SetWriteHandler(0xB000, 0xBFFF, M32Write3);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) used by the emulator.
 * 
 * This method checks if the WRAM pointer is not null. If WRAM is allocated, 
 * it frees the memory associated with WRAM using the FCEU_gfree function. 
 * After deallocating the memory, the WRAM pointer is set to NULL to indicate 
 * that no memory is currently allocated for WRAM.
 * 
 * @note This method is static and should be called when the emulator is shutting down 
 * or when WRAM needs to be explicitly deallocated.
 */
static void M32Close(void)
{
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specific version 
 * by first synchronizing the current state with the desired version. The synchronization 
 * ensures that all necessary data and configurations are aligned with the target version.
 *
 * @param version The version number to which the system's state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 32 configuration for the given cartridge.
 *
 * This method sets up the necessary function pointers and memory mappings for Mapper 32.
 * It assigns the `Power` and `Close` functions to the provided `CartInfo` structure,
 * and sets up the game state restoration function. Additionally, it allocates 8192 bytes
 * of Work RAM (WRAM) and configures the PRG mapping for the cartridge. The WRAM is also
 * added to the save state system for persistence across game sessions. Finally, the state
 * registers are added to the save state system.
 *
 * @param info Pointer to the `CartInfo` structure that holds cartridge-specific information.
 */
void Mapper32_Init(CartInfo *info) {
	info->Power = M32Power;
	info->Close = M32Close;
	GameStateRestore = StateRestore;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	AddExState(&StateRegs, ~0, 0, 0);
}
