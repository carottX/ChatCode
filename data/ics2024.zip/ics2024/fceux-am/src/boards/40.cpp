/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * FDS Conversion
 *
 */

#include "mapinc.h"

static uint8 reg;
static uint32 IRQCount, IRQa;

static SFORMAT StateRegs[] =
{
	{ &IRQCount, 4, "IRQC" },
	{ &IRQa, 4, "IRQA" },
	{ &reg, 1, "REG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the NES emulator.
 *
 * This method configures the Programmable Read-Only Memory (PRG) and 
 * Character Read-Only Memory (CHR) banks for the NES emulator. It sets 
 * specific PRG banks at different memory addresses (0x6000, 0x8000, 0xA000, 
 * 0xC000, and 0xE000) using the provided values. The CHR bank is set to 0, 
 * effectively mapping the entire CHR memory to a single bank. This method 
 * is typically used to ensure that the memory mapping is correctly aligned 
 * with the current state of the emulator.
 */
static void Sync(void) {
	setprg8(0x6000, ~1);
	setprg8(0x8000, ~3);
	setprg8(0xa000, ~2);
	setprg8(0xc000, reg);
	setprg8(0xe000, ~0);
	setchr8(0);
}

/**
 * @brief Handles memory writes for the M40 mapper.
 *
 * This method processes memory writes to specific addresses associated with the M40 mapper.
 * It performs different actions based on the address being written to:
 * - Writing to address 0x8000 disables the IRQ, resets the IRQ counter, and signals the end of an external IRQ.
 * - Writing to address 0xA000 enables the IRQ.
 * - Writing to address 0xE000 updates the internal register with the lower 3 bits of the value being written and synchronizes the mapper state.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M40Write) {
	switch (A & 0xe000) {
	case 0x8000: IRQa = 0; IRQCount = 0; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0xa000: IRQa = 1; break;
	case 0xe000: reg = V & 7; Sync(); break;
	}
}

/**
 * @brief Initializes the M40 power state by configuring the memory handlers.
 *
 * This method sets up the memory handlers for the M40 power state. It performs the following steps:
 * 1. Resets the `reg` variable to 0.
 * 2. Synchronizes the system state by calling `Sync()`.
 * 3. Sets the read handler for the memory range 0x6000 to 0xFFFF to `CartBR`.
 * 4. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M40Write`.
 *
 * This configuration is typically used to initialize the memory mapping and handlers
 * for a specific power state or mode in the system.
 */
static void M40Power(void) {
	reg = 0;
	Sync();
	SetReadHandler(0x6000, 0xffff, CartBR);
	SetWriteHandler(0x8000, 0xffff, M40Write);
}

/**
 * @brief Resets the M40 module to its initial state.
 *
 * This method performs a complete reset of the M40 module, clearing all internal
 * states, configurations, and data. It ensures that the module is returned to
 * a default state, ready for reinitialization or further operations. This is
 * typically used during system startup, error recovery, or when a clean state
 * is required.
 */
static void M40Reset(void) {
}

/**
 * @brief Handles the M40 IRQ (Interrupt Request) hook.
 *
 * This method is responsible for managing the M40 IRQ hook. It increments the IRQCount
 * by the specified value `a` if the IRQa flag is set. If the IRQCount reaches or exceeds
 * 4096, the IRQa flag is reset to 0, and an external IRQ is triggered by calling
 * X6502_IRQBegin with the FCEU_IQEXT parameter.
 *
 * @param a The value to add to IRQCount if IRQa is set.
 */
static void M40IRQHook(int a) {
	if (IRQa) {
		if (IRQCount < 4096)
			IRQCount += a;
		else{
			IRQa = 0;
			X6502_IRQBegin(FCEU_IQEXT);
		}
	}
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that the system is synchronized before proceeding with the restoration process by 
 * calling the `Sync()` method. This synchronization step is crucial to maintain consistency and 
 * avoid potential race conditions or data corruption during the restoration.
 * 
 * @param version The version number of the state to be restored. This version typically corresponds 
 *                to a previously saved state in the system's history.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 40 configuration for the given cartridge information.
 *
 * This method sets up the necessary function pointers and state management for Mapper 40.
 * It assigns the reset and power functions to the corresponding handlers (`M40Reset` and `M40Power`),
 * sets the IRQ hook function to `M40IRQHook`, and configures the game state restoration function
 * to `StateRestore`. Additionally, it adds the state registers to the emulator's state management
 * system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure that holds the cartridge's configuration and state.
 */
void Mapper40_Init(CartInfo *info) {
	info->Reset = M40Reset;
	info->Power = M40Power;
	MapIRQHook = M40IRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
