/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg0, reg1;

static SFORMAT StateRegs[] =
{
	{ &reg0, 1, "REG0" },
	{ &reg1, 1, "REG1" },
	{ 0 }
};

/**
 * @brief Synchronizes the PRG and CHR banks based on the current register values.
 *
 * This method updates the Program ROM (PRG) and Character ROM (CHR) banks by 
 * configuring the memory mapping registers. The PRG bank is set using the lower 
 * 4 bits of `reg0` and the least significant bit of `reg1`. The CHR bank is set 
 * using bits 4-6 of `reg1` and the upper 4 bits of `reg0`. The specific mappings 
 * are as follows:
 * - PRG Bank: The lower 4 bits of `reg0` are shifted left by 1 and combined with 
 *   the least significant bit of `reg1` to form the PRG bank address.
 * - CHR Bank: Bits 4-6 of `reg1` are combined with the upper 4 bits of `reg0` 
 *   shifted right by 1 to form the CHR bank address.
 *
 * @note This method assumes that `setprg32` and `setchr8` are predefined functions 
 *       for configuring the PRG and CHR banks, respectively.
 */
static void Sync(void) {
    setprg32(0x8000, (reg1 & 1) + ((reg0 & 0xF) << 1));
    setchr8(((reg1 >> 4) & 7) + ((reg0 & 0xF0) >> 1));
}

/**
 * @brief Writes a value to register 0 and synchronizes the state.
 *
 * This method updates the value of `reg0` with the provided value `V` and then
 * calls the `Sync()` method to ensure the system state is synchronized with
 * the new register value. This is typically used in emulation or low-level
 * hardware programming to update a register and trigger any necessary updates
 * or side effects.
 *
 * @param V The value to be written to register 0.
 */
static DECLFW(M46Write0) {
	reg0 = V;
	Sync();
}

/**
 * @brief Writes a value to the register `reg1` and synchronizes the state.
 *
 * This method assigns the provided value `V` to the register `reg1` and then
 * calls the `Sync()` function to ensure that the system state is updated
 * accordingly. This is typically used to update a specific register and
 * immediately reflect the changes in the system.
 *
 * @param V The value to be written to the register `reg1`.
 */
static DECLFW(M46Write1) {
	reg1 = V;
	Sync();
}

/**
 * @brief Initializes the M46 power state by resetting registers, synchronizing, and setting memory handlers.
 * 
 * This method performs the following operations:
 * 1. Resets `reg0` and `reg1` to 0.
 * 2. Calls `Sync()` to synchronize the system state.
 * 3. Sets a read handler for the memory range 0x8000 to 0xFFFF to `CartBR`.
 * 4. Sets a write handler for the memory range 0x6000 to 0x7FFF to `M46Write0`.
 * 5. Sets a write handler for the memory range 0x8000 to 0xFFFF to `M46Write1`.
 * 
 * This method is typically called during the initialization or reset phase of the M46 system.
 */
static void M46Power(void) {
	reg0 = reg1 = 0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, M46Write0);
	SetWriteHandler(0x8000, 0xFFFF, M46Write1);
}

/**
 * @brief Resets the M46 module by clearing the values of registers reg0 and reg1.
 * 
 * This method sets both reg0 and reg1 to 0, effectively resetting their states. 
 * After resetting the registers, it calls the Sync() function to ensure that 
 * the changes are synchronized across the system or hardware.
 */
static void M46Reset(void) {
	reg0 = reg1 = 0;
	Sync();
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state based on the provided version number. 
 * It ensures that the system is synchronized before proceeding with the restoration process. 
 * The synchronization is handled by the `Sync()` method, which is called internally.
 * 
 * @param version The version number of the state to be restored. This version should correspond 
 *                to a previously saved state in the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 46 for the provided cartridge information.
 * This function sets up the necessary function pointers for power and reset operations,
 * and configures the game state restoration mechanism.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific information.
 *             The function assigns the M46Power and M46Reset functions to the Power and Reset
 *             members of the CartInfo structure, respectively. It also sets up the
 *             GameStateRestore function pointer to StateRestore and adds the state registers
 *             to the emulator's state management system.
 */
void Mapper46_Init(CartInfo *info) {
	info->Power = M46Power;
	info->Reset = M46Reset;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
