/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * TXC/Micro Genius simplified mapper
 */

#include "mapinc.h"

static uint8 latche, mirr;

static SFORMAT StateRegs[] =
{
	{ &latche, 1, "LATC" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Synchronizes the PRG and CHR banks based on the current latch value.
 *
 * This method updates the Program ROM (PRG) and Character ROM (CHR) banks
 * using the value stored in the `latche` variable. The PRG bank is set to the
 * upper 4 bits of `latche` (shifted right by 4), and the CHR bank is set to
 * the lower 4 bits of `latche`. The PRG bank is mapped to the memory address
 * 0x8000, while the CHR bank is mapped to the entire CHR memory space.
 */
static void Sync(void) {
	setprg32(0x8000, latche >> 4);
	setchr8(latche & 0xf);
}

/**
 * @brief Handles the write operation for the M36 mapper.
 * 
 * This method processes a write operation to the M36 mapper, which is used in certain NES games.
 * It interprets the address and value to determine the mirroring mode and updates the internal
 * state accordingly. The method also updates the latch value and synchronizes the mapper state.
 * 
 * @param A The address being written to.
 * @param V The value being written.
 * 
 * The method performs the following actions:
 * - Determines the mirroring mode based on the address bits.
 * - Sets the mirroring mode to either vertical (MI_V) or horizontal (MI_H) depending on the address.
 * - Updates the internal latch value with the provided value (V).
 * - Synchronizes the mapper state to reflect the changes.
 */
static DECLFW(M36Write) {
	switch((A>>12)&7) {				// need to 4-in-1 MGC-26 BMC, doesnt break other games though
		case 0: mirr = MI_V; setmirror(mirr); break;
		case 4: mirr = MI_H; setmirror(mirr); break;
	}
	latche = V;
	Sync();
}

/**
 * @brief Reads the current value of the latche register.
 *
 * This method is used to retrieve the value stored in the `latche` register. 
 * It is specifically required by the game "Strike Wolf," which, despite being a simplified mapper, 
 * still relies on some features of the TCX mapper. The method ensures compatibility with these 
 * TCX mapper features by returning the value of the `latche` register.
 *
 * @return The current value of the `latche` register.
 */
static DECLFR(M36Read) {
	return latche;  // Need by Strike Wolf, being simplified mapper, this cart still uses some TCX mapper features andrely on it
}

/**
 * @brief Initializes the power state for the M36 mapper.
 *
 * This method sets up the initial state of the M36 mapper when the system is powered on.
 * It performs the following operations:
 * 1. Resets the `latche` variable to 0.
 * 2. Calls `Sync()` to synchronize the internal state of the mapper.
 * 3. Sets the read handler for the address range 0x4100-0x4100 to `M36Read`.
 * 4. Sets the read handler for the address range 0x8000-0xFFFF to `CartBR`.
 * 5. Sets the write handler for the address range 0x8000-0xFFFE to `M36Write`, with a note
 *    that a bus conflict prevents triggering the wrong banks.
 */
static void M36Power(void) {
	latche = 0;
	Sync();
	SetReadHandler(0x4100, 0x4100, M36Read);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFE, M36Write);  // Actually, BUS conflict there preventing from triggering the wrong banks
}

/**
 * @brief Restores the system state to a specific version.
 * 
 * This method is responsible for restoring the system to a state corresponding to the 
 * provided version number. It ensures that all necessary synchronization operations are 
 * performed before the restoration process begins. The synchronization is handled by 
 * calling the `Sync()` method, which ensures that all pending operations are completed 
 * and the system is in a consistent state before proceeding with the restoration.
 * 
 * @param version The version number to which the system should be restored. This 
 *                version number typically corresponds to a specific state or snapshot 
 *                of the system that has been previously saved.
 */
static void M36Restore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 36 for the given cartridge information.
 * This function sets up the necessary function pointers and state restoration
 * mechanisms for the Mapper 36. Specifically, it assigns the `M36Power` function
 * to the `Power` member of the `CartInfo` structure, which is responsible for
 * handling power-up initialization. It also sets the `GameStateRestore` function
 * to `M36Restore`, which is used to restore the game state. Additionally, it
 * registers the state registers using the `AddExState` function to ensure that
 * the emulator can save and restore the state of the mapper during emulation.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information that will be initialized for Mapper 36.
 */
void Mapper36_Init(CartInfo *info) {
	info->Power = M36Power;
	GameStateRestore = M36Restore;
	AddExState(StateRegs, ~0, 0, 0);
}
