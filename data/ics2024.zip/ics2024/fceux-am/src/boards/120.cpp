/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the NES emulator.
 *
 * This method configures the Programmable Read-Only Memory (PRG) and 
 * Character Read-Only Memory (CHR) banks for the NES emulator. 
 * Specifically, it:
 * - Maps the PRG ROM bank `reg` to the address range 0x6000-0x7FFF.
 * - Maps the PRG ROM bank 2 to the address range 0x8000-0xFFFF.
 * - Maps the CHR ROM bank 0 to the entire CHR memory space (0x0000-0x1FFF).
 *
 * This method is typically called to update the memory mapping after 
 * changes to the `reg` variable or other relevant state.
 */
static void Sync(void) {
	setprg8(0x6000, reg);
	setprg32(0x8000, 2);
	setchr8(0);
}

/**
 * @brief Handles the write operation for the M120 register.
 *
 * This method is a static function that processes a write operation to the M120 register.
 * It checks if the address `A` is equal to `0x41FF`. If the condition is met, it updates
 * the internal register `reg` with the lower 3 bits of the value `V` and then calls the
 * `Sync()` method to synchronize the state.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M120Write) {
	if (A == 0x41FF) {
		reg = V & 7;
		Sync();
	}
}

/**
 * @brief Configures the power settings for the M120 cartridge.
 *
 * This method initializes the M120 cartridge by performing the following steps:
 * 1. Resets the `reg` variable to 0.
 * 2. Synchronizes the system state by calling `Sync()`.
 * 3. Sets the read handler for the memory range 0x6000 to 0xFFFF to use the `CartBR` function.
 * 4. Sets the write handler for the memory range 0x4100 to 0x5FFF to use the `M120Write` function.
 *
 * This configuration ensures that the M120 cartridge is properly initialized and ready for operation.
 */
static void M120Power(void) {
	reg = 0;
	Sync();
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x4100, 0x5FFF, M120Write);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state by synchronizing
 * with the stored data corresponding to the specified version. It ensures that
 * the system is brought back to a consistent state as it was at the time of
 * the version's creation. The actual restoration process is handled by the
 * `Sync()` method, which is called internally.
 * 
 * @param version The version number of the state to be restored. This version
 *                should correspond to a previously saved state.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 120 for the emulated NES cartridge.
 * 
 * This function sets up the necessary function pointers and state information
 * for Mapper 120, which is used by certain NES games. It assigns the `Power`
 * function pointer in the `CartInfo` structure to `M120Power`, which handles
 * the power-up behavior of the mapper. Additionally, it sets the `GameStateRestore`
 * function pointer to `StateRestore`, which is responsible for restoring the
 * game state during emulation. Finally, it adds the state registers to the
 * emulator's state management system using `AddExState`, ensuring that the
 * state of the mapper can be saved and restored during emulation.
 * 
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper120_Init(CartInfo *info) {
	info->Power = M120Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
