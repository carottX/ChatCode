/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Moero!! Pro Tennis have ADPCM codec on-board, PROM isn't dumped, emulation isn't
 * possible just now.
 */

#include "mapinc.h"

static uint8 preg, creg;

static SFORMAT StateRegs[] =
{
	{ &preg, 1, "PREG" },
	{ &creg, 1, "CREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the program and character ROM banks with the specified registers.
 * 
 * This method configures the memory mapping for the NES by setting the program ROM (PRG) 
 * and character ROM (CHR) banks. It performs the following operations:
 * - Sets the first 16KB PRG ROM bank at address 0x8000 to the value stored in `preg`.
 * - Sets the second 16KB PRG ROM bank at address 0xC000 to the last bank (indicated by ~0).
 * - Sets the 8KB CHR ROM bank to the value stored in `creg`.
 * 
 * This ensures the correct memory layout for the NES emulator or hardware.
 */
static void Sync(void) {
    setprg16(0x8000, preg);
    setprg16(0xC000, ~0);
    setchr8(creg);
}

/**
 * @brief Handles writing to the M72 register.
 *
 * This method processes the value `V` and updates the internal registers `preg` and `creg` based on the bits set in `V`.
 * - If the most significant bit (bit 7) of `V` is set (i.e., `V & 0x80` is true), the `preg` register is updated with the lower 4 bits of `V` (i.e., `V & 0xF`).
 * - If bit 6 of `V` is set (i.e., `V & 0x40` is true), the `creg` register is updated with the lower 4 bits of `V` (i.e., `V & 0xF`).
 * After updating the registers, the `Sync()` function is called to synchronize the state of the system.
 *
 * @param V The value to be written to the M72 register.
 */
static DECLFW(M72Write) {
	if (V & 0x80)
		preg = V & 0xF;
	if (V & 0x40)
		creg = V & 0xF;
	Sync();
}

/**
 * @brief Initializes the M72 Power configuration for the cartridge.
 *
 * This method sets up the read and write handlers for the M72 Power cartridge.
 * It first synchronizes the system state by calling `Sync()`. Then, it assigns
 * the read handler `CartBR` to the memory range `0x8000` to `0xFFFF`, allowing
 * the cartridge to handle read operations in this range. Finally, it assigns the
 * write handler `M72Write` to the memory range `0x6000` to `0xFFFF`, enabling
 * the cartridge to handle write operations in this range.
 */
static void M72Power(void) {
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0xFFFF, M72Write);
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method performs a state restoration by synchronizing the current state
 * with the specified version. It ensures that all components are in sync
 * with the desired state version by calling the `Sync()` method.
 *
 * @param version The version number to which the state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 72 configuration for the provided cartridge information.
 * This function sets up the power function for the mapper to `M72Power` and
 * assigns the `StateRestore` function to the global `GameStateRestore` variable.
 * Additionally, it adds the state registers to the emulator's state management
 * system using `AddExState`, ensuring that the state is saved and restored
 * correctly during emulation.
 *
 * @param info A pointer to the `CartInfo` structure containing cartridge-specific
 *             information that will be configured for Mapper 72.
 */
void Mapper72_Init(CartInfo *info) {
	info->Power = M72Power;
	GameStateRestore = StateRestore;

	AddExState(&StateRegs, ~0, 0, 0);
}
