/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg[4], creg[8];
static uint8 IRQa, mirr;
static int32 IRQCount, IRQLatch;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ preg, 4, "PREG" },
	{ creg, 8, "CREG" },
	{ &mirr, 1, "MIRR" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 4, "IRQC" },
	{ &IRQLatch, 4, "IRQL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the emulated system.
 *
 * This method updates the CHR (Character) and PRG (Program) memory banks based on the current
 * configuration registers. It performs the following operations:
 * - Sets the CHR memory banks for the first 8 KB of CHR memory using the `creg` array.
 * - Configures the PRG memory banks at specific addresses (0x6000, 0x8000, 0xA000, 0xC000, 0xE000)
 *   using the `preg` array and a fixed value for the last bank.
 * - Sets the mirroring mode based on the value of the `mirr` variable, which determines whether
 *   horizontal or vertical mirroring is used.
 */
static void Sync(void) {
	int i;
	for (i = 0; i < 8; i++) setchr1(i << 10, creg[i]);
	setprg8r(0x10, 0x6000, 0);
	setprg8(0x8000, preg[0]);
	setprg8(0xA000, preg[1]);
	setprg8(0xC000, preg[2]);
	setprg8(0xE000, ~0);
	if (mirr & 2)
		setmirror(MI_0);
	else
		setmirror(mirr & 1);
}

/**
 * @brief Handles writes to the IRQ (Interrupt Request) control registers.
 *
 * This method processes writes to specific memory addresses that control the IRQ behavior
 * of the system. Depending on the address (`A`) and the value (`V`) written, it updates
 * the IRQ latch, IRQ counter, IRQ enable flag, or mirroring configuration.
 *
 * The method interprets the address (`A`) and performs the following actions:
 * - For addresses `0xE000` to `0xE003`: Updates specific nibbles of the `IRQLatch` register
 *   based on the value written (`V`). Each address corresponds to a different nibble:
 *   - `0xE000`: Updates the lowest nibble (bits 0-3).
 *   - `0xE001`: Updates the second nibble (bits 4-7).
 *   - `0xE002`: Updates the third nibble (bits 8-11).
 *   - `0xE003`: Updates the highest nibble (bits 12-15).
 * - For address `0xF000`: Copies the value of `IRQLatch` to `IRQCount`, resetting the IRQ counter.
 * - For address `0xF001`: Updates the IRQ enable flag (`IRQa`) based on the least significant bit of `V`.
 *   If the IRQ is disabled, it ends any pending external IRQ by calling `X6502_IRQEnd(FCEU_IQEXT)`.
 * - For address `0xF002`: Updates the mirroring configuration (`mirr`) based on the lowest two bits of `V`
 *   and synchronizes the system by calling `Sync()`.
 *
 * @param A The address being written to. Only specific addresses are handled.
 * @param V The value being written to the address.
 */
static DECLFW(M18WriteIRQ) {
	switch (A & 0xF003) {
	case 0xE000: IRQLatch &= 0xFFF0; IRQLatch |= (V & 0x0f) << 0x0; break;
	case 0xE001: IRQLatch &= 0xFF0F; IRQLatch |= (V & 0x0f) << 0x4; break;
	case 0xE002: IRQLatch &= 0xF0FF; IRQLatch |= (V & 0x0f) << 0x8; break;
	case 0xE003: IRQLatch &= 0x0FFF; IRQLatch |= (V & 0x0f) << 0xC; break;
	case 0xF000: IRQCount = IRQLatch; break;
	case 0xF001: IRQa = V & 1; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0xF002: mirr = V & 3; Sync(); break;
	}
}

/**
 * @brief Writes a value to the PRG (Program ROM) register based on the provided address and value.
 *
 * This method processes the given address `A` and value `V` to update the PRG register `preg`. 
 * The address `A` is used to determine the index `i` into the `preg` array and the specific nibble 
 * (4-bit segment) within the register to update. The index `i` is calculated by combining the 
 * second bit of `A` (shifted right by 1) and the result of subtracting `0x8000` from `A` and 
 * shifting right by 11. The method then updates the appropriate nibble in `preg[i]` based on 
 * the least significant bit of `A`. If `A` is even, the lower nibble is updated; if `A` is odd, 
 * the upper nibble is updated. Finally, the `Sync()` function is called to synchronize the 
 * changes with the system.
 *
 * @param A The address used to determine the index and nibble to update.
 * @param V The value to write to the PRG register.
 */
static DECLFW(M18WritePrg) {
	uint32 i = ((A >> 1) & 1) | ((A - 0x8000) >> 11);
	preg[i] &= (0xF0) >> ((A & 1) << 2);
	preg[i] |= (V & 0xF) << ((A & 1) << 2);
	Sync();
}

/**
 * @brief Writes a value to the CHR (Character) register of the M18 mapper.
 *
 * This method handles the write operation to the CHR register, which is used to control
 * the character memory mapping in the M18 mapper. The method calculates the appropriate
 * index into the `creg` array based on the address `A`. It then updates the specific bits
 * in the `creg` array corresponding to the address and the value `V`. The method ensures
 * that only the lower 4 bits of `V` are used, and they are placed in the correct position
 * within the `creg` entry. Finally, it calls `Sync()` to synchronize the changes with the
 * emulator's state.
 *
 * @param A The address used to determine the index and bit position in the `creg` array.
 * @param V The value to be written to the CHR register, with only the lower 4 bits being used.
 */
static DECLFW(M18WriteChr) {
	uint32 i = ((A >> 1) & 1) | ((A - 0xA000) >> 11);
	creg[i] &= (0xF0) >> ((A & 1) << 2);
	creg[i] |= (V & 0xF) << ((A & 1) << 2);
	Sync();
}

/**
 * @brief Initializes the M18 Power state for the emulator.
 *
 * This method sets up the initial state for the M18 Power emulation. It disables interrupts by setting `IRQa` to 0,
 * initializes the `preg` array with specific values, and synchronizes the emulator state using `Sync()`. It then
 * configures memory handlers for different address ranges:
 * - Sets a read handler for the range 0x6000-0xFFFF to `CartBR`.
 * - Sets write handlers for the ranges 0x6000-0x7FFF to `CartBW`, 0x8000-0x9FFF to `M18WritePrg`,
 *   0xA000-0xDFFF to `M18WriteChr`, and 0xE000-0xFFFF to `M18WriteIRQ`.
 * Finally, it adds RAM for cheat functionality using `FCEU_CheatAddRAM`.
 */
static void M18Power(void) {
	IRQa = 0;
	preg[0] = 0;
	preg[1] = 1;
	preg[2] = ~1;
	preg[3] = ~0;
	Sync();
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetWriteHandler(0x8000, 0x9FFF, M18WritePrg);
	SetWriteHandler(0xA000, 0xDFFF, M18WriteChr);
	SetWriteHandler(0xE000, 0xFFFF, M18WriteIRQ);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Handles the M18 IRQ (Interrupt Request) hook logic.
 *
 * This method is responsible for managing the IRQ count and triggering an IRQ when necessary.
 * It decrements the IRQ count by the specified amount `a`. If the IRQ count reaches or falls below zero,
 * it triggers an external IRQ using `X6502_IRQBegin` with the `FCEU_IQEXT` flag, resets the IRQ count to zero,
 * and disables further IRQ handling by setting `IRQa` to 0.
 *
 * @param a The amount by which the IRQ count should be decremented.
 */
static void M18IRQHook(int a) {
	if (IRQa && IRQCount) {
		IRQCount -= a;
		if (IRQCount <= 0) {
			X6502_IRQBegin(FCEU_IQEXT);
			IRQCount = 0;
			IRQa = 0;
		}
	}
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) memory.
 *
 * This method checks if the WRAM pointer is not null. If WRAM is allocated,
 * it frees the memory using the FCEU_gfree function and sets the WRAM pointer
 * to null to indicate that the memory has been deallocated. This ensures that
 * there are no memory leaks and the WRAM is properly cleaned up.
 */
static void M18Close(void)
{
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method triggers a synchronization process to ensure that the system's 
 * state is restored to the version specified by the `version` parameter. 
 * The actual restoration logic is handled by the `Sync()` method, which 
 * is called internally to perform the necessary operations.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 18 configuration for the given cartridge information.
 * This method sets up the necessary function pointers for power management,
 * cartridge closing, IRQ handling, and game state restoration. It also allocates
 * and configures the Work RAM (WRAM) for the cartridge, including setting up
 * PRG mapping and saving the WRAM state if the cartridge has a battery backup.
 *
 * @param info A pointer to the CartInfo structure that holds the cartridge's
 *             configuration and state information. This structure is modified
 *             to include the appropriate function pointers and WRAM setup.
 *
 * The function performs the following operations:
 * 1. Assigns the power management function (M18Power) to the `Power` field.
 * 2. Assigns the cartridge closing function (M18Close) to the `Close` field.
 * 3. Sets the IRQ hook function (M18IRQHook) for interrupt handling.
 * 4. Assigns the game state restoration function (StateRestore) to `GameStateRestore`.
 * 5. Allocates 8192 bytes of Work RAM (WRAM) and sets up PRG mapping for it.
 * 6. Adds the WRAM state to the external state system for saving/restoring.
 * 7. If the cartridge has a battery backup, it saves the WRAM pointer and size
 *    in the `SaveGame` and `SaveGameLen` fields of the CartInfo structure.
 * 8. Adds the state registers to the external state system.
 */
void Mapper18_Init(CartInfo *info) {
	info->Power = M18Power;
	info->Close = M18Close;
	MapIRQHook = M18IRQHook;
	GameStateRestore = StateRestore;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}

	AddExState(&StateRegs, ~0, 0, 0);
}

