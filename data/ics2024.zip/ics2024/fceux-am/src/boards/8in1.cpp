/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2016 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * 8-in-1  Rockin' Kats, Snake, (PCB marked as "8 in 1"), similar to 12IN1,
 * but with MMC3 on board, all games are hacked the same, Snake is buggy too!
 *
 * no reset-citcuit, so selected game can be reset, but to change it you must use power
 *
 */

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Sets the CHR (Character ROM) bank for the specified address in a BMC8IN1CW mapper.
 *
 * This method configures the CHR bank for the given address `A` by combining the upper bits
 * from the `EXPREGS[0]` register and the lower bits from the input value `V`. The upper bits
 * are extracted from bits 2 and 3 of `EXPREGS[0]` (masked with `0xC`), shifted left by 5 positions,
 * and combined with the lower 7 bits of `V` (masked with `0x7F`). The resulting value is used
 * to set the CHR bank via the `setchr1` function.
 *
 * @param A The address for which the CHR bank is being set.
 * @param V The value used to determine the lower bits of the CHR bank selection.
 */
static void BMC8IN1CW(uint32 A, uint8 V) {
	setchr1(A, ((EXPREGS[0] & 0xC) << 5) | (V & 0x7F));
}

/**
 * @brief Configures the PRG (Program ROM) banking for the BMC8IN1PW mapper.
 *
 * This method sets up the PRG banking based on the current mode and the provided parameters.
 * If the MMC3 mode is enabled (bit 4 of EXPREGS[0] is set), it configures the PRG bank using
 * the lower 4 bits of `V` and bits 2-3 of EXPREGS[0]. Otherwise, it sets the PRG bank to
 * the lower 4 bits of EXPREGS[0] for the entire 32KB PRG ROM space.
 *
 * @param A The address where the PRG bank should be configured.
 * @param V The value used to determine the PRG bank in MMC3 mode.
 */
static void BMC8IN1PW(uint32 A, uint8 V) {
	if(EXPREGS[0] & 0x10) {		// MMC3 mode
		setprg8(A, ((EXPREGS[0] & 0xC) << 2) | (V & 0xF));
	} else {
		setprg32(0x8000, EXPREGS[0] & 0xF);
	}
}

/**
 * @brief Handles write operations for the BMC8IN1 mapper.
 *
 * This method processes write operations to the BMC8IN1 mapper's memory space. It distinguishes
 * between two main scenarios based on the address (A) being written to:
 *
 * 1. If the address has the 0x1000 bit set (A & 0x1000), it updates the EXPREGS[0] register with
 *    the value (V) and triggers the fixing of the MMC3 PRG and CHR banks using the current MMC3
 *    command (MMC3_cmd).
 *
 * 2. If the address does not have the 0x1000 bit set, it further checks the address range:
 *    - For addresses below 0xC000, it delegates the write operation to the MMC3_CMDWrite function.
 *    - For addresses at or above 0xC000, it delegates the write operation to the MMC3_IRQWrite function.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(BMC8IN1Write) {
	if(A & 0x1000) {
		EXPREGS[0] = V;
		FixMMC3PRG(MMC3_cmd);
		FixMMC3CHR(MMC3_cmd);
	} else {
		if(A < 0xC000)
			MMC3_CMDWrite(A, V);
		else
			MMC3_IRQWrite(A, V);
	}
}

/**
 * @brief Initializes the power state for the BMC8IN1 mapper.
 *
 * This method sets up the initial state for the BMC8IN1 mapper by performing the following steps:
 * 1. Resets the first element of the EXPREGS array to 0, clearing any previous state.
 * 2. Calls the GenMMC3Power() function to initialize the MMC3 mapper's power state.
 * 3. Sets the write handler for the memory range 0x8000 to 0xFFFF to the BMC8IN1Write function,
 *    ensuring that writes to this range are properly handled by the BMC8IN1 mapper logic.
 */
static void BMC8IN1Power(void) {
	EXPREGS[0] = 0;
	GenMMC3Power();
	SetWriteHandler(0x8000, 0xFFFF, BMC8IN1Write);
}

/**
 * @brief Initializes the BMC8IN1 mapper for the provided cartridge information.
 *
 * This method sets up the BMC8IN1 mapper by initializing the MMC3 mapper with
 * specific parameters (128 KB of PRG ROM, 128 KB of CHR ROM, and no WRAM or
 * battery-backed RAM). It then configures the cartridge's CHR and PRG banking
 * wrappers to use the BMC8IN1-specific implementations (`BMC8IN1CW` and
 * `BMC8IN1PW`). Additionally, it assigns the `BMC8IN1Power` function to handle
 * power-up initialization and adds the EXPREGS state to the save state system
 * for emulation purposes.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information and configuration.
 */
void BMC8IN1_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 128, 0, 0);
	cwrap = BMC8IN1CW;
	pwrap = BMC8IN1PW;
	info->Power = BMC8IN1Power;
	AddExState(EXPREGS, 1, 0, "EXPR");
}
