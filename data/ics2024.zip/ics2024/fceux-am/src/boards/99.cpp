/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 latch;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;
static writefunc old4016;

static SFORMAT StateRegs[] =
{
	{ &latch, 1, "LATC" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and CHR/PRG banks based on the current latch value.
 *
 * This method performs the following operations:
 * 1. Sets the CHR bank based on the 3rd bit of the latch value (shifted right by 2).
 * 2. Sets the PRG RAM bank at address 0x6000 to use the specified memory region (0x10).
 * 3. Sets the PRG ROM bank at address 0x8000 to use the first 32 KB of the PRG ROM.
 * 4. Sets the PRG ROM bank at address 0x8000 based on the 3rd bit of the latch value (special case for VS Gumshoe).
 *
 * The latch value is used to determine the configuration of the memory mapping and banks.
 */
static void Sync(void) {
	setchr8((latch >> 2) & 1);
	setprg8r(0x10, 0x6000, 0);
	setprg32(0x8000, 0);
	setprg8(0x8000, latch & 4);        /* Special for VS Gumshoe */
}

/**
 * @brief Writes a value to the M99 register and synchronizes the state.
 *
 * This method updates the internal latch with the provided value `V`, 
 * triggers a synchronization operation using `Sync()`, and then forwards 
 * the write operation to the old 4016 handler with the address `A` and value `V`.
 *
 * @param A The address where the write operation is being performed.
 * @param V The value to be written to the M99 register.
 */
static DECLFW(M99Write) {
	latch = V;
	Sync();
	old4016(A, V);
}

/**
 * @brief Initializes and configures the M99 power state for the emulator.
 *
 * This method performs the following operations:
 * 1. Resets the latch to 0.
 * 2. Synchronizes the emulator state.
 * 3. Saves the current write handler for address 0x4016.
 * 4. Sets a new write handler for address 0x4016 to handle M99-specific writes.
 * 5. Configures the read handler for the address range 0x6000 to 0xFFFF to use CartBR.
 * 6. Configures the write handler for the address range 0x6000 to 0x7FFF to use CartBW.
 * 7. Adds RAM for cheat functionality, using WRAMSIZE to determine the size and WRAM as the base address.
 *
 * This method is typically called during the initialization or reset of the emulator
 * to ensure the M99 power state is properly set up.
 */
static void M99Power(void) {
	latch = 0;
	Sync();
	old4016 = GetWriteHandler(0x4016);
	SetWriteHandler(0x4016, 0x4016, M99Write);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) used by the system.
 *
 * This method checks if the WRAM pointer is not null. If it is not null, 
 * it frees the memory allocated for WRAM using the FCEU_gfree function 
 * and then sets the WRAM pointer to null to indicate that the memory 
 * has been deallocated and is no longer in use.
 */
static void M99Close(void)
{
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method is responsible for restoring the system's state based on the provided version number.
 * It ensures that all necessary components are synchronized before proceeding with the restoration.
 * The synchronization is achieved by calling the `Sync()` method, which guarantees that all pending
 * operations are completed and the system is in a consistent state before the restoration begins.
 *
 * @param version The version number of the state to be restored. This version should correspond to
 *                a previously saved state in the system's history.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 99 for the given cartridge information.
 * This function sets up the necessary callbacks for power and close operations,
 * allocates and configures the Work RAM (WRAM) for the cartridge, and sets up
 * the state restoration functionality.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific
 *             information and callbacks. This function sets the Power and Close
 *             callbacks to M99Power and M99Close respectively.
 *
 * The function performs the following operations:
 * 1. Assigns the M99Power and M99Close functions to the Power and Close callbacks
 *    in the CartInfo structure.
 * 2. Allocates 8192 bytes of Work RAM (WRAM) using FCEU_gmalloc and sets up
 *    the PRG mapping for the WRAM.
 * 3. Adds the WRAM to the external state for saving and restoring the emulator state.
 * 4. Sets the GameStateRestore callback to StateRestore and adds the state
 *    registers to the external state.
 */
void Mapper99_Init(CartInfo *info) {
	info->Power = M99Power;
	info->Close = M99Close;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
