/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2006 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 chr_reg[4];
static uint8 kogame, prg_reg, nt1, nt2, mirr;

static uint8 *WRAM = NULL;
static uint32 WRAMSIZE, count;

static SFORMAT StateRegs[] =
{
	{ &nt1, 1, "NT1" },
	{ &nt2, 1, "NT2" },
	{ &mirr, 1, "MIRR" },
	{ &prg_reg, 1, "PRG" },
	{ &kogame, 1, "KGME" },
	{ &count, 4, "CNT" },
	{ chr_reg, 4, "CHR" },
	{ 0 }
};

/**
 * @brief Adjusts the memory mapping and mirroring for the M68NT hardware.
 *
 * This method handles the configuration of the PPU (Picture Processing Unit) memory
 * mapping and mirroring based on the current state of the `mirr` and `UNIFchrrama` flags.
 * If `UNIFchrrama` is not set and the `mirr` flag has the 0x10 bit set, the method updates
 * the `vnapage` array with specific memory addresses derived from `CHRptr`, `nt1`, `nt2`,
 * and `CHRmask1`. The exact configuration depends on the lower 2 bits of `mirr`.
 * Otherwise, it sets the mirroring mode directly using the `setmirror` function based on
 * the lower 2 bits of `mirr`.
 */
static void M68NTfix(void) {
	if ((!UNIFchrrama) && (mirr & 0x10)) {
		PPUNTARAM = 0;
		switch (mirr & 3) {
		case 0:
			vnapage[0] = vnapage[2] = CHRptr[0] + (((nt1 | 128) & CHRmask1[0]) << 10);
			vnapage[1] = vnapage[3] = CHRptr[0] + (((nt2 | 128) & CHRmask1[0]) << 10);
			break;
		case 1:
			vnapage[0] = vnapage[1] = CHRptr[0] + (((nt1 | 128) & CHRmask1[0]) << 10);
			vnapage[2] = vnapage[3] = CHRptr[0] + (((nt2 | 128) & CHRmask1[0]) << 10);
			break;
		case 2:
			vnapage[0] = vnapage[1] = vnapage[2] = vnapage[3] = CHRptr[0] + (((nt1 | 128) & CHRmask1[0]) << 10);
			break;
		case 3:
			vnapage[0] = vnapage[1] = vnapage[2] = vnapage[3] = CHRptr[0] + (((nt2 | 128) & CHRmask1[0]) << 10);
			break;
		}
	} else
		switch (mirr & 3) {
		case 0: setmirror(MI_V); break;
		case 1: setmirror(MI_H); break;
		case 2: setmirror(MI_0); break;
		case 3: setmirror(MI_1); break;
		}
}

/**
 * @brief Synchronizes the CHR and PRG memory banks with the current state of the registers.
 *
 * This method updates the CHR (Character) and PRG (Program) memory banks based on the values stored in the `chr_reg` and `prg_reg` arrays. 
 * It performs the following operations:
 * - Sets the CHR memory banks at specific addresses (0x0000, 0x0800, 0x1000, 0x1800) using the values from `chr_reg[0]` to `chr_reg[3]`.
 * - Sets the PRG memory bank at address 0x6000 using the value from `prg_reg[0]`.
 * - Sets the PRG memory bank at address 0x8000, using either the `kogame` pointer or 0, depending on the value of `PRGptr[1]`.
 * - Sets the PRG memory bank at address 0xC000 to the last available bank (indicated by `~0`).
 *
 * This method is typically called to ensure that the memory banks are correctly mapped according to the current state of the emulator or system.
 */
static void Sync(void) {
	setchr2(0x0000, chr_reg[0]);
	setchr2(0x0800, chr_reg[1]);
	setchr2(0x1000, chr_reg[2]);
	setchr2(0x1800, chr_reg[3]);
	setprg8r(0x10, 0x6000, 0);
	setprg16r((PRGptr[1]) ? kogame : 0, 0x8000, prg_reg);
	setprg16(0xC000, ~0);
}

/**
 * @brief Reads data from the M68 memory region and conditionally updates the program register.
 *
 * This method checks if the `kogame` variable does not have the 8th bit set. If the condition is true,
 * it increments the `count` variable. When `count` reaches 1784, it sets the program register for the
 * 16KB region starting at address 0x8000 using the `prg_reg` value. Finally, it returns the value read
 * from the memory address `A` using the `CartBR` function.
 *
 * @return The value read from the memory address `A`.
 */
static DECLFR(M68Read) {
	if (!(kogame & 8)) {
		count++;
		if (count == 1784)
			setprg16r(0, 0x8000, prg_reg);
	}
	return CartBR(A);
}

/**
 * @brief Writes a value to the low byte of the M68 memory address.
 * 
 * This method handles the writing of a value to the low byte of the specified memory address 
 * in the M68 memory map. If the value `V` is zero, it resets the `count` variable to zero and 
 * sets the program ROM bank using the `setprg16r` function. The program ROM bank is determined 
 * by the `PRGptr[1]` flag; if `PRGptr[1]` is non-zero, it uses the `kogame` bank, otherwise it 
 * uses the default bank (0). The program ROM bank is set to the address `0x8000` and the 
 * `prg_reg` register. Finally, the method writes the value `V` to the memory address `A` using 
 * the `CartBW` function.
 * 
 * @param A The memory address to write to.
 * @param V The value to write to the memory address.
 */
static DECLFW(M68WriteLo) {
	if (!V) {
		count = 0;
		setprg16r((PRGptr[1]) ? kogame : 0, 0x8000, prg_reg);
	}
	CartBW(A, V);
}

/**
 * @brief Writes a value to the CHR register based on the address.
 *
 * This method updates the CHR register array with the provided value `V`. The specific register 
 * to be updated is determined by the address `A`. The method extracts the relevant bits from 
 * the address to index into the `chr_reg` array and assigns the value `V` to the selected register.
 * After updating the register, the method calls `Sync()` to ensure synchronization of the 
 * internal state or hardware components.
 *
 * @param A The address used to determine which CHR register to update. The upper bits of the 
 *          address are masked to select one of the four registers (indexed by 0 to 3).
 * @param V The value to be written to the selected CHR register.
 */
static DECLFW(M68WriteCHR) {
	chr_reg[(A >> 12) & 3] = V;
	Sync();
}

/**
 * @brief Writes a value to the NT1 register and triggers a fix operation.
 *
 * This static method is responsible for writing the provided value `V` to the 
 * NT1 register. After updating the NT1 register, it calls the `M68NTfix()` 
 * function to perform any necessary adjustments or fixes related to the NT1 
 * register. This method is typically used in the context of memory or 
 * register management in a 68k emulator or similar system.
 *
 * @param V The value to be written to the NT1 register.
 */
static DECLFW(M68WriteNT1) {
	nt1 = V;
	M68NTfix();
}

/**
 * @brief Writes a value to the NT2 register and triggers a fix operation.
 *
 * This method assigns the provided value `V` to the `nt2` register and then
 * calls the `M68NTfix()` function to perform any necessary adjustments or
 * updates based on the new value of `nt2`. This is typically used in the
 * context of memory-mapped I/O or hardware emulation where writing to a
 * specific register requires immediate side effects or corrections.
 *
 * @param V The value to be written to the NT2 register.
 */
static DECLFW(M68WriteNT2) {
	nt2 = V;
	M68NTfix();
}

/**
 * @brief Writes a value to the MIR (Mirror) register and updates the NT (Name Table) fix.
 *
 * This static method is responsible for writing a given value `V` to the MIR (Mirror) register.
 * After updating the MIR register, it calls the `M68NTfix()` function to ensure that the
 * Name Table (NT) is properly updated or corrected based on the new value in the MIR register.
 *
 * @param V The value to be written to the MIR register.
 */
static DECLFW(M68WriteMIR) {
	mirr = V;
	M68NTfix();
}

/**
 * @brief Writes a value to the M68 ROM register and updates the internal state.
 *
 * This method processes the input value `V` to update the program register (`prg_reg`)
 * and the `kogame` flag. The lower 3 bits of `V` are used to set the `prg_reg` (program
 * register), while the 4th bit (shifted right by 3) is used to toggle the `kogame` flag.
 * The `kogame` flag is inverted (XORed with 1) to ensure it is set to the opposite of
 * the 4th bit's value. After updating these values, the `Sync()` method is called to
 * synchronize the internal state with the new register and flag values.
 *
 * @param V The input value to be written to the ROM register.
 */
static DECLFW(M68WriteROM) {
	prg_reg = V & 7;
	kogame = ((V >> 3) & 1) ^ 1;
	Sync();
}

/**
 * @brief Initializes the M68 power state by resetting program registers and game state,
 *        synchronizing the system, and setting up memory handlers for read and write operations.
 *
 * This method performs the following steps:
 * 1. Resets the program register (`prg_reg`) and game state (`kogame`) to 0.
 * 2. Calls `Sync()` to synchronize the system state.
 * 3. Calls `M68NTfix()` to fix any NT (Nametable) related issues.
 * 4. Sets up read handlers for specific memory ranges:
 *    - 0x6000-0x7FFF: Uses `CartBR` for reading.
 *    - 0x8000-0xBFFF: Uses `M68Read` for reading.
 *    - 0xC000-0xFFFF: Uses `CartBR` for reading.
 * 5. Sets up write handlers for specific memory ranges:
 *    - 0x8000-0xBFFF: Uses `M68WriteCHR` for writing.
 *    - 0xC000-0xCFFF: Uses `M68WriteNT1` for writing.
 *    - 0xD000-0xDFFF: Uses `M68WriteNT2` for writing.
 *    - 0xE000-0xEFFF: Uses `M68WriteMIR` for writing.
 *    - 0xF000-0xFFFF: Uses `M68WriteROM` for writing.
 *    - 0x6000-0x6000: Uses `M68WriteLo` for writing.
 *    - 0x6001-0x7FFF: Uses `CartBW` for writing.
 * 6. Adds RAM for cheat functionality using `FCEU_CheatAddRAM`.
 */
static void M68Power(void) {
	prg_reg = 0;
	kogame = 0;
	Sync();
	M68NTfix();
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetReadHandler(0x8000, 0xBFFF, M68Read);
	SetReadHandler(0xC000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xBFFF, M68WriteCHR);
	SetWriteHandler(0xC000, 0xCFFF, M68WriteNT1);
	SetWriteHandler(0xD000, 0xDFFF, M68WriteNT2);
	SetWriteHandler(0xE000, 0xEFFF, M68WriteMIR);
	SetWriteHandler(0xF000, 0xFFFF, M68WriteROM);
	SetWriteHandler(0x6000, 0x6000, M68WriteLo);
	SetWriteHandler(0x6001, 0x7FFF, CartBW);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) memory used by the emulator.
 *
 * This method checks if the WRAM pointer is not null. If it is not null, it
 * deallocates the memory associated with WRAM using the FCEU_gfree function.
 * After deallocation, the WRAM pointer is set to NULL to indicate that the
 * memory has been released and is no longer in use.
 *
 * @note This method is static, meaning it can be called without an instance
 * of the class it belongs to. It is typically used to clean up resources
 * when the emulator is shutting down or when WRAM is no longer needed.
 */
static void M68Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method performs a series of operations to restore the system state 
 * to a specific version. It first calls `Sync()` to ensure all pending 
 * operations are completed and the system is in a consistent state. 
 * Then, it calls `M68NTfix()` to apply necessary fixes or adjustments 
 * specific to the M68NT architecture or context.
 * 
 * @param version The version of the state to restore. This parameter 
 *                specifies the target state version to which the system 
 *                should be reverted.
 */
static void StateRestore(int version) {
	Sync();
	M68NTfix();
}

/**
 * Initializes the Mapper 68 for the given cartridge information.
 * This method sets up the necessary callbacks and memory mappings for the emulator.
 * It assigns the power and close functions to the provided CartInfo structure.
 * Additionally, it allocates 8192 bytes of Work RAM (WRAM) and sets up the PRG mapping for it.
 * If the cartridge has a battery backup, it configures the save game memory accordingly.
 * The method also adds the WRAM and state registers to the emulator's state system for saving and restoring.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 */
void Mapper68_Init(CartInfo *info) {
	info->Power = M68Power;
	info->Close = M68Close;
	GameStateRestore = StateRestore;
	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	AddExState(&StateRegs, ~0, 0, 0);
}
