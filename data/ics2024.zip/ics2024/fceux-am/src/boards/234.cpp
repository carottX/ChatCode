/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 bank, preg;
static SFORMAT StateRegs[] =
{
	{ &bank, 1, "BANK" },
	{ &preg, 1, "PREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current state of the bank and preg registers.
 *
 * This method updates the Program ROM (PRG) and Character ROM (CHR) memory mappings, as well as the mirroring mode,
 * based on the values of the `bank` and `preg` registers. The behavior depends on the state of bit 6 (0x40) of the `bank` register:
 * - If bit 6 is set (0x40), the PRG ROM is set to a 32KB bank derived from bits 1-3 of `bank` and bit 0 of `preg`.
 *   The CHR ROM is set to an 8KB bank derived from bits 1-3 of `bank` and bits 4-6 of `preg`.
 * - If bit 6 is not set, the PRG ROM is set to a 32KB bank derived from bits 0-3 of `bank`.
 *   The CHR ROM is set to an 8KB bank derived from bits 0-3 of `bank` and bits 4-5 of `preg`.
 * Finally, the mirroring mode is set based on bit 7 of the `bank` register, inverted.
 */
static void Sync(void) {
	if (bank & 0x40) {
		setprg32(0x8000, (bank & 0xE) | (preg & 1));
		setchr8(((bank & 0xE) << 2) | ((preg >> 4) & 7));
	} else {
		setprg32(0x8000, bank & 0xF);
		setchr8(((bank & 0xF) << 2) | ((preg >> 4) & 3));
	}
	setmirror((bank >> 7) ^ 1);
}

/**
 * @brief Reads a byte from the cartridge bank and updates the bank if necessary.
 *
 * This method reads a byte from the cartridge memory at the specified address `A`.
 * If the `bank` variable is currently unset (i.e., zero), it updates the `bank` 
 * with the value read from the cartridge and calls the `Sync()` method to synchronize
 * the bank state. The method then returns the value read from the cartridge.
 *
 * @param A The address from which to read the byte.
 * @return The byte read from the cartridge memory.
 */
DECLFR(M234ReadBank) {
	uint8 r = CartBR(A);
	if (!bank) {
		bank = r;
		Sync();
	}
	return r;
}

/**
 * @brief Reads a byte from the cartridge memory at the specified address, updates the internal
 *        register (preg), and synchronizes the system state.
 *
 * This method performs the following operations:
 * 1. Reads a byte from the cartridge memory at the address 'A' using the CartBR function.
 * 2. Stores the read byte in the internal register 'preg'.
 * 3. Calls the Sync function to synchronize the system state.
 * 4. Returns the byte read from the cartridge memory.
 *
 * @param A The address from which to read the byte in the cartridge memory.
 * @return The byte read from the cartridge memory at the specified address.
 */
DECLFR(M234ReadPreg) {
	uint8 r = CartBR(A);
	preg = r;
	Sync();
	return r;
}

/**
 * @brief Resets the M234 module to its initial state.
 *
 * This method sets the internal bank and preg variables to 0, effectively
 * resetting the module's state. After resetting these variables, it calls
 * the Sync() function to ensure that the module's state is synchronized
 * with any dependent systems or components.
 */
static void M234Reset(void) {
	bank = preg = 0;
	Sync();
}

/**
 * @brief Initializes the M234 power state by resetting the M234 module and setting up memory read handlers.
 *
 * This method performs the following operations:
 * 1. Resets the M234 module by calling `M234Reset()`.
 * 2. Sets a read handler for the memory range `0x8000` to `0xFFFF` using `CartBR` as the handler.
 * 3. Sets a read handler for the memory range `0xFF80` to `0xFF9F` using `M234ReadBank` as the handler.
 * 4. Sets a read handler for the memory range `0xFFE8` to `0xFFF7` using `M234ReadPreg` as the handler.
 *
 * This method is typically called during the initialization or power-up sequence to configure the M234 module's memory access behavior.
 */
static void M234Power(void) {
    M234Reset();
    SetReadHandler(0x8000, 0xFFFF, CartBR);
    SetReadHandler(0xFF80, 0xFF9F, M234ReadBank);
    SetReadHandler(0xFFE8, 0xFFF7, M234ReadPreg);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method is responsible for restoring the system's state to a specific version.
 * It first calls the `Sync()` method to ensure that all pending operations are
 * completed and the system is in a consistent state before performing the restore.
 * 
 * @param version The version number of the state to restore. This version should
 *                correspond to a previously saved state.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 234 for the given cartridge information.
 *
 * This method sets up the necessary function pointers and state information
 * for Mapper 234. Specifically, it assigns the `Power` and `Reset` functions
 * to the corresponding Mapper 234 implementations (`M234Power` and `M234Reset`).
 * Additionally, it adds the state registers to the emulator's state management
 * system and sets the `GameStateRestore` function to `StateRestore` to handle
 * state restoration during emulation.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper234_Init(CartInfo *info) {
	info->Power = M234Power;
	info->Reset = M234Reset;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
