/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2015 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * "Dragon Fighter" protected MMC3 based custom mapper board
 * mostly hacky implementation, I can't verify if this mapper can read a RAM of the
 * console or watches the bus writes somehow.
 *
 */

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Handles the program ROM bank switching for the UNLBMW8544PW mapper.
 *
 * This method is responsible for setting the program ROM bank at the specified address `A`.
 * If the address `A` is 0x8000, the method uses a value from the `EXPREGS` array to set the bank,
 * specifically using the lower 5 bits of `EXPREGS[0]`. This behavior emulates a hardware-specific
 * override present in the real hardware, where the bank at 0x8000 is controlled by a dedicated register.
 * For all other addresses, the method directly sets the bank using the provided value `V`.
 *
 * @param A The address where the bank switching should occur.
 * @param V The value to use for bank switching if `A` is not 0x8000.
 */
static void UNLBMW8544PW(uint32 A, uint8 V) {
	if(A == 0x8000)
		setprg8(A,EXPREGS[0] & 0x1F);	// the real hardware has this bank overrided with it's own register,
	else								// but MMC3 prg swap still works and you can actually change bank C000 at the same time if use 0x46 cmd
		setprg8(A,V);
}

/**
 * @brief Configures the CHR memory mapping based on the provided address and value.
 *
 * This method is used to set up the CHR (Character) memory mapping for specific address ranges.
 * Depending on the value of the address `A`, it performs different operations:
 * - If `A` is `0x0000`, it sets a 2KB CHR block at address `0x0000` using the value `V` shifted right by 1,
 *   XORed with the value in `EXPREGS[1]`.
 * - If `A` is `0x0800`, it sets a 2KB CHR block at address `0x0800` using the value `V` shifted right by 1,
 *   ORed with the value in `EXPREGS[2]` shifted left by 1 and masked with `0x40`.
 * - If `A` is `0x1000`, it sets a 4KB CHR block at address `0x1000` using the value in `EXPREGS[2]` masked with `0x3F`.
 *
 * @param A The address to determine which CHR block to configure.
 * @param V The value used to configure the CHR block.
 */
static void UNLBMW8544CW(uint32 A, uint8 V) {
	if(A == 0x0000)
		setchr2(0x0000,(V >> 1) ^ EXPREGS[1]);
	else if (A == 0x0800)
		setchr2(0x0800,(V >> 1) | ((EXPREGS[2] & 0x40) << 1));
	else if (A == 0x1000)
		setchr4(0x1000, EXPREGS[2] & 0x3F);
}

/**
 * @brief Writes data to the UNLBMW8544 protection register.
 *
 * This method handles writing data to the UNLBMW8544 protection register. If the address `A` is even (i.e., the least significant bit is 0), 
 * the value `V` is written to the first entry of the `EXPREGS` array. After the write operation, the `FixMMC3PRG` function is called with 
 * the current `MMC3_cmd` value to update the PRG (Program ROM) banks accordingly. This method is typically used in the context of MMC3 
 * mapper emulation to manage memory protection and bank switching.
 *
 * @param A The address where the write operation is performed. Only even addresses trigger the write.
 * @param V The value to be written to the protection register.
 */
static DECLFW(UNLBMW8544ProtWrite) {
	if(!(A & 1)) {
		EXPREGS[0] = V;
		FixMMC3PRG(MMC3_cmd);
	}
}

/**
 * @brief Handles the read operation for the UNLBMW8544 mapper's protection mechanism.
 *
 * This method is responsible for reading data from the UNLBMW8544 mapper's protection
 * mechanism based on the current state of the EXPREGS array and the address being accessed.
 * 
 * The behavior depends on the value of `A & 1` and the state of `EXPREGS[0]`:
 * - If `A & 1` is false and `EXPREGS[0] & 0xE0` equals `0xC0`, the method reads a byte
 *   from address `0x6A` and stores it in `EXPREGS[1]`. This is likely part of a data
 *   latching mechanism, though the exact details are unclear without additional hardware
 *   and expertise.
 * - If `A & 1` is false but `EXPREGS[0] & 0xE0` does not equal `0xC0`, the method reads
 *   a byte from address `0xFF` and stores it in `EXPREGS[2]`. This may be an attempt to
 *   capture data written before the read operation.
 * 
 * Additionally, the method calls `FixMMC3CHR` with `MMC3_cmd & 0x7F` to adjust the CHR
 * bank mapping. Note that this mapper has additional behaviors not implemented here, as
 * they are unused by the game and could disrupt the current logic.
 *
 * @return Always returns 0, indicating no specific value is returned by this method.
 */
static DECLFR(UNLBMW8544ProtRead) {
	if(!fceuindbg) {
		if(!(A & 1)) {
			if((EXPREGS[0] & 0xE0) == 0xC0) {
				EXPREGS[1] = readb(0x6a);	// program can latch some data from the BUS, but I can't say how exactly,
			} else {							// without more euipment and skills ;) probably here we can try to get any write
				EXPREGS[2] = readb(0xff);	// before the read operation
			}
			FixMMC3CHR(MMC3_cmd & 0x7F);		// there are more different behaviour of the board isn't used by game itself, so unimplemented here and
		}										// actually will break the current logic ;)
	}
	return 0;
}

/**
 * @brief Initializes the power state for the UNLBMW8544 mapper.
 *
 * This method sets up the necessary handlers for reading and writing to the
 * memory range 0x6000-0x6FFF, which is specific to the UNLBMW8544 mapper.
 * It first calls GenMMC3Power() to initialize the base MMC3 power state,
 * then assigns custom read and write handlers (UNLBMW8544ProtRead and
 * UNLBMW8544ProtWrite) to the specified memory range to handle mapper-specific
 * functionality.
 */
static void UNLBMW8544Power(void) {
	GenMMC3Power();
	SetWriteHandler(0x6000, 0x6FFF, UNLBMW8544ProtWrite);
	SetReadHandler(0x6000, 0x6FFF, UNLBMW8544ProtRead);
}

/**
 * @brief Initializes the UNLBMW8544 mapper for the given cartridge.
 *
 * This function sets up the UNLBMW8544 mapper by initializing the MMC3
 * memory management controller with 128 KB of PRG-ROM and 256 KB of CHR-ROM.
 * It also configures the specific power-on behavior, PRG-ROM and CHR-ROM
 * wrapping functions, and adds the extended state for saving and loading
 * emulator states.
 *
 * @param info Pointer to the CartInfo structure containing cartridge
 *             information and configuration.
 */
void UNLBMW8544_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 256, 0, 0);
	pwrap = UNLBMW8544PW;
	cwrap = UNLBMW8544CW;
	info->Power = UNLBMW8544Power;
	AddExState(EXPREGS, 3, 0, "EXPR");
}
