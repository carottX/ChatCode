/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "mmc3.h"

static uint8 lut[4] = { 0x00, 0x02, 0x02, 0x03 };

/**
 * @brief Writes a value to the protection register of the UNL6035052 mapper.
 *
 * This method updates the protection register (EXPREGS[0]) based on the value of `V`.
 * The value written to the protection register is determined by looking up the value of `V & 3`
 * in a predefined lookup table (`lut`). This is typically used in emulation to handle
 * mapper-specific protection mechanisms or bank switching logic.
 *
 * @param V The input value used to determine the protection register value.
 */
static DECLFW(UNL6035052ProtWrite) {
	EXPREGS[0] = lut[V & 3];
}

/**
 * @brief Reads the value from the first element of the EXPREGS array.
 *
 * This static method is designed to fetch the value stored in the first index (index 0) 
 * of the EXPREGS array. It is typically used in scenarios where a specific register value 
 * needs to be accessed or read for further processing or evaluation.
 *
 * @return The value stored in EXPREGS[0].
 */
static DECLFR(UNL6035052ProtRead) {
	return EXPREGS[0];
}

/**
 * @brief Initializes the power state for the UNL6035052 mapper.
 *
 * This method sets up the necessary handlers for reading and writing operations
 * specific to the UNL6035052 mapper. It first calls the base MMC3 power initialization
 * function to set up the basic MMC3 functionality. Then, it configures custom read and
 * write handlers for the address range 0x4020 to 0x7FFF, using `UNL6035052ProtWrite`
 * for write operations and `UNL6035052ProtRead` for read operations. This allows for
 * custom behavior specific to the UNL6035052 mapper during memory access.
 */
static void UNL6035052Power(void) {
	GenMMC3Power();
	SetWriteHandler(0x4020, 0x7FFF, UNL6035052ProtWrite);
	SetReadHandler(0x4020, 0x7FFF, UNL6035052ProtRead);
}

/**
 * Initializes the UNL6035052 mapper for the emulator.
 * This method sets up the MMC3 mapper with specific configuration parameters
 * and assigns the power function for the mapper. It also adds the state
 * information for the emulator's save state functionality.
 *
 * @param info A pointer to the CartInfo structure that holds cartridge
 *             information and mapper-specific data.
 *
 * The method performs the following operations:
 * 1. Initializes the MMC3 mapper with 128 KB of PRG ROM, 256 KB of CHR ROM,
 *    and no WRAM or battery-backed RAM.
 * 2. Assigns the UNL6035052Power function to handle power-related operations
 *    for the mapper.
 * 3. Adds the state information for the emulator's save state functionality,
 *    using the EXPREGS array with a size of 6 bytes.
 */
void UNL6035052_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 256, 0, 0);
	info->Power = UNL6035052Power;
	AddExState(EXPREGS, 6, 0, "EXPR");
}
