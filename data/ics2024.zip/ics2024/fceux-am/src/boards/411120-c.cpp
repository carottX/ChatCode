/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2008 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

// actually cart ID is 811120-C, sorry ;) K-3094 - another ID

#include "mapinc.h"
#include "mmc3.h"

static uint8 reset_flag = 0;

/**
 * @brief Sets the CHR bank for the specified address in the BMC411120CCW mapper.
 *
 * This method configures the CHR (Character) bank for the given address `A` using the value `V`.
 * The value `V` is combined with bits 0 and 1 of the first expansion register (`EXPREGS[0]`) shifted left by 7 bits.
 * The resulting value is then used to set the CHR bank via the `setchr1` function.
 *
 * @param A The address for which the CHR bank is being set.
 * @param V The value to be used for setting the CHR bank, combined with bits from `EXPREGS[0]`.
 */
static void BMC411120CCW(uint32 A, uint8 V) {
	setchr1(A, V | ((EXPREGS[0] & 3) << 7));
}

/**
 * @brief Configures the program memory (PRG) banks based on the provided parameters and internal state.
 *
 * This method sets up the PRG banks in the memory mapper. The behavior depends on the value of `EXPREGS[0]`:
 * - If the `reset_flag` or bit 3 (0x08) of `EXPREGS[0]` is set, it configures a 32KB PRG bank at address 0x8000.
 *   The bank number is determined by bits 4-5 of `EXPREGS[0]` combined with a fixed value of 0x0C.
 * - Otherwise, it configures an 8KB PRG bank at the address specified by `A`. The bank number is determined by
 *   the lower 4 bits of `V` combined with bits 0-1 of `EXPREGS[0]` shifted left by 4.
 *
 * @param A The address where the 8KB PRG bank will be mapped if the reset condition is not met.
 * @param V The value used to determine the 8KB PRG bank number if the reset condition is not met.
 */
static void BMC411120CPW(uint32 A, uint8 V) {
	if (EXPREGS[0] & (8 | reset_flag))
		setprg32(0x8000, ((EXPREGS[0] >> 4) & 3) | (0x0C));
	else
		setprg8(A, (V & 0x0F) | ((EXPREGS[0] & 3) << 4));
}

/**
 * @brief Writes a value to the low byte of the BMC411120C register and updates the MMC3 PRG and CHR mappings.
 *
 * This method is responsible for writing the provided value `A` to the first entry of the `EXPREGS` array,
 * which represents the low byte of the BMC411120C register. After updating the register, it calls `FixMMC3PRG`
 * and `FixMMC3CHR` with the current `MMC3_cmd` to ensure that the Program ROM (PRG) and Character ROM (CHR)
 * mappings are correctly configured according to the MMC3 command.
 *
 * @param A The value to be written to the low byte of the BMC411120C register.
 */
static DECLFW(BMC411120CLoWrite) {
	EXPREGS[0] = A;
	FixMMC3PRG(MMC3_cmd);
	FixMMC3CHR(MMC3_cmd);
}

/**
 * @brief Resets the BMC411120C chip by performing the following operations:
 *        1. Clears the first entry in the EXPREGS array by setting it to 0.
 *        2. Toggles the reset_flag by performing a bitwise XOR operation with the value 4.
 *        3. Calls the MMC3RegReset() function to reset the MMC3 registers.
 * This method is typically used to initialize or restore the chip to a default state.
 */
static void BMC411120CReset(void) {
	EXPREGS[0] = 0;
	reset_flag ^= 4;
	MMC3RegReset();
}

/**
 * @brief Initializes the power state for the BMC411120C mapper.
 *
 * This method performs the following operations:
 * 1. Resets the value at index 0 of the EXPREGS array to 0.
 * 2. Calls the GenMMC3Power() function to initialize the MMC3 power state.
 * 3. Sets a write handler for the memory range 0x6000 to 0x7FFF to the BMC411120CLoWrite function.
 *
 * This is typically called when the emulator or system is powered on or reset.
 */
static void BMC411120CPower(void) {
	EXPREGS[0] = 0;
	GenMMC3Power();
	SetWriteHandler(0x6000, 0x7FFF, BMC411120CLoWrite);
}

/**
 * @brief Initializes the BMC411120C mapper for the given cartridge.
 *
 * This function sets up the BMC411120C mapper by initializing the MMC3 chip with
 * the specified parameters, configuring the PRG and CHR banking wrappers, and
 * assigning the Power and Reset functions for the cartridge. Additionally, it
 * adds an external state for the mapper's internal registers.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 *             This structure is used to configure the mapper and store relevant
 *             data such as Power and Reset function pointers.
 *
 * @details The function performs the following steps:
 * 1. Initializes the MMC3 chip with 128 KB of PRG ROM, 128 KB of CHR ROM,
 *    8 KB of WRAM, and no battery-backed RAM.
 * 2. Assigns the BMC411120C-specific PRG and CHR banking wrapper functions.
 * 3. Sets the Power and Reset function pointers in the CartInfo structure.
 * 4. Adds an external state for the mapper's internal registers, labeled as "EXPR".
 */
void BMC411120C_Init(CartInfo *info) {
	GenMMC3_Init(info, 128, 128, 8, 0);
	pwrap = BMC411120CPW;
	cwrap = BMC411120CCW;
	info->Power = BMC411120CPower;
	info->Reset = BMC411120CReset;
	AddExState(EXPREGS, 1, 0, "EXPR");
}
