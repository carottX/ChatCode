/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Configures the CHR (Character) memory bank for the MMC3 mapper.
 *
 * This method sets the CHR memory bank at the specified address `A` with the value `V`.
 * The method checks if the 13th bit of `A` (0x1000) matches the 8th bit of `MMC3_cmd` shifted left by 5 bits.
 * If they match, the 9th bit of `V` is set (ORed with 0x100) before configuring the CHR bank.
 * Otherwise, `V` is used as-is to configure the CHR bank.
 *
 * @param A The address in the CHR memory space to configure.
 * @param V The value to set in the CHR memory bank.
 */
static void M187CW(uint32 A, uint8 V) {
	if ((A & 0x1000) == ((MMC3_cmd & 0x80) << 5))
		setchr1(A, V | 0x100);
	else
		setchr1(A, V);
}

/**
 * @brief Configures the program memory (PRG) banks based on the provided parameters.
 *
 * This method is used to set up the PRG memory banks for a specific hardware configuration.
 * The behavior of the method depends on the value of `EXPREGS[0]`:
 * - If the most significant bit (MSB) of `EXPREGS[0]` is set (0x80), the method uses the lower 5 bits
 *   (0x1F) of `EXPREGS[0]` to determine the bank configuration. Depending on the values of the 6th (0x20)
 *   and 7th (0x40) bits, it either sets a 32KB PRG bank (with different shift operations) or two 16KB PRG banks.
 * - If the MSB of `EXPREGS[0]` is not set, the method sets an 8KB PRG bank using the lower 6 bits (0x3F) of `V`.
 *
 * @param A The address where the PRG bank should be set (used when setting an 8KB PRG bank).
 * @param V The value used to determine the PRG bank (used when setting an 8KB PRG bank).
 */
static void M187PW(uint32 A, uint8 V) {
	if (EXPREGS[0] & 0x80) {
		uint8 bank = EXPREGS[0] & 0x1F;
		if (EXPREGS[0] & 0x20) {
			if (EXPREGS[0] & 0x40)
				setprg32(0x8000, bank >> 2);
			else
				setprg32(0x8000, bank >> 1);  // hacky hacky! two mappers in one! need real hw carts to test
		} else {
			setprg16(0x8000, bank);
			setprg16(0xC000, bank);
		}
	} else
		setprg8(A, V & 0x3F);
}

/**
 * @brief Handles the write operation for the memory address 0x8000.
 * 
 * This method sets the second element of the `EXPREGS` array to 1 and then 
 * delegates the write operation to the `MMC3_CMDWrite` function with the 
 * provided address `A` and value `V`.
 * 
 * @param A The memory address where the write operation is performed.
 * @param V The value to be written to the specified memory address.
 */
static DECLFW(M187Write8000) {
	EXPREGS[1] = 1;
	MMC3_CMDWrite(A, V);
}

/**
 * @brief Handles writing to the M187 register at address 0x8001.
 *
 * This method checks if the second element of the EXPREGS array is non-zero.
 * If it is, the method delegates the write operation to the MMC3_CMDWrite function,
 * passing the address (A) and value (V) parameters. This is typically used in
 * the context of an emulator to handle specific memory-mapped I/O operations.
 *
 * @param A The address where the write operation is being performed.
 * @param V The value to be written at the specified address.
 */
static DECLFW(M187Write8001) {
	if (EXPREGS[1])
		MMC3_CMDWrite(A, V);
}

/**
 * @brief Handles writing to the low byte of the M187 register.
 *
 * This method is responsible for writing a value to the low byte of the M187 register
 * when the address `A` matches either `0x5000` or `0x6000`. Upon a successful match,
 * the value `V` is stored in the `EXPREGS[0]` register, and the `FixMMC3PRG` function
 * is called with the current `MMC3_cmd` as an argument to update the PRG banking.
 *
 * @param A The address to which the write operation is targeted.
 * @param V The value to be written to the register.
 */
static DECLFW(M187WriteLo) {
	if ((A == 0x5000) || (A == 0x6000)) {
		EXPREGS[0] = V;
		FixMMC3PRG(MMC3_cmd);
	}
}

static uint8 prot_data[4] = { 0x83, 0x83, 0x42, 0x00 };
/**
 * @brief Reads data from the M187 register based on the current value of EXPREGS[1].
 * 
 * This method retrieves a value from the `prot_data` array using the lower 2 bits of 
 * the value stored in `EXPREGS[1]` as the index. The index is calculated by performing 
 * a bitwise AND operation with 3 (0b11), ensuring that only the last two bits are used.
 * 
 * @return The value from `prot_data` at the index determined by `EXPREGS[1] & 3`.
 */
static DECLFR(M187Read) {
	return prot_data[EXPREGS[1] & 3];
}

/**
 * @brief Initializes the power state for the M187 mapper.
 *
 * This method sets up the M187 mapper by performing the following steps:
 * 1. Resets the expansion registers (EXPREGS[0] and EXPREGS[1]) to 0.
 * 2. Calls the base MMC3 power initialization function (GenMMC3Power) to set up the MMC3 mapper.
 * 3. Configures the read handler for the address range 0x5000 to 0x5FFF to use the M187Read function.
 * 4. Configures the write handler for the address range 0x5000 to 0x6FFF to use the M187WriteLo function.
 * 5. Configures the write handler for the address 0x8000 to use the M187Write8000 function.
 * 6. Configures the write handler for the address 0x8001 to use the M187Write8001 function.
 *
 * This setup ensures that the M187 mapper is properly initialized and ready to handle memory reads and writes.
 */
static void M187Power(void) {
	EXPREGS[0] = EXPREGS[1] = 0;
	GenMMC3Power();
	SetReadHandler(0x5000, 0x5FFF, M187Read);
	SetWriteHandler(0x5000, 0x6FFF, M187WriteLo);
	SetWriteHandler(0x8000, 0x8000, M187Write8000);
	SetWriteHandler(0x8001, 0x8001, M187Write8001);
}

/**
 * @brief Initializes the Mapper 187 for the NES cartridge.
 *
 * This method sets up the Mapper 187 by initializing the MMC3 chip with specific
 * parameters, configuring the program and character ROM wrapping functions, and
 * setting the power function for the cartridge. It also adds the external state
 * for the mapper to ensure proper save state functionality.
 *
 * @param info A pointer to the CartInfo structure that contains information
 *             about the cartridge being initialized.
 *
 * @details The method performs the following steps:
 * 1. Initializes the MMC3 chip with 256 KB of PRG ROM and 256 KB of CHR ROM,
 *    with no WRAM and no battery-backed RAM.
 * 2. Sets the program ROM wrapping function to M187PW.
 * 3. Sets the character ROM wrapping function to M187CW.
 * 4. Assigns the power function to M187Power.
 * 5. Adds the external state (EXPREGS) with a size of 3 bytes to the save state system.
 */
void Mapper187_Init(CartInfo *info) {
	GenMMC3_Init(info, 256, 256, 0, 0);
	pwrap = M187PW;
	cwrap = M187CW;
	info->Power = M187Power;
	AddExState(EXPREGS, 3, 0, "EXPR");
}
