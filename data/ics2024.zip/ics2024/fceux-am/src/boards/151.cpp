/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 regs[8];

static SFORMAT StateRegs[] =
{
	{ regs, 8, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the emulated system.
 *
 * This method updates the Programmable Read-Only Memory (PRG) and
 * Character Read-Only Memory (CHR) mappings based on the values stored
 * in the `regs` array. It configures the PRG ROM banks at specific
 * memory addresses (0x8000, 0xA000, 0xC000, and 0xE000) and the CHR ROM
 * banks at 0x0000 and 0x1000. The last PRG ROM bank is set to the fixed
 * value of ~0, which typically represents the last bank in the ROM.
 *
 * @details The method performs the following operations:
 * - Sets the PRG ROM bank at 0x8000 to the value in `regs[0]`.
 * - Sets the PRG ROM bank at 0xA000 to the value in `regs[2]`.
 * - Sets the PRG ROM bank at 0xC000 to the value in `regs[4]`.
 * - Sets the PRG ROM bank at 0xE000 to the fixed value ~0.
 * - Sets the CHR ROM bank at 0x0000 to the value in `regs[6]`.
 * - Sets the CHR ROM bank at 0x1000 to the value in `regs[7]`.
 */
static void Sync(void) {
	setprg8(0x8000, regs[0]);
	setprg8(0xA000, regs[2]);
	setprg8(0xC000, regs[4]);
	setprg8(0xE000, ~0);
	setchr4(0x0000, regs[6]);
	setchr4(0x1000, regs[7]);
}

/**
 * @brief Writes a value to a specific register based on the address.
 *
 * This method writes the value `V` to one of the registers in the `regs` array.
 * The specific register is determined by the address `A` using the formula `(A >> 12) & 7`.
 * After updating the register, the `Sync()` method is called to synchronize the state.
 *
 * @param A The address used to determine which register to write to.
 * @param V The value to be written to the selected register.
 */
static DECLFW(M151Write) {
	regs[(A >> 12) & 7] = V;
	Sync();
}

/**
 * @brief Configures the memory mapping for the M151 power state.
 * 
 * This method synchronizes the system state and sets up the read and write handlers
 * for the memory range 0x8000 to 0xFFFF. Specifically, it assigns the `CartBR` function
 * as the read handler and the `M151Write` function as the write handler for this memory range.
 * This setup is typically used to manage cartridge-based memory access in an emulator or
 * similar system.
 */
static void M151Power(void) {
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M151Write);
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specified version.
 * It first calls the `Sync()` method to ensure that all pending operations are
 * synchronized before proceeding with the state restoration. This is crucial to
 * maintain consistency and avoid potential data corruption or inconsistencies.
 *
 * @param version The version number to which the system's state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 151 for the NES cartridge.
 *
 * This function sets up the necessary configurations for Mapper 151, which is used in certain NES cartridges.
 * It assigns the power function (`M151Power`) to the `Power` member of the `CartInfo` structure, which is
 * responsible for handling the cartridge's power-up behavior. Additionally, it sets the `GameStateRestore`
 * function pointer to `StateRestore`, which is used to restore the game state. Finally, it adds the state
 * registers (`StateRegs`) to the external state management system using `AddExState`, ensuring that the
 * state is preserved and restored correctly during emulation.
 *
 * @param info A pointer to the `CartInfo` structure that contains cartridge-specific information and
 *             function pointers.
 */
void Mapper151_Init(CartInfo *info) {
	info->Power = M151Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
