/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg[8];
static uint8 mirror, cmd, is154;

static SFORMAT StateRegs[] =
{
	{ &cmd, 1, "CMD" },
	{ &mirror, 1, "MIRR" },
	{ reg, 8, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping registers with the CHR and PRG banks.
 *
 * This method updates the CHR (Character) and PRG (Program) memory banks based on the values
 * stored in the `reg` array. It performs the following operations:
 * - Sets the first two 2 KB CHR banks at addresses 0x0000 and 0x0800 using the values from `reg[0]` and `reg[1]`, respectively.
 * - Sets the next four 1 KB CHR banks at addresses 0x1000, 0x1400, 0x1800, and 0x1C00 using the values from `reg[2]`, `reg[3]`, `reg[4]`, and `reg[5]`, respectively, with the 0x40 bit set.
 * - Sets the PRG banks at addresses 0x8000, 0xA000, 0xC000, and 0xE000 using the values from `reg[6]`, `reg[7]`, and fixed values (~1 and ~0) for the last two banks.
 *
 * This method is typically called to apply changes to the memory mapping registers and ensure
 * that the CHR and PRG banks are correctly configured for the current state of the emulator or system.
 */
static void Sync(void) {
	setchr2(0x0000, reg[0] >> 1);
	setchr2(0x0800, reg[1] >> 1);
	setchr1(0x1000, reg[2] | 0x40);
	setchr1(0x1400, reg[3] | 0x40);
	setchr1(0x1800, reg[4] | 0x40);
	setchr1(0x1C00, reg[5] | 0x40);
	setprg8(0x8000, reg[6]);
	setprg8(0xA000, reg[7]);
	setprg8(0xC000, ~1);
	setprg8(0xE000, ~0);
}

/**
 * @brief Synchronizes the mirroring mode based on the current state.
 * 
 * This method checks if the `is154` flag is set and, if true, updates the mirroring mode
 * using the `setmirror` function. The mirroring mode is determined by the least significant
 * bit of the `mirror` variable, which is added to the base value `MI_0`.
 */
static void MSync(void) {
	if (is154) setmirror(MI_0 + (mirror & 1));
}

/**
 * @brief Handles write operations to the M88 memory-mapped I/O registers.
 * 
 * This method processes write requests to the M88 registers based on the address
 * and value provided. It supports two specific addresses:
 * - 0x8000: Sets the command (`cmd`) to the lower 3 bits of the value (`V`) and
 *           the mirroring mode (`mirror`) to the upper 2 bits of the value. It
 *           then calls `MSync()` to synchronize the state.
 * - 0x8001: Writes the value (`V`) to the register specified by the current
 *           command (`cmd`) and calls `Sync()` to update the state.
 * 
 * @param A The address to write to. Only addresses 0x8000 and 0x8001 are handled.
 * @param V The value to write to the specified address.
 */
static DECLFW(M88Write) {
	switch (A & 0x8001) {
	case 0x8000: cmd = V & 7; mirror = V >> 6; MSync(); break;
	case 0x8001: reg[cmd] = V; Sync(); break;
	}
}

/**
 * @brief Initializes and powers up the M88 hardware module.
 * 
 * This method performs the following operations:
 * 1. Resets all registers (reg[0] to reg[7]) to 0.
 * 2. Synchronizes the hardware state by calling Sync() and MSync().
 * 3. Sets the read handler for the memory range 0x8000 to 0xFFFF to CartBR.
 * 4. Sets the write handler for the memory range 0x8000 to 0xFFFF to M88Write.
 * 
 * This method is typically called during the initialization or reset phase of the M88 module
 * to ensure that all registers are cleared and the appropriate memory handlers are in place.
 */
static void M88Power(void) {
	reg[0] = reg[1] = reg[2] = reg[3] = reg[4] = reg[5] = reg[6] = reg[7] = 0;
	Sync();
	MSync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M88Write);
}

/**
 * @brief Restores the state of the system based on the provided version.
 * 
 * This method performs a state restoration by synchronizing the internal state 
 * of the system. It first calls the `Sync()` method to ensure that the primary 
 * state is synchronized, followed by the `MSync()` method to synchronize any 
 * additional or secondary state components. The version parameter specifies 
 * the version of the state to be restored, allowing for compatibility with 
 * different state formats or configurations.
 * 
 * @param version The version of the state to be restored. This parameter 
 *                determines how the state synchronization is performed.
 */
static void StateRestore(int version) {
	Sync();
	MSync();
}

/**
 * Initializes the Mapper 88 configuration for the provided cartridge information.
 * This function sets up the necessary state and function pointers for the Mapper 88.
 * Specifically, it initializes the `is154` flag to 0, assigns the `M88Power` function
 * to the `Power` pointer in the `CartInfo` structure, sets the `GameStateRestore`
 * function to `StateRestore`, and adds the state registers to the emulator's state
 * management system using `AddExState`. This ensures that the emulator can properly
 * handle power cycles and state saving/loading for cartridges using Mapper 88.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper88_Init(CartInfo *info) {
	is154 = 0;
	info->Power = M88Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * @brief Initializes the Mapper 154 for the emulated NES cartridge.
 *
 * This function sets up the necessary configurations for Mapper 154, which is used
 * to manage memory mapping and state handling for the emulated cartridge. It sets
 * the `is154` flag to indicate that Mapper 154 is active, assigns the `Power` function
 * pointer to `M88Power` for handling power-up initialization, and sets the `GameStateRestore`
 * function pointer to `StateRestore` for restoring the game state. Additionally, it
 * adds the state registers to the emulator's state management system using `AddExState`.
 *
 * @param info A pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper154_Init(CartInfo *info) {
	is154 = 1;
	info->Power = M88Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
