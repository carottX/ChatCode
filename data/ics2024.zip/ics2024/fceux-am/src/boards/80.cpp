/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg[3], creg[6], isExMirr;
static uint8 mirr, cmd, wram_enable, wram[256];
static uint8 mcache[8];
static uint32 lastppu;

static SFORMAT StateRegs80[] =
{
	{ preg, 3, "PREG" },
	{ creg, 6, "CREG" },
	{ wram, 256, "WRAM" },
	{ &mirr, 1, "MIRR" },
	{ &wram_enable, 1, "WRME" },
	{ 0 }
};

static SFORMAT StateRegs95[] =
{
	{ &cmd, 1, "CMDR" },
	{ preg, 3, "PREG" },
	{ creg, 6, "CREG" },
	{ mcache, 8, "MCCH" },
	{ &lastppu, 4, "LPPU" },
	{ 0 }
};

static SFORMAT StateRegs207[] =
{
	{ preg, 3, "PREG" },
	{ creg, 6, "CREG" },
	{ mcache, 8, "MCCH" },
	{ &lastppu, 4, "LPPU" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration of the emulated system.
 * 
 * This method updates the Program ROM (PRG) and Character ROM (CHR) memory mappings based on the current
 * values stored in the `preg` and `creg` arrays. It also sets the mirroring mode for the nametable memory.
 * 
 * The PRG ROM is mapped in 8KB chunks to the following addresses:
 * - 0x8000: Uses the value from `preg[0]`.
 * - 0xA000: Uses the value from `preg[1]`.
 * - 0xC000: Uses the value from `preg[2]`.
 * - 0xE000: Fixed to the last bank (`~0`).
 * 
 * The CHR ROM is mapped as follows:
 * - 0x0000: 2KB using the value `(creg[0] >> 1) & 0x3F`.
 * - 0x0800: 2KB using the value `(creg[1] >> 1) & 0x3F`.
 * - 0x1000: 1KB using the value from `creg[2]`.
 * - 0x1400: 1KB using the value from `creg[3]`.
 * - 0x1800: 1KB using the value from `creg[4]`.
 * - 0x1C00: 1KB using the value from `creg[5]`.
 * 
 * The mirroring mode is set based on the `isExMirr` flag:
 * - If `isExMirr` is true, the mirroring mode is set using `mcache[lastppu]`.
 * - Otherwise, the mirroring mode is set using the `mirr` variable.
 */
static void Sync(void) {
	setprg8(0x8000, preg[0]);
	setprg8(0xA000, preg[1]);
	setprg8(0xC000, preg[2]);
	setprg8(0xE000, ~0);
	setchr2(0x0000, (creg[0] >> 1) & 0x3F);
	setchr2(0x0800, (creg[1] >> 1) & 0x3F);
	setchr1(0x1000, creg[2]);
	setchr1(0x1400, creg[3]);
	setchr1(0x1800, creg[4]);
	setchr1(0x1C00, creg[5]);
	if (isExMirr) {
		setmirror(MI_0 + mcache[lastppu]);
	} else
		setmirror(mirr);
}

/**
 * @brief Writes a value to the M80 RAM if the write enable condition is met.
 *
 * This method writes the value `V` to the M80 RAM at the address `A & 0xFF` 
 * if the `wram_enable` flag is set to `0xA3`. The address is masked to ensure 
 * it is within the range of the RAM (0x00 to 0xFF). If the `wram_enable` flag 
 * is not set to `0xA3`, the write operation is ignored.
 *
 * @param A The address in the RAM where the value should be written.
 * @param V The value to be written to the RAM.
 */
static DECLFW(M80RamWrite) {
	if(wram_enable == 0xA3)
		wram[A & 0xFF] = V;
}

/**
 * @brief Reads a byte from the M80 RAM if the write enable condition is met.
 *
 * This method checks if the `wram_enable` flag is set to `0xA3`. If the condition is true,
 * it reads and returns the byte from the `wram` array at the address specified by `A & 0xFF`.
 * If the condition is not met, it returns `0xFF` as a default value.
 *
 * @param A The address to read from, masked with `0xFF` to ensure it is within the valid range.
 * @return The byte read from `wram` if `wram_enable` is `0xA3`, otherwise `0xFF`.
 */
static DECLFR(M80RamRead) {
	if(wram_enable == 0xA3)
		return wram[A & 0xFF];
	else
		return 0xFF;
}

/**
 * @brief Handles write operations to specific memory addresses for the M80 mapper.
 *
 * This method processes write operations to various memory addresses (0x7EF0 to 0x7EFF) and updates
 * internal registers and cache accordingly. The behavior depends on the address (A) and the value (V)
 * being written. The method also triggers a synchronization operation (Sync()) after updating the
 * relevant registers or cache.
 *
 * @param A The memory address being written to. This determines which register or cache is updated.
 * @param V The value being written to the specified address.
 *
 * The method performs the following operations based on the address:
 * - 0x7EF0: Updates creg[0] and sets mcache[0] and mcache[1] to V >> 7.
 * - 0x7EF1: Updates creg[1] and sets mcache[2] and mcache[3] to V >> 7.
 * - 0x7EF2: Updates creg[2] and sets mcache[4] to V >> 7.
 * - 0x7EF3: Updates creg[3] and sets mcache[5] to V >> 7.
 * - 0x7EF4: Updates creg[4] and sets mcache[6] to V >> 7.
 * - 0x7EF5: Updates creg[5] and sets mcache[7] to V >> 7.
 * - 0x7EF6: Updates the mirr register with V & 1.
 * - 0x7EF8: Updates the wram_enable register with V.
 * - 0x7EFA/0x7EFB: Updates preg[0].
 * - 0x7EFC/0x7EFD: Updates preg[1].
 * - 0x7EFE/0x7EFF: Updates preg[2].
 *
 * After each update, the Sync() method is called to synchronize the internal state.
 */
static DECLFW(M80Write) {
	switch (A) {
	case 0x7EF0: creg[0] = V; mcache[0] = mcache[1] = V >> 7; Sync(); break;
	case 0x7EF1: creg[1] = V; mcache[2] = mcache[3] = V >> 7; Sync(); break;
	case 0x7EF2: creg[2] = V; mcache[4] = V >> 7; Sync(); break;
	case 0x7EF3: creg[3] = V; mcache[5] = V >> 7; Sync(); break;
	case 0x7EF4: creg[4] = V; mcache[6] = V >> 7; Sync(); break;
	case 0x7EF5: creg[5] = V; mcache[7] = V >> 7; Sync(); break;
	case 0x7EF6: mirr = V & 1; Sync(); break;
	case 0x7EF8: wram_enable = V; break;
	case 0x7EFA:
	case 0x7EFB: preg[0] = V; Sync(); break;
	case 0x7EFC:
	case 0x7EFD: preg[1] = V; Sync(); break;
	case 0x7EFE:
	case 0x7EFF: preg[2] = V; Sync(); break;
	}
}

/**
 * @brief Handles write operations for the M95 memory mapper.
 *
 * This method processes write operations to specific memory addresses associated with the M95 mapper.
 * It updates internal registers and cache based on the address and value provided. The method supports
 * two primary address ranges:
 * - 0x8000: Updates the command register (`cmd`) with the provided value.
 * - 0x8001: Processes the value based on the current command (`cmd`). Depending on the command, it updates
 *   control registers (`creg`) and cache (`mcache`), or program registers (`preg`). After updating the
 *   appropriate registers, it calls `Sync()` to synchronize the state.
 *
 * @param A The address being written to. Only specific addresses (0x8000 and 0x8001) are processed.
 * @param V The value being written to the address.
 */
static DECLFW(M95Write) {
	switch (A & 0xF001) {
	case 0x8000: cmd = V; break;
	case 0x8001:
		switch (cmd & 0x07) {
		case 0: creg[0] = V & 0x1F; mcache[0] = mcache[1] = (V >> 5) & 1; Sync(); break;
		case 1: creg[1] = V & 0x1F; mcache[2] = mcache[3] = (V >> 5) & 1; Sync(); break;
		case 2: creg[2] = V & 0x1F; mcache[4] = (V >> 5) & 1; Sync(); break;
		case 3: creg[3] = V & 0x1F; mcache[5] = (V >> 5) & 1; Sync(); break;
		case 4: creg[4] = V & 0x1F; mcache[6] = (V >> 5) & 1; Sync(); break;
		case 5: creg[5] = V & 0x1F; mcache[7] = (V >> 5) & 1; Sync(); break;
		case 6: preg[0] = V; Sync(); break;
		case 7: preg[1] = V; Sync(); break;
		}
		Sync();
	}
}

/**
 * @brief Updates the PPU (Picture Processing Unit) mirroring based on the provided address.
 *
 * This method checks if the provided address `A` is within the PPU address range (0x0000-0x1FFF).
 * If it is, it calculates the corresponding mirroring index (`lastppu`) by shifting the address right by 10 bits.
 * The method then retrieves the current mirroring configuration (`curmirr`) from the `mcache` array using `lastppu`.
 * If the current mirroring configuration differs from the last recorded configuration (`lastmirr`),
 * it updates the PPU mirroring by calling `setmirror` with the new configuration and updates `lastmirr` to the current configuration.
 *
 * @param A The address to determine the PPU mirroring configuration.
 */
static void MExMirrPPU(uint32 A) {
	static int8 lastmirr = -1, curmirr;
	if (A < 0x2000) {
		lastppu = A >> 10;
		curmirr = mcache[lastppu];
		if (curmirr != lastmirr) {
			setmirror(MI_0 + curmirr);
			lastmirr = curmirr;
		}
	}
}

/**
 * @brief Initializes and configures the M80 power state by enabling WRAM, synchronizing the system,
 *        and setting up memory read and write handlers for specific address ranges.
 *
 * This method performs the following operations:
 * 1. Enables WRAM by setting `wram_enable` to 0xFF.
 * 2. Synchronizes the system by calling `Sync()`.
 * 3. Sets up a read handler for the address range 0x7F00 to 0x7FFF using `M80RamRead`.
 * 4. Sets up a write handler for the address range 0x7F00 to 0x7FFF using `M80RamWrite`.
 * 5. Sets up a write handler for the address range 0x7EF0 to 0x7EFF using `M80Write`.
 * 6. Sets up a read handler for the address range 0x8000 to 0xFFFF using `CartBR`.
 */
static void M80Power(void) {
	wram_enable = 0xFF;
	Sync();
	SetReadHandler(0x7F00, 0x7FFF, M80RamRead);
	SetWriteHandler(0x7F00, 0x7FFF, M80RamWrite);
	SetWriteHandler(0x7EF0, 0x7EFF, M80Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Resets the memory cache and sets up read/write handlers for specific memory ranges.
 * 
 * This method performs the following operations:
 * 1. Initializes the first eight elements of the `mcache` array to zero, effectively clearing the cache.
 * 2. Calls the `Sync()` function to synchronize the state of the system.
 * 3. Sets a write handler for the memory range `0x7EF0` to `0x7EFF` using the `M80Write` function.
 * 4. Sets a read handler for the memory range `0x8000` to `0xFFFF` using the `CartBR` function.
 * 
 * This method is typically used to prepare the system for memory operations by ensuring the cache is cleared
 * and appropriate handlers are in place for specific memory ranges.
 */
static void M207Power(void) {
	mcache[0] = mcache[1] = mcache[2] = mcache[3] = 0;
	mcache[4] = mcache[5] = mcache[6] = mcache[7] = 0;
	Sync();
	SetWriteHandler(0x7EF0, 0x7EFF, M80Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Initializes the M95 power state by resetting relevant registers and memory cache.
 * 
 * This method performs the following operations:
 * 1. Inverts the value of the second register in the `preg` array to reset its state.
 * 2. Clears the first eight elements of the `mcache` array by setting them to 0.
 * 3. Synchronizes the system state by calling `Sync()`.
 * 4. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M95Write`.
 * 5. Sets the read handler for the same memory range to `CartBR`.
 * 
 * This method is typically used to reset or initialize the M95 memory mapping and handlers.
 */
static void M95Power(void) {
	preg[2] = ~1;
	mcache[0] = mcache[1] = mcache[2] = mcache[3] = 0;
	mcache[4] = mcache[5] = mcache[6] = mcache[7] = 0;
	Sync();
	SetWriteHandler(0x8000, 0xFFFF, M95Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specific version
 * by synchronizing the current state with the desired version. It calls the `Sync()`
 * method to ensure that all necessary data and configurations are updated to match
 * the specified version.
 *
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 80 configuration for the provided cartridge information.
 *
 * This method sets up the initial state for Mapper 80 by configuring the mirroring mode,
 * assigning the power function, and setting up the game state restoration function. If the
 * cartridge has a battery-backed RAM, it also initializes the save game memory area. Finally,
 * it adds the Mapper 80 state registers to the emulator's state management system.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 *             This includes details such as whether the cartridge has battery-backed RAM,
 *             the power function to be used, and the save game memory configuration.
 */
void Mapper80_Init(CartInfo *info) {
	isExMirr = 0;
	info->Power = M80Power;
	GameStateRestore = StateRestore;

	if (info->battery) {
		info->SaveGame[0] = wram;
		info->SaveGameLen[0] = 256;
	}

	AddExState(&StateRegs80, ~0, 0, 0);
}

/**
 * Initializes the Mapper 95 for the given cartridge information.
 * This method sets up the necessary configurations for Mapper 95, including:
 * - Setting the mirroring mode to ExMirr (external mirroring).
 * - Assigning the power function to M95Power.
 * - Setting the PPU hook to MExMirrPPU for handling PPU events.
 * - Assigning the game state restore function to StateRestore.
 * - Adding the state registers for Mapper 95 using AddExState.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void Mapper95_Init(CartInfo *info) {
	isExMirr = 1;
	info->Power = M95Power;
	PPU_hook = MExMirrPPU;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs95, ~0, 0, 0);
}

/**
 * Initializes the Mapper 207 for the emulated NES cartridge.
 * 
 * This function sets up the necessary configurations for Mapper 207, including:
 * - Enabling extended mirroring by setting `isExMirr` to 1.
 * - Assigning the `M207Power` function to the `Power` callback in the `CartInfo` structure.
 * - Setting the `PPU_hook` to `MExMirrPPU` to handle PPU-related operations.
 * - Assigning the `StateRestore` function to the `GameStateRestore` callback.
 * - Adding the state registers for Mapper 207 using `AddExState` to ensure proper state saving and loading.
 * 
 * @param info Pointer to the `CartInfo` structure containing cartridge information and callbacks.
 */
void Mapper207_Init(CartInfo *info) {
	isExMirr = 1;
	info->Power = M207Power;
	PPU_hook = MExMirrPPU;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs207, ~0, 0, 0);
}
