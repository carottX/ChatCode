/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2011 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Super Game (Sugar Softec) protected mapper
 * Pocahontas 2 (Unl) [U][!], etc.
 * TODO: 9in1 LION KING HANGS!
 */

#include "mapinc.h"
#include "mmc3.h"

static uint8 cmdin;

static uint8 regperm[8][8] =
{
	{ 0, 1, 2, 3, 4, 5, 6, 7 },
	{ 0, 2, 6, 1, 7, 3, 4, 5 },
	{ 0, 5, 4, 1, 7, 2, 6, 3 },   // unused
	{ 0, 6, 3, 7, 5, 2, 4, 1 },
	{ 0, 2, 5, 3, 6, 1, 7, 4 },
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // empty
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // empty
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // empty
};

static uint8 adrperm[8][8] =
{
	{ 0, 1, 2, 3, 4, 5, 6, 7 },
	{ 3, 2, 0, 4, 1, 5, 6, 7 },
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // unused
	{ 5, 0, 1, 2, 3, 7, 6, 4 },
	{ 3, 1, 0, 5, 2, 4, 6, 7 },
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // empty
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // empty
	{ 0, 1, 2, 3, 4, 5, 6, 7 },   // empty
};

/**
 * @brief Configures the CHR (Character) memory mapping for a specific address.
 *
 * This method sets up the CHR memory mapping for the given address `A` based on the value `V` 
 * and the contents of the `EXPREGS` array. The behavior depends on the configuration bits in `EXPREGS[0]` 
 * and `EXPREGS[1]`:
 * - If bit 0x40 in `EXPREGS[0]` is set, the CHR mapping is calculated using a combination of bits from 
 *   `EXPREGS[1]` and `V`. Specifically, bits 0xC from `EXPREGS[1]` are shifted left by 6, combined with 
 *   the lower 7 bits of `V`, and further combined with bit 0x20 from `EXPREGS[1]` shifted left by 2.
 * - If bit 0x40 in `EXPREGS[0]` is not set, the CHR mapping is calculated using bits 0xC from `EXPREGS[1]` 
 *   shifted left by 6 and directly combined with `V`.
 *
 * @param A The address in CHR memory to configure.
 * @param V The value used to determine the CHR mapping.
 */
static void UNL8237CW(uint32 A, uint8 V) {
	if (EXPREGS[0] & 0x40)
		setchr1(A, ((EXPREGS[1] & 0xc) << 6) | (V & 0x7F) | ((EXPREGS[1] & 0x20) << 2));
	else
		setchr1(A, ((EXPREGS[1] & 0xc) << 6) | V);
}

/**
 * @brief Configures the PRG ROM banking for the UNL8237PW mapper.
 *
 * This method handles the PRG ROM banking logic based on the values stored in the EXPREGS array.
 * It supports different banking modes depending on the configuration bits in EXPREGS[0] and EXPREGS[1].
 *
 * The method checks the following bits in EXPREGS[0]:
 * - Bit 6 (0x40): Determines whether to use a special banking mode.
 * - Bit 7 (0x80): Determines whether to use 8KB or 16KB/32KB banking.
 * - Bit 5 (0x20): Determines whether to use 32KB banking (if 16KB/32KB mode is active).
 *
 * The method also uses bits from EXPREGS[1] and the input value V to calculate the bank number.
 *
 * @param A The address where the PRG ROM bank should be mapped.
 * @param V The value used to calculate the bank number in certain modes.
 */
static void UNL8237PW(uint32 A, uint8 V) {
	if (EXPREGS[0] & 0x40) {
		uint8 sbank = (EXPREGS[1] & 0x10);
		if (EXPREGS[0] & 0x80) {
			uint8 bank = ((EXPREGS[1] & 3) << 4) | (EXPREGS[0] & 0x7) | (sbank >> 1);
			if (EXPREGS[0] & 0x20)
				setprg32(0x8000, bank >> 1);
			else{
				setprg16(0x8000, bank);
				setprg16(0xC000, bank);
			}
		} else
			setprg8(A, ((EXPREGS[1] & 3) << 5) | (V & 0x0F) | sbank);
	} else {
		if (EXPREGS[0] & 0x80) {
			uint8 bank = ((EXPREGS[1] & 3) << 4) | (EXPREGS[0] & 0xF);
			if (EXPREGS[0] & 0x20)
				setprg32(0x8000, bank >> 1);
			else{
				setprg16(0x8000, bank);
				setprg16(0xC000, bank);
			}
		} else
			setprg8(A, ((EXPREGS[1] & 3) << 5) | (V & 0x1F));
	}
}

/**
 * @brief Sets the CHR (Character) memory bank for the UNL8237ACW mapper.
 *
 * This method configures the CHR memory bank based on the values stored in the `EXPREGS` array.
 * The specific bank configuration depends on the bitmask applied to `EXPREGS[0]` and `EXPREGS[1]`.
 * 
 * If bit 6 (0x40) of `EXPREGS[0]` is set, the CHR bank is configured using a combination of bits from
 * `EXPREGS[1]` and the input value `V`. Specifically:
 * - Bits 1-3 (0xE) of `EXPREGS[1]` are shifted left by 7 positions.
 * - The lower 7 bits (0x7F) of `V` are included.
 * - Bit 5 (0x20) of `EXPREGS[1]` is shifted left by 2 positions.
 *
 * If bit 6 of `EXPREGS[0]` is not set, the CHR bank is configured using only bits 1-3 of `EXPREGS[1]`
 * shifted left by 7 positions and the full value of `V`.
 *
 * @param A The address to set the CHR bank for.
 * @param V The value used to configure the CHR bank.
 */
static void UNL8237ACW(uint32 A, uint8 V) {
	if (EXPREGS[0] & 0x40)
		setchr1(A, ((EXPREGS[1] & 0xE) << 7) | (V & 0x7F) | ((EXPREGS[1] & 0x20) << 2));
	else
		setchr1(A, ((EXPREGS[1] & 0xE) << 7) | V);
}

/**
 * @brief Handles the memory mapping for the UNL8237A mapper.
 *
 * This method is responsible for configuring the Programmable Read-Only Memory (PRG-ROM) 
 * banks based on the values in the `EXPREGS` array and the provided address `A` and value `V`.
 * The method uses bitwise operations to determine the appropriate bank configuration and 
 * sets the PRG-ROM banks accordingly using the `setprg8`, `setprg16`, and `setprg32` functions.
 *
 * The behavior of this method depends on the flags set in `EXPREGS[0]` and `EXPREGS[1]`:
 * - If `EXPREGS[0] & 0x40` is true, the method uses a specific bank calculation logic.
 * - If `EXPREGS[0] & 0x80` is true, the method configures either 32KB or 16KB PRG-ROM banks.
 * - If `EXPREGS[0] & 0x20` is true, the method configures 32KB PRG-ROM banks.
 * - Otherwise, the method configures 8KB PRG-ROM banks based on the provided address `A` and value `V`.
 *
 * @param A The address used to determine the PRG-ROM bank configuration.
 * @param V The value used to calculate the PRG-ROM bank index.
 */
static void UNL8237APW(uint32 A, uint8 V) {
	if (EXPREGS[0] & 0x40) {
		uint8 sbank = (EXPREGS[1] & 0x10);
		if (EXPREGS[0] & 0x80) {
			uint8 bank = ((EXPREGS[1] & 3) << 4) | ((EXPREGS[1] & 8) << 3) | (EXPREGS[0] & 0x7) | (sbank >> 1);
			if (EXPREGS[0] & 0x20) {
//				FCEU_printf("8000:%02X\n",bank>>1);
				setprg32(0x8000, bank >> 1);
			} else {
//				FCEU_printf("8000-C000:%02X\n",bank);
				setprg16(0x8000, bank);
				setprg16(0xC000, bank);
			}
		} else {
//			FCEU_printf("%04x:%02X\n",A,((EXPREGS[1]&3)<<5)|((EXPREGS[1]&8)<<4)|(V&0x0F)|sbank);
			setprg8(A, ((EXPREGS[1] & 3) << 5) | ((EXPREGS[1] & 8) << 4) | (V & 0x0F) | sbank);
		}
	} else {
		if (EXPREGS[0] & 0x80) {
			uint8 bank = ((EXPREGS[1] & 3) << 4) | ((EXPREGS[1] & 8) << 3) | (EXPREGS[0] & 0xF);
			if (EXPREGS[0] & 0x20) {
//				FCEU_printf("8000:%02X\n",(bank>>1)&0x07);
				setprg32(0x8000, bank >> 1);
			} else {
//				FCEU_printf("8000-C000:%02X\n",bank&0x0F);
				setprg16(0x8000, bank);
				setprg16(0xC000, bank);
			}
		} else {
//			FCEU_printf("%04X:%02X\n",A,(((EXPREGS[1]&3)<<5)|((EXPREGS[1]&8)<<4)|(V&0x1F))&0x1F);
			setprg8(A, ((EXPREGS[1] & 3) << 5) | ((EXPREGS[1] & 8) << 4) | (V & 0x1F));
		}
	}
}
/**
 * @brief Writes data to the UNL8237 mapper's registers or IRQ counter.
 *
 * This method handles the write operation for the UNL8237 mapper, which is used in certain NES cartridges.
 * It processes the address and data to determine the appropriate register or IRQ counter to update.
 *
 * The method performs the following steps:
 * 1. Extracts the data to be written from the input parameter `V`.
 * 2. Determines the mapped address using the `adrperm` lookup table, which is indexed by the value in `EXPREGS[2]`
 *    and the address bits from `A` (specifically, bits 12 and 1).
 * 3. Constructs the final address by combining the mapped address bits with a base address of 0x8000.
 * 4. If the mapped address is less than 4, it updates the corresponding register using `MMC3_CMDWrite`.
 *    - If the mapped address is 0, the data is further modified using the `regperm` lookup table.
 * 5. If the mapped address is 4 or greater, it updates the IRQ counter using `MMC3_IRQWrite`.
 *
 * @param A The address to write to, used to determine the register or IRQ counter.
 * @param V The data to write, which may be modified before being written.
 */
static DECLFW(UNL8237Write) {
	uint8 dat = V;
	uint8 adr = adrperm[EXPREGS[2]][((A >> 12) & 6) | (A & 1)];
	uint16 addr = (adr & 1) | ((adr & 6) << 12) | 0x8000;
	if (adr < 4) {
		if (!adr)
			dat = (dat & 0xC0) | (regperm[EXPREGS[2]][dat & 7]);
		MMC3_CMDWrite(addr, dat);
	} else
		MMC3_IRQWrite(addr, dat);
}

/**
 * @brief Handles write operations for the UNL8237Ex mapper.
 *
 * This method processes write operations to specific memory addresses (0x5000, 0x5001, and 0x5007)
 * and updates the corresponding registers in the EXPREGS array. Depending on the address written to,
 * it may also trigger additional functions to fix the MMC3 PRG and CHR mappings.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 *
 * @details
 * - If the address is 0x5000, the value is written to EXPREGS[0], and FixMMC3PRG is called with MMC3_cmd.
 * - If the address is 0x5001, the value is written to EXPREGS[1], and both FixMMC3PRG and FixMMC3CHR are called with MMC3_cmd.
 * - If the address is 0x5007, the value is written to EXPREGS[2].
 */
static DECLFW(UNL8237ExWrite) {
	switch (A) {
	case 0x5000: EXPREGS[0] = V; FixMMC3PRG(MMC3_cmd); break;
	case 0x5001: EXPREGS[1] = V; FixMMC3PRG(MMC3_cmd); FixMMC3CHR(MMC3_cmd); break;
	case 0x5007: EXPREGS[2] = V; break;
	}
}

/**
 * @brief Initializes the power state for the UNL8237 mapper.
 *
 * This method sets up the initial state of the UNL8237 mapper by configuring the
 * expansion registers (EXPREGS) and initializing the MMC3 power state. It also
 * sets up write handlers for specific memory ranges:
 * - Writes to the range 0x8000-0xFFFF are handled by UNL8237Write.
 * - Writes to the range 0x5000-0x7FFF are handled by UNL8237ExWrite.
 *
 * The method performs the following steps:
 * 1. Clears EXPREGS[0] and EXPREGS[2] by setting them to 0.
 * 2. Sets EXPREGS[1] to 3.
 * 3. Calls GenMMC3Power() to initialize the MMC3 power state.
 * 4. Sets up write handlers for the specified memory ranges.
 */
static void UNL8237Power(void) {
	EXPREGS[0] = EXPREGS[2] = 0;
	EXPREGS[1] = 3;
	GenMMC3Power();
	SetWriteHandler(0x8000, 0xFFFF, UNL8237Write);
	SetWriteHandler(0x5000, 0x7FFF, UNL8237ExWrite);
}

/**
 * Initializes the UNL8237 mapper for the given cartridge information.
 * This method sets up the mapper by initializing the MMC3 base functionality
 * with specific parameters (256 KB PRG ROM, 256 KB CHR ROM, and no WRAM).
 * It also configures custom CHR and PRG wrapper functions for the mapper,
 * sets the power cycle handler, and adds additional state information
 * for emulator save states.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific
 *             information required for initialization.
 */
void UNL8237_Init(CartInfo *info) {
	GenMMC3_Init(info, 256, 256, 0, 0);
	cwrap = UNL8237CW;
	pwrap = UNL8237PW;
	info->Power = UNL8237Power;
	AddExState(EXPREGS, 3, 0, "EXPR");
	AddExState(&cmdin, 1, 0, "CMDI");
}

/**
 * @brief Initializes the UNL8237A mapper for the emulator.
 *
 * This method sets up the UNL8237A mapper by initializing the MMC3 base functionality
 * with specific parameters: 256 KB of PRG-ROM and 256 KB of CHR-ROM, with no WRAM or
 * battery-backed RAM. It also configures custom wrapper functions for CHR and PRG banking
 * (UNL8237ACW and UNL8237APW, respectively) and assigns the power function (UNL8237Power)
 * to the provided CartInfo structure. Additionally, it adds external state information
 * for the mapper's internal registers (EXPREGS) and command input (cmdin) to ensure
 * proper state saving and loading during emulation.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void UNL8237A_Init(CartInfo *info) {
	GenMMC3_Init(info, 256, 256, 0, 0);
	cwrap = UNL8237ACW;
	pwrap = UNL8237APW;
	info->Power = UNL8237Power;
	AddExState(EXPREGS, 3, 0, "EXPR");
	AddExState(&cmdin, 1, 0, "CMDI");
}
