/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 regs[8];
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ regs, 8, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping configuration of the program and character ROMs.
 *
 * This method configures the memory mapping for the program and character ROMs by setting
 * the appropriate memory regions using the provided registers. It performs the following operations:
 * - Sets the program ROM (PRG) memory regions at specific addresses using values from the `regs` array.
 * - Sets the character ROM (CHR) memory regions at specific addresses using values from the `regs` array.
 *
 * Specifically:
 * - The PRG memory is configured in 8 KB blocks at addresses 0x8000, 0xA000, 0xC000, and 0xE000.
 * - The CHR memory is configured in 2 KB blocks at addresses 0x0000, 0x0800, 0x1000, and 0x1800.
 * - Additionally, a 2 KB PRG memory region is set at address 0x6800 using a fixed value of 0x10.
 *
 * @note This method assumes that the `regs` array contains valid values for the memory mapping configuration.
 */
static void Sync(void) {
	setprg2r(0x10, 0x6800, 0);
	setprg8(0x8000, regs[0]);
	setprg8(0xA000, regs[1]);
	setprg8(0xC000, regs[2]);
	setprg8(0xE000, regs[3]);
	setchr2(0x0000, regs[4]);
	setchr2(0x0800, regs[5]);
	setchr2(0x1000, regs[6]);
	setchr2(0x1800, regs[7]);
}

/**
 * @brief Writes a value to a specific register in the M246 register set and synchronizes the state.
 *
 * This method writes the value `V` to the register indexed by the lower 3 bits of the address `A` 
 * in the `regs` array. After writing the value, it calls the `Sync()` method to ensure that the 
 * system state is updated accordingly.
 *
 * @param A The address used to determine the register index. Only the lower 3 bits are used.
 * @param V The value to be written to the selected register.
 */
static DECLFW(M246Write) {
	regs[A & 7] = V;
	Sync();
}

/**
 * @brief Initializes the M246 memory mapper by setting up the necessary handlers and registers.
 * 
 * This method performs the following operations:
 * 1. Sets all registers (regs[0] to regs[3]) to their maximum value (0xFFFFFFFF).
 * 2. Synchronizes the state of the emulator by calling the Sync() function.
 * 3. Sets up write handlers for the memory ranges 0x6000-0x67FF and 0x6800-0x6FFF, using the M246Write and CartBW functions respectively.
 * 4. Sets up read handlers for the memory ranges 0x6800-0x6FFF and 0x8000-0xFFFF, using the CartBR function.
 * 5. Adds RAM for cheat functionality using the FCEU_CheatAddRAM function, specifying the size of the WRAM and its starting address.
 * 
 * This method is typically called during the initialization of the M246 memory mapper to ensure proper memory handling and synchronization.
 */
static void M246Power(void) {
	regs[0] = regs[1] = regs[2] = regs[3] = ~0;
	Sync();
	SetWriteHandler(0x6000, 0x67FF, M246Write);
	SetReadHandler(0x6800, 0x6FFF, CartBR);
	SetWriteHandler(0x6800, 0x6FFF, CartBW);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) used by the system.
 *
 * This method checks if the WRAM pointer is not null. If it is not null, 
 * it deallocates the memory associated with WRAM using the FCEU_gfree function 
 * and then sets the WRAM pointer to null to indicate that the memory has been 
 * freed and is no longer in use. This ensures that there are no memory leaks 
 * and that the WRAM is properly cleaned up when it is no longer needed.
 */
static void M246Close(void)
{
	if(WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system state to a specific version.
 * It ensures that all necessary data and configurations are synchronized before
 * proceeding with the restoration process. The `Sync()` method is called to
 * guarantee that any pending operations are completed and the system is in a
 * consistent state before the restoration begins.
 *
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 246 for the provided cartridge information.
 * This method sets up the necessary function pointers for power and close operations,
 * allocates Work RAM (WRAM) for the cartridge, and configures the PRG mapping.
 * Additionally, it handles the saving and restoring of the game state if the cartridge
 * has a battery backup. The method also adds the WRAM and state registers to the
 * emulator's state system for proper state saving and loading.
 *
 * @param info A pointer to the CartInfo structure containing cartridge-specific
 *             information, such as whether the cartridge has a battery backup.
 */
void Mapper246_Init(CartInfo *info) {
	info->Power = M246Power;
	info->Close = M246Close;
	GameStateRestore = StateRestore;

	WRAMSIZE = 2048;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}

	AddExState(&StateRegs, ~0, 0, 0);
}
