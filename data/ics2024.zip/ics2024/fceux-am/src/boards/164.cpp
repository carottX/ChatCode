/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel 2006 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * It seems that 162/163/164 mappers are the same mapper with just different
 * mapper modes enabled or disabled in software or hardware, need more nanjing
 * carts
 */

#include "mapinc.h"

static uint8 laststrobe, trigger;
static uint8 reg[8];
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static writefunc pcmwrite;

static void (*WSync)(void);

static SFORMAT StateRegs[] =
{
	{ &laststrobe, 1, "STB" },
	{ &trigger, 1, "TRG" },
	{ reg, 8, "REGS" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and configuration of the program and character ROMs.
 * 
 * This method performs the following operations:
 * 1. Sets the program ROM (PRG) bank at address 0x6000 using the specified bank number (0x10) and 
 *    configures it to use the first bank (0) for the specified range.
 * 2. Sets the PRG ROM at address 0x8000 by combining the values from `reg[0]` and `reg[1]` to form 
 *    a 32-bit bank number. The value is calculated as `(reg[0] << 4) | (reg[1] & 0xF)`.
 * 3. Sets the character ROM (CHR) to use the first bank (0) for the entire 8 KB range.
 * 
 * This method is typically used to update the memory mapping configuration during runtime.
 */
static void Sync(void) {
	setprg8r(0x10, 0x6000, 0);
	setprg32(0x8000, (reg[0] << 4) | (reg[1] & 0xF));
	setchr8(0);
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the state of the system based on the provided version number. 
 * It ensures that the system is synchronized before proceeding with the restoration process by calling the WSync() function.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	WSync();
}

/**
 * @brief Reads data from a low memory address based on the provided address mask.
 *
 * This method reads data from a specific low memory address based on the value of the address
 * masked with 0x7700. The method handles two specific cases:
 * - If the masked address is 0x5100, it returns a combination of values from registers `reg[0]`,
 *   `reg[1]`, `reg[2]`, and the inverted value of `reg[3]`.
 * - If the masked address is 0x5500, it returns a combination of values from `reg[1]` and `reg[2]`
 *   if the `trigger` condition is true. Otherwise, it returns 0.
 * If the address does not match any of the specified cases, the method returns a default value of 4.
 *
 * @param A The memory address to read from, masked with 0x7700 to determine the specific case.
 * @return The data read from the specified memory address or a default value if no case matches.
 */
static DECLFR(ReadLow) {
	switch (A & 0x7700) {
	case 0x5100: return reg[2] | reg[0] | reg[1] | (reg[3] ^ 0xff); break;
	case 0x5500:
		if (trigger)
			return reg[2] | reg[1];   // Lei Dian Huang Bi Ka Qiu Chuan Shuo (NJ046) may broke other games
		else
			return 0;
	}
	return 4;
}

/**
 * @brief Handles CHR ROM bank switching for Mapper 163 (Nanjing) based on the current scanline and register state.
 *
 * This method is responsible for dynamically switching CHR ROM banks during rendering, specifically for Mapper 163.
 * It checks the value of `reg[1]` to determine if bank switching is enabled (bit 7 is set). If enabled, it switches
 * the CHR ROM banks based on the current scanline:
 * - If the scanline is 239, it sets both CHR banks 0x0000 and 0x1000 to bank 0.
 * - If the scanline is 127, it sets both CHR banks 0x0000 and 0x1000 to bank 1.
 *
 * This behavior is used to support specific games (e.g., "Hu Lu Jin Gang") that require dynamic CHR bank switching
 * during rendering. The commented-out block suggests an alternative implementation that switches banks based on
 * whether the scanline is above or below 127, but it is not used in the current implementation.
 */
static void M163HB(void) {
	if (reg[1] & 0x80) {
		if (scanline == 239) {
			setchr4(0x0000, 0);
			setchr4(0x1000, 0);
		} else if (scanline == 127) {
			setchr4(0x0000, 1);
			setchr4(0x1000, 1);
		}
/*
			if(scanline>=127)     // Hu Lu Jin Gang (NJ039) (Ch) [!] don't like it
			{
				setchr4(0x0000,1);
				setchr4(0x1000,1);
			}
			else
			{
				setchr4(0x0000,0);
				setchr4(0x1000,0);
			}
*/
	}
}

/**
 * @brief Writes a value to a specific register based on the address provided.
 *
 * This method handles writing a value (`V`) to one of the registers (`reg`) based on the address (`A`) provided.
 * The address is masked with `0x7300` to determine which register to write to:
 * - If the masked address is `0x5100`, the value is written to `reg[0]` and `WSync()` is called.
 * - If the masked address is `0x5000`, the value is written to `reg[1]` and `WSync()` is called.
 * - If the masked address is `0x5300`, the value is written to `reg[2]`.
 * - If the masked address is `0x5200`, the value is written to `reg[3]` and `WSync()` is called.
 *
 * @param A The address used to determine which register to write to.
 * @param V The value to be written to the selected register.
 */
static DECLFW(Write) {
	switch (A & 0x7300) {
	case 0x5100: reg[0] = V; WSync(); break;
	case 0x5000: reg[1] = V; WSync(); break;
	case 0x5300: reg[2] = V; break;
	case 0x5200: reg[3] = V; WSync(); break;
	}
}

/**
 * @brief Initializes the power state of the system by resetting registers, setting up memory handlers, and synchronizing the system.
 * 
 * This method performs the following operations:
 * 1. Clears the first 8 bytes of the `reg` array by setting them to 0.
 * 2. Sets the second byte of the `reg` array to 0xFF.
 * 3. Configures a write handler for the memory range 0x5000 to 0x5FFF using the `Write` function.
 * 4. Configures a read handler for the memory range 0x6000 to 0xFFFF using the `CartBR` function.
 * 5. Configures a write handler for the memory range 0x6000 to 0x7FFF using the `CartBW` function.
 * 6. Adds RAM for cheat functionality using `FCEU_CheatAddRAM`, with the size of WRAM divided by 1024, starting at address 0x6000.
 * 7. Synchronizes the system state by calling `WSync`.
 */
static void Power(void) {
	memset(reg, 0, 8);
	reg[1] = 0xFF;
	SetWriteHandler(0x5000, 0x5FFF, Write);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
	WSync();
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) memory.
 * 
 * This method checks if the WRAM pointer is not null. If it is not null,
 * it deallocates the memory associated with WRAM using the FCEU_gfree function.
 * After deallocation, the WRAM pointer is set to null to indicate that the
 * memory has been released and is no longer accessible.
 * 
 * @note This method is static and can be called without an instance of the class.
 */
static void Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Initializes the Mapper 164 for the provided cartridge information.
 *
 * This method sets up the necessary configurations for Mapper 164, including:
 * - Assigning the `Power` and `Close` functions to the cartridge info.
 * - Synchronizing the write operation using the `Sync` function.
 * - Allocating 8192 bytes of Work RAM (WRAM) and mapping it to the cartridge's PRG space.
 * - Adding the WRAM to the external state for save/restore operations.
 * - If the cartridge has a battery backup, configuring the WRAM as the save game memory.
 * - Setting up the game state restoration function and adding the state registers to the external state.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific information.
 */
void Mapper164_Init(CartInfo *info) {
	info->Power = Power;
	info->Close = Close;
	WSync = Sync;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}

	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * @brief Handles write operations to specific memory addresses, performing various actions based on the address and value.
 *
 * This method processes write operations to memory addresses, particularly focusing on addresses 0x5101, 0x5100, and a range of addresses masked with 0x7300. 
 * - If the address is 0x5101, it toggles the `trigger` flag when the strobe signal (`laststrobe`) transitions from high to low.
 * - If the address is 0x5100 and the value is 6, it sets the program ROM bank to 3 at the base address 0x8000.
 * - For addresses masked with 0x7300, it updates specific registers (`reg[0]`, `reg[1]`, `reg[2]`, `reg[3]`) and performs additional actions:
 *   - For address 0x5200, it updates `reg[0]` and calls `WSync()`.
 *   - For address 0x5000, it updates `reg[1]`, calls `WSync()`, and sets the character ROM bank to 0 if certain conditions are met.
 *   - For address 0x5300, it updates `reg[2]`.
 *   - For address 0x5100, it updates `reg[3]` and calls `WSync()`.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(Write2) {
	if (A == 0x5101) {
		if (laststrobe && !V) {
			trigger ^= 1;
		}
		laststrobe = V;
	} else if (A == 0x5100 && V == 6) //damn thoose protected games
		setprg32(0x8000, 3);
	else
		switch (A & 0x7300) {
		case 0x5200: reg[0] = V; WSync(); break;
		case 0x5000: reg[1] = V; WSync(); if (!(reg[1] & 0x80) && (scanline < 128)) setchr8(0); /* setchr8(0); */ break;
		case 0x5300: reg[2] = V; break;
		case 0x5100: reg[3] = V; WSync(); break;
		}
}

/**
 * @brief Initializes the Power2 functionality by setting up memory handlers and synchronization.
 *
 * This method performs the following operations:
 * 1. Clears the `reg` array by setting all its elements to 0.
 * 2. Sets the `laststrobe` variable to 1.
 * 3. Assigns the PCM write handler to the address 0x4011 using `GetWriteHandler`.
 * 4. Sets up read and write handlers for specific memory ranges:
 *    - Read handler for the range 0x5000 to 0x5FFF is set to `ReadLow`.
 *    - Write handler for the range 0x5000 to 0x5FFF is set to `Write2`.
 *    - Read handler for the range 0x6000 to 0xFFFF is set to `CartBR`.
 *    - Write handler for the range 0x6000 to 0x7FFF is set to `CartBW`.
 * 5. Adds RAM for cheat functionality using `FCEU_CheatAddRAM` with the specified size and address.
 * 6. Synchronizes the state by calling `WSync`.
 */
static void Power2(void) {
	memset(reg, 0, 8);
	laststrobe = 1;
	pcmwrite = GetWriteHandler(0x4011);
	SetReadHandler(0x5000, 0x5FFF, ReadLow);
	SetWriteHandler(0x5000, 0x5FFF, Write2);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
	WSync();
}

/**
 * @brief Initializes the Mapper 163 for the provided cartridge information.
 *
 * This function sets up the necessary configurations for Mapper 163, which is used in certain NES cartridges.
 * It assigns the power and close functions, sets the synchronization function, and configures the HBI (Horizontal Blank Interrupt) hook.
 * Additionally, it allocates memory for the WRAM (Work RAM) and sets up the PRG (Program ROM) mapping.
 * If the cartridge has a battery-backed save feature, it configures the save game memory.
 * Finally, it sets up the game state restoration and adds the state registers for emulation purposes.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 */
void Mapper163_Init(CartInfo *info) {
	info->Power = Power2;
	info->Close = Close;
	WSync = Sync;
	GameHBIRQHook = M163HB;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

/**
 * @brief Synchronizes the memory mapping configuration for the emulated system.
 *
 * This method configures the CHR and PRG memory banks based on the values stored in the `reg` array.
 * It first sets the CHR bank to 0 using `setchr8(0)`, then configures the PRG bank at address 0x6000
 * using `setprg8r(0x10, 0x6000, 0)`. The method then examines the lower 3 bits of `reg[3]` to determine
 * the appropriate PRG bank configuration at address 0x8000. The specific configuration depends on the
 * value of `reg[3] & 7`:
 * - Cases 0 and 2: Combines bits from `reg[0]`, `reg[1]`, and `reg[2]` to set the PRG bank.
 * - Cases 1 and 3: Combines bits from `reg[0]` and `reg[2]` to set the PRG bank.
 * - Cases 4 and 6: Combines bits from `reg[0]`, `reg[1]`, and `reg[2]` to set the PRG bank.
 * - Cases 5 and 7: Combines bits from `reg[0]` and `reg[2]` to set the PRG bank.
 *
 * This method is typically used to update the memory mapping during emulation when the configuration
 * registers change.
 */
static void Sync3(void) {
	setchr8(0);
	setprg8r(0x10, 0x6000, 0);
	switch (reg[3] & 7) {
	case 0:
	case 2: setprg32(0x8000, (reg[0] & 0xc) | (reg[1] & 2) | ((reg[2] & 0xf) << 4)); break;
	case 1:
	case 3: setprg32(0x8000, (reg[0] & 0xc) | (reg[2] & 0xf) << 4); break;
	case 4:
	case 6: setprg32(0x8000, (reg[0] & 0xe) | ((reg[1] >> 1) & 1) | ((reg[2] & 0xf) << 4)); break;
	case 5:
	case 7: setprg32(0x8000, (reg[0] & 0xf) | ((reg[2] & 0xf) << 4)); break;
	}
}

/**
 * @brief Writes a value to a specific register based on the provided address.
 *
 * This method writes the given value `V` to a register determined by the address `A`.
 * The register is selected by taking the upper 2 bits of the address `A` (shifted right by 8)
 * and masking it with 3 to ensure it falls within the range of 0 to 3. After updating the
 * register, the `WSync()` function is called to synchronize the write operation.
 *
 * @param A The address used to determine the register index.
 * @param V The value to be written to the selected register.
 */
static DECLFW(Write3) {
//	FCEU_printf("bs %04x %02x\n",A,V);
	reg[(A >> 8) & 3] = V;
	WSync();
}

/**
 * @brief Configures the memory mapping and handlers for a Power3 cartridge.
 *
 * This method initializes the registers and sets up the memory handlers for a Power3 cartridge.
 * It sets the first four registers to specific values (3, 0, 0, 7) and configures the read and write
 * handlers for specific memory ranges. Additionally, it adds RAM for cheat functionality and
 * synchronizes the write operations.
 *
 * The method performs the following operations:
 * 1. Sets `reg[0]` to 3, `reg[1]` to 0, `reg[2]` to 0, and `reg[3]` to 7.
 * 2. Configures a write handler for the memory range 0x5000 to 0x5FFF using the `Write3` function.
 * 3. Configures a read handler for the memory range 0x6000 to 0xFFFF using the `CartBR` function.
 * 4. Configures a write handler for the memory range 0x6000 to 0x7FFF using the `CartBW` function.
 * 5. Adds RAM for cheat functionality, using `WRAMSIZE >> 10` as the size, starting at address 0x6000,
 *    and using `WRAM` as the RAM buffer.
 * 6. Synchronizes the write operations by calling `WSync()`.
 */
static void Power3(void) {
	reg[0] = 3;
	reg[1] = 0;
	reg[2] = 0;
	reg[3] = 7;
	SetWriteHandler(0x5000, 0x5FFF, Write3);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
	WSync();
}

/**
 * Initializes the UNLFS304 cartridge by setting up the necessary configurations and memory mappings.
 * 
 * This function performs the following operations:
 * 1. Sets the `Power` and `Close` function pointers in the `CartInfo` structure to `Power3` and `Close` respectively.
 * 2. Assigns the `WSync` function pointer to `Sync3`.
 * 3. Allocates 8192 bytes of Work RAM (WRAM) using `FCEU_gmalloc` and sets up the PRG mapping for this memory.
 * 4. Adds the WRAM to the external state for saving and restoring the game state.
 * 5. If the cartridge has a battery, it configures the `SaveGame` and `SaveGameLen` fields in the `CartInfo` structure to save the WRAM contents.
 * 6. Sets the `GameStateRestore` function pointer to `StateRestore` and adds the state registers to the external state.
 * 
 * @param info A pointer to the `CartInfo` structure that contains the cartridge configuration and state information.
 */
void UNLFS304_Init(CartInfo *info) {
	info->Power = Power3;
	info->Close = Close;
	WSync = Sync3;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}

	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
