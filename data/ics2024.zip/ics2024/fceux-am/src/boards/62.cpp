/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 bank;
static uint16 mode;
static SFORMAT StateRegs[] =
{
	{ &bank, 1, "BANK" },
	{ &mode, 2, "MODE" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current mode and bank settings.
 *
 * This method updates the CHR (Character ROM) and PRG (Program ROM) memory mappings, as well as the mirroring mode,
 * according to the values stored in the `mode` and `bank` variables. The method performs the following operations:
 *
 * 1. Sets the 8KB CHR memory bank using the lower 5 bits of `mode` and the lower 2 bits of `bank`.
 * 2. If bit 5 of `mode` is set, it configures two 16KB PRG memory banks at addresses 0x8000 and 0xC000 using bits 6 and 8-13 of `mode`.
 *    Otherwise, it configures a single 32KB PRG memory bank at address 0x8000 using the same bits.
 * 3. Sets the mirroring mode based on bit 7 of `mode`, toggling between horizontal and vertical mirroring.
 *
 * This method is typically called whenever the `mode` or `bank` values are updated to ensure the memory mappings and
 * mirroring are correctly applied.
 */
static void Sync(void) {
	setchr8(((mode & 0x1F) << 2) | (bank & 0x03));
	if (mode & 0x20) {
		setprg16(0x8000, (mode & 0x40) | ((mode >> 8) & 0x3F));
		setprg16(0xc000, (mode & 0x40) | ((mode >> 8) & 0x3F));
	} else
		setprg32(0x8000, ((mode & 0x40) | ((mode >> 8) & 0x3F)) >> 1);
	setmirror(((mode >> 7) & 1) ^ 1);
}

/**
 * @brief Writes data to the M62 memory bank and updates the mode and bank registers.
 *
 * This method processes a write operation to the M62 memory bank. It updates the internal
 * `mode` register based on the lower 14 bits of the address (`A`) and the `bank` register
 * based on the lower 2 bits of the value (`V`). After updating these registers, it calls
 * the `Sync()` method to synchronize the state of the memory bank with the updated values.
 *
 * @param A The address used to determine the mode. Only the lower 14 bits are considered.
 * @param V The value used to determine the bank. Only the lower 2 bits are considered.
 */
static DECLFW(M62Write) {
	mode = A & 0x3FFF;
	bank = V & 3;
	Sync();
}

/**
 * @brief Initializes the M62 power state by resetting the bank and mode values,
 *        synchronizing the system, and setting up the read and write handlers
 *        for the specified memory range.
 *
 * This method performs the following operations:
 * 1. Resets the `bank` and `mode` variables to 0.
 * 2. Calls the `Sync()` function to synchronize the system state.
 * 3. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M62Write`.
 * 4. Sets the read handler for the memory range 0x8000 to 0xFFFF to `CartBR`.
 *
 * This method is typically called during the initialization or reset phase of
 * the M62 system to ensure a clean state and proper memory handling.
 */
static void M62Power(void) {
	bank = mode = 0;
	Sync();
	SetWriteHandler(0x8000, 0xFFFF, M62Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
}

/**
 * @brief Resets the M62 module to its initial state.
 *
 * This method sets the `bank` and `mode` variables to 0, effectively resetting
 * the M62 module to its default configuration. After resetting these variables,
 * the `Sync()` method is called to ensure that the module's state is properly
 * synchronized with the rest of the system.
 */
static void M62Reset(void) {
	bank = mode = 0;
	Sync();
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method is responsible for restoring the system's state based on the provided version.
 * It ensures that all necessary data and configurations are synchronized with the desired state
 * by calling the `Sync()` method, which handles the actual synchronization process.
 *
 * @param version The version of the state to restore. This parameter specifies which saved state
 *                should be used for the restoration process.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 62 for the given cartridge information.
 *
 * This function sets up the necessary function pointers and state information
 * for Mapper 62. It assigns the `Power` and `Reset` functions to the corresponding
 * handlers (`M62Power` and `M62Reset`). Additionally, it adds the state registers
 * to the emulator's state management system and sets the `GameStateRestore` function
 * to `StateRestore` to handle state restoration.
 *
 * @param info Pointer to the CartInfo structure that holds cartridge-specific
 *             information and function pointers.
 */
void Mapper62_Init(CartInfo *info) {
	info->Power = M62Power;
	info->Reset = M62Reset;
	AddExState(&StateRegs, ~0, 0, 0);
	GameStateRestore = StateRestore;
}
