/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2006 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * FDS Conversion
 *
 */

#include "mapinc.h"

static uint8 reg, swap;
static uint32 IRQCount, IRQa;

static SFORMAT StateRegs[] =
{
	{ &IRQCount, 4, "IRQC" },
	{ &IRQa, 4, "IRQA" },
	{ &reg, 1, "REG" },
	{ &swap, 1, "SWAP" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the emulator.
 *
 * This method configures the Programmable Read-Only Memory (PRG) and Character Read-Only Memory (CHR)
 * banks for the emulator. It sets the PRG banks at specific memory addresses, allowing the emulator
 * to switch between different memory banks dynamically. The method also handles special cases for
 * advanced versions of the emulator and ensures compatibility with specific ROM dumps.
 *
 * The PRG banks are configured as follows:
 * - 0x5000: Sets PRG bank 4 to a specific value for the YS-612 advanced version.
 * - 0x6000: Sets PRG bank 8 to either bank 0 or 2 based on the `swap` flag.
 * - 0x8000: Sets PRG bank 8 to bank 1.
 * - 0xa000: Sets PRG bank 8 to bank 0.
 * - 0xc000: Sets PRG bank 8 to the value stored in the `reg` variable.
 * - 0xe000: Sets PRG bank 8 to either bank 8 or 9 based on the `swap` flag. This is specifically
 *           for handling a hard dump of the "mr.Mary" ROM, which is 128K in size. Bank 9 is the
 *           last 2K of the ROM, and bank 8 is repeated 4 times. For compatibility with other
 *           ROM dumps, bank A (containing CHR data) is moved to the bank 9 position.
 *
 * Additionally, the CHR bank is set to 0, ensuring that the character memory is mapped correctly.
 */
static void Sync(void) {
	setprg4(0x5000, 8 << 1);	// Only YS-612 advanced version
	setprg8(0x6000, swap?0:2);
	setprg8(0x8000, 1);
	setprg8(0xa000, 0);
	setprg8(0xc000, reg);
	setprg8(0xe000, swap?8:9);	// hard dump for mr.Mary is 128K,
								// bank 9 is the last 2K ok bank 8 repeated 4 times, then till the end of 128K
								// instead used bank A, containing some CHR data, ines rom have unused banks removed,
								// and bank A moved to the bank 9 place for compatibility with other crappy dumps
	setchr8(0);
}

/**
 * @brief Handles write operations for M43 memory-mapped I/O.
 *
 * This method processes write operations to specific memory addresses related to the M43 hardware.
 * Depending on the address and the value written, it performs different actions:
 * - For address 0x4022, it updates a register (`reg`) based on a translation table (`transo`) and triggers a synchronization (`Sync()`).
 * - For address 0x4120, it updates a `swap` flag based on the written value and triggers a synchronization (`Sync()`).
 * - For addresses 0x4122 and 0x8122, it updates the IRQ enable flag (`IRQa`) and manages IRQ state using `X6502_IRQEnd` and `IRQCount`.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(M43Write) {
	//	int transo[8]={4,3,4,4,4,7,5,6};
	int transo[8] = { 4, 3, 5, 3, 6, 3, 7, 3 };	// According to hardware tests
	switch (A & 0xf1ff) {
	case 0x4022: reg = transo[V & 7]; Sync(); break;
	case 0x4120: swap = V & 1; Sync(); break;
	case 0x8122:																// hacked version
	case 0x4122: IRQa = V & 1; X6502_IRQEnd(FCEU_IQEXT); IRQCount = 0; break;	// original version
	}
}

/**
 * @brief Initializes the M43 power state by resetting internal registers and setting up memory handlers.
 *
 * This method performs the following operations:
 * 1. Resets the internal `reg` and `swap` variables to 0.
 * 2. Calls the `Sync()` function to synchronize the state.
 * 3. Sets a read handler for the memory range 0x5000 to 0xFFFF to use the `CartBR` function.
 * 4. Sets a write handler for the memory range 0x4020 to 0xFFFF to use the `M43Write` function.
 *
 * This is typically called during the initialization or reset phase of the M43 hardware.
 */
static void M43Power(void) {
	reg = swap = 0;
	Sync();
	SetReadHandler(0x5000, 0xffff, CartBR);
	SetWriteHandler(0x4020, 0xffff, M43Write);
}

/**
 * @brief Resets the M43 module to its initial state.
 *
 * This method performs a reset operation on the M43 module, restoring all internal
 * states, configurations, and registers to their default values. It is typically
 * called during system initialization or when a complete reset of the module is
 * required to ensure proper functionality.
 *
 * @note This method is static and does not require an instance of the class to be called.
 * It should be used with caution as it may affect the ongoing operations of the M43 module.
 */
static void M43Reset(void) {
}

/**
 * @brief Handles the M43 interrupt request (IRQ) by incrementing the IRQ counter and triggering an IRQ if necessary.
 *
 * This method is responsible for managing the M43 IRQ logic. It increments the IRQ counter by the specified value `a`.
 * If the IRQ is active (`IRQa` is true) and the IRQ counter reaches or exceeds the threshold of 4096, the IRQ is reset
 * (`IRQa` is set to 0) and an external IRQ is triggered using `X6502_IRQBegin` with the `FCEU_IQEXT` flag.
 *
 * @param a The value to add to the IRQ counter. This typically represents the number of cycles or events to count.
 */
static void M43IRQHook(int a) {
	IRQCount += a;
	if (IRQa)
		if (IRQCount >= 4096) {
			IRQa = 0;
			X6502_IRQBegin(FCEU_IQEXT);
		}
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the system state based on the provided version number.
 * It first ensures that all pending operations are synchronized by calling the `Sync()` method,
 * which guarantees that the system is in a consistent state before proceeding with the restoration.
 * 
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 43 configuration for the given cartridge information.
 *
 * This method sets up the necessary function pointers and state management for Mapper 43.
 * It assigns the reset and power functions to the corresponding handlers (`M43Reset` and `M43Power`),
 * hooks the IRQ handler (`M43IRQHook`), and sets up the game state restoration function (`StateRestore`).
 * Additionally, it adds the state registers to the emulator's state management system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure that holds the cartridge configuration and state.
 */
void Mapper43_Init(CartInfo *info) {
	info->Reset = M43Reset;
	info->Power = M43Power;
	MapIRQHook = M43IRQHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
