/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2009 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 chrlo[8], chrhi[8], prg, mirr, mirrisused = 0;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ &prg, 1, "PREG" },
	{ chrlo, 8, "CRGL" },
	{ chrhi, 8, "CRGH" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration for a NES emulator.
 *
 * This method updates the CHR (Character ROM) and PRG (Program ROM) memory mappings, 
 * as well as the mirroring configuration for the NES emulator. It performs the following steps:
 * - Iterates over 8 CHR banks (each 1KB in size) and sets their memory mappings using the `setchr1` function.
 *   The lower 8 bits of the CHR bank address are taken from `chrlo`, and the upper 8 bits are taken from `chrhi`.
 * - Sets the PRG RAM bank at address 0x6000 using `setprg8r` with a fixed bank number of 0x10.
 * - Sets the PRG ROM banks at addresses 0x8000 and 0xC000 using `setprg16`. The bank at 0x8000 is set to the value 
 *   of `prg`, while the bank at 0xC000 is set to the last bank (indicated by ~0).
 * - Configures the mirroring mode based on the `mirrisused` flag. If `mirrisused` is true, the mirroring mode 
 *   is toggled using the `mirr` value. Otherwise, the default mirroring mode `MI_0` is set.
 */
static void Sync(void) {
	uint32 i;
	for (i = 0; i < 8; i++)
		setchr1(i << 10, chrlo[i] | (chrhi[i] << 8));
	setprg8r(0x10, 0x6000, 0);
	setprg16(0x8000, prg);
	setprg16(0xC000, ~0);
	if (mirrisused)
		setmirror(mirr ^ 1);
	else
		setmirror(MI_0);
}

/**
 * @brief Handles writes to memory addresses associated with M156 mapper.
 *
 * This method processes write operations to specific memory addresses (0xC000 to 0xC014)
 * that control the behavior of the M156 mapper. Depending on the address (A) and the value (V),
 * it updates the corresponding CHR (Character ROM) or PRG (Program ROM) registers, or the mirroring
 * configuration. After updating the relevant register, it calls `Sync()` to apply the changes.
 *
 * - Addresses 0xC000-0xC003: Update the lower 4 bits of CHR registers 0-3.
 * - Addresses 0xC004-0xC007: Update the upper 4 bits of CHR registers 0-3.
 * - Addresses 0xC008-0xC00B: Update the lower 4 bits of CHR registers 4-7.
 * - Addresses 0xC00C-0xC00F: Update the upper 4 bits of CHR registers 4-7.
 * - Address 0xC010: Update the PRG register.
 * - Address 0xC014: Update the mirroring configuration and mark it as used.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the address.
 */
static DECLFW(M156Write) {
	switch (A) {
	case 0xC000:
	case 0xC001:
	case 0xC002:
	case 0xC003: chrlo[A & 3] = V; Sync(); break;
	case 0xC004:
	case 0xC005:
	case 0xC006:
	case 0xC007: chrhi[A & 3] = V; Sync(); break;
	case 0xC008:
	case 0xC009:
	case 0xC00A:
	case 0xC00B: chrlo[4 + (A & 3)] = V; Sync(); break;
	case 0xC00C:
	case 0xC00D:
	case 0xC00E:
	case 0xC00F: chrhi[4 + (A & 3)] = V; Sync(); break;
	case 0xC010: prg = V; Sync(); break;
	case 0xC014: mirr = V; mirrisused = 1; Sync(); break;
	}
}

/**
 * @brief Resets the M156 module's internal state to its default values.
 *
 * This method initializes the CHR (Character) low and high registers (chrlo and chrhi)
 * by setting all 8 elements of each array to 0. It also resets the PRG (Program) register
 * (prg) to 0, the mirroring register (mirr) to 0, and the mirroring usage flag (mirrisused)
 * to 0. This effectively clears the module's configuration and prepares it for a fresh
 * state or reinitialization.
 */
static void M156Reset(void) {
	uint32 i;
	for (i = 0; i < 8; i++) {
		chrlo[i] = 0;
		chrhi[i] = 0;
	}
	prg = 0;
	mirr = 0;
	mirrisused = 0;
}

/**
 * @brief Initializes and configures the power-up state for the M156 mapper.
 *
 * This method performs the following operations:
 * 1. Resets the M156 mapper to its default state using `M156Reset()`.
 * 2. Synchronizes the system state with `Sync()`.
 * 3. Sets the read handler for the memory range 0x6000 to 0xFFFF to use `CartBR` for cartridge bank reading.
 * 4. Sets the write handler for the memory range 0x6000 to 0x7FFF to use `CartBW` for cartridge bank writing.
 * 5. Sets the write handler for the memory range 0xC000 to 0xCFFF to use `M156Write` for M156-specific write operations.
 * 6. Adds RAM for cheat functionality using `FCEU_CheatAddRAM`, with the size of WRAM divided by 1024, starting at address 0x6000.
 *
 * This method is typically called during system initialization or when the emulator is reset.
 */
static void M156Power(void) {
	M156Reset();
	Sync();
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetWriteHandler(0xC000, 0xCFFF, M156Write);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) used by the emulator.
 *
 * This method checks if the WRAM pointer is not null. If WRAM is allocated,
 * it frees the memory associated with WRAM using the FCEU_gfree function.
 * After deallocating the memory, the WRAM pointer is set to NULL to indicate
 * that no memory is currently allocated for WRAM.
 *
 * @note This method is static, meaning it can be called without an instance of the class.
 */
static void M156Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method ensures that the system's state is synchronized with the specified version
 * by calling the `Sync()` function. It is typically used to revert the system to a known
 * good state after an error or to load a previously saved configuration.
 * 
 * @param version The version of the state to restore. This parameter specifies which
 *                saved state should be loaded and synchronized.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 156 for the given cartridge information.
 * This method sets up the necessary function pointers for reset, power, and close operations
 * specific to Mapper 156. It also allocates and configures the Work RAM (WRAM) for the cartridge,
 * mapping it appropriately in the cartridge's PRG memory space. Additionally, it sets up the
 * state restoration functionality for the mapper, allowing the emulator to save and restore
 * the state of the cartridge during gameplay.
 *
 * @param info A pointer to the CartInfo structure that holds the cartridge's configuration
 *             and state information. This structure is modified to include the mapper-specific
 *             functions and memory mappings.
 */
void Mapper156_Init(CartInfo *info) {
	info->Reset = M156Reset;
	info->Power = M156Power;
	info->Close = M156Close;

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
