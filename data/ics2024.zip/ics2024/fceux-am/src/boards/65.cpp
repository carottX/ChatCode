/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2012 CaH4e3
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 preg[3], creg[8], mirr;
static uint8 IRQa;
static int16 IRQCount, IRQLatch;

static SFORMAT StateRegs[] =
{
	{ preg, 3, "PREG" },
	{ creg, 8, "CREG" },
	{ &mirr, 1, "MIRR" },
	{ &IRQa, 1, "IRQA" },
	{ &IRQCount, 2, "IRQC" },
	{ &IRQLatch, 2, "IRQL" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping configuration for an emulated system.
 *
 * This method updates the memory mapping by configuring the Program ROM (PRG) and 
 * Character ROM (CHR) banks, as well as the mirroring mode. It performs the following steps:
 * 1. Sets the mirroring mode using the `mirr` variable.
 * 2. Configures the PRG ROM banks:
 *    - Maps the first PRG bank (`preg[0]`) to the address range 0x8000-0x9FFF.
 *    - Maps the second PRG bank (`preg[1]`) to the address range 0xA000-0xBFFF.
 *    - Maps the third PRG bank (`preg[2]`) to the address range 0xC000-0xDFFF.
 *    - Maps the last PRG bank (fixed to the last bank using `~0`) to the address range 0xE000-0xFFFF.
 * 3. Configures the CHR ROM banks:
 *    - Maps each of the 8 CHR banks (`creg[0]` to `creg[7]`) to consecutive 1 KB address ranges 
 *      starting from 0x0000 to 0x1C00.
 * 4. Reapplies the mirroring mode to ensure consistency.
 */
static void Sync(void) {
	setmirror(mirr);
	setprg8(0x8000, preg[0]);
	setprg8(0xA000, preg[1]);
	setprg8(0xC000, preg[2]);
	setprg8(0xE000, ~0);
	setchr1(0x0000, creg[0]);
	setchr1(0x0400, creg[1]);
	setchr1(0x0800, creg[2]);
	setchr1(0x0C00, creg[3]);
	setchr1(0x1000, creg[4]);
	setchr1(0x1400, creg[5]);
	setchr1(0x1800, creg[6]);
	setchr1(0x1C00, creg[7]);
	setmirror(mirr);
}

/**
 * @brief Handles write operations to specific memory addresses for the M65 mapper.
 *
 * This method processes write operations to various memory addresses, updating internal
 * registers and triggering synchronization or interrupt handling as needed. The behavior
 * depends on the address (`A`) and the value (`V`) being written:
 *
 * - `0x8000`: Updates `preg[0]` and triggers a synchronization (`Sync()`).
 * - `0xA000`: Updates `preg[1]` and triggers a synchronization (`Sync()`).
 * - `0xC000`: Updates `preg[2]` and triggers a synchronization (`Sync()`).
 * - `0x9001`: Updates the `mirr` register based on the value's bit 7 and triggers a synchronization (`Sync()`).
 * - `0x9003`: Updates the `IRQa` register and ends any external interrupt (`X6502_IRQEnd(FCEU_IQEXT)`).
 * - `0x9004`: Resets the `IRQCount` to the value of `IRQLatch`.
 * - `0x9005`: Updates the upper byte of `IRQLatch`.
 * - `0x9006`: Updates the lower byte of `IRQLatch`.
 * - `0xB000` to `0xB007`: Updates the corresponding `creg` register and triggers a synchronization (`Sync()`).
 *
 * @param A The memory address being written to.
 * @param V The value being written to the memory address.
 */
static DECLFW(M65Write) {
	switch (A) {
	case 0x8000: preg[0] = V; Sync(); break;
	case 0xA000: preg[1] = V; Sync(); break;
	case 0xC000: preg[2] = V; Sync(); break;
	case 0x9001: mirr = ((V >> 7) & 1) ^ 1; Sync(); break;
	case 0x9003: IRQa = V & 0x80; X6502_IRQEnd(FCEU_IQEXT); break;
	case 0x9004: IRQCount = IRQLatch; break;
	case 0x9005: IRQLatch &= 0x00FF; IRQLatch |= V << 8; break;
	case 0x9006: IRQLatch &= 0xFF00; IRQLatch |= V; break;
	case 0xB000: creg[0] = V; Sync(); break;
	case 0xB001: creg[1] = V; Sync(); break;
	case 0xB002: creg[2] = V; Sync(); break;
	case 0xB003: creg[3] = V; Sync(); break;
	case 0xB004: creg[4] = V; Sync(); break;
	case 0xB005: creg[5] = V; Sync(); break;
	case 0xB006: creg[6] = V; Sync(); break;
	case 0xB007: creg[7] = V; Sync(); break;
	}
}

/**
 * @brief Initializes the M65 power state by configuring the relevant registers and memory handlers.
 *
 * This method performs the following operations:
 * 1. Updates the value of `preg[2]` to the bitwise NOT of 1, effectively setting it to a specific state.
 * 2. Calls `Sync()` to synchronize the internal state with the updated register value.
 * 3. Sets the read handler for the memory range 0x8000 to 0xFFFF to `CartBR`, which handles cartridge bus reads.
 * 4. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M65Write`, which handles M65-specific writes.
 *
 * This method is typically called during the initialization or reset sequence of the M65 system.
 */
static void M65Power(void) {
	preg[2] = ~1;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M65Write);
}

/**
 * @brief Handles the M65 IRQ (Interrupt Request) logic.
 *
 * This method is responsible for managing the IRQ count and triggering an IRQ
 * when the count falls below a certain threshold. If the IRQ is active (IRQa is true),
 * the IRQCount is decremented by the specified amount `a`. If the IRQCount drops below
 * -4, an external IRQ is initiated using `X6502_IRQBegin` with the `FCEU_IQEXT` flag,
 * the IRQ is deactivated by setting `IRQa` to 0, and the `IRQCount` is reset to -1.
 *
 * @param a The amount by which the IRQCount is decremented.
 */
void M65IRQ(int a) {
	if (IRQa) {
		IRQCount -= a;
		if (IRQCount < -4) {
			X6502_IRQBegin(FCEU_IQEXT);
			IRQa = 0;
			IRQCount = -1;
		}
	}
}

/**
 * @brief Restores the state of the system to a previous version.
 *
 * This method is responsible for restoring the system's state to a specific version
 * by synchronizing the current state with the desired version. It calls the `Sync()`
 * method to ensure that all components are aligned with the specified version.
 *
 * @param version The version number to which the system's state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 65 configuration for the emulator.
 * This method sets up the necessary function pointers and state restoration
 * mechanisms for Mapper 65, which is used in certain NES cartridges.
 *
 * @param info A pointer to the CartInfo structure that holds cartridge-specific
 *             information, including the Power function pointer.
 *
 * The method performs the following operations:
 * 1. Assigns the M65Power function to the Power member of the CartInfo structure,
 *    which handles power-up initialization for the mapper.
 * 2. Sets the MapIRQHook function pointer to M65IRQ, which handles IRQ-related
 *    functionality specific to Mapper 65.
 * 3. Assigns the StateRestore function to the GameStateRestore pointer, enabling
 *    the emulator to restore the game state when needed.
 * 4. Calls AddExState to register the state registers for saving and restoring
 *    the emulator state, ensuring persistence across sessions.
 */
void Mapper65_Init(CartInfo *info) {
	info->Power = M65Power;
	MapIRQHook = M65IRQ;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}

