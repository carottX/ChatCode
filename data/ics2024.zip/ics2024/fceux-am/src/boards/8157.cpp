/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * GG1 boards, similar to T-262, with no Data latch
 *
 */

#include "mapinc.h"

static uint16 cmdreg;
static uint8 reset;
static SFORMAT StateRegs[] =
{
	{ &reset, 1, "REST" },
	{ &cmdreg, 2, "CREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the command register.
 *
 * This method updates the Program ROM (PRG) banks and mirroring settings according to the current
 * state of the command register (`cmdreg`). It calculates the base address, bank index, and
 * last bank index based on the bits in `cmdreg`. Depending on whether the PRG pointer (`PRGptr[1]`)
 * is set, it either uses the split ROM configuration or the standard configuration to map the
 * PRG banks. Finally, it sets the mirroring mode based on the command register.
 *
 * The method performs the following steps:
 * 1. Calculates the base address from bits 6, 5, and 9 of `cmdreg`.
 * 2. Determines the bank index from bits 4, 3, and 2 of `cmdreg`.
 * 3. Determines the last bank index based on bits 9 and 7 of `cmdreg`.
 * 4. Maps the PRG banks to the appropriate memory addresses using either `setprg16r` (for split ROMs)
 *    or `setprg16` (for standard configuration).
 * 5. Sets the mirroring mode based on bit 1 of `cmdreg`.
 */
static void Sync(void) {
	uint32 base = ((cmdreg & 0x060) | ((cmdreg & 0x100) >> 1)) >> 2;
	uint32 bank = (cmdreg & 0x01C) >> 2;
	uint32 lbank = (cmdreg & 0x200) ? 7 : ((cmdreg & 0x80) ? bank : 0);
	if (PRGptr[1]) {
		setprg16r(base >> 3, 0x8000, bank);        // for versions with split ROMs
		setprg16r(base >> 3, 0xC000, lbank);
	} else {
		setprg16(0x8000, base | bank);
		setprg16(0xC000, base | lbank);
	}
	setmirror(((cmdreg & 2) >> 1) ^ 1);
}

/**
 * @brief Reads data from the UNL8157 memory mapper.
 *
 * This method handles reading data from the UNL8157 memory mapper based on the provided address `A`.
 * If the `cmdreg` has the 0x100 bit set and the size of the PRG ROM (`PRGsize[0]`) is less than 1MB,
 * the address `A` is modified by masking it with 0xFFF0 and adding the `reset` value. This ensures
 * the correct memory location is accessed. The method then calls `CartBR(A)` to perform the actual
 * read operation from the cartridge memory.
 *
 * @param A The address to read from.
 * @return The data read from the specified address.
 */
static DECLFR(UNL8157Read) {
	if ((cmdreg & 0x100) && (PRGsize[0] < (1024 * 1024))) {
		A = (A & 0xFFF0) + reset;
	}
	return CartBR(A);
}

/**
 * @brief Writes a value to the UNL8157 command register and synchronizes the state.
 *
 * This method assigns the value of the parameter `A` to the `cmdreg` variable, 
 * which represents the command register for the UNL8157 device. After updating 
 * the register, it calls the `Sync()` method to ensure the device state is 
 * synchronized with the new command value.
 *
 * @param A The value to be written to the command register.
 */
static DECLFW(UNL8157Write) {
	cmdreg = A;
	Sync();
}

/**
 * @brief Initializes the power state for the UNL8157 mapper.
 *
 * This method sets up the CHR ROM to use 8KB of memory by calling `setchr8(0)`.
 * It then configures the read and write handlers for the memory range 0x8000 to 0xFFFF
 * to use the `UNL8157Read` and `UNL8157Write` functions, respectively. Additionally, it
 * resets the command register (`cmdreg`) and reset state (`reset`) to 0, and synchronizes
 * the mapper state by calling `Sync()`.
 */
static void UNL8157Power(void) {
	setchr8(0);
	SetWriteHandler(0x8000, 0xFFFF, UNL8157Write);
	SetReadHandler(0x8000, 0xFFFF, UNL8157Read);
	cmdreg = reset = 0;
	Sync();
}

/**
 * @brief Resets the UNL8157 device by initializing the command register and reset flag.
 * 
 * This method performs the following steps:
 * 1. Sets both the `cmdreg` and `reset` variables to 0.
 * 2. Increments the `reset` variable by 1.
 * 3. Masks the `reset` variable to ensure it does not exceed 0x1F (31 in decimal).
 * 4. Calls the `Sync()` function to synchronize the state of the device.
 * 
 * The purpose of this method is to reset the UNL8157 device to its initial state,
 * ensuring that the command register and reset flag are properly initialized.
 */
static void UNL8157Reset(void) {
	cmdreg = reset = 0;
	reset++;
	reset &= 0x1F;
	Sync();
}

/**
 * @brief Restores the system state to a specific version by synchronizing data.
 *
 * This method is responsible for restoring the system to a specified version by invoking 
 * the `Sync()` function. The `Sync()` function ensures that all relevant data and state 
 * are synchronized to match the desired version. The version parameter indicates the 
 * target state to which the system should be restored.
 *
 * @param version The version number to which the system should be restored. This 
 *                parameter determines the specific state or configuration that the 
 *                system will revert to after synchronization.
 */
static void UNL8157Restore(int version) {
	Sync();
}

/**
 * @brief Initializes the UNL8157 cartridge by setting up the necessary function pointers and state.
 *
 * This function configures the provided `CartInfo` structure with the appropriate power, reset, and restore
 * functions for the UNL8157 cartridge. It also sets up the state restoration mechanism by adding the state
 * registers to the emulator's state management system.
 *
 * @param info A pointer to the `CartInfo` structure that will be initialized with the UNL8157 cartridge's
 *             power, reset, and restore functions.
 */
void UNL8157_Init(CartInfo *info) {
	info->Power = UNL8157Power;
	info->Reset = UNL8157Reset;
	GameStateRestore = UNL8157Restore;
	AddExState(&StateRegs, ~0, 0, 0);
}
