/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "mmc3.h"

/**
 * @brief Sets the Program ROM (PRG) bank for the specified address range.
 *
 * This method configures the PRG bank for the address range starting at 0x8000.
 * The bank number is determined by the lower 3 bits of the value stored in EXPREGS[0].
 * The setprg32 function is called with the base address (0x8000) and the computed bank number.
 *
 * @param A Unused parameter in this context.
 * @param V Unused parameter in this context.
 */
static void M189PW(uint32 A, uint8 V) {
    setprg32(0x8000, EXPREGS[0] & 7);
}

/**
 * @brief Writes a value to the M189 mapper register and updates the PRG ROM banks.
 * 
 * This method is responsible for handling writes to the M189 mapper register. It updates
 * the value in the EXPREGS[0] register by combining the input value `V` with its shifted 
 * version (V >> 4). This operation effectively merges the high and low bits of the input 
 * value, which is used for bank switching in the M189 mapper. There are two versions of 
 * the M189 mapper, one that uses the high bits and another that uses the low bits for 
 * bank switching.
 * 
 * After updating the EXPREGS[0] register, the method calls `FixMMC3PRG(MMC3_cmd)` to 
 * update the PRG ROM banks based on the current MMC3 command.
 * 
 * @param V The value to be written to the M189 mapper register.
 */
static DECLFW(M189Write) {
	EXPREGS[0] = V | (V >> 4); //actually, there is a two versions of 189 mapper with hi or lo bits bankswitching.
	FixMMC3PRG(MMC3_cmd);
}

/**
 * @brief Initializes the power state for the M189 mapper.
 *
 * This method is responsible for setting up the initial state of the M189 mapper when the system is powered on.
 * It performs the following operations:
 * 1. Resets the values of the expansion registers (EXPREGS[0] and EXPREGS[1]) to 0.
 * 2. Calls the GenMMC3Power() function to initialize the MMC3 power state, which is the base functionality for this mapper.
 * 3. Sets up a write handler for the memory range 0x4120 to 0x7FFF, using the M189Write function to handle write operations in this range.
 *
 * This method is typically called during the system's power-on sequence to ensure the mapper is properly configured.
 */
static void M189Power(void) {
	EXPREGS[0] = EXPREGS[1] = 0;
	GenMMC3Power();
	SetWriteHandler(0x4120, 0x7FFF, M189Write);
}

/**
 * Initializes the Mapper 189 for the given cartridge information.
 * This method sets up the MMC3 memory management controller with 256KB of PRG ROM
 * and 256KB of CHR ROM, and initializes the mapper-specific power function and
 * state. It also configures the PRG write handler to use the M189PW function.
 * Additionally, it adds the extra state registers (EXPREGS) to the emulator's
 * save state system.
 *
 * @param info Pointer to the CartInfo structure containing cartridge information.
 */
void Mapper189_Init(CartInfo *info) {
	GenMMC3_Init(info, 256, 256, 0, 0);
	pwrap = M189PW;
	info->Power = M189Power;
	AddExState(EXPREGS, 2, 0, "EXPR");
}
