/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2013 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * DSOUNDV1/FL-TR8MA boards (32K WRAM, 8/16M), 178 mapper boards (8K WRAM, 4/8M)
 * Various Education Cartridges
 *
 */

#include "mapinc.h"

static uint8 reg[4];

static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;

// Tennis with VR sensor, very simple behaviour
extern void GetMouseData(uint32 (&md)[3]);
static uint32 MouseData[3], click, lastclick;
static int32 SensorDelay;

// highly experimental, not actually working, just curious if it hapen to work with some other decoder
// SND Registers
static uint8 pcm_enable = 0;

static SFORMAT StateRegs[] =
{
	{ reg, 4, "REGS" },
	{ 0 }
};

//static int16 step_size[49] = {
//	16, 17, 19, 21, 23, 25, 28, 31, 34, 37,
//	41, 45, 50, 55, 60, 66, 73, 80, 88, 97,
//	107, 118, 130, 143, 157, 173, 190, 209, 230, 253,
//	279, 307, 337, 371, 408, 449, 494, 544, 598, 658,
//	724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552
//};	//49 items
//static int32 step_adj[16] = { -1, -1, -1, -1, 2, 5, 7, 9, -1, -1, -1, -1, 2, 5, 7, 9 };

//decode stuff
//static int32 jedi_table[16 * 49];
//static int32 acc = 0;	//ADPCM accumulator, initial condition must be 0
//static int32 decstep = 0;	//ADPCM decoding step, initial condition must be 0

//static void jedi_table_init() {
//	int step, nib;
//
//	for (step = 0; step < 49; step++) {
//		for (nib = 0; nib < 16; nib++) {
//			int value = (2 * (nib & 0x07) + 1) * step_size[step] / 8;
//			jedi_table[step * 16 + nib] = ((nib & 0x08) != 0) ? -value : value;
//		}
//	}
//}

//static uint8 decode(uint8 code) {
//	acc += jedi_table[decstep + code];
//	if ((acc & ~0x7ff) != 0)	// acc is > 2047
//		acc |= ~0xfff;
//	else acc &= 0xfff;
//	decstep += step_adj[code & 7] * 16;
//	if (decstep < 0) decstep = 0;
//	if (decstep > 48 * 16) decstep = 48 * 16;
//	return (acc >> 8) & 0xff;
//}

static void Sync(void) {
	uint32 sbank = reg[1] & 0x7;
	uint32 bbank = reg[2];
	setchr8(0);
	setprg8r(0x10, 0x6000, reg[3] & 3);
	if (reg[0] & 2) {	// UNROM mode
		setprg16(0x8000, (bbank << 3) | sbank);
		if (reg[0] & 4)
			setprg16(0xC000, (bbank << 3) | 6 | (reg[1] & 1));
		else
			setprg16(0xC000, (bbank << 3) | 7);
	} else {			// NROM mode
		uint32 bank = (bbank << 3) | sbank;
		if (reg[0] & 4) {
			setprg16(0x8000, bank);
			setprg16(0xC000, bank);
		} else
			setprg32(0x8000, bank >> 1);
	}
	setmirror((reg[0] & 1) ^ 1);
}

/**
 * @brief Writes a value to a specific register in the M178 device.
 *
 * This method is responsible for writing a given value `V` to a register 
 * identified by the lower 2 bits of the address `A`. The register is 
 * selected using the expression `A & 3`, which ensures only the first 
 * four registers (0-3) are accessible. After updating the register, 
 * the `Sync()` function is called to synchronize the state of the device.
 *
 * @param A The address used to determine the target register. Only the 
 *          lower 2 bits of `A` are used to select the register.
 * @param V The value to be written to the selected register.
 */
static DECLFW(M178Write) {
	reg[A & 3] = V;
//	FCEU_printf("cmd %04x:%02x\n", A, V);
	Sync();
}

/**
 * @brief Handles the write operation for the sound register at address 0x5800.
 *
 * This method is responsible for managing the state of the PCM (Pulse Code Modulation) 
 * sound output based on the value written to the sound register. When the address `A` 
 * is 0x5800, the method checks the value `V` written to this address. If the upper nibble 
 * of `V` (bits 7-4) is non-zero, it enables the PCM sound output by setting `pcm_enable` 
 * to 1. If the upper nibble is zero, it disables the PCM sound output by setting 
 * `pcm_enable` to 0.
 *
 * The method currently contains commented-out code that suggests additional functionality 
 * for writing PCM data to a sound register (0x4011) and decoding the value `V`, but this 
 * functionality is not active in the current implementation.
 *
 * @param A The address to which the value is being written.
 * @param V The value being written to the address.
 */
static DECLFW(M178WriteSnd) {
	if (A == 0x5800) {
		if (V & 0xF0) {
			pcm_enable = 1;
//			pcmwrite(0x4011, (V & 0xF) << 3);
//			pcmwrite(0x4011, decode(V & 0xf));
		} else
			pcm_enable = 0;
	}// else
//		FCEU_printf("misc %04x:%02x\n", A, V);
}

/**
 * @brief Reads the sound data from the specified memory address.
 * 
 * This method is responsible for reading sound data from the memory address `A`. 
 * If the address is `0x5800`, it returns a modified version of the `X.DB` register 
 * where the 6th bit is toggled based on the `pcm_enable` flag. If the address is 
 * not `0x5800`, it simply returns the value of the `X.DB` register.
 * 
 * @param A The memory address to read from.
 * @return The sound data read from the specified memory address.
 */
static DECLFR(M178ReadSnd) {
	if (A == 0x5800)
		return (X.DB & 0xBF) | ((pcm_enable ^ 1) << 6);
	else
		return X.DB;
}

/**
 * @brief Reads the sensor value for mapper 178.
 *
 * This method is a static function that simulates the behavior of reading a sensor
 * value for mapper 178. It performs the following actions:
 * - Clears the IRQ (Interrupt Request) by calling `X6502_IRQEnd(FCEU_IQEXT)`.
 *   This is a hacky implementation to mimic the behavior of the actual register
 *   at address 6000, which clears the IRQ upon reading.
 * - Returns a fixed value of 0x00, indicating no sensor data is available or
 *   the sensor read operation is not implemented.
 *
 * @return uint8_t Always returns 0x00.
 */
static DECLFR(M178ReadSensor) {
	X6502_IRQEnd(FCEU_IQEXT);		// hacky-hacky, actual reg is 6000 and it clear IRQ while reading, but then I need another mapper lol
	return 0x00;
}

/**
 * @brief Initializes the M178 hardware by resetting registers, setting up memory handlers, and configuring cheat RAM.
 *
 * This method performs the following operations:
 * 1. Resets the registers `reg[0]`, `reg[1]`, `reg[2]`, `reg[3]`, and `SensorDelay` to 0.
 * 2. Calls `Sync()` to synchronize the system state.
 * 3. Sets up write handlers for specific memory ranges:
 *    - `0x4800` to `0x4FFF` to use `M178Write`.
 *    - `0x5800` to `0x5FFF` to use `M178WriteSnd`.
 * 4. Sets up read handlers for specific memory ranges:
 *    - `0x5800` to `0x5FFF` to use `M178ReadSnd`.
 *    - `0x5000` to `0x5000` to use `M178ReadSensor`.
 *    - `0x6000` to `0x7FFF` and `0x8000` to `0xFFFF` to use `CartBR`.
 * 5. Sets up write handlers for the memory range `0x6000` to `0x7FFF` to use `CartBW`.
 * 6. Configures cheat RAM using `FCEU_CheatAddRAM` for the specified size and base address.
 */
static void M178Power(void) {
	reg[0] = reg[1] = reg[2] = reg[3] = SensorDelay = 0;
	Sync();
//	pcmwrite = GetWriteHandler(0x4011);
	SetWriteHandler(0x4800, 0x4fff, M178Write);
	SetWriteHandler(0x5800, 0x5fff, M178WriteSnd);
	SetReadHandler(0x5800, 0x5fff, M178ReadSnd);
	SetReadHandler(0x5000, 0x5000, M178ReadSensor);
	SetReadHandler(0x6000, 0x7fff, CartBR);
	SetWriteHandler(0x6000, 0x7fff, CartBW);
	SetReadHandler(0x8000, 0xffff, CartBR);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Adjusts the sensor delay and processes mouse click events.
 *
 * This method increments the global `SensorDelay` by the provided value `a`. If the `SensorDelay` 
 * exceeds the threshold `0x32768`, it wraps around by subtracting `32768` and processes mouse data. 
 * The method retrieves the current mouse data and compares the current click state with the previous 
 * one to detect a button release event. If a button release is detected (i.e., the button was 
 * previously pressed and is now released), it triggers an external IRQ (Interrupt Request) using 
 * `X6502_IRQBegin(FCEU_IQEXT)`. This is done to prevent continuous IRQ triggers when the button is 
 * held down, as the actual circuit uses a D-C-R (Diode-Capacitor-Resistor) edge detector for the 
 * IR-sensor, which is triggered by the active IR bat.
 *
 * @param a The value to add to the `SensorDelay`. This parameter controls the adjustment of the 
 *          sensor delay and indirectly influences the timing of mouse click event processing.
 */
static void M178SndClk(int a) {
	SensorDelay += a;
	if(SensorDelay > 0x32768) {
		SensorDelay -= 32768;
		GetMouseData (MouseData);
		lastclick = click;
		click = MouseData[2] & 1;	// to prevent from continuos IRQ trigger if button is held.
									// actual circuit is just a D-C-R edge detector for IR-sensor
									// triggered by the active IR bat.
		if(lastclick && !click)
			X6502_IRQBegin(FCEU_IQEXT);
	}

//	if (pcm_enable) {
//		pcm_latch -= a;
//		if (pcm_latch <= 0) {
//			pcm_latch += pcm_clock;
//			pcm_enable = 0;
//		}
//	}
}

/**
 * @brief Closes and deallocates the WRAM (Work RAM) memory.
 *
 * This method checks if the WRAM pointer is not null. If it is not null,
 * it frees the memory allocated for WRAM using the FCEU_gfree function.
 * After deallocating the memory, the WRAM pointer is set to null to indicate
 * that no memory is currently allocated for WRAM.
 */
static void M178Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * @brief Restores the state of the system based on the provided version.
 * 
 * This method ensures that the system is synchronized before proceeding with 
 * the state restoration process. The synchronization is achieved by calling 
 * the `Sync()` method, which guarantees that all pending operations are 
 * completed and the system is in a consistent state.
 * 
 * @param version The version of the state to be restored. This parameter 
 *                specifies which state snapshot or configuration should be 
 *                applied to the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 178 for the given cartridge information.
 * This method sets up the necessary function pointers for power management,
 * closing operations, and sound clock handling. It also initializes the
 * Work RAM (WRAM) for the cartridge, configures the PRG mapping, and sets up
 * state restoration for the game. If the cartridge has a battery backup, it
 * ensures the WRAM is saved and restored appropriately.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific
 *             information and configuration. This includes function pointers
 *             for power management, closing operations, and battery backup
 *             settings.
 *
 * @note The method allocates 32KB of WRAM and sets up PRG mapping for it.
 *       If the cartridge has a battery, the WRAM is marked for saving.
 *       Additionally, state restoration and IRQ hook for sound clock are
 *       configured.
 */
void Mapper178_Init(CartInfo *info) {
	info->Power = M178Power;
	info->Close = M178Close;
	GameStateRestore = StateRestore;
	MapIRQHook = M178SndClk;

//	jedi_table_init();

	WRAMSIZE = 32768;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");

	AddExState(&StateRegs, ~0, 0, 0);
}
