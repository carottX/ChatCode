/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2011 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 prot[4], prg, mode, chr, mirr;

static SFORMAT StateRegs[] =
{
	{ prot, 4, "PROT" },
	{ &prg, 1, "PRG" },
	{ &chr, 1, "CHR" },
	{ &mode, 1, "MODE" },
	{ &mirr, 1, "MIRR" },
	{ 0 }
};

/**
 * @brief Synchronizes the program and character memory banks and sets the mirroring mode.
 *
 * This method updates the memory mapping for the program (PRG) and character (CHR) ROM banks
 * based on the current mode. If the mode is set to true, it maps two 16KB PRG banks to the
 * addresses 0x8000 and 0xC000 using the provided `prg` value. If the mode is false, it maps
 * a single 32KB PRG bank to the address 0x8000, using `prg >> 1` to determine the bank index.
 * Additionally, it updates the CHR bank to the value specified by `chr` and sets the mirroring
 * mode based on the value of `mirr`, toggling it by XORing with 1.
 */
static void Sync(void) {
	if (mode) {
		setprg16(0x8000, prg);
		setprg16(0xC000, prg);
	} else
		setprg32(0x8000, prg >> 1);
	setchr8(chr);
	setmirror(mirr ^ 1);
}

/**
 * @brief Handles the write operation for Mapper 225 (M225).
 *
 * This method processes a write operation to the Mapper 225 registers. It decodes the address `A`
 * to determine the bank, mirroring mode, and CHR/PRG bank settings. The decoded values are then
 * used to update the internal state of the mapper and synchronize the memory mapping.
 *
 * @param A The address being written to. The address is decoded as follows:
 *   - Bit 14: Determines the bank (0 or 1).
 *   - Bit 13: Determines the mirroring mode (0 or 1).
 *   - Bit 12: Determines the mode (0 or 1).
 *   - Bits 0-5: Specify the CHR bank (lower 6 bits).
 *   - Bits 6-11: Specify the PRG bank (bits 6-11).
 *
 * The method updates the following internal variables:
 *   - `bank`: The selected bank (0 or 1).
 *   - `mirr`: The mirroring mode (0 or 1).
 *   - `mode`: The mode (0 or 1).
 *   - `chr`: The CHR bank, calculated as (A & 0x3F) | (bank << 6).
 *   - `prg`: The PRG bank, calculated as ((A >> 6) & 0x3F) | (bank << 6).
 *
 * Finally, the `Sync()` method is called to apply the updated memory mapping.
 */
static DECLFW(M225Write) {
	uint32 bank = (A >> 14) & 1;
	mirr = (A >> 13) & 1;
	mode = (A >> 12) & 1;
	chr = (A & 0x3f) | (bank << 6);
	prg = ((A >> 6) & 0x3f) | (bank << 6);
	Sync();
}

/**
 * @brief Handles low byte writes to the M225 memory-mapped I/O register.
 *
 * This static method is invoked when a write operation is performed on the low byte
 * of the M225 register. It is typically used in emulation or low-level hardware
 * interaction to process the written data and update the internal state or hardware
 * behavior accordingly.
 *
 * @param addr The memory address where the write operation is performed.
 * @param value The byte value being written to the specified address.
 */
static DECLFW(M225LoWrite) {
}

/**
 * @brief Reads the low byte of the M225 register.
 *
 * This method is a static function that simulates reading the low byte of the M225 register.
 * It currently returns a fixed value of 0, indicating that the register is not implemented
 * or that the read operation is not supported in the current context.
 *
 * @return The low byte of the M225 register, which is always 0 in this implementation.
 */
static DECLFR(M225LoRead) {
	return 0;
}

/**
 * @brief Initializes the M225 memory mapper on power-up.
 *
 * This method sets up the M225 memory mapper by initializing its internal state
 * and configuring the read and write handlers for specific memory ranges.
 * It performs the following steps:
 * 1. Resets the program counter (`prg`) to 0.
 * 2. Resets the mode to 0.
 * 3. Synchronizes the internal state by calling `Sync()`.
 * 4. Sets the read handler for the memory range 0x5000-0x5FFF to `M225LoRead`.
 * 5. Sets the write handler for the memory range 0x5000-0x5FFF to `M225LoWrite`.
 * 6. Sets the read handler for the memory range 0x8000-0xFFFF to `CartBR`.
 * 7. Sets the write handler for the memory range 0x8000-0xFFFF to `M225Write`.
 *
 * This method is typically called during the power-up sequence of the emulator
 * to ensure the M225 mapper is properly initialized.
 */
static void M225Power(void) {
	prg = 0;
	mode = 0;
	Sync();
	SetReadHandler(0x5000, 0x5FFF, M225LoRead);
	SetWriteHandler(0x5000, 0x5FFF, M225LoWrite);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M225Write);
}

/**
 * @brief Resets the M225 module to its default state.
 *
 * This method sets the program counter (`prg`) and the mode to their default values (0).
 * After resetting these values, it calls the `Sync()` method to ensure that the module's
 * internal state is synchronized with the new settings.
 */
static void M225Reset(void) {
	prg = 0;
	mode = 0;
	Sync();
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method synchronizes the current state of the system with the state 
 * corresponding to the specified version. It ensures that all necessary 
 * data and configurations are restored to match the state at the given version.
 *
 * @param version The version number of the state to restore. This should 
 *                correspond to a previously saved state in the system.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 225 for the given cartridge information.
 *
 * This method sets up the necessary function pointers and state restoration
 * mechanisms for Mapper 225. Specifically, it assigns the `Reset` and `Power`
 * functions to the corresponding handlers (`M225Reset` and `M225Power`). 
 * Additionally, it sets the `GameStateRestore` function to `StateRestore` and
 * adds the state registers to the external state management system using
 * `AddExState`. This ensures that the emulator can properly handle reset,
 * power cycles, and state saving/loading for cartridges using Mapper 225.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific
 *             information and function pointers.
 */
void Mapper225_Init(CartInfo *info) {
	info->Reset = M225Reset;
	info->Power = M225Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
