/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2017 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 bios_prg, rom_prg, rom_mode, mirror;

static SFORMAT StateRegs[] =
{
	{ &bios_prg, 1, "BREG" },
	{ &rom_prg, 1, "RREG" },
	{ &rom_mode, 1, "RMODE" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current ROM mode.
 *
 * This method updates the CHR and PRG memory banks and sets the mirroring mode based on the values of `rom_mode`, `bios_prg`, and `rom_prg`.
 * - If the ROM mode bit 1 is set (i.e., `rom_mode & 2` is true), it sets the PRG bank at 0x8000 using a combination of `bios_prg` and `rom_prg`.
 * - Otherwise, it sets the PRG bank at 0x8000 using only the lower bits of `bios_prg`.
 * - The PRG bank at 0xC000 is always set using the lower 7 bits of `rom_prg`.
 * - The mirroring mode is determined by the bit 4 of `bios_prg` and is inverted before being applied.
 */
static void Sync(void) {
	setchr8(0);
	if(rom_mode&2) {
		setprg16r(0,0x8000,(bios_prg&0xF)|(rom_prg&0x70));
	} else {
		setprg16r(1,0x8000,bios_prg&3);
	}
	setprg16r(0,0xC000,rom_prg&0x7F);
	setmirror(((bios_prg>>4)&1)^1);
}

/**
 * @brief Writes a value to either the BIOS or ROM program registers based on the address.
 * 
 * This method determines the target register by extracting bits 13 and 14 from the address `A`.
 * If the extracted register value is 0, the value `V` is written to the `bios_prg` register.
 * Otherwise, the value `V` is written to the `rom_prg` register, and the `rom_mode` register is
 * updated with the extracted register value. After updating the registers, the `Sync()` function
 * is called to synchronize the state.
 * 
 * @param A The address used to determine the target register.
 * @param V The value to be written to the target register.
 */
static DECLFW(BMC80013BWrite) {
	uint8 reg = (A>>13)&3;
	if(reg == 0) {
		bios_prg = V;
	} else {
		rom_prg = V;
		rom_mode = reg;
	}
	Sync();
}

/**
 * @brief Initializes the BMC80013B power state by resetting various memory-related
 *        variables and setting up read and write handlers for the specified memory range.
 *
 * This method performs the following operations:
 * 1. Resets the `bios_prg`, `rom_prg`, `rom_mode`, and `mirror` variables to 0.
 * 2. Calls the `Sync()` method to synchronize the internal state.
 * 3. Sets up a read handler for the memory range 0x8000 to 0xFFFF using `CartBR`.
 * 4. Sets up a write handler for the memory range 0x8000 to 0xFFFF using `BMC80013BWrite`.
 *
 * This method is typically called during the initialization or reset of the BMC80013B
 * hardware to ensure a clean state and proper memory handling.
 */
static void BMC80013BPower(void) {
	bios_prg=rom_prg=rom_mode=mirror=0;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, BMC80013BWrite);
}

/**
 * @brief Resets the BMC80013B mapper to its initial state.
 *
 * This method sets the internal state variables `bios_prg`, `rom_prg`, `rom_mode`, 
 * and `mirror` to 0, effectively resetting the mapper's configuration. After resetting 
 * these variables, the method calls the `Sync()` function to synchronize the mapper's 
 * state with the emulator or hardware. This is typically used during a system reset 
 * or power-on to ensure the mapper starts in a known state.
 */
static void BMC80013BReset(void) {
	bios_prg=rom_prg=rom_mode=mirror=0;
	Sync();
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method performs a state restoration by first synchronizing the current state
 * with the desired version. The synchronization ensures that all necessary data and
 * configurations are updated to match the specified version.
 * 
 * @param version The version number to which the state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the BMC80013B mapper by setting up the necessary function pointers and state.
 *
 * This function configures the provided `CartInfo` structure with the appropriate reset and power
 * functions for the BMC80013B mapper. It also sets up the game state restoration function and
 * adds the state registers to the emulator's state management system.
 *
 * @param info Pointer to the `CartInfo` structure that will be initialized with the BMC80013B
 *             mapper's functions and state.
 *
 * @details The function performs the following operations:
 * - Assigns the `BMC80013BReset` function to the `Reset` member of the `CartInfo` structure.
 * - Assigns the `BMC80013BPower` function to the `Power` member of the `CartInfo` structure.
 * - Sets the global `GameStateRestore` function to `StateRestore`.
 * - Adds the state registers to the emulator's state management system using `AddExState`.
 */
void BMC80013B_Init(CartInfo *info) {
	info->Reset = BMC80013BReset;
	info->Power = BMC80013BPower;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
