/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 cmd;
static uint8 DRegs[8];

static SFORMAT StateRegs[] =
{
	{ &cmd, 1, "CMD" },
	{ DRegs, 8, "DREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the CHR and PRG memory banks with the values stored in the DRegs array.
 *
 * This method updates the CHR (Character) and PRG (Program) memory banks based on the values
 * in the DRegs array. It performs the following operations:
 * - Sets two 2KB CHR banks at addresses 0x0000 and 0x0800 using DRegs[0] and DRegs[1], respectively.
 * - Sets four 1KB CHR banks starting at address 0x1000, using DRegs[2] to DRegs[5].
 * - Sets three 8KB PRG banks at addresses 0x8000, 0xA000, and 0xC000 using DRegs[6], DRegs[7], and a fixed value (~1), respectively.
 * - Sets the last 8KB PRG bank at address 0xE000 to a fixed value (~0).
 *
 * This method is typically used in the context of an emulator or memory management system to
 * ensure that the memory banks are correctly mapped according to the current configuration.
 */
static void Sync(void) {
	setchr2(0x0000, DRegs[0]);
	setchr2(0x0800, DRegs[1]);
	int x;
	for (x = 0; x < 4; x++)
		setchr1(0x1000 + (x << 10), DRegs[2 + x]);
	setprg8(0x8000, DRegs[6]);
	setprg8(0xa000, DRegs[7]);
	setprg8(0xc000, ~1);
	setprg8(0xe000, ~0);
}

/**
 * @brief Restores the state of the system to a previously saved version.
 *
 * This method is responsible for restoring the system state based on the provided version.
 * It first synchronizes the current state with any pending changes or updates by calling
 * the `Sync()` method. This ensures that the restoration process is performed on the most
 * up-to-date state of the system.
 *
 * @param version The version number of the state to restore. This version should correspond
 *                to a previously saved state in the system's history.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Handles writing to the M206 register based on the address and value provided.
 *
 * This method processes writes to the M206 register by interpreting the address (`A`) and value (`V`).
 * The behavior depends on the address:
 * - If the address is `0x8000`, the method sets the command (`cmd`) to the lower 3 bits of the value (`V & 0x07`).
 * - If the address is `0x8001`, the method processes the value based on the current command (`cmd`):
 *   - For commands `0x00` to `0x05`, the value is masked to 6 bits (`V & 0x3F`).
 *   - For commands `0x06` and `0x07`, the value is masked to 4 bits (`V & 0x0F`).
 *   - For commands `0x00` and `0x01`, the value is right-shifted by 1 bit.
 *   The processed value is then stored in the corresponding register (`DRegs[cmd & 0x07]`), and a synchronization operation (`Sync()`) is triggered.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M206Write) {
	switch (A & 0x8001) {
	case 0x8000: cmd = V & 0x07; break;
	case 0x8001:
		if (cmd <= 0x05)
			V &= 0x3F;
		else
			V &= 0x0F;
		if (cmd <= 0x01) V >>= 1;
		DRegs[cmd & 0x07] = V;
		Sync();
		break;
	}
}

/**
 * @brief Executes the M206 power sequence for the cartridge.
 *
 * This method initializes the M206 cartridge by performing the following steps:
 * 1. Resets the `cmd` variable to 0.
 * 2. Sets the value of `DRegs[6]` to 0.
 * 3. Sets the value of `DRegs[7]` to 1.
 * 4. Synchronizes the system state by calling `Sync()`.
 * 5. Sets the read handler for the memory range 0x8000 to 0xFFFF to `CartBR`.
 * 6. Sets the write handler for the memory range 0x8000 to 0xFFFF to `M206Write`.
 *
 * This sequence ensures that the cartridge is properly initialized and ready for
 * read and write operations within the specified memory range.
 */
static void M206Power(void) {
	cmd = 0;
	DRegs[6] = 0;
	DRegs[7] = 1;
	Sync();
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M206Write);
}


/**
 * @brief Initializes the Mapper 206 for the provided cartridge information.
 *
 * This method sets up the necessary configurations for Mapper 206 by assigning the
 * power function (`M206Power`) to the `Power` member of the `CartInfo` structure.
 * It also sets the `GameStateRestore` function to `StateRestore` and adds the state
 * registers (`StateRegs`) to the emulator's state management system using `AddExState`.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge-specific information.
 */
void Mapper206_Init(CartInfo *info) {
	info->Power = M206Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
