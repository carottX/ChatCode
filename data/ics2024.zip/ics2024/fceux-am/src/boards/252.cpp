/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2009 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 creg[8], preg[2];
static int32 IRQa, IRQCount, IRQClock, IRQLatch;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;
static uint8 *CHRRAM = NULL;
static uint32 CHRRAMSIZE;

static SFORMAT StateRegs[] =
{
	{ creg, 8, "CREG" },
	{ preg, 2, "PREG" },
	{ &IRQa, 4, "IRQA" },
	{ &IRQCount, 4, "IRQC" },
	{ &IRQLatch, 4, "IRQL" },
	{ &IRQClock, 4, "IRQK" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the program and character ROMs.
 *
 * This method configures the memory mapping for the NES emulator by setting the
 * program ROM (PRG) and character ROM (CHR) banks. It performs the following steps:
 * - Sets the PRG bank at address 0x6000 to use the specified memory region (0x10).
 * - Configures the PRG banks at addresses 0x8000, 0xA000, 0xC000, and 0xE000 using
 *   the values from the `preg` array and predefined constants.
 * - Iterates through the `creg` array to configure the CHR banks. If the value in
 *   `creg` is 6 or 7, it uses the specified memory region (0x10) for the CHR bank.
 *   Otherwise, it directly sets the CHR bank based on the value in `creg`.
 *
 * This method ensures that the memory mapping is updated to reflect the current
 * state of the emulator's memory configuration.
 */
static void Sync(void) {
	uint8 i;
	setprg8r(0x10, 0x6000, 0);
	setprg8(0x8000, preg[0]);
	setprg8(0xa000, preg[1]);
	setprg8(0xc000, ~1);
	setprg8(0xe000, ~0);
	for (i = 0; i < 8; i++)
		if ((creg[i] == 6) || (creg[i] == 7))
			setchr1r(0x10, i << 10, creg[i] & 1);
		else
			setchr1(i << 10, creg[i]);
}

/**
 * Handles writing to the M252 memory-mapped registers.
 *
 * This method processes write operations to specific memory addresses, updating
 * internal registers or triggering actions based on the address and value written.
 * 
 * - For addresses in the range 0xB000 to 0xEFFF:
 *   - The method calculates an index (`ind`) and a shift amount (`sar`) based on the address.
 *   - It updates a specific control register (`creg[ind]`) by merging the new value (`V`) with the existing register value.
 *   - Calls `Sync()` to synchronize state changes.
 *
 * - For other addresses:
 *   - The method uses a switch statement to handle specific cases:
 *     - Addresses 0x8000, 0x8004, 0x8008, 0x800C: Updates `preg[0]` and calls `Sync()`.
 *     - Addresses 0xA000, 0xA004, 0xA008, 0xA00C: Updates `preg[1]` and calls `Sync()`.
 *     - Address 0xF000: Updates the lower nibble of `IRQLatch` and ends an IRQ.
 *     - Address 0xF004: Updates the upper nibble of `IRQLatch` and ends an IRQ.
 *     - Address 0xF008: Resets `IRQClock`, sets `IRQCount` to `IRQLatch`, and updates `IRQa` based on the value written.
 *
 * @param A The memory address being written to.
 * @param V The value being written to the address.
 */
static DECLFW(M252Write) {
	if ((A >= 0xB000) && (A <= 0xEFFF)) {
		uint8 ind = ((((A & 8) | (A >> 8)) >> 3) + 2) & 7;
		uint8 sar = A & 4;
		creg[ind] = (creg[ind] & (0xF0 >> sar)) | ((V & 0x0F) << sar);
		Sync();
	} else
		switch (A & 0xF00C) {
		case 0x8000:
		case 0x8004:
		case 0x8008:
		case 0x800C: preg[0] = V; Sync(); break;
		case 0xA000:
		case 0xA004:
		case 0xA008:
		case 0xA00C: preg[1] = V; Sync(); break;
		case 0xF000: X6502_IRQEnd(FCEU_IQEXT); IRQLatch &= 0xF0; IRQLatch |= V & 0xF; break;
		case 0xF004: X6502_IRQEnd(FCEU_IQEXT); IRQLatch &= 0x0F; IRQLatch |= V << 4; break;
		case 0xF008: X6502_IRQEnd(FCEU_IQEXT); IRQClock = 0; IRQCount = IRQLatch; IRQa = V & 2; break;
		}
}

/**
 * @brief Initializes the memory mapping and handlers for the M252 Power configuration.
 *
 * This method sets up the read and write handlers for specific memory ranges to manage
 * cartridge-based memory access. It synchronizes the system, configures handlers for the
 * memory ranges 0x6000-0x7FFF and 0x8000-0xFFFF, and adds RAM for cheat functionality.
 *
 * The method performs the following steps:
 * 1. Calls `Sync()` to ensure the system is in a consistent state.
 * 2. Sets the read handler for the memory range 0x6000-0x7FFF to `CartBR`.
 * 3. Sets the write handler for the memory range 0x6000-0x7FFF to `CartBW`.
 * 4. Sets the read handler for the memory range 0x8000-0xFFFF to `CartBR`.
 * 5. Sets the write handler for the memory range 0x8000-0xFFFF to `M252Write`.
 * 6. Adds RAM for cheat functionality using `FCEU_CheatAddRAM`, with the size of WRAM
 *    divided by 1024, starting at address 0x6000.
 */
static void M252Power(void) {
	Sync();
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0xFFFF, M252Write);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
}

/**
 * @brief Handles the M252 IRQ (Interrupt Request) logic.
 *
 * This method processes the IRQ signal for the M252 system. It increments the IRQ clock based on the input parameter `a`.
 * When the IRQ clock exceeds the predefined cycle count (`LCYCS`), it triggers an IRQ event. The IRQ event is handled by
 * decrementing the IRQ clock by `LCYCS` and incrementing the IRQ counter. If the IRQ counter reaches a specific threshold
 * (0x100), an external IRQ is initiated via `X6502_IRQBegin`, and the IRQ counter is reset to the value stored in `IRQLatch`.
 *
 * @param a The input value used to increment the IRQ clock. Typically represents a time or cycle increment.
 */
static void M252IRQ(int a) {
	#define LCYCS 341
	if (IRQa) {
		IRQClock += a * 3;
		if (IRQClock >= LCYCS) {
			while (IRQClock >= LCYCS) {
				IRQClock -= LCYCS;
				IRQCount++;
				if (IRQCount & 0x100) {
					X6502_IRQBegin(FCEU_IQEXT);
					IRQCount = IRQLatch;
				}
			}
		}
	}
}

/**
 * @brief Closes and frees the memory allocated for the WRAM and CHRRAM buffers.
 *
 * This method checks if the WRAM and CHRRAM buffers are not null, and if so,
 * it frees the memory allocated for these buffers using the FCEU_gfree function.
 * After freeing the memory, both WRAM and CHRRAM pointers are set to NULL to
 * indicate that the memory has been released and to prevent any further access
 * to the freed memory.
 */
static void M252Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	if (CHRRAM)
		FCEU_gfree(CHRRAM);
	WRAM = CHRRAM = NULL;
}

/**
 * @brief Restores the state of the system to a previously saved version.
 * 
 * This method triggers a synchronization process to ensure that the system's 
 * state is consistent with the specified version. It is typically used to 
 * revert the system to a known good state after an error or to load a saved 
 * configuration.
 * 
 * @param version The version of the state to restore. This should correspond 
 *                to a previously saved state in the system's history.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * Initializes the Mapper 252 for the provided cartridge information.
 * This function sets up the necessary power and close handlers, configures the IRQ hook,
 * and allocates memory for CHR RAM and WRAM. It also sets up the memory mappings for
 * CHR RAM and WRAM, and adds their states for saving and restoring. If the cartridge
 * has a battery backup, it configures the save game memory accordingly. Finally, it
 * sets up the state restoration function and adds the state registers for saving and
 * restoring the emulator state.
 *
 * @param info Pointer to the CartInfo structure containing cartridge-specific information.
 */
void Mapper252_Init(CartInfo *info) {
	info->Power = M252Power;
	info->Close = M252Close;
	MapIRQHook = M252IRQ;

	CHRRAMSIZE = 2048;
	CHRRAM = (uint8*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CRAM");

	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
