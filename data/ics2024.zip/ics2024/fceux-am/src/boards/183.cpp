/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2005 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Gimmick Bootleg (VRC4 mapper)
 */

#include "mapinc.h"

static uint8 prg[4], chr[8], mirr;
static uint8 IRQCount;
static uint8 IRQPre;
static uint8 IRQa;

static SFORMAT StateRegs[] =
{
	{ prg, 4, "PRG" },
	{ chr, 8, "CHR" },
	{ &mirr, 1, "MIRR" },
	{ &IRQCount, 1, "IRQC" },
	{ &IRQPre, 1, "IRQP" },
	{ &IRQa, 1, "IRQA" },
	{ 0 }
};

/**
 * @brief Synchronizes the Program ROM (PRG) banks in the emulator's memory map.
 *
 * This method configures the PRG ROM banks by mapping them to specific memory 
 * addresses. It uses the `setprg8` function to assign 8 KB PRG ROM banks to 
 * the following memory regions:
 * - 0x6000: Maps the PRG bank at index 3.
 * - 0x8000: Maps the PRG bank at index 0.
 * - 0xA000: Maps the PRG bank at index 1.
 * - 0xC000: Maps the PRG bank at index 2.
 * - 0xE000: Maps the last PRG bank (typically the fixed bank) by using the value ~0.
 *
 * This setup is commonly used in NES emulation to ensure the correct PRG ROM 
 * banks are accessible at the expected memory locations during runtime.
 */
static void SyncPrg(void) {
	setprg8(0x6000, prg[3]);
	setprg8(0x8000, prg[0]);
	setprg8(0xA000, prg[1]);
	setprg8(0xC000, prg[2]);
	setprg8(0xE000, ~0);
}

/**
 * @brief Synchronizes the mirroring mode based on the current value of `mirr`.
 *
 * This method sets the mirroring mode of the system by calling `setmirror` with the appropriate
 * mirroring mode constant. The mirroring mode is determined by the value of the `mirr` variable:
 * - 0: Sets vertical mirroring (MI_V).
 * - 1: Sets horizontal mirroring (MI_H).
 * - 2: Sets single-screen mirroring with the first screen (MI_0).
 * - 3: Sets single-screen mirroring with the second screen (MI_1).
 *
 * The method does not return any value.
 */
static void SyncMirr(void) {
	switch (mirr) {
	case 0: setmirror(MI_V); break;
	case 1: setmirror(MI_H); break;
	case 2: setmirror(MI_0); break;
	case 3: setmirror(MI_1); break;
	}
}

/**
 * @brief Synchronizes the CHR (Character) memory banks by writing the values from the `chr` array to the appropriate memory locations.
 *
 * This method iterates over the first 8 CHR banks (each 1 KB in size) and updates their contents
 * using the `setchr1` function. The `chr` array is assumed to contain the values to be written to
 * each CHR bank. The memory address for each bank is calculated by shifting the index `i` left by
 * 10 bits (equivalent to multiplying by 1024), which aligns with the 1 KB boundary of each CHR bank.
 *
 * @note The `chr` array is expected to be defined elsewhere in the code and must contain at least
 *       8 elements to avoid out-of-bounds access.
 */
static void SyncChr(void) {
	int i;
	for (i = 0; i < 8; i++)
		setchr1(i << 10, chr[i]);
}

/**
 * @brief Restores the emulator state to a previously saved version.
 * 
 * This method synchronizes the program memory (PRG), character memory (CHR),
 * and mirroring settings (MIRR) to match the state of the specified version.
 * It is typically used to revert the emulator to a known state after loading
 * a saved game or snapshot.
 * 
 * @param version The version of the state to restore. This parameter is used
 *                to identify the specific state to which the emulator should
 *                be reverted.
 */
static void StateRestore(int version) {
	SyncPrg();
	SyncChr();
	SyncMirr();
}

/**
 * @brief Handles write operations for the M183 mapper.
 *
 * This method processes write operations to specific memory addresses, updating
 * the PRG ROM, CHR ROM, mirroring, and IRQ settings based on the address (A) and
 * value (V) provided. The behavior depends on the address range and specific
 * address patterns:
 * - If the address matches 0x6800 (masked with 0xF800), it updates the third PRG
 *   ROM bank with the lower 6 bits of the address and synchronizes the PRG ROM.
 * - If the address falls within the range 0xB000 to 0xE00C (masked with 0xF80C),
 *   it updates a specific CHR ROM bank based on the address and value, then
 *   synchronizes the CHR ROM.
 * - For specific address patterns (0x8800, 0xA800, 0xA000, 0x9800), it updates
 *   the corresponding PRG ROM bank or mirroring setting and synchronizes the
 *   respective component.
 * - For IRQ-related addresses (0xF000, 0xF004, 0xF008, 0xF00C), it updates the
 *   IRQ counter, IRQ enable flag, or IRQ pre-counter, and handles IRQ state
 *   changes.
 *
 * @param A The address being written to.
 * @param V The value being written.
 */
static DECLFW(M183Write) {
	if ((A & 0xF800) == 0x6800) {
		prg[3] = A & 0x3F;
		SyncPrg();
	} else if (((A & 0xF80C) >= 0xB000) && ((A & 0xF80C) <= 0xE00C)) {
		int index = (((A >> 11) - 6) | (A >> 3)) & 7;
		chr[index] = (chr[index] & (0xF0 >> (A & 4))) | ((V & 0x0F) << (A & 4));
		SyncChr();
	} else switch (A & 0xF80C) {
		case 0x8800: prg[0] = V; SyncPrg(); break;
		case 0xA800: prg[1] = V; SyncPrg(); break;
		case 0xA000: prg[2] = V; SyncPrg(); break;
		case 0x9800: mirr = V & 3; SyncMirr(); break;
		case 0xF000: IRQCount = ((IRQCount & 0xF0) | (V & 0xF)); break;
		case 0xF004: IRQCount = ((IRQCount & 0x0F) | ((V & 0xF) << 4)); break;
		case 0xF008: IRQa = V; if (!V) IRQPre = 0; X6502_IRQEnd(FCEU_IQEXT); break;
		case 0xF00C: IRQPre = 16; break;
		}
}

/**
 * @brief Handles the IRQ counter logic for M183.
 *
 * This method increments the IRQ counter (IRQCount) if the IRQ flag (IRQa) is set.
 * When the difference between the current IRQ counter value and the previous IRQ counter value (IRQPre)
 * reaches 238, it triggers an external IRQ (FCEU_IQEXT) by calling X6502_IRQBegin.
 *
 * This method is typically used in an emulator context to manage interrupt requests
 * for a specific hardware component (M183).
 */
static void M183IRQCounter(void) {
	if (IRQa) {
		IRQCount++;
		if ((IRQCount - IRQPre) == 238)
			X6502_IRQBegin(FCEU_IQEXT);
	}
}

/**
 * @brief Initializes the M183 mapper's power state.
 *
 * This method sets up the M183 mapper by resetting the IRQ-related variables
 * (IRQPre, IRQCount, and IRQa) to 0. It then configures the memory read and write
 * handlers for the address range 0x6000 to 0xFFFF. The read handler is set to
 * CartBR, and the write handler is set to M183Write. Finally, it synchronizes
 * the PRG and CHR banks by calling SyncPrg() and SyncChr() respectively.
 */
static void M183Power(void) {
	IRQPre = IRQCount = IRQa = 0;
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0xFFFF, M183Write);
	SyncPrg();
	SyncChr();
}

/**
 * @brief Initializes the Mapper 183 for the NES emulator.
 *
 * This function sets up the necessary function pointers and state information for Mapper 183.
 * It assigns the power function (`M183Power`) to the `Power` member of the `CartInfo` structure,
 * which is responsible for handling power-up and reset behavior. Additionally, it sets the IRQ
 * hook (`M183IRQCounter`) to handle interrupt requests during horizontal blanking intervals.
 * The function also registers the state restoration function (`StateRestore`) to restore the
 * emulator state when needed. Finally, it adds the state registers (`StateRegs`) to the emulator's
 * state management system, ensuring that the mapper's state is properly saved and restored.
 *
 * @param info Pointer to the `CartInfo` structure containing cartridge information and function pointers.
 */
void Mapper183_Init(CartInfo *info) {
	info->Power = M183Power;
	GameHBIRQHook = M183IRQCounter;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
