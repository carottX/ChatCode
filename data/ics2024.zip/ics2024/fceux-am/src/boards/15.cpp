/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2006 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "mapinc.h"

static uint16 latchea;
static uint8 latched;
static uint8 *WRAM = NULL;
static uint32 WRAMSIZE;
static SFORMAT StateRegs[] =
{
	{ &latchea, 2, "AREG" },
	{ &latched, 1, "DREG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping and mirroring configuration based on the current state of the latched values.
 *
 * This method updates the Program ROM (PRG) and Character ROM (CHR) memory mappings, as well as the mirroring mode,
 * according to the values stored in the `latched` and `latchea` variables. The behavior depends on the lower 2 bits of `latchea`:
 * - Case 0: Maps four 8KB PRG ROM banks sequentially, starting from the base address derived from `latched`.
 * - Case 2: Maps four 8KB PRG ROM banks with an offset derived from the 7th bit of `latched`.
 * - Cases 1 and 3: Maps four 8KB PRG ROM banks with additional logic to handle specific conditions based on `latchea` and `latched`.
 *
 * The mirroring mode is set using the 6th bit of `latched`, inverted to determine the appropriate mirroring configuration.
 * Finally, the CHR ROM is mapped to a single 8KB bank at address 0.
 */
static void Sync(void) {
	int i;
	setmirror(((latched >> 6) & 1) ^ 1);
	switch (latchea & 3) {
	case 0:
		for (i = 0; i < 4; i++)
			setprg8(0x8000 + (i << 13), ((latched & 0x3F) << 1) + i);
		break;
	case 2:
		for (i = 0; i < 4; i++)
			setprg8(0x8000 + (i << 13), ((latched & 0x3F) << 1) + (latched >> 7));
		break;
	case 1:
	case 3:
		for (i = 0; i < 4; i++) {
			unsigned int b;
			b = latched & 0x3F;
			if (i >= 2 && !(latchea & 0x2))
				b = b | 0x07;
			setprg8(0x8000 + (i << 13), (i & 1) + (b << 1));
		}
		break;
	}
	setchr8(0);
}

/**
 * @brief Handles write operations for Mapper 15 (M15) in the NES emulator.
 * 
 * This method processes write operations to the Mapper 15 (M15) memory space. It updates the 
 * latch values `latchea` and `latched` with the provided address (`A`) and value (`V`). 
 * Depending on the value of `latchea`, it configures the CHR (Character ROM) mapping for the 
 * cartridge. Specifically, if the lower two bits of `latchea` are set to 3 (i.e., `latchea & 3 == 3`), 
 * it sets up the CHR mapping with write protection disabled. Otherwise, it enables write protection.
 * 
 * This implementation supports both complex multi-game cartridges (e.g., 110-in-1 or 168-in-1) and 
 * simplified versions used in Subor/Waixing Chinese originals and hacks. The CHR write protection 
 * is only applied in mode 3, ensuring compatibility across different ROMs.
 * 
 * @param A The address where the write operation is performed.
 * @param V The value to be written to the specified address.
 */
static DECLFW(M15Write) {
	latchea = A;
	latched = V;
	// cah4e3 02.10.19 once again, there may be either two similar mapper 15 exist. the one for 110in1 or 168in1 carts with complex multi game features.
	// and another implified version for subor/waixing chinese originals and hacks with no different modes, working only in mode 0 and which does not
	// expect there is any CHR write protection. protecting CHR writes only for mode 3 fixes the problem, all roms may be run on the same source again.
	if((latchea & 3) == 3)
		SetupCartCHRMapping(0, CHRptr[0], 0x2000, 0);
	else
		SetupCartCHRMapping(0, CHRptr[0], 0x2000, 1);
	Sync();
}

/**
 * @brief Restores the state of the system based on the provided version.
 *
 * This static method is responsible for restoring the system's state to a specific version.
 * It ensures that all necessary synchronization operations are performed by calling the
 * `Sync()` method internally. This method is typically used during system recovery or
 * state rollback scenarios where the system needs to revert to a previous state.
 *
 * @param version The version number to which the system state should be restored.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the M15 power state for the emulator.
 *
 * This method sets up the initial state for the M15 mapper by configuring the
 * latches, PRG-ROM, and memory handlers. It performs the following operations:
 * - Initializes `latchea` to 0x8000 and `latched` to 0.
 * - Maps the PRG-ROM bank 0x10 to the address range 0x6000-0x7FFF.
 * - Sets up read and write handlers for the address ranges 0x6000-0x7FFF and
 *   0x8000-0xFFFF, using `CartBR` for reads and `CartBW` for writes in the
 *   lower range, and `M15Write` for writes in the upper range.
 * - Adds RAM for cheat functionality at the address 0x6000 with the size of
 *   `WRAMSIZE`.
 * - Synchronizes the emulator state to ensure consistency.
 */
static void M15Power(void) {
	latchea = 0x8000;
	latched = 0;
	setprg8r(0x10, 0x6000, 0);
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetWriteHandler(0x8000, 0xFFFF, M15Write);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	FCEU_CheatAddRAM(WRAMSIZE >> 10, 0x6000, WRAM);
	Sync();
}

/**
 * @brief Resets the M15 module to its initial state.
 * 
 * This method sets the `latchea` register to its default value of 0x8000 and
 * clears the `latched` register by setting it to 0. After updating these registers,
 * it calls the `Sync()` function to ensure the module's state is synchronized.
 * 
 * This is typically used to initialize or reset the M15 module to a known state
 * before starting or restarting its operation.
 */
static void M15Reset(void) {
	latchea = 0x8000;
	latched = 0;
	Sync();
}

/**
 * @brief Closes and frees the memory allocated for the WRAM (Work RAM) used by the emulator.
 *
 * This method checks if the WRAM pointer is not null. If WRAM is allocated, it frees the memory
 * using the `FCEU_gfree` function to prevent memory leaks. After freeing the memory, it sets the
 * WRAM pointer to null to indicate that no memory is currently allocated for WRAM.
 *
 * @note This method is static, meaning it can be called without an instance of the class.
 */
static void M15Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
}

/**
 * Initializes the Mapper 15 configuration for the given cartridge information.
 * This method sets up the necessary function pointers for power, reset, and close operations
 * specific to Mapper 15. It also allocates and configures the Work RAM (WRAM) for the cartridge,
 * sets up the PRG mapping, and handles battery-backed save game data if applicable. Additionally,
 * it registers the WRAM and state registers for emulator state saving and restoring.
 *
 * @param info A pointer to the CartInfo structure that holds the cartridge configuration
 *             and state information. This structure is modified to include the Mapper 15
 *             specific settings and memory mappings.
 */
void Mapper15_Init(CartInfo *info) {
	info->Power = M15Power;
	info->Reset = M15Reset;
	info->Close = M15Close;
	GameStateRestore = StateRestore;
	WRAMSIZE = 8192;
	WRAM = (uint8*)FCEU_gmalloc(WRAMSIZE);
	SetupCartPRGMapping(0x10, WRAM, WRAMSIZE, 1);
	if (info->battery) {
		info->SaveGame[0] = WRAM;
		info->SaveGameLen[0] = WRAMSIZE;
	}
	AddExState(WRAM, WRAMSIZE, 0, "WRAM");
	AddExState(&StateRegs, ~0, 0, 0);
}

