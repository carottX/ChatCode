/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"

static uint8 reg;

static SFORMAT StateRegs[] =
{
	{ &reg, 1, "REG" },
	{ 0 }
};

/**
 * @brief Synchronizes the memory mapping for the NES emulator.
 * 
 * This method configures the Programmable Read-Only Memory (PRG) and 
 * Character Read-Only Memory (CHR) banks for the NES emulator. It performs 
 * the following operations:
 * - Maps the PRG bank at address 0x6000 using the value stored in the `reg` variable.
 * - Maps the last 32 KB PRG bank (indicated by ~0) at address 0x8000.
 * - Maps the entire 8 KB CHR bank at address 0x0000.
 * 
 * This ensures that the emulator's memory is properly configured for the 
 * current state of the game or application being emulated.
 */
static void Sync(void) {
	setprg8(0x6000, reg);
	setprg32(0x8000, ~0);
	setchr8(0);
}

/**
 * @brief Writes a value to the M108 register and synchronizes the state.
 *
 * This method assigns the provided value `V` to the `reg` variable, which represents
 * the M108 register. After updating the register, it calls the `Sync()` method to
 * ensure that the system state is synchronized with the new register value.
 *
 * @param V The value to be written to the M108 register.
 */
static DECLFW(M108Write) {
	reg = V;
	Sync();
}

/**
 * @brief Configures the memory mapping for the M108 cartridge.
 *
 * This method sets up the read and write handlers for the M108 cartridge. It synchronizes
 * the system state and then configures the following memory mappings:
 * - Read handlers for the address ranges 0x6000-0x7FFF and 0x8000-0xFFFF to use the CartBR function.
 * - Write handlers for the address ranges 0x8000-0x8FFF and 0xF000-0xFFFF to use the M108Write function.
 * The write handlers are configured to support both the regular M108 cartridge and a simplified
 * Kaiser BB Hack variant.
 */
static void M108Power(void) {
	Sync();
	SetReadHandler(0x6000, 0x7FFF, CartBR);
	SetReadHandler(0x8000, 0xFFFF, CartBR);
	SetWriteHandler(0x8000, 0x8FFF, M108Write); // regular 108
	SetWriteHandler(0xF000, 0xFFFF, M108Write); // simplified Kaiser BB Hack
}

/**
 * @brief Restores the state of the system to a previous version.
 * 
 * This method is responsible for restoring the system state to a specified version.
 * It first calls the `Sync()` method to ensure that all pending operations are
 * synchronized before proceeding with the state restoration. The `version` parameter
 * indicates the specific state version to which the system should be restored.
 * 
 * @param version The version number of the state to restore.
 */
static void StateRestore(int version) {
	Sync();
}

/**
 * @brief Initializes the Mapper 108 for the given cartridge information.
 *
 * This method sets up the necessary configurations for Mapper 108 by assigning the 
 * power function (`M108Power`) to the `Power` member of the `CartInfo` structure. 
 * It also sets the `GameStateRestore` function to `StateRestore` and adds the 
 * state registers (`StateRegs`) to the external state management system using 
 * `AddExState`. The `AddExState` function is called with parameters to ensure 
 * that all state registers are included and no specific flags are set.
 *
 * @param info Pointer to the `CartInfo` structure that holds the cartridge 
 *             configuration and state information.
 */
void Mapper108_Init(CartInfo *info) {
	info->Power = M108Power;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
}
