#include "types.h"
#include "sound.h"

//uint32 soundtsoffs = 0;
//uint32 soundtsinc = 1;
//bool DMC_7bit = 0;
//EXPSOUND GameExpSound = {};
//int32 WaveHi[40000] = {};
//int32 Wave[2048+512] = {};
//int32 nesincsize=0;
uint8 *UNIFchrrama = 0;

/**
 * @brief Adds an external state to the current context.
 *
 * This method is used to register an external state block with the system, allowing it to be managed
 * and persisted as part of the application's state. The state block is identified by its memory address,
 * size, type, and an optional description.
 *
 * @param v Pointer to the external state block to be added.
 * @param s Size of the external state block in bytes.
 * @param type Type identifier for the external state block, used for categorization or processing.
 * @param desc Optional description of the external state block, providing additional context or information.
 */
void AddExState(void *v, uint32 s, int type, const char *desc) { }
/**
 * @brief Adds a cheat code to the RAM of the emulator.
 *
 * This method is used to insert a cheat code into the emulator's RAM at a specified address.
 * The cheat code modifies the memory at the given address to the specified value, allowing
 * for game modifications such as infinite lives, invincibility, etc.
 *
 * @param s The size of the cheat code in bytes. This determines how many bytes will be modified
 *          starting from the specified address.
 * @param A The address in the emulator's RAM where the cheat code will be applied. This is the
 *          starting location for the memory modification.
 * @param p A pointer to the data that will be written to the specified address. This data
 *          represents the cheat code value(s) to be applied.
 */
void FCEU_CheatAddRAM(int s, uint32 A, uint8 *p) { }
