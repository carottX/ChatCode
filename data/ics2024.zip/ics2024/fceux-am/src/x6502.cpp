/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "types.h"
#include "x6502.h"
#include "fceu.h"
#include "sound.h"

#include "x6502abbrev.h"

X6502 X;
uint32 timestamp;
uint32 soundtimestamp;
void (*MapIRQHook)(int a);

#define ADDCYC(x) \
{                 \
 int __x=x;       \
 _tcount+=__x;    \
 _count-=__x*48;  \
 timestamp+=__x;  \
 if(!overclocking) soundtimestamp+=__x; \
}

//normal memory read
static INLINE uint8 RdMem(unsigned int A)
{
 return(_DB=readb(A));
}

//normal memory write
static INLINE void WrMem(unsigned int A, uint8 V)
{
	writeb(A, V);
}

/**
 * @brief Reads a byte from the emulated RAM at the specified address.
 *
 * This method is used to read a single byte from the emulated RAM at the given address `A`.
 * The read value is stored in the global variable `_DB` and then returned. The method is 
 * optimized for inline execution and is typically used in performance-critical sections 
 * of the emulator.
 *
 * @param A The address in the emulated RAM from which to read the byte.
 * @return The byte read from the RAM at address `A`.
 */
static INLINE uint8 RdRAM(unsigned int A)
{
  //bbit edited: this was changed so cheat substituion would work
  //return(_DB=ARead[A](A));
   return(_DB=RAM[A]);
}

/**
 * @brief Writes a value to the specified address in the RAM.
 * 
 * This method writes the given 8-bit value `V` to the memory location 
 * specified by the address `A` in the RAM. The address `A` is expected 
 * to be a valid index within the bounds of the RAM array.
 * 
 * @param A The address in the RAM where the value will be written.
 * @param V The 8-bit value to be written to the specified RAM address.
 */
static INLINE void WrRAM(unsigned int A, uint8 V)
{
	RAM[A]=V;
}

/**
 * @brief Performs a Direct Memory Read (DMR) operation on the 6502 processor.
 * 
 * This method reads a byte from the specified memory address `A` and stores it in the
 * data bus (DB) register of the 6502 processor. It also increments the cycle count by 1
 * to account for the time taken to perform the memory read operation.
 * 
 * @param A The 32-bit memory address from which to read the byte.
 * @return The byte read from memory address `A`, which is also stored in the DB register.
 */
uint8 X6502_DMR(uint32 A)
{
 ADDCYC(1);
 return(X.DB=readb(A));
}

/**
 * @brief Writes a byte to the specified memory address and increments the cycle count.
 *
 * This method writes the given byte value `V` to the memory address `A` using the `writeb` function.
 * Additionally, it increments the cycle count by 1 using the `ADDCYC` macro. This is typically used
 * in the context of a 6502 processor emulator to simulate memory write operations and track the
 * number of cycles consumed by the operation.
 *
 * @param A The 32-bit memory address where the byte will be written.
 * @param V The 8-bit value to write to the specified memory address.
 */
void X6502_DMW(uint32 A, uint8 V)
{
 ADDCYC(1);
 writeb(A, V);
}

#define PUSH(V) \
{       \
 uint8 VTMP=V;  \
 WrRAM(0x100+_S,VTMP);  \
 _S--;  \
}

#define POP() RdRAM(0x100+(++_S))

static uint8 ZNTable[256];
/* Some of these operations will only make sense if you know what the flag
   constants are. */

#define X_ZN(zort)      _P&=~(Z_FLAG|N_FLAG);_P|=ZNTable[zort]
#define X_ZNT(zort)  _P|=ZNTable[zort]

#define JR(cond);  \
{    \
 if(cond)  \
 {  \
  uint32 tmp;  \
  int32 disp;  \
  disp=(int8)RdMem(_PC);  \
  _PC++;  \
  ADDCYC(1);  \
  tmp=_PC;  \
  _PC+=disp;  \
  if((tmp^_PC)&0x100)  \
  ADDCYC(1);  \
 }  \
 else _PC++;  \
}


#define LDA     _A=x;X_ZN(_A)
#define LDX     _X=x;X_ZN(_X)
#define LDY  _Y=x;X_ZN(_Y)

/*  All of the freaky arithmetic operations. */
#define AND  _A&=x;X_ZN(_A)
#define BIT  _P&=~(Z_FLAG|V_FLAG|N_FLAG);_P|=ZNTable[x&_A]&Z_FLAG;_P|=x&(V_FLAG|N_FLAG)
#define EOR  _A^=x;X_ZN(_A)
#define ORA  _A|=x;X_ZN(_A)

#define ADC  {  \
        uint32 l=_A+x+(_P&1);  \
        _P&=~(Z_FLAG|C_FLAG|N_FLAG|V_FLAG);  \
        _P|=((((_A^x)&0x80)^0x80) & ((_A^l)&0x80))>>1;  \
        _P|=(l>>8)&C_FLAG;  \
        _A=l;  \
        X_ZNT(_A);  \
       }

#define SBC  {  \
        uint32 l=_A-x-((_P&1)^1);  \
        _P&=~(Z_FLAG|C_FLAG|N_FLAG|V_FLAG);  \
        _P|=((_A^l)&(_A^x)&0x80)>>1;  \
        _P|=((l>>8)&C_FLAG)^C_FLAG;  \
        _A=l;  \
        X_ZNT(_A);  \
       }

#define CMPL(a1,a2) {  \
         uint32 t=a1-a2;  \
         X_ZN(t&0xFF);  \
         _P&=~C_FLAG;  \
         _P|=((t>>8)&C_FLAG)^C_FLAG;  \
		    }

/* Special undocumented operation.  Very similar to CMP. */
#define AXS      {  \
                     uint32 t=(_A&_X)-x;    \
                     X_ZN(t&0xFF);      \
                     _P&=~C_FLAG;       \
         _P|=((t>>8)&C_FLAG)^C_FLAG;  \
         _X=t;  \
        }

#define CMP    CMPL(_A,x)
#define CPX    CMPL(_X,x)
#define CPY          CMPL(_Y,x)

/* The following operations modify the byte being worked on. */
#define DEC         x--;X_ZN(x)
#define INC    x++;X_ZN(x)

#define ASL  _P&=~C_FLAG;_P|=x>>7;x<<=1;X_ZN(x)
#define LSR  _P&=~(C_FLAG|N_FLAG|Z_FLAG);_P|=x&1;x>>=1;X_ZNT(x)

/* For undocumented instructions, maybe for other things later... */
#define LSRA  _P&=~(C_FLAG|N_FLAG|Z_FLAG);_P|=_A&1;_A>>=1;X_ZNT(_A)

#define ROL  {  \
     uint8 l=x>>7;  \
     x<<=1;  \
     x|=_P&C_FLAG;  \
     _P&=~(Z_FLAG|N_FLAG|C_FLAG);  \
     _P|=l;  \
     X_ZNT(x);  \
    }
#define ROR  {  \
     uint8 l=x&1;  \
     x>>=1;  \
     x|=(_P&C_FLAG)<<7;  \
     _P&=~(Z_FLAG|N_FLAG|C_FLAG);  \
     _P|=l;  \
     X_ZNT(x);  \
		}

/* Icky icky thing for some undocumented instructions.  Can easily be
   broken if names of local variables are changed.
*/

/* Absolute */
#define GetAB(target)   \
{  \
 target=RdMem(_PC);  \
 _PC++;  \
 target|=RdMem(_PC)<<8;  \
 _PC++;  \
}

/* Absolute Indexed(for reads) */
#define GetABIRD(target, i)  \
{  \
 unsigned int tmp;  \
 GetAB(tmp);  \
 target=tmp;  \
 target+=i;  \
 if((target^tmp)&0x100)  \
 {  \
  target&=0xFFFF;  \
  RdMem(target^0x100);  \
  ADDCYC(1);  \
 }  \
}

/* Absolute Indexed(for writes and rmws) */
#define GetABIWR(target, i)  \
{  \
 unsigned int rt;  \
 GetAB(rt);  \
 target=rt;  \
 target+=i;  \
 target&=0xFFFF;  \
 RdMem((target&0x00FF)|(rt&0xFF00));  \
}

/* Zero Page */
#define GetZP(target)  \
{  \
 target=RdMem(_PC);   \
 _PC++;  \
}

/* Zero Page Indexed */
#define GetZPI(target,i)  \
{  \
 target=i+RdMem(_PC);  \
 _PC++;  \
}

/* Indexed Indirect */
#define GetIX(target)  \
{  \
 uint8 tmp;  \
 tmp=RdMem(_PC);  \
 _PC++;  \
 tmp+=_X;  \
 target=RdRAM(tmp);  \
 tmp++;    \
 target|=RdRAM(tmp)<<8;  \
}

/* Indirect Indexed(for reads) */
#define GetIYRD(target)  \
{  \
 unsigned int rt;  \
 uint8 tmp;  \
 tmp=RdMem(_PC);  \
 _PC++;  \
 rt=RdRAM(tmp);  \
 tmp++;  \
 rt|=RdRAM(tmp)<<8;  \
 target=rt;  \
 target+=_Y;  \
 if((target^rt)&0x100)  \
 {  \
  target&=0xFFFF;  \
  RdMem(target^0x100);  \
  ADDCYC(1);  \
 }  \
}

/* Indirect Indexed(for writes and rmws) */
#define GetIYWR(target)  \
{  \
 unsigned int rt;  \
 uint8 tmp;  \
 tmp=RdMem(_PC);  \
 _PC++;  \
 rt=RdRAM(tmp);  \
 tmp++;  \
 rt|=RdRAM(tmp)<<8;  \
 target=rt;  \
 target+=_Y;  \
 target&=0xFFFF; \
 RdMem((target&0x00FF)|(rt&0xFF00));  \
}

/* Now come the macros to wrap up all of the above stuff addressing mode functions
   and operation macros.  Note that operation macros will always operate(redundant
   redundant) on the variable "x".
*/

#define RMW_A(op) {uint8 x=_A; op; _A=x; break; } /* Meh... */
#define RMW_AB(op) {unsigned int A; uint8 x; GetAB(A); x=RdMem(A); WrMem(A,x); op; WrMem(A,x); break; }
#define RMW_ABI(reg,op) {unsigned int A; uint8 x; GetABIWR(A,reg); x=RdMem(A); WrMem(A,x); op; WrMem(A,x); break; }
#define RMW_ABX(op)  RMW_ABI(_X,op)
#define RMW_ABY(op)  RMW_ABI(_Y,op)
#define RMW_IX(op)  {unsigned int A; uint8 x; GetIX(A); x=RdMem(A); WrMem(A,x); op; WrMem(A,x); break; }
#define RMW_IY(op)  {unsigned int A; uint8 x; GetIYWR(A); x=RdMem(A); WrMem(A,x); op; WrMem(A,x); break; }
#define RMW_ZP(op)  {uint8 A; uint8 x; GetZP(A); x=RdRAM(A); op; WrRAM(A,x); break; }
#define RMW_ZPX(op) {uint8 A; uint8 x; GetZPI(A,_X); x=RdRAM(A); op; WrRAM(A,x); break;}

#define LD_IM(op)  {uint8 x; x=RdMem(_PC); _PC++; op; break;}
#define LD_ZP(op)  {uint8 A; uint8 x; GetZP(A); x=RdRAM(A); op; break;}
#define LD_ZPX(op)  {uint8 A; uint8 x; GetZPI(A,_X); x=RdRAM(A); op; break;}
#define LD_ZPY(op)  {uint8 A; uint8 x; GetZPI(A,_Y); x=RdRAM(A); op; break;}
#define LD_AB(op)  {unsigned int A;  __attribute__((unused)) uint8 x; GetAB(A); x=RdMem(A); op; break; }
#define LD_ABI(reg,op)  {unsigned int A; __attribute__((unused)) uint8 x; GetABIRD(A,reg); x=RdMem(A); op; break;}
#define LD_ABX(op)  LD_ABI(_X,op)
#define LD_ABY(op)  LD_ABI(_Y,op)
#define LD_IX(op)  {unsigned int A; uint8 x; GetIX(A); x=RdMem(A); op; break;}
#define LD_IY(op)  {unsigned int A; uint8 x; GetIYRD(A); x=RdMem(A); op; break;}

#define ST_ZP(r)  {uint8 A; GetZP(A); WrRAM(A,r); break;}
#define ST_ZPX(r)  {uint8 A; GetZPI(A,_X); WrRAM(A,r); break;}
#define ST_ZPY(r)  {uint8 A; GetZPI(A,_Y); WrRAM(A,r); break;}
#define ST_AB(r)  {unsigned int A; GetAB(A); WrMem(A,r); break;}
#define ST_ABI(reg,r)  {unsigned int A; GetABIWR(A,reg); WrMem(A,r); break; }
#define ST_ABX(r)  ST_ABI(_X,r)
#define ST_ABY(r)  ST_ABI(_Y,r)
#define ST_IX(r)  {unsigned int A; GetIX(A); WrMem(A,r); break; }
#define ST_IY(r)  {unsigned int A; GetIYWR(A); WrMem(A,r); break; }

static uint8 CycTable[256] =
{
/*0x00*/ 7,6,2,8,3,3,5,5,3,2,2,2,4,4,6,6,
/*0x10*/ 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
/*0x20*/ 6,6,2,8,3,3,5,5,4,2,2,2,4,4,6,6,
/*0x30*/ 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
/*0x40*/ 6,6,2,8,3,3,5,5,3,2,2,2,3,4,6,6,
/*0x50*/ 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
/*0x60*/ 6,6,2,8,3,3,5,5,4,2,2,2,5,4,6,6,
/*0x70*/ 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
/*0x80*/ 2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4,
/*0x90*/ 2,6,2,6,4,4,4,4,2,5,2,5,5,5,5,5,
/*0xA0*/ 2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4,
/*0xB0*/ 2,5,2,5,4,4,4,4,2,4,2,4,4,4,4,4,
/*0xC0*/ 2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6,
/*0xD0*/ 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
/*0xE0*/ 2,6,3,8,3,3,5,5,2,2,2,2,4,4,6,6,
/*0xF0*/ 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
};

/**
 * @brief Signals the start of an interrupt request (IRQ) by setting the specified IRQ flag.
 *
 * This method sets the IRQ flag in the internal state of the X6502 processor. The flag is 
 * combined with the existing IRQ flags using a bitwise OR operation. This allows multiple 
 * IRQ sources to be active simultaneously. When an IRQ flag is set, the processor will 
 * handle the interrupt at the next appropriate cycle.
 *
 * @param w The IRQ flag to set. This is typically a bitmask representing a specific IRQ source.
 */
void X6502_IRQBegin(int w)
{
 _IRQlow|=w;
}

/**
 * @brief Clears the specified interrupt request (IRQ) flag in the _IRQlow register.
 *
 * This method is used to signal the end of an interrupt request by clearing the corresponding bit
 * in the _IRQlow register. The bit to be cleared is specified by the parameter `w`, which represents
 * the mask for the IRQ flag. The method performs a bitwise AND operation with the complement of `w`
 * to clear the corresponding bit in _IRQlow.
 *
 * @param w The mask representing the IRQ flag to be cleared. Only the bit corresponding to `w` will
 *          be cleared in the _IRQlow register.
 */
void X6502_IRQEnd(int w)
{
 _IRQlow&=~w;
}

/**
 * @brief Triggers a Non-Maskable Interrupt (NMI) by setting the NMI flag in the IRQ status register.
 *
 * This method sets the NMI bit in the `_IRQlow` register, which is used to indicate that a Non-Maskable Interrupt
 * has been triggered. Non-Maskable Interrupts are special types of interrupts that cannot be ignored by the CPU
 * and are typically used for critical system events. The `FCEU_IQNMI` constant represents the bitmask for the NMI flag.
 *
 * @note This method does not return any value and does not take any parameters. It directly modifies the `_IRQlow`
 * register to signal the NMI.
 */
void TriggerNMI(void)
{
 _IRQlow|=FCEU_IQNMI;
}

/**
 * @brief Triggers a Non-Maskable Interrupt (NMI) of type 2.
 *
 * This method sets the NMI2 flag in the interrupt request (IRQ) status register.
 * The NMI2 flag is combined with the existing IRQ status using a bitwise OR operation,
 * ensuring that the NMI2 interrupt is recognized by the system. This is typically used
 * to signal a high-priority event that requires immediate attention, as NMIs cannot
 * be masked or ignored by the processor.
 *
 * @note The specific behavior of the NMI2 interrupt is dependent on the system's
 * interrupt handling logic and the definition of `FCEU_IQNMI2`.
 */
void TriggerNMI2(void)
{
 _IRQlow|=FCEU_IQNMI2;
}

/**
 * @brief Resets the X6502 processor by setting the IRQ line to the reset state.
 *
 * This method initializes the X6502 processor by setting the internal IRQ line
 * to the reset state using the `FCEU_IQRESET` constant. This is typically called
 * during a system reset to ensure the processor starts in a known state.
 */
void X6502_Reset(void)
{
 _IRQlow=FCEU_IQRESET;
}
/**
* Initializes the 6502 CPU
**/
void X6502_Init(void)
{
	unsigned int i;

	// Initialize the CPU structure
	memset((void *)&X,0,sizeof(X));

	for(i = 0; i < sizeof(ZNTable); i++)
	{
		if(!i)
		{
			ZNTable[i] = Z_FLAG;
		}
		else if ( i & 0x80 )
		{
			ZNTable[i] = N_FLAG;
		}
		else
		{
			ZNTable[i] = 0;
		}
	}
}

extern int StackAddrBackup;
/**
 * @brief Resets the state of the 6502 processor to its initial power-on state.
 *
 * This method initializes all internal registers and flags of the 6502 processor to their default values.
 * Specifically, it sets the cycle counters (_count and _tcount), interrupt flags (_IRQlow), program counter (_PC),
 * accumulator (_A), X register (_X), Y register (_Y), status register (_P), previous interrupt status (_PI),
 * data bus (_DB), and jammed state (_jammed) to 0. The stack pointer (_S) is initialized to 0xFD, which is the
 * default value for the stack pointer at power-on. The timestamp and soundtimestamp are also reset to 0.
 * Finally, the method calls X6502_Reset() to perform any additional reset operations.
 */
void X6502_Power(void)
{
 _count=_tcount=_IRQlow=_PC=_A=_X=_Y=_P=_PI=_DB=_jammed=0;
 _S=0xFD;
 timestamp=soundtimestamp=0;
 X6502_Reset();
 //StackAddrBackup = -1;
}

/**
 * @brief Executes the emulated CPU for a specified number of cycles.
 *
 * This method runs the emulated CPU for the given number of cycles, adjusting for PAL/NTSC timing differences.
 * It handles interrupt requests (IRQs), non-maskable interrupts (NMIs), and reset signals. The method also
 * processes CPU instructions, updates the program counter (PC), and manages cycle counting. Debugging and
 * sound processing hooks are invoked as needed. If the CPU enters a spin loop, it ensures the run completes
 * efficiently.
 *
 * @param cycles The number of cycles to execute. This value is adjusted based on the PAL/NTSC timing mode.
 *               In PAL mode, the cycles are multiplied by 15 (15*4=60), and in NTSC mode, they are multiplied
 *               by 16 (16*4=64).
 *
 * @details The method performs the following steps:
 * 1. Adjusts the cycle count based on the PAL/NTSC timing mode.
 * 2. Handles IRQs, NMIs, and reset signals, updating the CPU state and program counter as necessary.
 * 3. Processes CPU instructions, updating the program counter and cycle count.
 * 4. Invokes debugging and sound processing hooks if enabled.
 * 5. Detects and handles spin loops to ensure efficient execution.
 */
void X6502_Run(int32 cycles)
{
  if(PAL)
   cycles*=15;    // 15*4=60
  else
   cycles*=16;    // 16*4=64

  _count+=cycles;
extern int test; test++;
  while(_count>0)
  {
   int32 temp;
   uint8 b1;

   if(_IRQlow)
   {
    if(_IRQlow&FCEU_IQRESET)
    {
	 DEBUG( if(debug_loggingCD) LogCDVectors(0xFFFC); )
     _PC=RdMem(0xFFFC);
     _PC|=RdMem(0xFFFD)<<8;
     _jammed=0;
     _PI=_P=I_FLAG;
     _IRQlow&=~FCEU_IQRESET;
    }
    else if(_IRQlow&FCEU_IQNMI2)
     {
     _IRQlow&=~FCEU_IQNMI2;
     _IRQlow|=FCEU_IQNMI;
    }
    else if(_IRQlow&FCEU_IQNMI)
    {
     if(!_jammed)
     {
      ADDCYC(7);
      PUSH(_PC>>8);
      PUSH(_PC);
      PUSH((_P&~B_FLAG)|(U_FLAG));
      _P|=I_FLAG;
	  DEBUG( if(debug_loggingCD) LogCDVectors(0xFFFA) );
      _PC=RdMem(0xFFFA);
      _PC|=RdMem(0xFFFB)<<8;
      _IRQlow&=~FCEU_IQNMI;
     }
    }
    else
    {
     if(!(_PI&I_FLAG) && !_jammed)
     {
      ADDCYC(7);
      PUSH(_PC>>8);
      PUSH(_PC);
      PUSH((_P&~B_FLAG)|(U_FLAG));
      _P|=I_FLAG;
	  DEBUG( if(debug_loggingCD) LogCDVectors(0xFFFE) );
      _PC=RdMem(0xFFFE);
      _PC|=RdMem(0xFFFF)<<8;
     }
    }
    _IRQlow&=~(FCEU_IQTEMP);
    if(_count<=0)
    {
     _PI=_P;
     return;
     } //Should increase accuracy without a
              //major speed hit.
   }

	//will probably cause a major speed decrease on low-end systems
   DEBUG( DebugCycle() );

   //IncrementInstructionsCounters();

   _PI=_P;
   b1=RdMem(_PC);

   ADDCYC(CycTable[b1]);

   temp=_tcount;
   _tcount=0;
   if(MapIRQHook) MapIRQHook(temp);

   if (!overclocking)
    FCEU_SoundCPUHook(temp);

   uint32 lastPC = _PC;
   _PC++;
   switch(b1)
   {
    #include "ops.inc"
   }
   if (lastPC == _PC && _count > 0) {
     // spinning, just finish the run
     ADDCYC(_count / 48);
   }
  }
}

//--------------------------
//---Called from debuggers
void FCEUI_NMI(void)
{
 _IRQlow|=FCEU_IQNMI;
}

/**
 * @brief Sets the IRQ (Interrupt Request) flag by performing a bitwise OR operation
 *        between the current value of _IRQlow and the value of FCEU_IQTEMP.
 * 
 * This method is used to signal an interrupt request by updating the _IRQlow
 * variable. The specific interrupt type or condition is represented by the
 * FCEU_IQTEMP constant. The method ensures that the IRQ flag is set without
 * clearing any previously set flags in _IRQlow.
 */
void FCEUI_IRQ(void)
{
 _IRQlow|=FCEU_IQTEMP;
}

/**
 * @brief Retrieves the interrupt vectors from the memory addresses 0xFFFC, 0xFFFD, 0xFFFA, 0xFFFB, 0xFFFE, and 0xFFFF.
 * 
 * This method reads the reset, NMI (Non-Maskable Interrupt), and IRQ (Interrupt Request) vectors from the specified memory locations.
 * The reset vector is read from addresses 0xFFFC and 0xFFFD, the NMI vector from addresses 0xFFFA and 0xFFFB, and the IRQ vector from addresses 0xFFFE and 0xFFFF.
 * The values are combined into 16-bit integers and stored in the provided pointers.
 * 
 * @param reset Pointer to store the 16-bit reset vector.
 * @param irq Pointer to store the 16-bit IRQ vector.
 * @param nmi Pointer to store the 16-bit NMI vector.
 */
void FCEUI_GetIVectors(uint16 *reset, uint16 *irq, uint16 *nmi)
{
 fceuindbg=1;

 *reset=RdMem(0xFFFC);
 *reset|=RdMem(0xFFFD)<<8;
 *nmi=RdMem(0xFFFA);
 *nmi|=RdMem(0xFFFB)<<8;
 *irq=RdMem(0xFFFE);
 *irq|=RdMem(0xFFFF)<<8;
 fceuindbg=0;
}

//the opsize table is used to quickly grab the instruction sizes (in bytes)
const uint8 opsize[256] = {
#ifdef BRK_3BYTE_HACK
/*0x00*/	3, //BRK
#else
/*0x00*/	1, //BRK
#endif
/*0x01*/      2,0,0,0,2,2,0,1,2,1,0,0,3,3,0,
/*0x10*/	2,2,0,0,0,2,2,0,1,3,0,0,0,3,3,0,
/*0x20*/	3,2,0,0,2,2,2,0,1,2,1,0,3,3,3,0,
/*0x30*/	2,2,0,0,0,2,2,0,1,3,0,0,0,3,3,0,
/*0x40*/	1,2,0,0,0,2,2,0,1,2,1,0,3,3,3,0,
/*0x50*/	2,2,0,0,0,2,2,0,1,3,0,0,0,3,3,0,
/*0x60*/	1,2,0,0,0,2,2,0,1,2,1,0,3,3,3,0,
/*0x70*/	2,2,0,0,0,2,2,0,1,3,0,0,0,3,3,0,
/*0x80*/	0,2,0,0,2,2,2,0,1,0,1,0,3,3,3,0,
/*0x90*/	2,2,0,0,2,2,2,0,1,3,1,0,0,3,0,0,
/*0xA0*/	2,2,2,0,2,2,2,0,1,2,1,0,3,3,3,0,
/*0xB0*/	2,2,0,0,2,2,2,0,1,3,1,0,3,3,3,0,
/*0xC0*/	2,2,0,0,2,2,2,0,1,2,1,0,3,3,3,0,
/*0xD0*/	2,2,0,0,0,2,2,0,1,3,0,0,0,3,3,0,
/*0xE0*/	2,2,0,0,2,2,2,0,1,2,1,0,3,3,3,0,
/*0xF0*/	2,2,0,0,0,2,2,0,1,3,0,0,0,3,3,0
};


//the optype table is a quick way to grab the addressing mode for any 6502 opcode
//
//  0 = Implied\Accumulator\Immediate\Branch\NULL
//  1 = (Indirect,X)
//  2 = Zero Page
//  3 = Absolute
//  4 = (Indirect),Y
//  5 = Zero Page,X
//  6 = Absolute,Y
//  7 = Absolute,X
//  8 = Zero Page,Y
//
const uint8 optype[256] = {
/*0x00*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0x10*/	0,4,0,3,5,5,5,5,0,6,0,6,7,7,7,7,
/*0x20*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0x30*/	0,4,0,3,5,5,5,5,0,6,0,6,7,7,7,7,
/*0x40*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0x50*/	0,4,0,3,5,5,5,5,0,6,0,6,7,7,7,7,
/*0x60*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0x70*/	0,4,0,3,5,5,5,5,0,6,0,6,7,7,7,7,
/*0x80*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0x90*/	0,4,0,3,5,5,8,8,0,6,0,6,7,7,6,6,
/*0xA0*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0xB0*/	0,4,0,3,5,5,8,8,0,6,0,6,7,7,6,6,
/*0xC0*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0xD0*/	0,4,0,3,5,5,5,5,0,6,0,6,7,7,7,7,
/*0xE0*/	0,1,0,1,2,2,2,2,0,0,0,0,3,3,3,3,
/*0xF0*/	0,4,0,3,5,5,5,5,0,6,0,6,7,7,7,7,
};

// the opwrite table aids in predicting the value written for any 6502 opcode
//
//  0 = No value written
//  1 = Write from A
//  2 = Write from X
//  3 = Write from Y
//  4 = Write from P
//  5 = ASL (SLO)
//  6 = LSR (SRE)
//  7 = ROL (RLA)
//  8 = ROR (RRA)
//  9 = INC (ISC)
// 10 = DEC (DCP)
// 11 = (SAX)
// 12 = (AHX)
// 13 = (SHY)
// 14 = (SHX)
// 15 = (TAS)

const uint8 opwrite[256] = {
/*0x00*/	 0, 0, 0, 5, 0, 0, 5, 5, 4, 0, 0, 0, 0, 0, 5, 5,
/*0x10*/	 0, 0, 0, 5, 0, 0, 5, 5, 0, 0, 0, 5, 0, 0, 5, 5,
/*0x20*/	 0, 0, 0, 7, 0, 0, 7, 7, 0, 0, 7, 0, 0, 0, 7, 7,
/*0x30*/	 0, 0, 0, 7, 0, 0, 7, 7, 0, 0, 0, 7, 0, 0, 7, 7,
/*0x40*/	 0, 0, 0, 6, 0, 0, 6, 6, 1, 0, 6, 0, 0, 0, 6, 6,
/*0x50*/	 0, 0, 0, 6, 0, 0, 6, 6, 0, 0, 0, 6, 0, 0, 6, 6,
/*0x60*/	 0, 0, 0, 8, 0, 0, 8, 8, 0, 0, 8, 0, 0, 0, 8, 8,
/*0x70*/	 0, 0, 0, 8, 0, 0, 8, 8, 0, 0, 0, 8, 0, 0, 8, 8,
/*0x80*/	 0, 1, 0,11, 3, 1, 2,11, 0, 0, 0, 0, 3, 1, 2,11,
/*0x90*/	 0, 1, 0,12, 3, 1, 2,11, 0, 1, 0,15,13, 1,14,12,
/*0xA0*/	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
/*0xB0*/	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
/*0xC0*/	 0, 0, 0,10, 0, 0,10,10, 0, 0, 0, 0, 0, 0,10,10,
/*0xD0*/	 0, 0, 0,10, 0, 0,10,10, 0, 0, 0,10, 0, 0,10,10,
/*0xE0*/	 0, 0, 0, 9, 0, 0, 9, 9, 0, 0, 0, 0, 0, 0, 9, 9,
/*0xF0*/	 0, 0, 0, 9, 0, 0, 9, 9, 0, 0, 0, 9, 0, 0, 9, 9,
};
