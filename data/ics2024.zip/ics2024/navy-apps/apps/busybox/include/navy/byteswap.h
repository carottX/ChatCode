# define bswap_64 __bswap64
# define bswap_32 __bswap32
# define bswap_16 __bswap16
