// stb_truetype.h - v1.24 - public domain
// authored from 2009-2020 by Sean Barrett / RAD Game Tools
//
// =======================================================================
//
//    NO SECURITY GUARANTEE -- DO NOT USE THIS ON UNTRUSTED FONT FILES
//
// This library does no range checking of the offsets found in the file,
// meaning an attacker can use it to read arbitrary memory.
//
// =======================================================================
//
//   This library processes TrueType files:
//        parse files
//        extract glyph metrics
//        extract glyph shapes
//        render glyphs to one-channel bitmaps with antialiasing (box filter)
//        render glyphs to one-channel SDF bitmaps (signed-distance field/function)
//
//   Todo:
//        non-MS cmaps
//        crashproof on bad data
//        hinting? (no longer patented)
//        cleartype-style AA?
//        optimize: use simple memory allocator for intermediates
//        optimize: build edge-list directly from curves
//        optimize: rasterize directly from curves?
//
// ADDITIONAL CONTRIBUTORS
//
//   Mikko Mononen: compound shape support, more cmap formats
//   Tor Andersson: kerning, subpixel rendering
//   Dougall Johnson: OpenType / Type 2 font handling
//   Daniel Ribeiro Maciel: basic GPOS-based kerning
//
//   Misc other:
//       Ryan Gordon
//       Simon Glass
//       github:IntellectualKitty
//       Imanol Celaya
//       Daniel Ribeiro Maciel
//
//   Bug/warning reports/fixes:
//       "Zer" on mollyrocket       Fabian "ryg" Giesen   github:NiLuJe
//       Cass Everitt               Martins Mozeiko       github:aloucks
//       stoiko (Haemimont Games)   Cap Petschulat        github:oyvindjam
//       Brian Hook                 Omar Cornut           github:vassvik
//       Walter van Niftrik         Ryan Griege
//       David Gow                  Peter LaValle
//       David Given                Sergey Popov
//       Ivan-Assen Ivanov          Giumo X. Clanjor
//       Anthony Pesch              Higor Euripedes
//       Johan Duparc               Thomas Fields
//       Hou Qiming                 Derek Vinyard
//       Rob Loach                  Cort Stratton
//       Kenney Phillis Jr.         Brian Costabile
//       Ken Voskuil (kaesve)
//
// VERSION HISTORY
//
//   1.24 (2020-02-05) fix warning
//   1.23 (2020-02-02) query SVG data for glyphs; query whole kerning table (but only kern not GPOS)
//   1.22 (2019-08-11) minimize missing-glyph duplication; fix kerning if both 'GPOS' and 'kern' are defined
//   1.21 (2019-02-25) fix warning
//   1.20 (2019-02-07) PackFontRange skips missing codepoints; GetScaleFontVMetrics()
//   1.19 (2018-02-11) GPOS kerning, STBTT_fmod
//   1.18 (2018-01-29) add missing function
//   1.17 (2017-07-23) make more arguments const; doc fix
//   1.16 (2017-07-12) SDF support
//   1.15 (2017-03-03) make more arguments const
//   1.14 (2017-01-16) num-fonts-in-TTC function
//   1.13 (2017-01-02) support OpenType fonts, certain Apple fonts
//   1.12 (2016-10-25) suppress warnings about casting away const with -Wcast-qual
//   1.11 (2016-04-02) fix unused-variable warning
//   1.10 (2016-04-02) user-defined fabs(); rare memory leak; remove duplicate typedef
//   1.09 (2016-01-16) warning fix; avoid crash on outofmem; use allocation userdata properly
//   1.08 (2015-09-13) document stbtt_Rasterize(); fixes for vertical & horizontal edges
//   1.07 (2015-08-01) allow PackFontRanges to accept arrays of sparse codepoints;
//                     variant PackFontRanges to pack and render in separate phases;
//                     fix stbtt_GetFontOFfsetForIndex (never worked for non-0 input?);
//                     fixed an assert() bug in the new rasterizer
//                     replace assert() with STBTT_assert() in new rasterizer
//
//   Full history can be found at the end of this file.
//
// LICENSE
//
//   See end of file for license information.
//
// USAGE
//
//   Include this file in whatever places need to refer to it. In ONE C/C++
//   file, write:
//      #define STB_TRUETYPE_IMPLEMENTATION
//   before the #include of this file. This expands out the actual
//   implementation into that C/C++ file.
//
//   To make the implementation private to the file that generates the implementation,
//      #define STBTT_STATIC
//
//   Simple 3D API (don't ship this, but it's fine for tools and quick start)
//           stbtt_BakeFontBitmap()               -- bake a font to a bitmap for use as texture
//           stbtt_GetBakedQuad()                 -- compute quad to draw for a given char
//
//   Improved 3D API (more shippable):
//           #include "stb_rect_pack.h"           -- optional, but you really want it
//           stbtt_PackBegin()
//           stbtt_PackSetOversampling()          -- for improved quality on small fonts
//           stbtt_PackFontRanges()               -- pack and renders
//           stbtt_PackEnd()
//           stbtt_GetPackedQuad()
//
//   "Load" a font file from a memory buffer (you have to keep the buffer loaded)
//           stbtt_InitFont()
//           stbtt_GetFontOffsetForIndex()        -- indexing for TTC font collections
//           stbtt_GetNumberOfFonts()             -- number of fonts for TTC font collections
//
//   Render a unicode codepoint to a bitmap
//           stbtt_GetCodepointBitmap()           -- allocates and returns a bitmap
//           stbtt_MakeCodepointBitmap()          -- renders into bitmap you provide
//           stbtt_GetCodepointBitmapBox()        -- how big the bitmap must be
//
//   Character advance/positioning
//           stbtt_GetCodepointHMetrics()
//           stbtt_GetFontVMetrics()
//           stbtt_GetFontVMetricsOS2()
//           stbtt_GetCodepointKernAdvance()
//
//   Starting with version 1.06, the rasterizer was replaced with a new,
//   faster and generally-more-precise rasterizer. The new rasterizer more
//   accurately measures pixel coverage for anti-aliasing, except in the case
//   where multiple shapes overlap, in which case it overestimates the AA pixel
//   coverage. Thus, anti-aliasing of intersecting shapes may look wrong. If
//   this turns out to be a problem, you can re-enable the old rasterizer with
//        #define STBTT_RASTERIZER_VERSION 1
//   which will incur about a 15% speed hit.
//
// ADDITIONAL DOCUMENTATION
//
//   Immediately after this block comment are a series of sample programs.
//
//   After the sample programs is the "header file" section. This section
//   includes documentation for each API function.
//
//   Some important concepts to understand to use this library:
//
//      Codepoint
//         Characters are defined by unicode codepoints, e.g. 65 is
//         uppercase A, 231 is lowercase c with a cedilla, 0x7e30 is
//         the hiragana for "ma".
//
//      Glyph
//         A visual character shape (every codepoint is rendered as
//         some glyph)
//
//      Glyph index
//         A font-specific integer ID representing a glyph
//
//      Baseline
//         Glyph shapes are defined relative to a baseline, which is the
//         bottom of uppercase characters. Characters extend both above
//         and below the baseline.
//
//      Current Point
//         As you draw text to the screen, you keep track of a "current point"
//         which is the origin of each character. The current point's vertical
//         position is the baseline. Even "baked fonts" use this model.
//
//      Vertical Font Metrics
//         The vertical qualities of the font, used to vertically position
//         and space the characters. See docs for stbtt_GetFontVMetrics.
//
//      Font Size in Pixels or Points
//         The preferred interface for specifying font sizes in stb_truetype
//         is to specify how tall the font's vertical extent should be in pixels.
//         If that sounds good enough, skip the next paragraph.
//
//         Most font APIs instead use "points", which are a common typographic
//         measurement for describing font size, defined as 72 points per inch.
//         stb_truetype provides a point API for compatibility. However, true
//         "per inch" conventions don't make much sense on computer displays
//         since different monitors have different number of pixels per
//         inch. For example, Windows traditionally uses a convention that
//         there are 96 pixels per inch, thus making 'inch' measurements have
//         nothing to do with inches, and thus effectively defining a point to
//         be 1.333 pixels. Additionally, the TrueType font data provides
//         an explicit scale factor to scale a given font's glyphs to points,
//         but the author has observed that this scale factor is often wrong
//         for non-commercial fonts, thus making fonts scaled in points
//         according to the TrueType spec incoherently sized in practice.
//
// DETAILED USAGE:
//
//  Scale:
//    Select how high you want the font to be, in points or pixels.
//    Call ScaleForPixelHeight or ScaleForMappingEmToPixels to compute
//    a scale factor SF that will be used by all other functions.
//
//  Baseline:
//    You need to select a y-coordinate that is the baseline of where
//    your text will appear. Call GetFontBoundingBox to get the baseline-relative
//    bounding box for all characters. SF*-y0 will be the distance in pixels
//    that the worst-case character could extend above the baseline, so if
//    you want the top edge of characters to appear at the top of the
//    screen where y=0, then you would set the baseline to SF*-y0.
//
//  Current point:
//    Set the current point where the first character will appear. The
//    first character could extend left of the current point; this is font
//    dependent. You can either choose a current point that is the leftmost
//    point and hope, or add some padding, or check the bounding box or
//    left-side-bearing of the first character to be displayed and set
//    the current point based on that.
//
//  Displaying a character:
//    Compute the bounding box of the character. It will contain signed values
//    relative to <current_point, baseline>. I.e. if it returns x0,y0,x1,y1,
//    then the character should be displayed in the rectangle from
//    <current_point+SF*x0, baseline+SF*y0> to <current_point+SF*x1,baseline+SF*y1).
//
//  Advancing for the next character:
//    Call GlyphHMetrics, and compute 'current_point += SF * advance'.
//
//
// ADVANCED USAGE
//
//   Quality:
//
//    - Use the functions with Subpixel at the end to allow your characters
//      to have subpixel positioning. Since the font is anti-aliased, not
//      hinted, this is very import for quality. (This is not possible with
//      baked fonts.)
//
//    - Kerning is now supported, and if you're supporting subpixel rendering
//      then kerning is worth using to give your text a polished look.
//
//   Performance:
//
//    - Convert Unicode codepoints to glyph indexes and operate on the glyphs;
//      if you don't do this, stb_truetype is forced to do the conversion on
//      every call.
//
//    - There are a lot of memory allocations. We should modify it to take
//      a temp buffer and allocate from the temp buffer (without freeing),
//      should help performance a lot.
//
// NOTES
//
//   The system uses the raw data found in the .ttf file without changing it
//   and without building auxiliary data structures. This is a bit inefficient
//   on little-endian systems (the data is big-endian), but assuming you're
//   caching the bitmaps or glyph shapes this shouldn't be a big deal.
//
//   It appears to be very hard to programmatically determine what font a
//   given file is in a general way. I provide an API for this, but I don't
//   recommend it.
//
//
// PERFORMANCE MEASUREMENTS FOR 1.06:
//
//                      32-bit     64-bit
//   Previous release:  8.83 s     7.68 s
//   Pool allocations:  7.72 s     6.34 s
//   Inline sort     :  6.54 s     5.65 s
//   New rasterizer  :  5.63 s     5.00 s

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
////
////  SAMPLE PROGRAMS
////
//
//  Incomplete text-in-3d-api example, which draws quads properly aligned to be lossless
//
#if 0
#define STB_TRUETYPE_IMPLEMENTATION  // force following include to generate implementation
#include "stb_truetype.h"

unsigned char ttf_buffer[1<<20];
unsigned char temp_bitmap[512*512];

stbtt_bakedchar cdata[96]; // ASCII 32..126 is 95 glyphs
GLuint ftex;

/**
 * Initializes a font by loading a TrueType font file from the Windows fonts directory,
 * baking the font into a bitmap, and creating an OpenGL texture from the bitmap.
 *
 * This function performs the following steps:
 * 1. Reads the "times.ttf" font file from the "c:/windows/fonts" directory into a buffer.
 * 2. Bakes the font into a bitmap using the stbtt_BakeFontBitmap function with a size of 32.0.
 *    The bitmap is stored in a temporary buffer with dimensions 512x512.
 * 3. Generates an OpenGL texture and binds it to the GL_TEXTURE_2D target.
 * 4. Uploads the baked font bitmap to the OpenGL texture as an alpha channel.
 * 5. Sets the texture parameters to use linear filtering for the GL_TEXTURE_MIN_FILTER.
 *
 * Note: The ttf_buffer and temp_bitmap can be freed after the texture is created.
 */
void my_stbtt_initfont(void)
{
   fread(ttf_buffer, 1, 1<<20, fopen("c:/windows/fonts/times.ttf", "rb"));
   stbtt_BakeFontBitmap(ttf_buffer,0, 32.0, temp_bitmap,512,512, 32,96, cdata); // no guarantee this fits!
   // can free ttf_buffer at this point
   glGenTextures(1, &ftex);
   glBindTexture(GL_TEXTURE_2D, ftex);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, 512,512, 0, GL_ALPHA, GL_UNSIGNED_BYTE, temp_bitmap);
   // can free temp_bitmap at this point
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}

/**
 * Renders a string of text at a specified position using a pre-baked font texture.
 * This function assumes an orthographic projection with units in screen pixels
 * and the origin at the top-left corner of the screen.
 *
 * The function enables 2D texturing, binds the pre-baked font texture, and
 * iterates through each character in the provided text string. For each
 * printable ASCII character (32 to 127), it retrieves the corresponding
 * texture coordinates and vertex positions from the pre-baked font data,
 * then renders the character as a textured quad.
 *
 * @param x The x-coordinate (in pixels) where the text should be rendered.
 * @param y The y-coordinate (in pixels) where the text should be rendered.
 * @param text The null-terminated string of text to render.
 *
 * @note This function relies on OpenGL for rendering and assumes that the
 *       necessary OpenGL context and font texture (`ftex`) are already set up.
 *       The font data (`cdata`) must also be pre-baked and available.
 */
void my_stbtt_print(float x, float y, char *text)
{
   // assume orthographic projection with units = screen pixels, origin at top left
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, ftex);
   glBegin(GL_QUADS);
   while (*text) {
      if (*text >= 32 && *text < 128) {
         stbtt_aligned_quad q;
         stbtt_GetBakedQuad(cdata, 512,512, *text-32, &x,&y,&q,1);//1=opengl & d3d10+,0=d3d9
         glTexCoord2f(q.s0,q.t1); glVertex2f(q.x0,q.y0);
         glTexCoord2f(q.s1,q.t1); glVertex2f(q.x1,q.y0);
         glTexCoord2f(q.s1,q.t0); glVertex2f(q.x1,q.y1);
         glTexCoord2f(q.s0,q.t0); glVertex2f(q.x0,q.y1);
      }
      ++text;
   }
   glEnd();
}
#endif
//
//
//////////////////////////////////////////////////////////////////////////////
//
// Complete program (this compiles): get a single bitmap, print as ASCII art
//
#if 0
#include <stdio.h>
#define STB_TRUETYPE_IMPLEMENTATION  // force following include to generate implementation
#include "stb_truetype.h"

char ttf_buffer[1<<25];

/**
 * @brief Main function to render a specified character from a TrueType font as a bitmap.
 *
 * This program loads a TrueType font file, initializes a font object, and renders a specified
 * character as a bitmap. The bitmap is then printed to the console using ASCII characters to
 * represent the pixel intensity.
 *
 * @param argc The number of command-line arguments.
 * @param argv The command-line arguments:
 *             - argv[1]: The Unicode codepoint of the character to render (default is 'a').
 *             - argv[2]: The pixel height of the rendered character (default is 20).
 *             - argv[3]: The path to the TrueType font file (default is "c:/windows/fonts/arialbd.ttf").
 *
 * @return 0 on successful execution.
 */
int main(int argc, char **argv)
{
   stbtt_fontinfo font;
   unsigned char *bitmap;
   int w,h,i,j,c = (argc > 1 ? atoi(argv[1]) : 'a'), s = (argc > 2 ? atoi(argv[2]) : 20);

   fread(ttf_buffer, 1, 1<<25, fopen(argc > 3 ? argv[3] : "c:/windows/fonts/arialbd.ttf", "rb"));

   stbtt_InitFont(&font, ttf_buffer, stbtt_GetFontOffsetForIndex(ttf_buffer,0));
   bitmap = stbtt_GetCodepointBitmap(&font, 0,stbtt_ScaleForPixelHeight(&font, s), c, &w, &h, 0,0);

   for (j=0; j < h; ++j) {
      for (i=0; i < w; ++i)
         putchar(" .:ioVM@"[bitmap[j*w+i]>>5]);
      putchar('\n');
   }
   return 0;
}
#endif
//
// Output:
//
//     .ii.
//    @@@@@@.
//   V@Mio@@o
//   :i.  V@V
//     :oM@@M
//   :@@@MM@M
//   @@o  o@M
//  :@@.  M@M
//   @@@o@@@@
//   :M@@V:@@.
//
//////////////////////////////////////////////////////////////////////////////
//
// Complete program: print "Hello World!" banner, with bugs
//
#if 0
char buffer[24<<20];
unsigned char screen[20][79];

/**
 * @brief Main function to render a text string using the STB TrueType library.
 *
 * This function reads a TrueType font file, initializes the font, and renders the text "Heljo World!"
 * to a character-based screen buffer. The text is intentionally misspelled to demonstrate the
 * handling of character overlaps (e.g., 'lj'). The function calculates the scale, baseline, and
 * horizontal metrics for each character, then renders the characters to a screen buffer using
 * subpixel positioning. The final rendered text is printed to the console using ASCII characters
 * to represent the bitmap.
 *
 * @param arg The number of command-line arguments.
 * @param argv The array of command-line arguments.
 * @return int Returns 0 on successful execution.
 */
int main(int arg, char **argv)
{
   stbtt_fontinfo font;
   int i,j,ascent,baseline,ch=0;
   float scale, xpos=2; // leave a little padding in case the character extends left
   char *text = "Heljo World!"; // intentionally misspelled to show 'lj' brokenness

   fread(buffer, 1, 1000000, fopen("c:/windows/fonts/arialbd.ttf", "rb"));
   stbtt_InitFont(&font, buffer, 0);

   scale = stbtt_ScaleForPixelHeight(&font, 15);
   stbtt_GetFontVMetrics(&font, &ascent,0,0);
   baseline = (int) (ascent*scale);

   while (text[ch]) {
      int advance,lsb,x0,y0,x1,y1;
      float x_shift = xpos - (float) floor(xpos);
      stbtt_GetCodepointHMetrics(&font, text[ch], &advance, &lsb);
      stbtt_GetCodepointBitmapBoxSubpixel(&font, text[ch], scale,scale,x_shift,0, &x0,&y0,&x1,&y1);
      stbtt_MakeCodepointBitmapSubpixel(&font, &screen[baseline + y0][(int) xpos + x0], x1-x0,y1-y0, 79, scale,scale,x_shift,0, text[ch]);
      // note that this stomps the old data, so where character boxes overlap (e.g. 'lj') it's wrong
      // because this API is really for baking character bitmaps into textures. if you want to render
      // a sequence of characters, you really need to render each bitmap to a temp buffer, then
      // "alpha blend" that into the working buffer
      xpos += (advance * scale);
      if (text[ch+1])
         xpos += scale*stbtt_GetCodepointKernAdvance(&font, text[ch],text[ch+1]);
      ++ch;
   }

   for (j=0; j < 20; ++j) {
      for (i=0; i < 78; ++i)
         putchar(" .:ioVM@"[screen[j][i]>>5]);
      putchar('\n');
   }

   return 0;
}
#endif


//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
////
////   INTEGRATION WITH YOUR CODEBASE
////
////   The following sections allow you to supply alternate definitions
////   of C library functions used by stb_truetype, e.g. if you don't
////   link with the C runtime library.

#ifdef STB_TRUETYPE_IMPLEMENTATION
   // #define your own (u)stbtt_int8/16/32 before including to override this
   #ifndef stbtt_uint8
   typedef unsigned char   stbtt_uint8;
   typedef signed   char   stbtt_int8;
   typedef unsigned short  stbtt_uint16;
   typedef signed   short  stbtt_int16;
   typedef unsigned int    stbtt_uint32;
   typedef signed   int    stbtt_int32;
   #endif

   typedef char stbtt__check_size32[sizeof(stbtt_int32)==4 ? 1 : -1];
   typedef char stbtt__check_size16[sizeof(stbtt_int16)==2 ? 1 : -1];

   #include <fixedptc.h>

   #define STBTT_ifloor(x)   (fixedpt_toint(fixedpt_floor(x)))
   #define STBTT_iceil(x)    (fixedpt_toint(fixedpt_ceil(x)))
   #define STBTT_sqrt(x)     fixedpt_sqrt(x)
   #define STBTT_fabs(x)     fixedpt_abs(x)

   // #define your own functions "STBTT_malloc" / "STBTT_free" to avoid malloc.h
   #ifndef STBTT_malloc
   #include <stdlib.h>
   #define STBTT_malloc(x,u)  ((void)(u),malloc(x))
   #define STBTT_free(x,u)    ((void)(u),free(x))
   #endif

   #ifndef STBTT_assert
   #include <assert.h>
   #define STBTT_assert(x)    assert(x)
   #endif

   #ifndef STBTT_strlen
   #include <string.h>
   #define STBTT_strlen(x)    strlen(x)
   #endif

   #ifndef STBTT_memcpy
   #include <string.h>
   #define STBTT_memcpy       memcpy
   #define STBTT_memset       memset
   #endif
#endif

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
////
////   INTERFACE
////
////

#ifndef __STB_INCLUDE_STB_TRUETYPE_H__
#define __STB_INCLUDE_STB_TRUETYPE_H__

#ifdef STBTT_STATIC
#define STBTT_DEF static
#else
#define STBTT_DEF extern
#endif

#ifdef __cplusplus
extern "C" {
#endif

// private structure
typedef struct
{
   unsigned char *data;
   int cursor;
   int size;
} stbtt__buf;

typedef struct stbtt_fontinfo stbtt_fontinfo;

#define STBTT_POINT_SIZE(x)   (-(x))

//////////////////////////////////////////////////////////////////////////////
//
// FONT LOADING
//
//

STBTT_DEF int stbtt_GetNumberOfFonts(const unsigned char *data);
// This function will determine the number of fonts in a font file.  TrueType
// collection (.ttc) files may contain multiple fonts, while TrueType font
// (.ttf) files only contain one font. The number of fonts can be used for
// indexing with the previous function where the index is between zero and one
// less than the total fonts. If an error occurs, -1 is returned.

STBTT_DEF int stbtt_GetFontOffsetForIndex(const unsigned char *data, int index);
// Each .ttf/.ttc file may have more than one font. Each font has a sequential
// index number starting from 0. Call this function to get the font offset for
// a given index; it returns -1 if the index is out of range. A regular .ttf
// file will only define one font and it always be at offset 0, so it will
// return '0' for index 0, and -1 for all other indices.

// The following structure is defined publicly so you can declare one on
// the stack or as a global or etc, but you should treat it as opaque.
struct stbtt_fontinfo
{
   void           * userdata;
   unsigned char  * data;              // pointer to .ttf file
   int              fontstart;         // offset of start of font

   int numGlyphs;                     // number of glyphs, needed for range checking

   int loca,head,glyf,hhea,hmtx,kern,gpos,svg; // table locations as offset from start of .ttf
   int index_map;                     // a cmap mapping for our chosen character encoding
   int indexToLocFormat;              // format needed to map from glyph index to glyph

   stbtt__buf cff;                    // cff font data
   stbtt__buf charstrings;            // the charstring index
   stbtt__buf gsubrs;                 // global charstring subroutines index
   stbtt__buf subrs;                  // private charstring subroutines index
   stbtt__buf fontdicts;              // array of font dicts
   stbtt__buf fdselect;               // map from glyph to fontdict
};

STBTT_DEF int stbtt_InitFont(stbtt_fontinfo *info, const unsigned char *data, int offset);
// Given an offset into the file that defines a font, this function builds
// the necessary cached info for the rest of the system. You must allocate
// the stbtt_fontinfo yourself, and stbtt_InitFont will fill it out. You don't
// need to do anything special to free it, because the contents are pure
// value data with no additional data structures. Returns 0 on failure.


//////////////////////////////////////////////////////////////////////////////
//
// CHARACTER TO GLYPH-INDEX CONVERSIOn

STBTT_DEF int stbtt_FindGlyphIndex(const stbtt_fontinfo *info, int unicode_codepoint);
// If you're going to perform multiple operations on the same character
// and you want a speed-up, call this function with the character you're
// going to process, then use glyph-based functions instead of the
// codepoint-based functions.
// Returns 0 if the character codepoint is not defined in the font.


//////////////////////////////////////////////////////////////////////////////
//
// CHARACTER PROPERTIES
//

STBTT_DEF fixedpt stbtt_ScaleForPixelHeight(const stbtt_fontinfo *info, fixedpt pixels);
// computes a scale factor to produce a font whose "height" is 'pixels' tall.
// Height is measured as the distance from the highest ascender to the lowest
// descender; in other words, it's equivalent to calling stbtt_GetFontVMetrics
// and computing:
//       scale = pixels / (ascent - descent)
// so if you prefer to measure height by the ascent only, use a similar calculation.

STBTT_DEF fixedpt stbtt_ScaleForMappingEmToPixels(const stbtt_fontinfo *info, fixedpt pixels);
// computes a scale factor to produce a font whose EM size is mapped to
// 'pixels' tall. This is probably what traditional APIs compute, but
// I'm not positive.

STBTT_DEF void stbtt_GetFontVMetrics(const stbtt_fontinfo *info, int *ascent, int *descent, int *lineGap);
// ascent is the coordinate above the baseline the font extends; descent
// is the coordinate below the baseline the font extends (i.e. it is typically negative)
// lineGap is the spacing between one row's descent and the next row's ascent...
// so you should advance the vertical position by "*ascent - *descent + *lineGap"
//   these are expressed in unscaled coordinates, so you must multiply by
//   the scale factor for a given size

STBTT_DEF int  stbtt_GetFontVMetricsOS2(const stbtt_fontinfo *info, int *typoAscent, int *typoDescent, int *typoLineGap);
// analogous to GetFontVMetrics, but returns the "typographic" values from the OS/2
// table (specific to MS/Windows TTF files).
//
// Returns 1 on success (table present), 0 on failure.

STBTT_DEF void stbtt_GetFontBoundingBox(const stbtt_fontinfo *info, int *x0, int *y0, int *x1, int *y1);
// the bounding box around all possible characters

STBTT_DEF void stbtt_GetCodepointHMetrics(const stbtt_fontinfo *info, int codepoint, int *advanceWidth, int *leftSideBearing);
// leftSideBearing is the offset from the current horizontal position to the left edge of the character
// advanceWidth is the offset from the current horizontal position to the next horizontal position
//   these are expressed in unscaled coordinates

STBTT_DEF int  stbtt_GetCodepointKernAdvance(const stbtt_fontinfo *info, int ch1, int ch2);
// an additional amount to add to the 'advance' value between ch1 and ch2

STBTT_DEF int stbtt_GetCodepointBox(const stbtt_fontinfo *info, int codepoint, int *x0, int *y0, int *x1, int *y1);
// Gets the bounding box of the visible part of the glyph, in unscaled coordinates

STBTT_DEF void stbtt_GetGlyphHMetrics(const stbtt_fontinfo *info, int glyph_index, int *advanceWidth, int *leftSideBearing);
STBTT_DEF int  stbtt_GetGlyphKernAdvance(const stbtt_fontinfo *info, int glyph1, int glyph2);
STBTT_DEF int  stbtt_GetGlyphBox(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1);
// as above, but takes one or more glyph indices for greater efficiency

typedef struct stbtt_kerningentry
{
   int glyph1; // use stbtt_FindGlyphIndex
   int glyph2;
   int advance;
} stbtt_kerningentry;

STBTT_DEF int  stbtt_GetKerningTableLength(const stbtt_fontinfo *info);
STBTT_DEF int  stbtt_GetKerningTable(const stbtt_fontinfo *info, stbtt_kerningentry* table, int table_length);
// Retrieves a complete list of all of the kerning pairs provided by the font
// stbtt_GetKerningTable never writes more than table_length entries and returns how many entries it did write.
// The table will be sorted by (a.glyph1 == b.glyph1)?(a.glyph2 < b.glyph2):(a.glyph1 < b.glyph1)

//////////////////////////////////////////////////////////////////////////////
//
// GLYPH SHAPES (you probably don't need these, but they have to go before
// the bitmaps for C declaration-order reasons)
//

#ifndef STBTT_vmove // you can predefine these to use different values (but why?)
   enum {
      STBTT_vmove=1,
      STBTT_vline,
      STBTT_vcurve,
      STBTT_vcubic
   };
#endif

#ifndef stbtt_vertex // you can predefine this to use different values
                   // (we share this with other code at RAD)
   #define stbtt_vertex_type short // can't use stbtt_int16 because that's not visible in the header file
   typedef struct
   {
      stbtt_vertex_type x,y,cx,cy,cx1,cy1;
      unsigned char type,padding;
   } stbtt_vertex;
#endif

STBTT_DEF int stbtt_IsGlyphEmpty(const stbtt_fontinfo *info, int glyph_index);
// returns non-zero if nothing is drawn for this glyph

STBTT_DEF int stbtt_GetCodepointShape(const stbtt_fontinfo *info, int unicode_codepoint, stbtt_vertex **vertices);
STBTT_DEF int stbtt_GetGlyphShape(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **vertices);
// returns # of vertices and fills *vertices with the pointer to them
//   these are expressed in "unscaled" coordinates
//
// The shape is a series of contours. Each one starts with
// a STBTT_moveto, then consists of a series of mixed
// STBTT_lineto and STBTT_curveto segments. A lineto
// draws a line from previous endpoint to its x,y; a curveto
// draws a quadratic bezier from previous endpoint to
// its x,y, using cx,cy as the bezier control point.

STBTT_DEF void stbtt_FreeShape(const stbtt_fontinfo *info, stbtt_vertex *vertices);
// frees the data allocated above

STBTT_DEF int stbtt_GetCodepointSVG(const stbtt_fontinfo *info, int unicode_codepoint, const char **svg);
STBTT_DEF int stbtt_GetGlyphSVG(const stbtt_fontinfo *info, int gl, const char **svg);
// fills svg with the character's SVG data.
// returns data size or 0 if SVG not found.

//////////////////////////////////////////////////////////////////////////////
//
// BITMAP RENDERING
//

STBTT_DEF void stbtt_FreeBitmap(unsigned char *bitmap, void *userdata);
// frees the bitmap allocated below

STBTT_DEF unsigned char *stbtt_GetCodepointBitmap(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, int codepoint, int *width, int *height, int *xoff, int *yoff);
// allocates a large-enough single-channel 8bpp bitmap and renders the
// specified character/glyph at the specified scale into it, with
// antialiasing. 0 is no coverage (transparent), 255 is fully covered (opaque).
// *width & *height are filled out with the width & height of the bitmap,
// which is stored left-to-right, top-to-bottom.
//
// xoff/yoff are the offset it pixel space from the glyph origin to the top-left of the bitmap

STBTT_DEF unsigned char *stbtt_GetCodepointBitmapSubpixel(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int codepoint, int *width, int *height, int *xoff, int *yoff);
// the same as stbtt_GetCodepoitnBitmap, but you can specify a subpixel
// shift for the character

STBTT_DEF void stbtt_MakeCodepointBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, int codepoint);
// the same as stbtt_GetCodepointBitmap, but you pass in storage for the bitmap
// in the form of 'output', with row spacing of 'out_stride' bytes. the bitmap
// is clipped to out_w/out_h bytes. Call stbtt_GetCodepointBitmapBox to get the
// width and height and positioning info for it first.

STBTT_DEF void stbtt_MakeCodepointBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int codepoint);
// same as stbtt_MakeCodepointBitmap, but you can specify a subpixel
// shift for the character

STBTT_DEF void stbtt_MakeCodepointBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int oversample_x, int oversample_y, fixedpt *sub_x, fixedpt *sub_y, int codepoint);
// same as stbtt_MakeCodepointBitmapSubpixel, but prefiltering
// is performed (see stbtt_PackSetOversampling)

STBTT_DEF void stbtt_GetCodepointBitmapBox(const stbtt_fontinfo *font, int codepoint, fixedpt scale_x, fixedpt scale_y, int *ix0, int *iy0, int *ix1, int *iy1);
// get the bbox of the bitmap centered around the glyph origin; so the
// bitmap width is ix1-ix0, height is iy1-iy0, and location to place
// the bitmap top left is (leftSideBearing*scale,iy0).
// (Note that the bitmap uses y-increases-down, but the shape uses
// y-increases-up, so CodepointBitmapBox and CodepointBox are inverted.)

STBTT_DEF void stbtt_GetCodepointBitmapBoxSubpixel(const stbtt_fontinfo *font, int codepoint, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int *ix0, int *iy0, int *ix1, int *iy1);
// same as stbtt_GetCodepointBitmapBox, but you can specify a subpixel
// shift for the character

// the following functions are equivalent to the above functions, but operate
// on glyph indices instead of Unicode codepoints (for efficiency)
STBTT_DEF unsigned char *stbtt_GetGlyphBitmap(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, int glyph, int *width, int *height, int *xoff, int *yoff);
STBTT_DEF unsigned char *stbtt_GetGlyphBitmapSubpixel(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int glyph, int *width, int *height, int *xoff, int *yoff);
STBTT_DEF void stbtt_MakeGlyphBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, int glyph);
STBTT_DEF void stbtt_MakeGlyphBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int glyph);
STBTT_DEF void stbtt_MakeGlyphBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int oversample_x, int oversample_y, fixedpt *sub_x, fixedpt *sub_y, int glyph);
STBTT_DEF void stbtt_GetGlyphBitmapBox(const stbtt_fontinfo *font, int glyph, fixedpt scale_x, fixedpt scale_y, int *ix0, int *iy0, int *ix1, int *iy1);
STBTT_DEF void stbtt_GetGlyphBitmapBoxSubpixel(const stbtt_fontinfo *font, int glyph, fixedpt scale_x, fixedpt scale_y,fixedpt shift_x, fixedpt shift_y, int *ix0, int *iy0, int *ix1, int *iy1);


// @TODO: don't expose this structure
typedef struct
{
   int w,h,stride;
   unsigned char *pixels;
} stbtt__bitmap;

// rasterize a shape with quadratic beziers into a bitmap
STBTT_DEF void stbtt_Rasterize(stbtt__bitmap *result,        // 1-channel bitmap to draw into
                               fixedpt flatness_in_pixels,     // allowable error of curve in pixels
                               stbtt_vertex *vertices,       // array of vertices defining shape
                               int num_verts,                // number of vertices in above array
                               fixedpt scale_x, fixedpt scale_y, // scale applied to input vertices
                               fixedpt shift_x, fixedpt shift_y, // translation applied to input vertices
                               int x_off, int y_off,         // another translation applied to input
                               int invert,                   // if non-zero, vertically flip shape
                               void *userdata);              // context for to STBTT_MALLOC


// some of the values for the IDs are below; for more see the truetype spec:
//     http://developer.apple.com/textfonts/TTRefMan/RM06/Chap6name.html
//     http://www.microsoft.com/typography/otspec/name.htm

enum { // platformID
   STBTT_PLATFORM_ID_UNICODE   =0,
   STBTT_PLATFORM_ID_MAC       =1,
   STBTT_PLATFORM_ID_ISO       =2,
   STBTT_PLATFORM_ID_MICROSOFT =3
};

enum { // encodingID for STBTT_PLATFORM_ID_UNICODE
   STBTT_UNICODE_EID_UNICODE_1_0    =0,
   STBTT_UNICODE_EID_UNICODE_1_1    =1,
   STBTT_UNICODE_EID_ISO_10646      =2,
   STBTT_UNICODE_EID_UNICODE_2_0_BMP=3,
   STBTT_UNICODE_EID_UNICODE_2_0_FULL=4
};

enum { // encodingID for STBTT_PLATFORM_ID_MICROSOFT
   STBTT_MS_EID_SYMBOL        =0,
   STBTT_MS_EID_UNICODE_BMP   =1,
   STBTT_MS_EID_SHIFTJIS      =2,
   STBTT_MS_EID_UNICODE_FULL  =10
};

enum { // encodingID for STBTT_PLATFORM_ID_MAC; same as Script Manager codes
   STBTT_MAC_EID_ROMAN        =0,   STBTT_MAC_EID_ARABIC       =4,
   STBTT_MAC_EID_JAPANESE     =1,   STBTT_MAC_EID_HEBREW       =5,
   STBTT_MAC_EID_CHINESE_TRAD =2,   STBTT_MAC_EID_GREEK        =6,
   STBTT_MAC_EID_KOREAN       =3,   STBTT_MAC_EID_RUSSIAN      =7
};

enum { // languageID for STBTT_PLATFORM_ID_MICROSOFT; same as LCID...
       // problematic because there are e.g. 16 english LCIDs and 16 arabic LCIDs
   STBTT_MS_LANG_ENGLISH     =0x0409,   STBTT_MS_LANG_ITALIAN     =0x0410,
   STBTT_MS_LANG_CHINESE     =0x0804,   STBTT_MS_LANG_JAPANESE    =0x0411,
   STBTT_MS_LANG_DUTCH       =0x0413,   STBTT_MS_LANG_KOREAN      =0x0412,
   STBTT_MS_LANG_FRENCH      =0x040c,   STBTT_MS_LANG_RUSSIAN     =0x0419,
   STBTT_MS_LANG_GERMAN      =0x0407,   STBTT_MS_LANG_SPANISH     =0x0409,
   STBTT_MS_LANG_HEBREW      =0x040d,   STBTT_MS_LANG_SWEDISH     =0x041D
};

enum { // languageID for STBTT_PLATFORM_ID_MAC
   STBTT_MAC_LANG_ENGLISH      =0 ,   STBTT_MAC_LANG_JAPANESE     =11,
   STBTT_MAC_LANG_ARABIC       =12,   STBTT_MAC_LANG_KOREAN       =23,
   STBTT_MAC_LANG_DUTCH        =4 ,   STBTT_MAC_LANG_RUSSIAN      =32,
   STBTT_MAC_LANG_FRENCH       =1 ,   STBTT_MAC_LANG_SPANISH      =6 ,
   STBTT_MAC_LANG_GERMAN       =2 ,   STBTT_MAC_LANG_SWEDISH      =5 ,
   STBTT_MAC_LANG_HEBREW       =10,   STBTT_MAC_LANG_CHINESE_SIMPLIFIED =33,
   STBTT_MAC_LANG_ITALIAN      =3 ,   STBTT_MAC_LANG_CHINESE_TRAD =19
};

#ifdef __cplusplus
}
#endif

#endif // __STB_INCLUDE_STB_TRUETYPE_H__

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
////
////   IMPLEMENTATION
////
////

#ifdef STB_TRUETYPE_IMPLEMENTATION

#ifndef STBTT_MAX_OVERSAMPLE
#define STBTT_MAX_OVERSAMPLE   8
#endif

#if STBTT_MAX_OVERSAMPLE > 255
#error "STBTT_MAX_OVERSAMPLE cannot be > 255"
#endif

typedef int stbtt__test_oversample_pow2[(STBTT_MAX_OVERSAMPLE & (STBTT_MAX_OVERSAMPLE-1)) == 0 ? 1 : -1];

#ifndef STBTT_RASTERIZER_VERSION
#define STBTT_RASTERIZER_VERSION 2
#endif

#ifdef _MSC_VER
#define STBTT__NOTUSED(v)  (void)(v)
#else
#define STBTT__NOTUSED(v)  (void)sizeof(v)
#endif

//////////////////////////////////////////////////////////////////////////
//
// stbtt__buf helpers to parse data from file
//

static stbtt_uint8 stbtt__buf_get8(stbtt__buf *b)
{
   if (b->cursor >= b->size)
      return 0;
   return b->data[b->cursor++];
}

/**
 * Peeks at the next byte in the buffer without advancing the cursor.
 *
 * This function returns the byte at the current cursor position in the buffer.
 * If the cursor is at or beyond the end of the buffer, it returns 0.
 * The cursor position remains unchanged after this operation.
 *
 * @param b A pointer to the stbtt__buf structure representing the buffer.
 * @return The byte at the current cursor position, or 0 if the cursor is out of bounds.
 */
static stbtt_uint8 stbtt__buf_peek8(stbtt__buf *b)
{
   if (b->cursor >= b->size)
      return 0;
   return b->data[b->cursor];
}

/**
 * Moves the cursor of the buffer to the specified offset.
 * 
 * This function sets the cursor position of the buffer `b` to the offset `o`. 
 * If the offset `o` is outside the valid range (i.e., less than 0 or greater than the buffer size), 
 * the cursor is clamped to the buffer size. This ensures that the cursor does not point to an 
 * invalid position. 
 * 
 * @param b Pointer to the buffer whose cursor is to be moved.
 * @param o The desired offset to which the cursor should be moved.
 * 
 * @note The function asserts that the offset `o` is within the valid range (0 <= o <= b->size).
 */
static void stbtt__buf_seek(stbtt__buf *b, int o)
{
   STBTT_assert(!(o > b->size || o < 0));
   b->cursor = (o > b->size || o < 0) ? b->size : o;
}

/**
 * Skips a specified number of bytes in the buffer by moving the cursor forward.
 * This function adjusts the cursor position by adding the offset `o` to the current cursor position.
 * The actual cursor movement is delegated to the `stbtt__buf_seek` function.
 *
 * @param b Pointer to the buffer whose cursor is to be moved.
 * @param o The number of bytes to skip (positive value moves the cursor forward).
 */
static void stbtt__buf_skip(stbtt__buf *b, int o)
{
   stbtt__buf_seek(b, b->cursor + o);
}

/**
 * Reads and returns a `stbtt_uint32` value from the buffer `b` by extracting `n` bytes.
 * The method reads `n` bytes (where `n` is between 1 and 4) from the buffer, 
 * combines them into a single 32-bit unsigned integer, and returns the result.
 * The bytes are read in big-endian order, meaning the first byte read becomes 
 * the most significant byte of the resulting integer.
 *
 * @param b Pointer to the `stbtt__buf` structure representing the buffer.
 * @param n The number of bytes to read (must be between 1 and 4).
 * @return The `stbtt_uint32` value constructed from the read bytes.
 */
static stbtt_uint32 stbtt__buf_get(stbtt__buf *b, int n)
{
   stbtt_uint32 v = 0;
   int i;
   STBTT_assert(n >= 1 && n <= 4);
   for (i = 0; i < n; i++)
      v = (v << 8) | stbtt__buf_get8(b);
   return v;
}

/**
 * @brief Creates a new stbtt__buf structure initialized with the provided data and size.
 *
 * This function initializes a new stbtt__buf structure with the given data pointer and size.
 * The size is asserted to be less than 0x40000000 to ensure it fits within the internal buffer size limits.
 * The cursor of the buffer is set to 0, indicating the start of the buffer.
 *
 * @param p Pointer to the data that the buffer will reference.
 * @param size The size of the data in bytes.
 * @return A new stbtt__buf structure with the provided data, size, and cursor set to 0.
 */
static stbtt__buf stbtt__new_buf(const void *p, size_t size)
{
   stbtt__buf r;
   STBTT_assert(size < 0x40000000);
   r.data = (stbtt_uint8*) p;
   r.size = (int) size;
   r.cursor = 0;
   return r;
}

#define stbtt__buf_get16(b)  stbtt__buf_get((b), 2)
#define stbtt__buf_get32(b)  stbtt__buf_get((b), 4)

/**
 * Creates a new buffer that represents a subrange of the given buffer.
 *
 * This function creates a new `stbtt__buf` that points to a portion of the original buffer `b`,
 * starting at the offset `o` and spanning `s` bytes. The new buffer does not allocate new memory
 * but instead references the original buffer's data.
 *
 * @param b The original buffer from which to create the subrange.
 * @param o The offset within the original buffer where the subrange starts.
 * @param s The size of the subrange in bytes.
 *
 * @return A new `stbtt__buf` representing the subrange. If the offset or size is invalid
 *         (i.e., negative, or exceeds the bounds of the original buffer), an empty buffer
 *         is returned.
 */
static stbtt__buf stbtt__buf_range(const stbtt__buf *b, int o, int s)
{
   stbtt__buf r = stbtt__new_buf(NULL, 0);
   if (o < 0 || s < 0 || o > b->size || s > b->size - o) return r;
   r.data = b->data + o;
   r.size = s;
   return r;
}

/**
 * Reads and processes an index from a CFF (Compact Font Format) buffer.
 * 
 * This function retrieves an index structure from the provided buffer `b`. 
 * The index consists of a count of elements, followed by an offset size, 
 * and then a series of offsets that point to the actual data. The function 
 * skips over the offsets and returns a sub-buffer that represents the range 
 * of data corresponding to the index.
 * 
 * @param b A pointer to the stbtt__buf structure containing the CFF data.
 * 
 * @return An stbtt__buf structure representing the range of data for the index.
 *         The returned buffer is a sub-buffer of the original buffer `b`.
 */
static stbtt__buf stbtt__cff_get_index(stbtt__buf *b)
{
   int count, start, offsize;
   start = b->cursor;
   count = stbtt__buf_get16(b);
   if (count) {
      offsize = stbtt__buf_get8(b);
      STBTT_assert(offsize >= 1 && offsize <= 4);
      stbtt__buf_skip(b, offsize * count);
      stbtt__buf_skip(b, stbtt__buf_get(b, offsize) - 1);
   }
   return stbtt__buf_range(b, start, b->cursor - start);
}

/**
 * Parses an integer from a CFF (Compact Font Format) buffer.
 * 
 * The method reads the first byte from the buffer and interprets it according to the CFF specification:
 * - If the byte is between 32 and 246, it returns the value (b0 - 139).
 * - If the byte is between 247 and 250, it reads the next byte and returns ((b0 - 247) * 256 + next_byte + 108).
 * - If the byte is between 251 and 254, it reads the next byte and returns (-(b0 - 251) * 256 - next_byte - 108).
 * - If the byte is 28, it reads the next two bytes as a 16-bit integer and returns it.
 * - If the byte is 29, it reads the next four bytes as a 32-bit integer and returns it.
 * 
 * If the byte does not match any of the above cases, the method asserts and returns 0.
 * 
 * @param b A pointer to the CFF buffer from which the integer is to be parsed.
 * @return The parsed integer value.
 */
static stbtt_uint32 stbtt__cff_int(stbtt__buf *b)
{
   int b0 = stbtt__buf_get8(b);
   if (b0 >= 32 && b0 <= 246)       return b0 - 139;
   else if (b0 >= 247 && b0 <= 250) return (b0 - 247)*256 + stbtt__buf_get8(b) + 108;
   else if (b0 >= 251 && b0 <= 254) return -(b0 - 251)*256 - stbtt__buf_get8(b) - 108;
   else if (b0 == 28)               return stbtt__buf_get16(b);
   else if (b0 == 29)               return stbtt__buf_get32(b);
   STBTT_assert(0);
   return 0;
}

/**
 * Skips over an operand in a CFF (Compact Font Format) data stream.
 *
 * This function is used to skip past an operand in a CFF data stream, which is stored in a `stbtt__buf` buffer.
 * The function first peeks at the first byte of the operand to determine its type. If the byte is 30, it indicates
 * a real number operand, which is skipped by advancing the buffer cursor past the real number. For other values,
 * the function assumes the operand is an integer and skips it using the `stbtt__cff_int` function.
 *
 * @param b Pointer to the `stbtt__buf` buffer containing the CFF data stream.
 *
 * @note The function asserts that the first byte of the operand is at least 28, as per the CFF specification.
 */
static void stbtt__cff_skip_operand(stbtt__buf *b) {
   int v, b0 = stbtt__buf_peek8(b);
   STBTT_assert(b0 >= 28);
   if (b0 == 30) {
      stbtt__buf_skip(b, 1);
      while (b->cursor < b->size) {
         v = stbtt__buf_get8(b);
         if ((v & 0xF) == 0xF || (v >> 4) == 0xF)
            break;
      }
   } else {
      stbtt__cff_int(b);
   }
}

/**
 * Searches for a specific key in a dictionary stored within a buffer and returns the corresponding value.
 * The buffer is expected to contain a sequence of dictionary entries, each consisting of an operator (op)
 * followed by its operands. The method seeks to the start of the buffer and iterates through the entries
 * until it finds the matching key.
 *
 * @param b A pointer to the stbtt__buf structure representing the buffer containing the dictionary.
 * @param key The key to search for within the dictionary. This is typically an operator code.
 * @return An stbtt__buf structure representing the range of data associated with the key. If the key is
 *         not found, an empty buffer (range of length 0) is returned.
 */
static stbtt__buf stbtt__dict_get(stbtt__buf *b, int key)
{
   stbtt__buf_seek(b, 0);
   while (b->cursor < b->size) {
      int start = b->cursor, end, op;
      while (stbtt__buf_peek8(b) >= 28)
         stbtt__cff_skip_operand(b);
      end = b->cursor;
      op = stbtt__buf_get8(b);
      if (op == 12)  op = stbtt__buf_get8(b) | 0x100;
      if (op == key) return stbtt__buf_range(b, start, end-start);
   }
   return stbtt__buf_range(b, 0, 0);
}

/**
 * Retrieves an array of integers from a dictionary in a CFF (Compact Font Format) buffer.
 * 
 * This function searches for a specific key in the provided CFF buffer and extracts an array of
 * integers associated with that key. The integers are stored in the output array `out`. The number
 * of integers to extract is specified by `outcount`, but the function will stop extracting if the
 * end of the operands buffer is reached.
 *
 * @param b         Pointer to the CFF buffer containing the dictionary.
 * @param key       The key to search for in the dictionary.
 * @param outcount  The maximum number of integers to extract.
 * @param out       Pointer to the output array where the extracted integers will be stored.
 */
static void stbtt__dict_get_ints(stbtt__buf *b, int key, int outcount, stbtt_uint32 *out)
{
   int i;
   stbtt__buf operands = stbtt__dict_get(b, key);
   for (i = 0; i < outcount && operands.cursor < operands.size; i++)
      out[i] = stbtt__cff_int(&operands);
}

/**
 * Retrieves the count of elements in the CFF (Compact Font Format) index.
 * This function seeks to the beginning of the provided buffer and reads
 * the first 16-bit value, which represents the number of elements in the index.
 *
 * @param b A pointer to the stbtt__buf structure containing the CFF index data.
 * @return The count of elements in the CFF index as a 16-bit integer.
 */
static int stbtt__cff_index_count(stbtt__buf *b)
{
   stbtt__buf_seek(b, 0);
   return stbtt__buf_get16(b);
}

/**
 * Retrieves a specific entry from a CFF (Compact Font Format) index.
 *
 * The CFF index is a data structure that contains a collection of objects, each of which can be accessed by its index.
 * This method reads the index header to determine the number of entries and the size of the offsets, then calculates
 * the start and end positions of the requested entry. It returns a sub-buffer containing the data for the specified entry.
 *
 * @param b A buffer containing the CFF index data.
 * @param i The index of the entry to retrieve. Must be non-negative and less than the number of entries in the index.
 * @return A buffer representing the data of the specified entry. The buffer is a sub-range of the original buffer.
 *
 * @note This function assumes that the buffer `b` is properly formatted as a CFF index. It performs assertions to ensure
 *       that the index `i` is within bounds and that the offset size is valid (between 1 and 4 bytes).
 */
static stbtt__buf stbtt__cff_index_get(stbtt__buf b, int i)
{
   int count, offsize, start, end;
   stbtt__buf_seek(&b, 0);
   count = stbtt__buf_get16(&b);
   offsize = stbtt__buf_get8(&b);
   STBTT_assert(i >= 0 && i < count);
   STBTT_assert(offsize >= 1 && offsize <= 4);
   stbtt__buf_skip(&b, i*offsize);
   start = stbtt__buf_get(&b, offsize);
   end = stbtt__buf_get(&b, offsize);
   return stbtt__buf_range(&b, 2+(count+1)*offsize+start, end - start);
}

//////////////////////////////////////////////////////////////////////////
//
// accessors to parse data from file
//

// on platforms that don't allow misaligned reads, if we want to allow
// truetype fonts that aren't padded to alignment, define ALLOW_UNALIGNED_TRUETYPE

#define ttBYTE(p)     (* (stbtt_uint8 *) (p))
#define ttCHAR(p)     (* (stbtt_int8 *) (p))
#define ttFixed(p)    ttLONG(p)

/**
 * Converts a pair of bytes from a given pointer into a 16-bit unsigned integer.
 * The function assumes big-endian byte order, where the first byte (p[0]) represents
 * the high byte and the second byte (p[1]) represents the low byte of the resulting
 * 16-bit value.
 *
 * @param p A pointer to the start of the byte array containing the two bytes to convert.
 * @return The 16-bit unsigned integer formed by combining the two bytes.
 */
static stbtt_uint16 ttUSHORT(stbtt_uint8 *p) { return p[0]*256 + p[1]; }
/**
 * Reads a 16-bit signed integer in big-endian format from the given byte array.
 *
 * This function interprets the two bytes starting at the pointer `p` as a
 * 16-bit signed integer in big-endian format. The first byte (p[0]) is treated
 * as the most significant byte (MSB), and the second byte (p[1]) is treated as
 * the least significant byte (LSB). The function returns the resulting integer.
 *
 * @param p A pointer to the start of the byte array containing the 16-bit integer.
 * @return The 16-bit signed integer value read from the byte array.
 */
static stbtt_int16 ttSHORT(stbtt_uint8 *p) { return p[0]*256 + p[1]; }
/**
 * Reads a 32-bit unsigned integer from a byte array in big-endian format.
 * 
 * This function interprets the first four bytes of the given array as a big-endian
 * 32-bit unsigned integer. The bytes are combined in the following manner:
 * - The first byte (p[0]) is shifted left by 24 bits.
 * - The second byte (p[1]) is shifted left by 16 bits.
 * - The third byte (p[2]) is shifted left by 8 bits.
 * - The fourth byte (p[3]) is used as-is.
 * 
 * The result is the sum of these shifted values, representing the 32-bit unsigned integer.
 * 
 * @param p A pointer to the byte array from which to read the 32-bit unsigned integer.
 * @return The 32-bit unsigned integer read from the byte array.
 */
static stbtt_uint32 ttULONG(stbtt_uint8 *p)  { return (p[0]<<24) + (p[1]<<16) + (p[2]<<8) + p[3]; }
/**
 * Reads a 32-bit signed integer from a byte array in big-endian format.
 * 
 * This function interprets the first four bytes of the provided array as a big-endian
 * 32-bit integer. The bytes are combined as follows:
 * - The first byte (p[0]) is shifted left by 24 bits.
 * - The second byte (p[1]) is shifted left by 16 bits.
 * - The third byte (p[2]) is shifted left by 8 bits.
 * - The fourth byte (p[3]) is used as-is.
 * The resulting values are summed to produce the final 32-bit integer.
 *
 * @param p A pointer to the byte array containing the big-endian 32-bit integer.
 * @return The 32-bit signed integer value read from the byte array.
 */
static stbtt_int32 ttLONG(stbtt_uint8 *p)    { return (p[0]<<24) + (p[1]<<16) + (p[2]<<8) + p[3]; }

#define stbtt_tag4(p,c0,c1,c2,c3) ((p)[0] == (c0) && (p)[1] == (c1) && (p)[2] == (c2) && (p)[3] == (c3))
#define stbtt_tag(p,str)           stbtt_tag4(p,str[0],str[1],str[2],str[3])

/**
 * @brief Checks if the provided byte array represents a valid font file.
 *
 * This function examines the header of the font file to determine if it matches
 * known font formats. It checks for the following formats:
 * - TrueType 1 (tag '1' followed by three zeros)
 * - TrueType with Type 1 font (tag "typ1") - note: this format is not supported
 * - OpenType with CFF (tag "OTTO")
 * - OpenType 1.0 (tag with bytes 0, 1, 0, 0)
 * - Apple specification for TrueType fonts (tag "true")
 *
 * @param font A pointer to the byte array representing the font file.
 * @return int Returns 1 if the font file matches any of the known formats,
 *             otherwise returns 0.
 */
static int stbtt__isfont(stbtt_uint8 *font)
{
   // check the version number
   if (stbtt_tag4(font, '1',0,0,0))  return 1; // TrueType 1
   if (stbtt_tag(font, "typ1"))   return 1; // TrueType with type 1 font -- we don't support this!
   if (stbtt_tag(font, "OTTO"))   return 1; // OpenType with CFF
   if (stbtt_tag4(font, 0,1,0,0)) return 1; // OpenType 1.0
   if (stbtt_tag(font, "true"))   return 1; // Apple specification for TrueType fonts
   return 0;
}

// @OPTIMIZE: binary search
static stbtt_uint32 stbtt__find_table(stbtt_uint8 *data, stbtt_uint32 fontstart, const char *tag)
{
   stbtt_int32 num_tables = ttUSHORT(data+fontstart+4);
   stbtt_uint32 tabledir = fontstart + 12;
   stbtt_int32 i;
   for (i=0; i < num_tables; ++i) {
      stbtt_uint32 loc = tabledir + 16*i;
      if (stbtt_tag(data+loc+0, tag))
         return ttULONG(data+loc+8);
   }
   return 0;
}

/**
 * Determines the byte offset of a font within a font collection based on the specified index.
 *
 * This function is used to locate the starting position of a specific font in a font collection
 * (e.g., a TrueType Collection (TTC) file). If the input is a single font file (not a collection),
 * it only validates the index (which must be 0). For TTC files, it checks the version and retrieves
 * the offset of the font at the specified index.
 *
 * @param font_collection A pointer to the font collection data in memory.
 * @param index The index of the font within the collection. For single font files, this must be 0.
 *
 * @return The byte offset of the font within the collection, or -1 if the index is invalid or the
 *         collection format is unsupported.
 */
static int stbtt_GetFontOffsetForIndex_internal(unsigned char *font_collection, int index)
{
   // if it's just a font, there's only one valid index
   if (stbtt__isfont(font_collection))
      return index == 0 ? 0 : -1;

   // check if it's a TTC
   if (stbtt_tag(font_collection, "ttcf")) {
      // version 1?
      if (ttULONG(font_collection+4) == 0x00010000 || ttULONG(font_collection+4) == 0x00020000) {
         stbtt_int32 n = ttLONG(font_collection+8);
         if (index >= n)
            return -1;
         return ttULONG(font_collection+12+index*4);
      }
   }
   return -1;
}

/**
 * Determines the number of fonts contained within a given font collection.
 * 
 * This function checks if the provided `font_collection` is a single font or a TrueType Collection (TTC).
 * If it is a single font, the function returns 1. If it is a TTC, the function checks the version of the TTC
 * and returns the number of fonts contained within the collection. If the `font_collection` is neither a single
 * font nor a valid TTC, the function returns 0.
 *
 * @param font_collection A pointer to the font data, which could be a single font or a TTC.
 * @return The number of fonts in the collection. Returns 1 if it's a single font, the number of fonts if it's a TTC,
 *         or 0 if the input is neither.
 */
static int stbtt_GetNumberOfFonts_internal(unsigned char *font_collection)
{
   // if it's just a font, there's only one valid font
   if (stbtt__isfont(font_collection))
      return 1;

   // check if it's a TTC
   if (stbtt_tag(font_collection, "ttcf")) {
      // version 1?
      if (ttULONG(font_collection+4) == 0x00010000 || ttULONG(font_collection+4) == 0x00020000) {
         return ttLONG(font_collection+8);
      }
   }
   return 0;
}

/**
 * Retrieves the subroutine index (Subrs) from a CFF (Compact Font Format) font dictionary.
 *
 * This function extracts the Subrs index, which contains local subroutines used in the font's
 * charstring data. It first retrieves the private dictionary from the font dictionary, then
 * locates the Subrs offset within the private dictionary. Finally, it returns the Subrs index
 * as a buffer.
 *
 * @param cff The CFF data buffer containing the font data.
 * @param fontdict The font dictionary buffer from which to extract the private dictionary.
 * @return A buffer containing the Subrs index. If the private dictionary or Subrs offset
 *         is not found, an empty buffer is returned.
 */
static stbtt__buf stbtt__get_subrs(stbtt__buf cff, stbtt__buf fontdict)
{
   stbtt_uint32 subrsoff = 0, private_loc[2] = { 0, 0 };
   stbtt__buf pdict;
   stbtt__dict_get_ints(&fontdict, 18, 2, private_loc);
   if (!private_loc[1] || !private_loc[0]) return stbtt__new_buf(NULL, 0);
   pdict = stbtt__buf_range(&cff, private_loc[1], private_loc[0]);
   stbtt__dict_get_ints(&pdict, 19, 1, &subrsoff);
   if (!subrsoff) return stbtt__new_buf(NULL, 0);
   stbtt__buf_seek(&cff, private_loc[1]+subrsoff);
   return stbtt__cff_get_index(&cff);
}

// since most people won't use this, find this table the first time it's needed
static int stbtt__get_svg(stbtt_fontinfo *info)
{
   stbtt_uint32 t;
   if (info->svg < 0) {
      t = stbtt__find_table(info->data, info->fontstart, "SVG ");
      if (t) {
         stbtt_uint32 offset = ttULONG(info->data + t + 2);
         info->svg = t + offset;
      } else {
         info->svg = 0;
      }
   }
   return info->svg;
}

/**
 * Initializes a `stbtt_fontinfo` structure with the provided font data.
 * This function is an internal helper used to set up the font information
 * required for rendering and querying glyphs. It locates and validates
 * essential font tables (e.g., `cmap`, `head`, `hhea`, `hmtx`, `glyf`, `loca`)
 * and initializes the fontinfo structure accordingly. For TrueType fonts,
 * it ensures the presence of required tables, while for CFF/Type2 fonts,
 * it performs additional initialization specific to those formats.
 *
 * The function also identifies a suitable character map (cmap) encoding
 * table for glyph lookup and sets up the `index_map` for glyph indexing.
 * If any required tables are missing or the font data is invalid, the
 * function returns 0 to indicate failure. On success, it returns 1.
 *
 * @param info       Pointer to the `stbtt_fontinfo` structure to initialize.
 * @param data       Pointer to the raw font data.
 * @param fontstart  Offset within the font data where the font begins.
 * @return           1 if initialization succeeds, 0 otherwise.
 */
static int stbtt_InitFont_internal(stbtt_fontinfo *info, unsigned char *data, int fontstart)
{
   stbtt_uint32 cmap, t;
   stbtt_int32 i,numTables;

   info->data = data;
   info->fontstart = fontstart;
   info->cff = stbtt__new_buf(NULL, 0);

   cmap = stbtt__find_table(data, fontstart, "cmap");       // required
   info->loca = stbtt__find_table(data, fontstart, "loca"); // required
   info->head = stbtt__find_table(data, fontstart, "head"); // required
   info->glyf = stbtt__find_table(data, fontstart, "glyf"); // required
   info->hhea = stbtt__find_table(data, fontstart, "hhea"); // required
   info->hmtx = stbtt__find_table(data, fontstart, "hmtx"); // required
   info->kern = stbtt__find_table(data, fontstart, "kern"); // not required
   info->gpos = stbtt__find_table(data, fontstart, "GPOS"); // not required

   if (!cmap || !info->head || !info->hhea || !info->hmtx)
      return 0;
   if (info->glyf) {
      // required for truetype
      if (!info->loca) return 0;
   } else {
      // initialization for CFF / Type2 fonts (OTF)
      stbtt__buf b, topdict, topdictidx;
      stbtt_uint32 cstype = 2, charstrings = 0, fdarrayoff = 0, fdselectoff = 0;
      stbtt_uint32 cff;

      cff = stbtt__find_table(data, fontstart, "CFF ");
      if (!cff) return 0;

      info->fontdicts = stbtt__new_buf(NULL, 0);
      info->fdselect = stbtt__new_buf(NULL, 0);

      // @TODO this should use size from table (not 512MB)
      info->cff = stbtt__new_buf(data+cff, 512*1024*1024);
      b = info->cff;

      // read the header
      stbtt__buf_skip(&b, 2);
      stbtt__buf_seek(&b, stbtt__buf_get8(&b)); // hdrsize

      // @TODO the name INDEX could list multiple fonts,
      // but we just use the first one.
      stbtt__cff_get_index(&b);  // name INDEX
      topdictidx = stbtt__cff_get_index(&b);
      topdict = stbtt__cff_index_get(topdictidx, 0);
      stbtt__cff_get_index(&b);  // string INDEX
      info->gsubrs = stbtt__cff_get_index(&b);

      stbtt__dict_get_ints(&topdict, 17, 1, &charstrings);
      stbtt__dict_get_ints(&topdict, 0x100 | 6, 1, &cstype);
      stbtt__dict_get_ints(&topdict, 0x100 | 36, 1, &fdarrayoff);
      stbtt__dict_get_ints(&topdict, 0x100 | 37, 1, &fdselectoff);
      info->subrs = stbtt__get_subrs(b, topdict);

      // we only support Type 2 charstrings
      if (cstype != 2) return 0;
      if (charstrings == 0) return 0;

      if (fdarrayoff) {
         // looks like a CID font
         if (!fdselectoff) return 0;
         stbtt__buf_seek(&b, fdarrayoff);
         info->fontdicts = stbtt__cff_get_index(&b);
         info->fdselect = stbtt__buf_range(&b, fdselectoff, b.size-fdselectoff);
      }

      stbtt__buf_seek(&b, charstrings);
      info->charstrings = stbtt__cff_get_index(&b);
   }

   t = stbtt__find_table(data, fontstart, "maxp");
   if (t)
      info->numGlyphs = ttUSHORT(data+t+4);
   else
      info->numGlyphs = 0xffff;

   info->svg = -1;

   // find a cmap encoding table we understand *now* to avoid searching
   // later. (todo: could make this installable)
   // the same regardless of glyph.
   numTables = ttUSHORT(data + cmap + 2);
   info->index_map = 0;
   for (i=0; i < numTables; ++i) {
      stbtt_uint32 encoding_record = cmap + 4 + 8 * i;
      // find an encoding we understand:
      switch(ttUSHORT(data+encoding_record)) {
         case STBTT_PLATFORM_ID_MICROSOFT:
            switch (ttUSHORT(data+encoding_record+2)) {
               case STBTT_MS_EID_UNICODE_BMP:
               case STBTT_MS_EID_UNICODE_FULL:
                  // MS/Unicode
                  info->index_map = cmap + ttULONG(data+encoding_record+4);
                  break;
            }
            break;
        case STBTT_PLATFORM_ID_UNICODE:
            // Mac/iOS has these
            // all the encodingIDs are unicode, so we don't bother to check it
            info->index_map = cmap + ttULONG(data+encoding_record+4);
            break;
      }
   }
   if (info->index_map == 0)
      return 0;

   info->indexToLocFormat = ttUSHORT(data+info->head + 50);
   return 1;
}

/**
 * @brief Finds the glyph index for a given Unicode codepoint in a TrueType font.
 *
 * This function searches the font's character map (cmap) table to determine the glyph index
 * corresponding to the specified Unicode codepoint. The function supports various cmap formats,
 * including format 0 (Apple byte encoding), format 2 (high-byte mapping for CJK), format 4
 * (standard mapping for Windows fonts), format 6 (trimmed table mapping), and formats 12/13
 * (segmented coverage).
 *
 * @param info A pointer to the stbtt_fontinfo structure containing the font data.
 * @param unicode_codepoint The Unicode codepoint for which to find the glyph index.
 * @return The glyph index corresponding to the codepoint, or 0 if the codepoint is not found
 *         or the format is unsupported.
 */
STBTT_DEF int stbtt_FindGlyphIndex(const stbtt_fontinfo *info, int unicode_codepoint)
{
   stbtt_uint8 *data = info->data;
   stbtt_uint32 index_map = info->index_map;

   stbtt_uint16 format = ttUSHORT(data + index_map + 0);
   if (format == 0) { // apple byte encoding
      stbtt_int32 bytes = ttUSHORT(data + index_map + 2);
      if (unicode_codepoint < bytes-6)
         return ttBYTE(data + index_map + 6 + unicode_codepoint);
      return 0;
   } else if (format == 6) {
      stbtt_uint32 first = ttUSHORT(data + index_map + 6);
      stbtt_uint32 count = ttUSHORT(data + index_map + 8);
      if ((stbtt_uint32) unicode_codepoint >= first && (stbtt_uint32) unicode_codepoint < first+count)
         return ttUSHORT(data + index_map + 10 + (unicode_codepoint - first)*2);
      return 0;
   } else if (format == 2) {
      STBTT_assert(0); // @TODO: high-byte mapping for japanese/chinese/korean
      return 0;
   } else if (format == 4) { // standard mapping for windows fonts: binary search collection of ranges
      stbtt_uint16 segcount = ttUSHORT(data+index_map+6) >> 1;
      stbtt_uint16 searchRange = ttUSHORT(data+index_map+8) >> 1;
      stbtt_uint16 entrySelector = ttUSHORT(data+index_map+10);
      stbtt_uint16 rangeShift = ttUSHORT(data+index_map+12) >> 1;

      // do a binary search of the segments
      stbtt_uint32 endCount = index_map + 14;
      stbtt_uint32 search = endCount;

      if (unicode_codepoint > 0xffff)
         return 0;

      // they lie from endCount .. endCount + segCount
      // but searchRange is the nearest power of two, so...
      if (unicode_codepoint >= ttUSHORT(data + search + rangeShift*2))
         search += rangeShift*2;

      // now decrement to bias correctly to find smallest
      search -= 2;
      while (entrySelector) {
         stbtt_uint16 end;
         searchRange >>= 1;
         end = ttUSHORT(data + search + searchRange*2);
         if (unicode_codepoint > end)
            search += searchRange*2;
         --entrySelector;
      }
      search += 2;

      {
         stbtt_uint16 offset, start;
         stbtt_uint16 item = (stbtt_uint16) ((search - endCount) >> 1);

         STBTT_assert(unicode_codepoint <= ttUSHORT(data + endCount + 2*item));
         start = ttUSHORT(data + index_map + 14 + segcount*2 + 2 + 2*item);
         if (unicode_codepoint < start)
            return 0;

         offset = ttUSHORT(data + index_map + 14 + segcount*6 + 2 + 2*item);
         if (offset == 0)
            return (stbtt_uint16) (unicode_codepoint + ttSHORT(data + index_map + 14 + segcount*4 + 2 + 2*item));

         return ttUSHORT(data + offset + (unicode_codepoint-start)*2 + index_map + 14 + segcount*6 + 2 + 2*item);
      }
   } else if (format == 12 || format == 13) {
      stbtt_uint32 ngroups = ttULONG(data+index_map+12);
      stbtt_int32 low,high;
      low = 0; high = (stbtt_int32)ngroups;
      // Binary search the right group.
      while (low < high) {
         stbtt_int32 mid = low + ((high-low) >> 1); // rounds down, so low <= mid < high
         stbtt_uint32 start_char = ttULONG(data+index_map+16+mid*12);
         stbtt_uint32 end_char = ttULONG(data+index_map+16+mid*12+4);
         if ((stbtt_uint32) unicode_codepoint < start_char)
            high = mid;
         else if ((stbtt_uint32) unicode_codepoint > end_char)
            low = mid+1;
         else {
            stbtt_uint32 start_glyph = ttULONG(data+index_map+16+mid*12+8);
            if (format == 12)
               return start_glyph + unicode_codepoint-start_char;
            else // format == 13
               return start_glyph;
         }
      }
      return 0; // not found
   }
   // @TODO
   STBTT_assert(0);
   return 0;
}

/**
 * Retrieves the shape of a Unicode codepoint from a TrueType font as a sequence of vertices.
 *
 * This function first finds the glyph index corresponding to the specified Unicode codepoint
 * using `stbtt_FindGlyphIndex`, then retrieves the shape of that glyph using `stbtt_GetGlyphShape`.
 * The shape is represented as an array of vertices, which describe the contours of the glyph.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param unicode_codepoint The Unicode codepoint for which to retrieve the shape.
 * @param vertices A pointer to an array of `stbtt_vertex` structures that will be filled with the
 *                 vertices describing the shape of the glyph. The caller is responsible for
 *                 freeing this array.
 * @return The number of vertices in the `vertices` array, or 0 if the codepoint has no shape
 *         (e.g., for whitespace or invalid codepoints).
 */
STBTT_DEF int stbtt_GetCodepointShape(const stbtt_fontinfo *info, int unicode_codepoint, stbtt_vertex **vertices)
{
   return stbtt_GetGlyphShape(info, stbtt_FindGlyphIndex(info, unicode_codepoint), vertices);
}

/**
 * Sets the properties of a vertex in a TrueType font outline.
 *
 * This function initializes a `stbtt_vertex` structure with the specified type and coordinates.
 * The vertex represents a point in the outline of a glyph, and its type determines how it is used
 * in the path construction (e.g., move-to, line-to, curve-to, etc.).
 *
 * @param v    Pointer to the `stbtt_vertex` structure to be initialized.
 * @param type The type of the vertex, which defines its role in the path (e.g., STBTT_vmove, STBTT_vline, STBTT_vcurve).
 * @param x    The x-coordinate of the vertex.
 * @param y    The y-coordinate of the vertex.
 * @param cx   The x-coordinate of the control point (used for curve vertices).
 * @param cy   The y-coordinate of the control point (used for curve vertices).
 */
static void stbtt_setvertex(stbtt_vertex *v, stbtt_uint8 type, stbtt_int32 x, stbtt_int32 y, stbtt_int32 cx, stbtt_int32 cy)
{
   v->type = type;
   v->x = (stbtt_int16) x;
   v->y = (stbtt_int16) y;
   v->cx = (stbtt_int16) cx;
   v->cy = (stbtt_int16) cy;
}

/**
 * Retrieves the offset of the glyph data in the 'glyf' table for a given glyph index.
 *
 * This function calculates the offset of the glyph data in the 'glyf' table based on the 
 * provided glyph index. It supports two formats for the 'loca' table (indexToLocFormat): 
 * 0 (short offsets) and 1 (long offsets). If the glyph index is out of range or the 
 * indexToLocFormat is unsupported, the function returns -1. Additionally, if the calculated 
 * offset indicates a glyph with zero length, the function also returns -1.
 *
 * @param info        Pointer to the stbtt_fontinfo structure containing font data.
 * @param glyph_index The index of the glyph for which the offset is to be retrieved.
 *
 * @return            The offset of the glyph data in the 'glyf' table, or -1 if the glyph 
 *                    index is out of range, the indexToLocFormat is unsupported, or the 
 *                    glyph has zero length.
 */
static int stbtt__GetGlyfOffset(const stbtt_fontinfo *info, int glyph_index)
{
   int g1,g2;

   STBTT_assert(!info->cff.size);

   if (glyph_index >= info->numGlyphs) return -1; // glyph index out of range
   if (info->indexToLocFormat >= 2)    return -1; // unknown index->glyph map format

   if (info->indexToLocFormat == 0) {
      g1 = info->glyf + ttUSHORT(info->data + info->loca + glyph_index * 2) * 2;
      g2 = info->glyf + ttUSHORT(info->data + info->loca + glyph_index * 2 + 2) * 2;
   } else {
      g1 = info->glyf + ttULONG (info->data + info->loca + glyph_index * 4);
      g2 = info->glyf + ttULONG (info->data + info->loca + glyph_index * 4 + 4);
   }

   return g1==g2 ? -1 : g1; // if length is 0, return -1
}

static int stbtt__GetGlyphInfoT2(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1);

/**
 * Retrieves the bounding box of a glyph in a TrueType or OpenType font.
 *
 * This function calculates the bounding box (the smallest rectangle that completely encloses the glyph)
 * for a specified glyph in the font. The bounding box is returned in font units, which are typically
 * scaled to the font's em size.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param glyph_index The index of the glyph for which to retrieve the bounding box.
 * @param x0 A pointer to an integer where the leftmost x-coordinate of the bounding box will be stored.
 *           Can be NULL if this value is not needed.
 * @param y0 A pointer to an integer where the bottommost y-coordinate of the bounding box will be stored.
 *           Can be NULL if this value is not needed.
 * @param x1 A pointer to an integer where the rightmost x-coordinate of the bounding box will be stored.
 *           Can be NULL if this value is not needed.
 * @param y1 A pointer to an integer where the topmost y-coordinate of the bounding box will be stored.
 *           Can be NULL if this value is not needed.
 *
 * @return Returns 1 if the bounding box was successfully retrieved, and 0 if the glyph index is invalid
 *         or the glyph has no bounding box (e.g., a space character).
 */
STBTT_DEF int stbtt_GetGlyphBox(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1)
{
   if (info->cff.size) {
      stbtt__GetGlyphInfoT2(info, glyph_index, x0, y0, x1, y1);
   } else {
      int g = stbtt__GetGlyfOffset(info, glyph_index);
      if (g < 0) return 0;

      if (x0) *x0 = ttSHORT(info->data + g + 2);
      if (y0) *y0 = ttSHORT(info->data + g + 4);
      if (x1) *x1 = ttSHORT(info->data + g + 6);
      if (y1) *y1 = ttSHORT(info->data + g + 8);
   }
   return 1;
}

/**
 * Retrieves the bounding box of a specified Unicode codepoint in a font.
 *
 * This function calculates the bounding box that encloses the glyph corresponding
 * to the given codepoint. The bounding box is defined by the coordinates of its
 * bottom-left corner (x0, y0) and its top-right corner (x1, y1).
 *
 * @param info        A pointer to the stbtt_fontinfo structure containing the font data.
 * @param codepoint   The Unicode codepoint for which to retrieve the bounding box.
 * @param x0         A pointer to store the x-coordinate of the bottom-left corner of the bounding box.
 * @param y0         A pointer to store the y-coordinate of the bottom-left corner of the bounding box.
 * @param x1         A pointer to store the x-coordinate of the top-right corner of the bounding box.
 * @param y1         A pointer to store the y-coordinate of the top-right corner of the bounding box.
 *
 * @return            Returns 1 if the bounding box was successfully retrieved, 0 otherwise.
 */
STBTT_DEF int stbtt_GetCodepointBox(const stbtt_fontinfo *info, int codepoint, int *x0, int *y0, int *x1, int *y1)
{
   return stbtt_GetGlyphBox(info, stbtt_FindGlyphIndex(info,codepoint), x0,y0,x1,y1);
}

/**
 * Determines whether a glyph in a TrueType or OpenType font is empty.
 * 
 * This function checks if the specified glyph in the font is empty, meaning it contains no contours.
 * For fonts in the Compact Font Format (CFF), it uses the `stbtt__GetGlyphInfoT2` function to retrieve
 * the glyph information and checks if the glyph has zero contours. For TrueType fonts, it calculates
 * the offset of the glyph in the glyf table and checks the number of contours directly from the font data.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param glyph_index The index of the glyph to check.
 * @return Returns 1 if the glyph is empty (has no contours), otherwise returns 0.
 */
STBTT_DEF int stbtt_IsGlyphEmpty(const stbtt_fontinfo *info, int glyph_index)
{
   stbtt_int16 numberOfContours;
   int g;
   if (info->cff.size)
      return stbtt__GetGlyphInfoT2(info, glyph_index, NULL, NULL, NULL, NULL) == 0;
   g = stbtt__GetGlyfOffset(info, glyph_index);
   if (g < 0) return 1;
   numberOfContours = ttSHORT(info->data + g);
   return numberOfContours == 0;
}

/**
 * Closes a shape by adding the necessary vertices to the provided vertex array.
 * This function is used to finalize a shape by connecting the last vertex back to the starting point.
 * Depending on the parameters, it adds either a curve or a line segment to complete the shape.
 *
 * @param vertices The array of vertices representing the shape.
 * @param num_vertices The current number of vertices in the array.
 * @param was_off Indicates whether the previous segment was a curve (1) or a line (0).
 * @param start_off Indicates whether the starting segment was a curve (1) or a line (0).
 * @param sx The x-coordinate of the starting point.
 * @param sy The y-coordinate of the starting point.
 * @param scx The x-coordinate of the control point for the starting curve.
 * @param scy The y-coordinate of the control point for the starting curve.
 * @param cx The x-coordinate of the last control point.
 * @param cy The y-coordinate of the last control point.
 *
 * @return The updated number of vertices in the array after closing the shape.
 */
static int stbtt__close_shape(stbtt_vertex *vertices, int num_vertices, int was_off, int start_off,
    stbtt_int32 sx, stbtt_int32 sy, stbtt_int32 scx, stbtt_int32 scy, stbtt_int32 cx, stbtt_int32 cy)
{
   if (start_off) {
      if (was_off)
         stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, (cx+scx)>>1, (cy+scy)>>1, cx,cy);
      stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, sx,sy,scx,scy);
   } else {
      if (was_off)
         stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve,sx,sy,cx,cy);
      else
         stbtt_setvertex(&vertices[num_vertices++], STBTT_vline,sx,sy,0,0);
   }
   return num_vertices;
}

/**
 * Retrieves the glyph shape for a given glyph index from a TrueType font.
 * This function processes the glyph data to extract contour information and
 * generates a set of vertices representing the glyph's shape. The vertices
 * are stored in an array allocated by the caller via the `pvertices` pointer.
 *
 * The function handles both simple and compound glyphs. For simple glyphs,
 * it extracts contour points and converts them into a sequence of vertices.
 * For compound glyphs, it recursively processes each component, applying
 * transformations and merging the resulting vertices.
 *
 * @param info           Pointer to the `stbtt_fontinfo` structure containing
 *                       the font data.
 * @param glyph_index    The index of the glyph to retrieve the shape for.
 * @param pvertices      Pointer to a pointer where the resulting vertices
 *                       will be stored. The caller is responsible for freeing
 *                       this memory.
 *
 * @return               The number of vertices generated. Returns 0 if the
 *                       glyph index is invalid or if memory allocation fails.
 */
static int stbtt__GetGlyphShapeTT(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **pvertices)
{
   stbtt_int16 numberOfContours;
   stbtt_uint8 *endPtsOfContours;
   stbtt_uint8 *data = info->data;
   stbtt_vertex *vertices=0;
   int num_vertices=0;
   int g = stbtt__GetGlyfOffset(info, glyph_index);

   *pvertices = NULL;

   if (g < 0) return 0;

   numberOfContours = ttSHORT(data + g);

   if (numberOfContours > 0) {
      stbtt_uint8 flags=0,flagcount;
      stbtt_int32 ins, i,j=0,m,n, next_move, was_off=0, off, start_off=0;
      stbtt_int32 x,y,cx,cy,sx,sy, scx,scy;
      stbtt_uint8 *points;
      endPtsOfContours = (data + g + 10);
      ins = ttUSHORT(data + g + 10 + numberOfContours * 2);
      points = data + g + 10 + numberOfContours * 2 + 2 + ins;

      n = 1+ttUSHORT(endPtsOfContours + numberOfContours*2-2);

      m = n + 2*numberOfContours;  // a loose bound on how many vertices we might need
      vertices = (stbtt_vertex *) STBTT_malloc(m * sizeof(vertices[0]), info->userdata);
      if (vertices == 0)
         return 0;

      next_move = 0;
      flagcount=0;

      // in first pass, we load uninterpreted data into the allocated array
      // above, shifted to the end of the array so we won't overwrite it when
      // we create our final data starting from the front

      off = m - n; // starting offset for uninterpreted data, regardless of how m ends up being calculated

      // first load flags

      for (i=0; i < n; ++i) {
         if (flagcount == 0) {
            flags = *points++;
            if (flags & 8)
               flagcount = *points++;
         } else
            --flagcount;
         vertices[off+i].type = flags;
      }

      // now load x coordinates
      x=0;
      for (i=0; i < n; ++i) {
         flags = vertices[off+i].type;
         if (flags & 2) {
            stbtt_int16 dx = *points++;
            x += (flags & 16) ? dx : -dx; // ???
         } else {
            if (!(flags & 16)) {
               x = x + (stbtt_int16) (points[0]*256 + points[1]);
               points += 2;
            }
         }
         vertices[off+i].x = (stbtt_int16) x;
      }

      // now load y coordinates
      y=0;
      for (i=0; i < n; ++i) {
         flags = vertices[off+i].type;
         if (flags & 4) {
            stbtt_int16 dy = *points++;
            y += (flags & 32) ? dy : -dy; // ???
         } else {
            if (!(flags & 32)) {
               y = y + (stbtt_int16) (points[0]*256 + points[1]);
               points += 2;
            }
         }
         vertices[off+i].y = (stbtt_int16) y;
      }

      // now convert them to our format
      num_vertices=0;
      sx = sy = cx = cy = scx = scy = 0;
      for (i=0; i < n; ++i) {
         flags = vertices[off+i].type;
         x     = (stbtt_int16) vertices[off+i].x;
         y     = (stbtt_int16) vertices[off+i].y;

         if (next_move == i) {
            if (i != 0)
               num_vertices = stbtt__close_shape(vertices, num_vertices, was_off, start_off, sx,sy,scx,scy,cx,cy);

            // now start the new one
            start_off = !(flags & 1);
            if (start_off) {
               // if we start off with an off-curve point, then when we need to find a point on the curve
               // where we can start, and we need to save some state for when we wraparound.
               scx = x;
               scy = y;
               if (!(vertices[off+i+1].type & 1)) {
                  // next point is also a curve point, so interpolate an on-point curve
                  sx = (x + (stbtt_int32) vertices[off+i+1].x) >> 1;
                  sy = (y + (stbtt_int32) vertices[off+i+1].y) >> 1;
               } else {
                  // otherwise just use the next point as our start point
                  sx = (stbtt_int32) vertices[off+i+1].x;
                  sy = (stbtt_int32) vertices[off+i+1].y;
                  ++i; // we're using point i+1 as the starting point, so skip it
               }
            } else {
               sx = x;
               sy = y;
            }
            stbtt_setvertex(&vertices[num_vertices++], STBTT_vmove,sx,sy,0,0);
            was_off = 0;
            next_move = 1 + ttUSHORT(endPtsOfContours+j*2);
            ++j;
         } else {
            if (!(flags & 1)) { // if it's a curve
               if (was_off) // two off-curve control points in a row means interpolate an on-curve midpoint
                  stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, (cx+x)>>1, (cy+y)>>1, cx, cy);
               cx = x;
               cy = y;
               was_off = 1;
            } else {
               if (was_off)
                  stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, x,y, cx, cy);
               else
                  stbtt_setvertex(&vertices[num_vertices++], STBTT_vline, x,y,0,0);
               was_off = 0;
            }
         }
      }
      num_vertices = stbtt__close_shape(vertices, num_vertices, was_off, start_off, sx,sy,scx,scy,cx,cy);
   } else if (numberOfContours < 0) {
      // Compound shapes.
      int more = 1;
      stbtt_uint8 *comp = data + g + 10;
      num_vertices = 0;
      vertices = 0;
      while (more) {
         stbtt_uint16 flags, gidx;
         int comp_num_verts = 0, i;
         stbtt_vertex *comp_verts = 0, *tmp = 0;
         fixedpt mtx[6] = {FIXEDPT_ONE,0,0,FIXEDPT_ONE,0,0}, m, n;

         flags = ttSHORT(comp); comp+=2;
         gidx = ttSHORT(comp); comp+=2;

         if (flags & 2) { // XY values
            if (flags & 1) { // shorts
               mtx[4] = fixedpt_fromint(ttSHORT(comp)); comp+=2;
               mtx[5] = fixedpt_fromint(ttSHORT(comp)); comp+=2;
            } else {
               mtx[4] = fixedpt_fromint(ttCHAR(comp)); comp+=1;
               mtx[5] = fixedpt_fromint(ttCHAR(comp)); comp+=1;
            }
         }
         else {
            // @TODO handle matching point
            STBTT_assert(0);
         }
         if (flags & (1<<3)) { // WE_HAVE_A_SCALE
            mtx[0] = mtx[3] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)), 16384); comp+=2;
            mtx[1] = mtx[2] = 0;
         } else if (flags & (1<<6)) { // WE_HAVE_AN_X_AND_YSCALE
            mtx[0] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)),16384); comp+=2;
            mtx[1] = mtx[2] = 0;
            mtx[3] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)),16384); comp+=2;
         } else if (flags & (1<<7)) { // WE_HAVE_A_TWO_BY_TWO
            mtx[0] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)),16384); comp+=2;
            mtx[1] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)),16384); comp+=2;
            mtx[2] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)),16384); comp+=2;
            mtx[3] = fixedpt_divi(fixedpt_fromint(ttSHORT(comp)),16384); comp+=2;
         }

         // Find transformation scales.
         m = STBTT_sqrt(fixedpt_mul(mtx[0], mtx[0]) + fixedpt_mul(mtx[1], mtx[1]));
         n = STBTT_sqrt(fixedpt_mul(mtx[2], mtx[2]) + fixedpt_mul(mtx[3], mtx[3]));

         // Get indexed glyph.
         comp_num_verts = stbtt_GetGlyphShape(info, gidx, &comp_verts);
         if (comp_num_verts > 0) {
            // Transform vertices.
            for (i = 0; i < comp_num_verts; ++i) {
               stbtt_vertex* v = &comp_verts[i];
               stbtt_vertex_type x,y;
               x=v->x; y=v->y;
               v->x  = (stbtt_vertex_type)(fixedpt_toint(fixedpt_mul(m, (fixedpt_muli(mtx[0],x) + fixedpt_muli(mtx[2],y) + mtx[4]))));
               v->y  = (stbtt_vertex_type)(fixedpt_toint(fixedpt_mul(n, (fixedpt_muli(mtx[1],x) + fixedpt_muli(mtx[3],y) + mtx[5]))));
               x=v->cx; y=v->cy;
               v->cx = (stbtt_vertex_type)(fixedpt_toint(fixedpt_mul(m, (fixedpt_muli(mtx[0],x) + fixedpt_muli(mtx[2],y) + mtx[4]))));
               v->cy = (stbtt_vertex_type)(fixedpt_toint(fixedpt_mul(n, (fixedpt_muli(mtx[1],x) + fixedpt_muli(mtx[3],y) + mtx[5]))));
            }
            // Append vertices.
            tmp = (stbtt_vertex*)STBTT_malloc((num_vertices+comp_num_verts)*sizeof(stbtt_vertex), info->userdata);
            if (!tmp) {
               if (vertices) STBTT_free(vertices, info->userdata);
               if (comp_verts) STBTT_free(comp_verts, info->userdata);
               return 0;
            }
            if (num_vertices > 0) STBTT_memcpy(tmp, vertices, num_vertices*sizeof(stbtt_vertex));
            STBTT_memcpy(tmp+num_vertices, comp_verts, comp_num_verts*sizeof(stbtt_vertex));
            if (vertices) STBTT_free(vertices, info->userdata);
            vertices = tmp;
            STBTT_free(comp_verts, info->userdata);
            num_vertices += comp_num_verts;
         }
         // More components ?
         more = flags & (1<<5);
      }
   } else {
      // numberOfCounters == 0, do nothing
   }

   *pvertices = vertices;
   return num_vertices;
}

typedef struct
{
   int bounds;
   int started;
   float first_x, first_y;
   float x, y;
   stbtt_int32 min_x, max_x, min_y, max_y;

   stbtt_vertex *pvertices;
   int num_vertices;
} stbtt__csctx;

#define STBTT__CSCTX_INIT(bounds) {bounds,0, 0,0, 0,0, 0,0,0,0, NULL, 0}

/**
 * Updates the bounding box of a shape by tracking the minimum and maximum x and y coordinates
 * of the vertices. This function is typically used in the context of parsing or rendering
 * vector graphics to determine the extent of the shape.
 *
 * @param c A pointer to the stbtt__csctx context, which stores the current bounding box
 *          information and the state of the tracking process.
 * @param x The x-coordinate of the vertex to be tracked.
 * @param y The y-coordinate of the vertex to be tracked.
 *
 * The function updates the bounding box (min_x, min_y, max_x, max_y) in the context `c` to
 * include the provided vertex (x, y). If the context has not been initialized (i.e., `c->started`
 * is false), the bounding box is initialized with the vertex coordinates. After the first call,
 * `c->started` is set to 1, indicating that the bounding box has been initialized.
 */
static void stbtt__track_vertex(stbtt__csctx *c, stbtt_int32 x, stbtt_int32 y)
{
   if (x > c->max_x || !c->started) c->max_x = x;
   if (y > c->max_y || !c->started) c->max_y = y;
   if (x < c->min_x || !c->started) c->min_x = x;
   if (y < c->min_y || !c->started) c->min_y = y;
   c->started = 1;
}

/**
 * Adds a vertex to the context `c` based on the provided type and coordinates.
 * This function is used to handle both simple vertices and cubic Bézier curve vertices.
 * If the context is in bounds-tracking mode (`c->bounds` is true), it updates the bounds
 * by tracking the provided vertices. Otherwise, it adds the vertex to the vertex array
 * `c->pvertices` and increments the vertex count.
 *
 * @param c     Pointer to the `stbtt__csctx` context where the vertex is added.
 * @param type  The type of the vertex (e.g., `STBTT_vcubic` for cubic Bézier curves).
 * @param x     The x-coordinate of the vertex.
 * @param y     The y-coordinate of the vertex.
 * @param cx    The x-coordinate of the first control point (for cubic Bézier curves).
 * @param cy    The y-coordinate of the first control point (for cubic Bézier curves).
 * @param cx1   The x-coordinate of the second control point (for cubic Bézier curves).
 * @param cy1   The y-coordinate of the second control point (for cubic Bézier curves).
 */
static void stbtt__csctx_v(stbtt__csctx *c, stbtt_uint8 type, stbtt_int32 x, stbtt_int32 y, stbtt_int32 cx, stbtt_int32 cy, stbtt_int32 cx1, stbtt_int32 cy1)
{
   if (c->bounds) {
      stbtt__track_vertex(c, x, y);
      if (type == STBTT_vcubic) {
         stbtt__track_vertex(c, cx, cy);
         stbtt__track_vertex(c, cx1, cy1);
      }
   } else {
      stbtt_setvertex(&c->pvertices[c->num_vertices], type, x, y, cx, cy);
      c->pvertices[c->num_vertices].cx1 = (stbtt_int16) cx1;
      c->pvertices[c->num_vertices].cy1 = (stbtt_int16) cy1;
   }
   c->num_vertices++;
}

/**
 * Closes the current shape in the context by drawing a line from the current position
 * back to the starting position of the shape, if necessary. This ensures that the shape
 * is properly closed by connecting the last point to the first point.
 *
 * @param ctx The context containing the current state of the shape being constructed.
 *            This includes the current position (x, y) and the starting position (first_x, first_y).
 *
 * If the current position (x, y) is not the same as the starting position (first_x, first_y),
 * a line segment is added to the context to connect the two points, effectively closing the shape.
 */
static void stbtt__csctx_close_shape(stbtt__csctx *ctx)
{
   if (ctx->first_x != ctx->x || ctx->first_y != ctx->y)
      stbtt__csctx_v(ctx, STBTT_vline, (int)ctx->first_x, (int)ctx->first_y, 0, 0, 0, 0);
}

/**
 * Moves the current point in the context to a new position relative to the current coordinates.
 * This function first closes the current shape (if any) by calling `stbtt__csctx_close_shape`.
 * It then updates the current position (`x`, `y`) and the starting position (`first_x`, `first_y`)
 * by adding the specified offsets `dx` and `dy` to the current coordinates. Finally, it records
 * a move-to command (`STBTT_vmove`) in the context with the updated position.
 *
 * @param ctx Pointer to the `stbtt__csctx` context structure.
 * @param dx  The horizontal offset to move the current point by.
 * @param dy  The vertical offset to move the current point by.
 */
static void stbtt__csctx_rmove_to(stbtt__csctx *ctx, float dx, float dy)
{
   stbtt__csctx_close_shape(ctx);
   ctx->first_x = ctx->x = ctx->x + dx;
   ctx->first_y = ctx->y = ctx->y + dy;
   stbtt__csctx_v(ctx, STBTT_vmove, (int)ctx->x, (int)ctx->y, 0, 0, 0, 0);
}

/**
 * Adds a relative line-to command to the context's path.
 * This function updates the current position in the context by adding the specified
 * delta values (dx, dy) to the current coordinates (ctx->x, ctx->y). It then adds
 * a line-to command to the path, using the updated coordinates as the endpoint.
 *
 * @param ctx Pointer to the stbtt__csctx context structure that holds the current state.
 * @param dx  The horizontal distance to move relative to the current position.
 * @param dy  The vertical distance to move relative to the current position.
 */
static void stbtt__csctx_rline_to(stbtt__csctx *ctx, float dx, float dy)
{
   ctx->x += dx;
   ctx->y += dy;
   stbtt__csctx_v(ctx, STBTT_vline, (int)ctx->x, (int)ctx->y, 0, 0, 0, 0);
}

/**
 * Adds a cubic Bézier curve to the current path in the context.
 * The curve is defined by three control points relative to the current position.
 * The first control point is (ctx->x + dx1, ctx->y + dy1), the second control point is
 * (cx1 + dx2, cy1 + dy2), and the end point is (cx2 + dx3, cy2 + dy3).
 * After adding the curve, the current position is updated to the end point of the curve.
 *
 * @param ctx The context to which the curve is added.
 * @param dx1 The x-offset from the current position to the first control point.
 * @param dy1 The y-offset from the current position to the first control point.
 * @param dx2 The x-offset from the first control point to the second control point.
 * @param dy2 The y-offset from the first control point to the second control point.
 * @param dx3 The x-offset from the second control point to the end point.
 * @param dy3 The y-offset from the second control point to the end point.
 */
static void stbtt__csctx_rccurve_to(stbtt__csctx *ctx, float dx1, float dy1, float dx2, float dy2, float dx3, float dy3)
{
   float cx1 = ctx->x + dx1;
   float cy1 = ctx->y + dy1;
   float cx2 = cx1 + dx2;
   float cy2 = cy1 + dy2;
   ctx->x = cx2 + dx3;
   ctx->y = cy2 + dy3;
   stbtt__csctx_v(ctx, STBTT_vcubic, (int)ctx->x, (int)ctx->y, (int)cx1, (int)cy1, (int)cx2, (int)cy2);
}

/**
 * Retrieves a subroutine (subr) from a CFF (Compact Font Format) index buffer.
 * The method calculates the appropriate bias based on the number of subroutines
 * in the index and adjusts the requested subroutine index `n` accordingly.
 * If the adjusted index is out of bounds, an empty buffer is returned.
 *
 * @param idx The CFF index buffer containing the subroutines.
 * @param n The index of the subroutine to retrieve (before applying bias).
 * @return A buffer containing the requested subroutine if the index is valid;
 *         otherwise, an empty buffer is returned.
 */
static stbtt__buf stbtt__get_subr(stbtt__buf idx, int n)
{
   int count = stbtt__cff_index_count(&idx);
   int bias = 107;
   if (count >= 33900)
      bias = 32768;
   else if (count >= 1240)
      bias = 1131;
   n += bias;
   if (n < 0 || n >= count)
      return stbtt__new_buf(NULL, 0);
   return stbtt__cff_index_get(idx, n);
}

/**
 * Retrieves the subroutines (subrs) associated with a specific glyph in a CID-keyed font.
 * 
 * This function determines the Font DICT Selector (FDSelect) for the given glyph index by
 * parsing the FDSelect table in the font's CFF (Compact Font Format) data. The FDSelect table
 * maps glyph indices to specific Font DICTs, which contain the subroutines used by the glyph.
 * 
 * The function supports two formats of the FDSelect table:
 * - Format 0: A direct mapping where each glyph index corresponds to a single byte FDSelect value.
 * - Format 3: A range-based mapping where glyph indices are grouped into ranges, each associated
 *   with an FDSelect value.
 * 
 * If the glyph index does not match any range or is out of bounds, the function returns an empty
 * buffer. Otherwise, it retrieves the subroutines from the appropriate Font DICT.
 * 
 * @param info        Pointer to the stbtt_fontinfo structure containing font data.
 * @param glyph_index The index of the glyph whose subroutines are to be retrieved.
 * 
 * @return A buffer containing the subroutines for the specified glyph. If the glyph index is
 *         invalid or no subroutines are found, an empty buffer is returned.
 */
static stbtt__buf stbtt__cid_get_glyph_subrs(const stbtt_fontinfo *info, int glyph_index)
{
   stbtt__buf fdselect = info->fdselect;
   int nranges, start, end, v, fmt, fdselector = -1, i;

   stbtt__buf_seek(&fdselect, 0);
   fmt = stbtt__buf_get8(&fdselect);
   if (fmt == 0) {
      // untested
      stbtt__buf_skip(&fdselect, glyph_index);
      fdselector = stbtt__buf_get8(&fdselect);
   } else if (fmt == 3) {
      nranges = stbtt__buf_get16(&fdselect);
      start = stbtt__buf_get16(&fdselect);
      for (i = 0; i < nranges; i++) {
         v = stbtt__buf_get8(&fdselect);
         end = stbtt__buf_get16(&fdselect);
         if (glyph_index >= start && glyph_index < end) {
            fdselector = v;
            break;
         }
         start = end;
      }
   }
   if (fdselector == -1) stbtt__new_buf(NULL, 0);
   return stbtt__get_subrs(info->cff, stbtt__cff_index_get(info->fontdicts, fdselector));
}

/**
 * @brief Interprets and executes a glyph's charstring commands to construct its outline.
 *
 * This method processes the charstring data of a glyph, which contains a series of commands
 * that define the glyph's outline. It handles various PostScript Type 2 charstring commands,
 * including but not limited to moveto, lineto, curveto, and subroutines. The method uses a
 * state machine to interpret the commands and updates the glyph's outline context (`stbtt__csctx`)
 * accordingly.
 *
 * @param info Pointer to the font information structure containing the charstring data.
 * @param glyph_index The index of the glyph whose charstring is to be processed.
 * @param c Pointer to the context structure (`stbtt__csctx`) that stores the glyph's outline data.
 *
 * @return Returns 1 if the charstring is successfully processed and ends with an `endchar` command.
 *         Returns 0 if an error occurs during processing (e.g., invalid command, stack overflow).
 *
 * @note This method currently ignores hinting commands and does not implement hinting.
 *       It also assumes the presence of horizontal metrics (hmtx) and ignores the initial width value.
 *       Subroutines (callsubr, callgsubr) are supported, but recursion is limited to a depth of 10.
 */
static int stbtt__run_charstring(const stbtt_fontinfo *info, int glyph_index, stbtt__csctx *c)
{
   int in_header = 1, maskbits = 0, subr_stack_height = 0, sp = 0, v, i, b0;
   int has_subrs = 0, clear_stack;
   float s[48];
   stbtt__buf subr_stack[10], subrs = info->subrs, b;
   float f;

#define STBTT__CSERR(s) (0)

   // this currently ignores the initial width value, which isn't needed if we have hmtx
   b = stbtt__cff_index_get(info->charstrings, glyph_index);
   while (b.cursor < b.size) {
      i = 0;
      clear_stack = 1;
      b0 = stbtt__buf_get8(&b);
      switch (b0) {
      // @TODO implement hinting
      case 0x13: // hintmask
      case 0x14: // cntrmask
         if (in_header)
            maskbits += (sp / 2); // implicit "vstem"
         in_header = 0;
         stbtt__buf_skip(&b, (maskbits + 7) / 8);
         break;

      case 0x01: // hstem
      case 0x03: // vstem
      case 0x12: // hstemhm
      case 0x17: // vstemhm
         maskbits += (sp / 2);
         break;

      case 0x15: // rmoveto
         in_header = 0;
         if (sp < 2) return STBTT__CSERR("rmoveto stack");
         stbtt__csctx_rmove_to(c, s[sp-2], s[sp-1]);
         break;
      case 0x04: // vmoveto
         in_header = 0;
         if (sp < 1) return STBTT__CSERR("vmoveto stack");
         stbtt__csctx_rmove_to(c, 0, s[sp-1]);
         break;
      case 0x16: // hmoveto
         in_header = 0;
         if (sp < 1) return STBTT__CSERR("hmoveto stack");
         stbtt__csctx_rmove_to(c, s[sp-1], 0);
         break;

      case 0x05: // rlineto
         if (sp < 2) return STBTT__CSERR("rlineto stack");
         for (; i + 1 < sp; i += 2)
            stbtt__csctx_rline_to(c, s[i], s[i+1]);
         break;

      // hlineto/vlineto and vhcurveto/hvcurveto alternate horizontal and vertical
      // starting from a different place.

      case 0x07: // vlineto
         if (sp < 1) return STBTT__CSERR("vlineto stack");
         goto vlineto;
      case 0x06: // hlineto
         if (sp < 1) return STBTT__CSERR("hlineto stack");
         for (;;) {
            if (i >= sp) break;
            stbtt__csctx_rline_to(c, s[i], 0);
            i++;
      vlineto:
            if (i >= sp) break;
            stbtt__csctx_rline_to(c, 0, s[i]);
            i++;
         }
         break;

      case 0x1F: // hvcurveto
         if (sp < 4) return STBTT__CSERR("hvcurveto stack");
         goto hvcurveto;
      case 0x1E: // vhcurveto
         if (sp < 4) return STBTT__CSERR("vhcurveto stack");
         for (;;) {
            if (i + 3 >= sp) break;
            stbtt__csctx_rccurve_to(c, 0, s[i], s[i+1], s[i+2], s[i+3], (sp - i == 5) ? s[i + 4] : 0.0f);
            i += 4;
      hvcurveto:
            if (i + 3 >= sp) break;
            stbtt__csctx_rccurve_to(c, s[i], 0, s[i+1], s[i+2], (sp - i == 5) ? s[i+4] : 0.0f, s[i+3]);
            i += 4;
         }
         break;

      case 0x08: // rrcurveto
         if (sp < 6) return STBTT__CSERR("rcurveline stack");
         for (; i + 5 < sp; i += 6)
            stbtt__csctx_rccurve_to(c, s[i], s[i+1], s[i+2], s[i+3], s[i+4], s[i+5]);
         break;

      case 0x18: // rcurveline
         if (sp < 8) return STBTT__CSERR("rcurveline stack");
         for (; i + 5 < sp - 2; i += 6)
            stbtt__csctx_rccurve_to(c, s[i], s[i+1], s[i+2], s[i+3], s[i+4], s[i+5]);
         if (i + 1 >= sp) return STBTT__CSERR("rcurveline stack");
         stbtt__csctx_rline_to(c, s[i], s[i+1]);
         break;

      case 0x19: // rlinecurve
         if (sp < 8) return STBTT__CSERR("rlinecurve stack");
         for (; i + 1 < sp - 6; i += 2)
            stbtt__csctx_rline_to(c, s[i], s[i+1]);
         if (i + 5 >= sp) return STBTT__CSERR("rlinecurve stack");
         stbtt__csctx_rccurve_to(c, s[i], s[i+1], s[i+2], s[i+3], s[i+4], s[i+5]);
         break;

      case 0x1A: // vvcurveto
      case 0x1B: // hhcurveto
         if (sp < 4) return STBTT__CSERR("(vv|hh)curveto stack");
         f = 0.0;
         if (sp & 1) { f = s[i]; i++; }
         for (; i + 3 < sp; i += 4) {
            if (b0 == 0x1B)
               stbtt__csctx_rccurve_to(c, s[i], f, s[i+1], s[i+2], s[i+3], 0.0);
            else
               stbtt__csctx_rccurve_to(c, f, s[i], s[i+1], s[i+2], 0.0, s[i+3]);
            f = 0.0;
         }
         break;

      case 0x0A: // callsubr
         if (!has_subrs) {
            if (info->fdselect.size)
               subrs = stbtt__cid_get_glyph_subrs(info, glyph_index);
            has_subrs = 1;
         }
         // fallthrough
      case 0x1D: // callgsubr
         if (sp < 1) return STBTT__CSERR("call(g|)subr stack");
         v = (int) s[--sp];
         if (subr_stack_height >= 10) return STBTT__CSERR("recursion limit");
         subr_stack[subr_stack_height++] = b;
         b = stbtt__get_subr(b0 == 0x0A ? subrs : info->gsubrs, v);
         if (b.size == 0) return STBTT__CSERR("subr not found");
         b.cursor = 0;
         clear_stack = 0;
         break;

      case 0x0B: // return
         if (subr_stack_height <= 0) return STBTT__CSERR("return outside subr");
         b = subr_stack[--subr_stack_height];
         clear_stack = 0;
         break;

      case 0x0E: // endchar
         stbtt__csctx_close_shape(c);
         return 1;

      case 0x0C: { // two-byte escape
         float dx1, dx2, dx3, dx4, dx5, dx6, dy1, dy2, dy3, dy4, dy5, dy6;
         float dx, dy;
         int b1 = stbtt__buf_get8(&b);
         switch (b1) {
         // @TODO These "flex" implementations ignore the flex-depth and resolution,
         // and always draw beziers.
         case 0x22: // hflex
            if (sp < 7) return STBTT__CSERR("hflex stack");
            dx1 = s[0];
            dx2 = s[1];
            dy2 = s[2];
            dx3 = s[3];
            dx4 = s[4];
            dx5 = s[5];
            dx6 = s[6];
            stbtt__csctx_rccurve_to(c, dx1, 0, dx2, dy2, dx3, 0);
            stbtt__csctx_rccurve_to(c, dx4, 0, dx5, -dy2, dx6, 0);
            break;

         case 0x23: // flex
            if (sp < 13) return STBTT__CSERR("flex stack");
            dx1 = s[0];
            dy1 = s[1];
            dx2 = s[2];
            dy2 = s[3];
            dx3 = s[4];
            dy3 = s[5];
            dx4 = s[6];
            dy4 = s[7];
            dx5 = s[8];
            dy5 = s[9];
            dx6 = s[10];
            dy6 = s[11];
            //fd is s[12]
            stbtt__csctx_rccurve_to(c, dx1, dy1, dx2, dy2, dx3, dy3);
            stbtt__csctx_rccurve_to(c, dx4, dy4, dx5, dy5, dx6, dy6);
            break;

         case 0x24: // hflex1
            if (sp < 9) return STBTT__CSERR("hflex1 stack");
            dx1 = s[0];
            dy1 = s[1];
            dx2 = s[2];
            dy2 = s[3];
            dx3 = s[4];
            dx4 = s[5];
            dx5 = s[6];
            dy5 = s[7];
            dx6 = s[8];
            stbtt__csctx_rccurve_to(c, dx1, dy1, dx2, dy2, dx3, 0);
            stbtt__csctx_rccurve_to(c, dx4, 0, dx5, dy5, dx6, -(dy1+dy2+dy5));
            break;

         case 0x25: // flex1
            if (sp < 11) return STBTT__CSERR("flex1 stack");
            dx1 = s[0];
            dy1 = s[1];
            dx2 = s[2];
            dy2 = s[3];
            dx3 = s[4];
            dy3 = s[5];
            dx4 = s[6];
            dy4 = s[7];
            dx5 = s[8];
            dy5 = s[9];
            dx6 = dy6 = s[10];
            dx = dx1+dx2+dx3+dx4+dx5;
            dy = dy1+dy2+dy3+dy4+dy5;
            assert(0); // STBTT_fabs
            if (STBTT_fabs(dx) > STBTT_fabs(dy))
               dy6 = -dy;
            else
               dx6 = -dx;
            stbtt__csctx_rccurve_to(c, dx1, dy1, dx2, dy2, dx3, dy3);
            stbtt__csctx_rccurve_to(c, dx4, dy4, dx5, dy5, dx6, dy6);
            break;

         default:
            return STBTT__CSERR("unimplemented");
         }
      } break;

      default:
         if (b0 != 255 && b0 != 28 && (b0 < 32 || b0 > 254))
            return STBTT__CSERR("reserved operator");

         // push immediate
         if (b0 == 255) {
            f = (float)(stbtt_int32)stbtt__buf_get32(&b) / 0x10000;
         } else {
            stbtt__buf_skip(&b, -1);
            f = (float)(stbtt_int16)stbtt__cff_int(&b);
         }
         if (sp >= 48) return STBTT__CSERR("push stack overflow");
         s[sp++] = f;
         clear_stack = 0;
         break;
      }
      if (clear_stack) sp = 0;
   }
   return STBTT__CSERR("no endchar");

#undef STBTT__CSERR
}

/**
 * @brief Retrieves the glyph shape in TrueType format for a given glyph index.
 *
 * This function processes the glyph's charstring twice: first to count the number of vertices
 * required to represent the glyph shape, and second to populate the vertices array with the
 * actual glyph shape data. This two-pass approach avoids the need for reallocating memory
 * during the process.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing font data.
 * @param glyph_index The index of the glyph whose shape is to be retrieved.
 * @param pvertices Pointer to a pointer where the array of vertices will be stored.
 *                  The caller is responsible for freeing this memory.
 * @return The number of vertices in the glyph shape if successful, or 0 if an error occurs.
 *         If the function fails, *pvertices is set to NULL.
 */
static int stbtt__GetGlyphShapeT2(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **pvertices)
{
   // runs the charstring twice, once to count and once to output (to avoid realloc)
   stbtt__csctx count_ctx = STBTT__CSCTX_INIT(1);
   stbtt__csctx output_ctx = STBTT__CSCTX_INIT(0);
   if (stbtt__run_charstring(info, glyph_index, &count_ctx)) {
      *pvertices = (stbtt_vertex*)STBTT_malloc(count_ctx.num_vertices*sizeof(stbtt_vertex), info->userdata);
      output_ctx.pvertices = *pvertices;
      if (stbtt__run_charstring(info, glyph_index, &output_ctx)) {
         STBTT_assert(output_ctx.num_vertices == count_ctx.num_vertices);
         return output_ctx.num_vertices;
      }
   }
   *pvertices = NULL;
   return 0;
}

/**
 * Retrieves the bounding box and vertex count for a glyph in a TrueType font.
 *
 * This function processes the glyph data using the TrueType character string (T2) format
 * and calculates the bounding box (x0, y0, x1, y1) and the number of vertices for the glyph.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param glyph_index The index of the glyph to retrieve information for.
 * @param x0 Pointer to store the minimum x-coordinate of the bounding box. Can be NULL.
 * @param y0 Pointer to store the minimum y-coordinate of the bounding box. Can be NULL.
 * @param x1 Pointer to store the maximum x-coordinate of the bounding box. Can be NULL.
 * @param y1 Pointer to store the maximum y-coordinate of the bounding box. Can be NULL.
 *
 * @return The number of vertices in the glyph if successful, or 0 if the glyph could not be processed.
 */
static int stbtt__GetGlyphInfoT2(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1)
{
   stbtt__csctx c = STBTT__CSCTX_INIT(1);
   int r = stbtt__run_charstring(info, glyph_index, &c);
   if (x0)  *x0 = r ? c.min_x : 0;
   if (y0)  *y0 = r ? c.min_y : 0;
   if (x1)  *x1 = r ? c.max_x : 0;
   if (y1)  *y1 = r ? c.max_y : 0;
   return r ? c.num_vertices : 0;
}

/**
 * Retrieves the vector shape of a glyph from a font.
 *
 * This function extracts the vector outline of a glyph specified by `glyph_index` from the font
 * described by `info`. The shape is returned as a list of vertices in the `pvertices` array.
 * The caller is responsible for freeing the allocated memory for the vertices.
 *
 * The function automatically selects the appropriate method to retrieve the glyph shape based on
 * the font format. If the font is a TrueType font (TTF), it uses `stbtt__GetGlyphShapeTT`. If the
 * font is a Compact Font Format (CFF) font, it uses `stbtt__GetGlyphShapeT2`.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param glyph_index The index of the glyph whose shape is to be retrieved.
 * @param pvertices A pointer to an array of `stbtt_vertex` structures where the glyph's vertices
 *                  will be stored. The array is allocated by the function.
 *
 * @return The number of vertices in the `pvertices` array. Returns 0 if the glyph has no shape
 *         or if an error occurred.
 */
STBTT_DEF int stbtt_GetGlyphShape(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **pvertices)
{
   if (!info->cff.size)
      return stbtt__GetGlyphShapeTT(info, glyph_index, pvertices);
   else
      return stbtt__GetGlyphShapeT2(info, glyph_index, pvertices);
}

/**
 * Retrieves the horizontal metrics (advance width and left side bearing) for a specific glyph in a TrueType font.
 *
 * This function calculates the horizontal metrics for the glyph specified by `glyph_index` using the font's
 * horizontal metrics table (`hmtx`) and horizontal header table (`hhea`). The function handles both cases where
 * the glyph index is within the range of the `hmtx` table's long metrics entries and where it falls into the
 * array of left side bearings.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param glyph_index The index of the glyph for which to retrieve the horizontal metrics.
 * @param advanceWidth A pointer to an integer where the advance width of the glyph will be stored. If NULL, the
 *                     advance width is not returned.
 * @param leftSideBearing A pointer to an integer where the left side bearing of the glyph will be stored. If NULL,
 *                        the left side bearing is not returned.
 *
 * @note The `advanceWidth` represents the horizontal distance from the origin of this glyph to the origin of the
 *       next glyph. The `leftSideBearing` represents the horizontal distance from the origin of this glyph to the
 *       leftmost part of the glyph's bounding box.
 */
STBTT_DEF void stbtt_GetGlyphHMetrics(const stbtt_fontinfo *info, int glyph_index, int *advanceWidth, int *leftSideBearing)
{
   stbtt_uint16 numOfLongHorMetrics = ttUSHORT(info->data+info->hhea + 34);
   if (glyph_index < numOfLongHorMetrics) {
      if (advanceWidth)     *advanceWidth    = ttSHORT(info->data + info->hmtx + 4*glyph_index);
      if (leftSideBearing)  *leftSideBearing = ttSHORT(info->data + info->hmtx + 4*glyph_index + 2);
   } else {
      if (advanceWidth)     *advanceWidth    = ttSHORT(info->data + info->hmtx + 4*(numOfLongHorMetrics-1));
      if (leftSideBearing)  *leftSideBearing = ttSHORT(info->data + info->hmtx + 4*numOfLongHorMetrics + 2*(glyph_index - numOfLongHorMetrics));
   }
}

/**
 * Retrieves the length of the kerning table from the provided font information.
 * 
 * This function examines the kerning table data within the font to determine the number of kerning pairs.
 * It specifically looks for the first kerning table, which must be of horizontal format (format 0) and have
 * the horizontal flag set. If the kerning table is not present, or if the first table does not meet the
 * required criteria, the function returns 0.
 * 
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @return The length of the kerning table (number of kerning pairs) if the table is valid; otherwise, 0.
 */
STBTT_DEF int  stbtt_GetKerningTableLength(const stbtt_fontinfo *info)
{
   stbtt_uint8 *data = info->data + info->kern;

   // we only look at the first table. it must be 'horizontal' and format 0.
   if (!info->kern)
      return 0;
   if (ttUSHORT(data+2) < 1) // number of tables, need at least 1
      return 0;
   if (ttUSHORT(data+8) != 1) // horizontal flag must be set in format
      return 0;

   return ttUSHORT(data+10);
}

/**
 * Retrieves the kerning table from the provided font information and stores it in the given table array.
 * 
 * This function extracts the kerning table from the font data, specifically looking for the first table
 * that is marked as 'horizontal' and uses format 0. The kerning table contains pairs of glyphs and their
 * corresponding kerning values, which are used to adjust the spacing between specific glyph pairs.
 * 
 * @param info A pointer to the stbtt_fontinfo structure containing the font data.
 * @param table A pointer to an array of stbtt_kerningentry structures where the kerning table will be stored.
 * @param table_length The maximum number of entries that can be stored in the table array.
 * 
 * @return The number of kerning entries successfully retrieved and stored in the table array. 
 *         If the font does not contain a kerning table, or if the first table is not 'horizontal' 
 *         or does not use format 0, the function returns 0.
 */
STBTT_DEF int stbtt_GetKerningTable(const stbtt_fontinfo *info, stbtt_kerningentry* table, int table_length)
{
   stbtt_uint8 *data = info->data + info->kern;
   int k, length;

   // we only look at the first table. it must be 'horizontal' and format 0.
   if (!info->kern)
      return 0;
   if (ttUSHORT(data+2) < 1) // number of tables, need at least 1
      return 0;
   if (ttUSHORT(data+8) != 1) // horizontal flag must be set in format
      return 0;

   length = ttUSHORT(data+10);
   if (table_length < length)
      length = table_length;

   for (k = 0; k < length; k++)
   {
      table[k].glyph1 = ttUSHORT(data+18+(k*6));
      table[k].glyph2 = ttUSHORT(data+20+(k*6));
      table[k].advance = ttSHORT(data+22+(k*6));
   }

   return length;
}

/**
 * Retrieves the kerning advance between two glyphs from the font's kerning table.
 * 
 * This method searches the font's kerning table for the advance value between two specified glyphs.
 * The kerning table must be in a specific format: it must be the first table, it must be horizontal,
 * and it must use format 0. If the table is not found or does not meet these criteria, the method
 * returns 0.
 *
 * The method performs a binary search on the kerning table to find the kerning pair (glyph1, glyph2).
 * If the pair is found, the corresponding kerning advance is returned. If the pair is not found,
 * the method returns 0.
 *
 * @param info    Pointer to the stbtt_fontinfo structure containing the font data.
 * @param glyph1  The first glyph index in the kerning pair.
 * @param glyph2  The second glyph index in the kerning pair.
 * @return        The kerning advance between the two glyphs, or 0 if no kerning information is found.
 */
static int  stbtt__GetGlyphKernInfoAdvance(const stbtt_fontinfo *info, int glyph1, int glyph2)
{
   stbtt_uint8 *data = info->data + info->kern;
   stbtt_uint32 needle, straw;
   int l, r, m;

   // we only look at the first table. it must be 'horizontal' and format 0.
   if (!info->kern)
      return 0;
   if (ttUSHORT(data+2) < 1) // number of tables, need at least 1
      return 0;
   if (ttUSHORT(data+8) != 1) // horizontal flag must be set in format
      return 0;

   l = 0;
   r = ttUSHORT(data+10) - 1;
   needle = glyph1 << 16 | glyph2;
   while (l <= r) {
      m = (l + r) >> 1;
      straw = ttULONG(data+18+(m*6)); // note: unaligned read
      if (needle < straw)
         r = m - 1;
      else if (needle > straw)
         l = m + 1;
      else
         return ttSHORT(data+22+(m*6));
   }
   return 0;
}

/**
 * Retrieves the coverage index for a given glyph from a coverage table.
 *
 * The coverage table is part of the OpenType font format and defines how glyphs are mapped
 * to specific features or rules. This function supports two coverage formats:
 * - Format 1: A simple list of glyph IDs. The function performs a binary search to find the glyph
 *   in the list and returns its index if found.
 * - Format 2: A list of ranges, where each range specifies a start and end glyph ID, and a
 *   starting coverage index. The function performs a binary search to find the range that
 *   contains the glyph and calculates the coverage index based on the range's start coverage index.
 *
 * If the glyph is not found in the coverage table, the function returns -1.
 *
 * @param coverageTable A pointer to the coverage table data.
 * @param glyph The glyph ID to find in the coverage table.
 * @return The coverage index of the glyph if found, or -1 if the glyph is not covered.
 */
static stbtt_int32  stbtt__GetCoverageIndex(stbtt_uint8 *coverageTable, int glyph)
{
    stbtt_uint16 coverageFormat = ttUSHORT(coverageTable);
    switch(coverageFormat) {
        case 1: {
            stbtt_uint16 glyphCount = ttUSHORT(coverageTable + 2);

            // Binary search.
            stbtt_int32 l=0, r=glyphCount-1, m;
            int straw, needle=glyph;
            while (l <= r) {
                stbtt_uint8 *glyphArray = coverageTable + 4;
                stbtt_uint16 glyphID;
                m = (l + r) >> 1;
                glyphID = ttUSHORT(glyphArray + 2 * m);
                straw = glyphID;
                if (needle < straw)
                    r = m - 1;
                else if (needle > straw)
                    l = m + 1;
                else {
                     return m;
                }
            }
        } break;

        case 2: {
            stbtt_uint16 rangeCount = ttUSHORT(coverageTable + 2);
            stbtt_uint8 *rangeArray = coverageTable + 4;

            // Binary search.
            stbtt_int32 l=0, r=rangeCount-1, m;
            int strawStart, strawEnd, needle=glyph;
            while (l <= r) {
                stbtt_uint8 *rangeRecord;
                m = (l + r) >> 1;
                rangeRecord = rangeArray + 6 * m;
                strawStart = ttUSHORT(rangeRecord);
                strawEnd = ttUSHORT(rangeRecord + 2);
                if (needle < strawStart)
                    r = m - 1;
                else if (needle > strawEnd)
                    l = m + 1;
                else {
                    stbtt_uint16 startCoverageIndex = ttUSHORT(rangeRecord + 4);
                    return startCoverageIndex + glyph - strawStart;
                }
            }
        } break;

        default: {
            // There are no other cases.
            STBTT_assert(0);
        } break;
    }

    return -1;
}

/**
 * Retrieves the class value for a specified glyph from a Class Definition Table.
 *
 * The method supports two formats of Class Definition Tables:
 * - Format 1: The table contains a range of glyph IDs and an array of class values.
 *             The class value for a glyph is directly looked up in the array if the glyph ID
 *             falls within the specified range.
 * - Format 2: The table contains a set of range records, each defining a range of glyph IDs
 *             and a corresponding class value. A binary search is performed to find the class
 *             value for the specified glyph ID.
 *
 * @param classDefTable A pointer to the Class Definition Table in the font file.
 * @param glyph The glyph ID for which the class value is to be retrieved.
 * @return The class value for the specified glyph, or -1 if the glyph is not found in the table.
 */
static stbtt_int32  stbtt__GetGlyphClass(stbtt_uint8 *classDefTable, int glyph)
{
    stbtt_uint16 classDefFormat = ttUSHORT(classDefTable);
    switch(classDefFormat)
    {
        case 1: {
            stbtt_uint16 startGlyphID = ttUSHORT(classDefTable + 2);
            stbtt_uint16 glyphCount = ttUSHORT(classDefTable + 4);
            stbtt_uint8 *classDef1ValueArray = classDefTable + 6;

            if (glyph >= startGlyphID && glyph < startGlyphID + glyphCount)
                return (stbtt_int32)ttUSHORT(classDef1ValueArray + 2 * (glyph - startGlyphID));

            classDefTable = classDef1ValueArray + 2 * glyphCount;
        } break;

        case 2: {
            stbtt_uint16 classRangeCount = ttUSHORT(classDefTable + 2);
            stbtt_uint8 *classRangeRecords = classDefTable + 4;

            // Binary search.
            stbtt_int32 l=0, r=classRangeCount-1, m;
            int strawStart, strawEnd, needle=glyph;
            while (l <= r) {
                stbtt_uint8 *classRangeRecord;
                m = (l + r) >> 1;
                classRangeRecord = classRangeRecords + 6 * m;
                strawStart = ttUSHORT(classRangeRecord);
                strawEnd = ttUSHORT(classRangeRecord + 2);
                if (needle < strawStart)
                    r = m - 1;
                else if (needle > strawEnd)
                    l = m + 1;
                else
                    return (stbtt_int32)ttUSHORT(classRangeRecord + 4);
            }

            classDefTable = classRangeRecords + 6 * classRangeCount;
        } break;

        default: {
            // There are no other cases.
            STBTT_assert(0);
        } break;
    }

    return -1;
}

// Define to STBTT_assert(x) if you want to break on unimplemented formats.
#define STBTT_GPOS_TODO_assert(x)

/**
 * @brief Retrieves the horizontal advance value for a pair of glyphs from the GPOS table.
 *
 * This function searches the GPOS (Glyph Positioning) table of a font to find the horizontal advance
 * value for a pair of glyphs (glyph1 and glyph2). It specifically looks for Pair Adjustment Positioning
 * subtables (LookupType 2) and supports Format 1 and Format 2 of these subtables.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param glyph1 The first glyph index in the pair.
 * @param glyph2 The second glyph index in the pair.
 * @return The horizontal advance value for the glyph pair if found, otherwise 0.
 *
 * The function performs the following steps:
 * 1. Checks if the GPOS table exists in the font data.
 * 2. Validates the GPOS table version (must be version 1.0).
 * 3. Iterates through the lookup list in the GPOS table.
 * 4. For each lookup table of type 2 (Pair Adjustment), it searches for the glyph pair in the subtables.
 * 5. If the glyph pair is found, it returns the corresponding horizontal advance value.
 * 6. If the glyph pair is not found or the GPOS table is invalid, it returns 0.
 */
static stbtt_int32  stbtt__GetGlyphGPOSInfoAdvance(const stbtt_fontinfo *info, int glyph1, int glyph2)
{
    stbtt_uint16 lookupListOffset;
    stbtt_uint8 *lookupList;
    stbtt_uint16 lookupCount;
    stbtt_uint8 *data;
    stbtt_int32 i;

    if (!info->gpos) return 0;

    data = info->data + info->gpos;

    if (ttUSHORT(data+0) != 1) return 0; // Major version 1
    if (ttUSHORT(data+2) != 0) return 0; // Minor version 0

    lookupListOffset = ttUSHORT(data+8);
    lookupList = data + lookupListOffset;
    lookupCount = ttUSHORT(lookupList);

    for (i=0; i<lookupCount; ++i) {
        stbtt_uint16 lookupOffset = ttUSHORT(lookupList + 2 + 2 * i);
        stbtt_uint8 *lookupTable = lookupList + lookupOffset;

        stbtt_uint16 lookupType = ttUSHORT(lookupTable);
        stbtt_uint16 subTableCount = ttUSHORT(lookupTable + 4);
        stbtt_uint8 *subTableOffsets = lookupTable + 6;
        switch(lookupType) {
            case 2: { // Pair Adjustment Positioning Subtable
                stbtt_int32 sti;
                for (sti=0; sti<subTableCount; sti++) {
                    stbtt_uint16 subtableOffset = ttUSHORT(subTableOffsets + 2 * sti);
                    stbtt_uint8 *table = lookupTable + subtableOffset;
                    stbtt_uint16 posFormat = ttUSHORT(table);
                    stbtt_uint16 coverageOffset = ttUSHORT(table + 2);
                    stbtt_int32 coverageIndex = stbtt__GetCoverageIndex(table + coverageOffset, glyph1);
                    if (coverageIndex == -1) continue;

                    switch (posFormat) {
                        case 1: {
                            stbtt_int32 l, r, m;
                            int straw, needle;
                            stbtt_uint16 valueFormat1 = ttUSHORT(table + 4);
                            stbtt_uint16 valueFormat2 = ttUSHORT(table + 6);
                            stbtt_int32 valueRecordPairSizeInBytes = 2;
                            stbtt_uint16 pairSetCount = ttUSHORT(table + 8);
                            stbtt_uint16 pairPosOffset = ttUSHORT(table + 10 + 2 * coverageIndex);
                            stbtt_uint8 *pairValueTable = table + pairPosOffset;
                            stbtt_uint16 pairValueCount = ttUSHORT(pairValueTable);
                            stbtt_uint8 *pairValueArray = pairValueTable + 2;
                            // TODO: Support more formats.
                            STBTT_GPOS_TODO_assert(valueFormat1 == 4);
                            if (valueFormat1 != 4) return 0;
                            STBTT_GPOS_TODO_assert(valueFormat2 == 0);
                            if (valueFormat2 != 0) return 0;

                            STBTT_assert(coverageIndex < pairSetCount);
                            STBTT__NOTUSED(pairSetCount);

                            needle=glyph2;
                            r=pairValueCount-1;
                            l=0;

                            // Binary search.
                            while (l <= r) {
                                stbtt_uint16 secondGlyph;
                                stbtt_uint8 *pairValue;
                                m = (l + r) >> 1;
                                pairValue = pairValueArray + (2 + valueRecordPairSizeInBytes) * m;
                                secondGlyph = ttUSHORT(pairValue);
                                straw = secondGlyph;
                                if (needle < straw)
                                    r = m - 1;
                                else if (needle > straw)
                                    l = m + 1;
                                else {
                                    stbtt_int16 xAdvance = ttSHORT(pairValue + 2);
                                    return xAdvance;
                                }
                            }
                        } break;

                        case 2: {
                            stbtt_uint16 valueFormat1 = ttUSHORT(table + 4);
                            stbtt_uint16 valueFormat2 = ttUSHORT(table + 6);

                            stbtt_uint16 classDef1Offset = ttUSHORT(table + 8);
                            stbtt_uint16 classDef2Offset = ttUSHORT(table + 10);
                            int glyph1class = stbtt__GetGlyphClass(table + classDef1Offset, glyph1);
                            int glyph2class = stbtt__GetGlyphClass(table + classDef2Offset, glyph2);

                            stbtt_uint16 class1Count = ttUSHORT(table + 12);
                            stbtt_uint16 class2Count = ttUSHORT(table + 14);
                            STBTT_assert(glyph1class < class1Count);
                            STBTT_assert(glyph2class < class2Count);

                            // TODO: Support more formats.
                            STBTT_GPOS_TODO_assert(valueFormat1 == 4);
                            if (valueFormat1 != 4) return 0;
                            STBTT_GPOS_TODO_assert(valueFormat2 == 0);
                            if (valueFormat2 != 0) return 0;

                            if (glyph1class >= 0 && glyph1class < class1Count && glyph2class >= 0 && glyph2class < class2Count) {
                                stbtt_uint8 *class1Records = table + 16;
                                stbtt_uint8 *class2Records = class1Records + 2 * (glyph1class * class2Count);
                                stbtt_int16 xAdvance = ttSHORT(class2Records + 2 * glyph2class);
                                return xAdvance;
                            }
                        } break;

                        default: {
                            // There are no other cases.
                            STBTT_assert(0);
                            break;
                        };
                    }
                }
                break;
            };

            default:
                // TODO: Implement other stuff.
                break;
        }
    }

    return 0;
}

/**
 * Retrieves the kerning advance between two glyphs in a TrueType font.
 *
 * This function calculates the horizontal kerning advance (spacing adjustment) between two glyphs
 * (`g1` and `g2`) in the given font. It supports both GPOS (Glyph Positioning) and kern (Kerning)
 * tables for determining the kerning value. If the font contains a GPOS table, it is used to
 * calculate the advance. Otherwise, if the font contains a kern table, it is used instead.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param g1 The index of the first glyph.
 * @param g2 The index of the second glyph.
 * @return The horizontal kerning advance between the two glyphs in font units. If no kerning
 *         information is available, the function returns 0.
 */
STBTT_DEF int  stbtt_GetGlyphKernAdvance(const stbtt_fontinfo *info, int g1, int g2)
{
   int xAdvance = 0;

   if (info->gpos)
      xAdvance += stbtt__GetGlyphGPOSInfoAdvance(info, g1, g2);
   else if (info->kern)
      xAdvance += stbtt__GetGlyphKernInfoAdvance(info, g1, g2);

   return xAdvance;
}

/**
 * @brief Retrieves the kerning advance between two codepoints in a font.
 *
 * This function calculates the horizontal kerning advance between two Unicode codepoints (`ch1` and `ch2`)
 * in the specified font. Kerning adjusts the spacing between specific pairs of characters to improve visual
 * appearance. If the font does not contain a kerning table (`kern`) or a GPOS table (`gpos`), the function
 * returns 0, indicating no kerning adjustment is needed.
 *
 * @param info Pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param ch1 The first Unicode codepoint.
 * @param ch2 The second Unicode codepoint.
 * @return The kerning advance in font units. A positive value increases the spacing between the characters,
 *         while a negative value decreases it. Returns 0 if no kerning data is available.
 */
STBTT_DEF int  stbtt_GetCodepointKernAdvance(const stbtt_fontinfo *info, int ch1, int ch2)
{
   if (!info->kern && !info->gpos) // if no kerning table, don't waste time looking up both codepoint->glyphs
      return 0;
   return stbtt_GetGlyphKernAdvance(info, stbtt_FindGlyphIndex(info,ch1), stbtt_FindGlyphIndex(info,ch2));
}

/**
 * Retrieves the horizontal metrics for a given Unicode codepoint in the specified font.
 * 
 * This function calculates the advance width and left side bearing for the glyph corresponding
 * to the provided codepoint. The advance width is the horizontal distance from the current
 * position to the next position where a subsequent glyph should be placed. The left side bearing
 * is the horizontal offset from the current position to the leftmost edge of the glyph.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param codepoint The Unicode codepoint for which to retrieve the horizontal metrics.
 * @param advanceWidth Pointer to an integer where the advance width will be stored.
 * @param leftSideBearing Pointer to an integer where the left side bearing will be stored.
 *
 * @note This function internally calls stbtt_FindGlyphIndex to find the glyph index for the
 *       given codepoint and then uses stbtt_GetGlyphHMetrics to retrieve the metrics.
 */
STBTT_DEF void stbtt_GetCodepointHMetrics(const stbtt_fontinfo *info, int codepoint, int *advanceWidth, int *leftSideBearing)
{
   stbtt_GetGlyphHMetrics(info, stbtt_FindGlyphIndex(info,codepoint), advanceWidth, leftSideBearing);
}

/**
 * Retrieves the vertical metrics of a font from the 'hhea' table.
 *
 * The 'hhea' (Horizontal Header) table contains information about the font's vertical metrics,
 * including the ascent, descent, and line gap. This function extracts these values and stores
 * them in the provided output parameters.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param ascent Pointer to an integer where the font's ascent will be stored. The ascent is the
 *               distance from the baseline to the highest point of the font's glyphs.
 *               If NULL, this value will not be retrieved.
 * @param descent Pointer to an integer where the font's descent will be stored. The descent is
 *                the distance from the baseline to the lowest point of the font's glyphs.
 *                If NULL, this value will not be retrieved.
 * @param lineGap Pointer to an integer where the font's line gap will be stored. The line gap
 *                is the recommended additional space between lines of text. If NULL, this value
 *                will not be retrieved.
 */
STBTT_DEF void stbtt_GetFontVMetrics(const stbtt_fontinfo *info, int *ascent, int *descent, int *lineGap)
{
   if (ascent ) *ascent  = ttSHORT(info->data+info->hhea + 4);
   if (descent) *descent = ttSHORT(info->data+info->hhea + 6);
   if (lineGap) *lineGap = ttSHORT(info->data+info->hhea + 8);
}

/**
 * Retrieves the typographic vertical metrics from the OS/2 table of a TrueType font.
 * The OS/2 table contains various metrics and other data used in Windows-specific
 * font handling. This function specifically extracts the typographic ascent, descent,
 * and line gap values from the OS/2 table.
 *
 * @param info A pointer to the stbtt_fontinfo structure containing the font data.
 * @param typoAscent  If non-NULL, this will be set to the typographic ascent value.
 *                    The typographic ascent is the distance from the baseline to the
 *                    top of the highest character in the font.
 * @param typoDescent If non-NULL, this will be set to the typographic descent value.
 *                    The typographic descent is the distance from the baseline to the
 *                    bottom of the lowest character in the font.
 * @param typoLineGap If non-NULL, this will be set to the typographic line gap value.
 *                    The typographic line gap is the recommended additional space
 *                    between lines of text.
 *
 * @return Returns 1 if the OS/2 table was found and the metrics were successfully
 *         retrieved, otherwise returns 0 if the OS/2 table is not present in the font.
 */
STBTT_DEF int  stbtt_GetFontVMetricsOS2(const stbtt_fontinfo *info, int *typoAscent, int *typoDescent, int *typoLineGap)
{
   int tab = stbtt__find_table(info->data, info->fontstart, "OS/2");
   if (!tab)
      return 0;
   if (typoAscent ) *typoAscent  = ttSHORT(info->data+tab + 68);
   if (typoDescent) *typoDescent = ttSHORT(info->data+tab + 70);
   if (typoLineGap) *typoLineGap = ttSHORT(info->data+tab + 72);
   return 1;
}

/**
 * Retrieves the bounding box of the font.
 *
 * This function extracts the bounding box of the font from the 'head' table of the TrueType font data.
 * The bounding box is defined by the coordinates of the lower-left corner (x0, y0) and the upper-right
 * corner (x1, y1) of the font's design space. These coordinates are typically in font units and represent
 * the smallest rectangle that can enclose all the glyphs in the font.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param x0   Pointer to an integer where the x-coordinate of the lower-left corner will be stored.
 * @param y0   Pointer to an integer where the y-coordinate of the lower-left corner will be stored.
 * @param x1   Pointer to an integer where the x-coordinate of the upper-right corner will be stored.
 * @param y1   Pointer to an integer where the y-coordinate of the upper-right corner will be stored.
 */
STBTT_DEF void stbtt_GetFontBoundingBox(const stbtt_fontinfo *info, int *x0, int *y0, int *x1, int *y1)
{
   *x0 = ttSHORT(info->data + info->head + 36);
   *y0 = ttSHORT(info->data + info->head + 38);
   *x1 = ttSHORT(info->data + info->head + 40);
   *y1 = ttSHORT(info->data + info->head + 42);
}

/**
 * @brief Calculates the scaling factor required to render a font at a specified pixel height.
 *
 * This function computes the scaling factor needed to render the font described by the `stbtt_fontinfo`
 * structure at a desired pixel height. The scaling factor is derived from the font's metrics, specifically
 * the difference between the ascent and descent values from the 'hhea' table.
 *
 * @param info Pointer to an `stbtt_fontinfo` structure containing the font data.
 * @param height The desired pixel height for the rendered font.
 * @return The scaling factor as a fixed-point value (fixedpt) that should be applied to the font's metrics
 *         to achieve the specified pixel height.
 */
STBTT_DEF fixedpt stbtt_ScaleForPixelHeight(const stbtt_fontinfo *info, fixedpt height)
{
   int fheight = ttSHORT(info->data + info->hhea + 4) - ttSHORT(info->data + info->hhea + 6);
   return fixedpt_divi(height, fheight);
}

/**
 * Computes the scaling factor required to map font units (EM) to a specified number of pixels.
 * This is useful for scaling glyphs or other font metrics to a desired pixel size.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param pixels The target number of pixels to which the EM units should be mapped.
 * @return The scaling factor as a fixed-point number, calculated as pixels divided by the font's units per EM.
 */
STBTT_DEF fixedpt stbtt_ScaleForMappingEmToPixels(const stbtt_fontinfo *info, fixedpt pixels)
{
   int unitsPerEm = ttUSHORT(info->data + info->head + 18);
   return fixedpt_divi(pixels, unitsPerEm);
}

/**
 * Frees the memory allocated for a shape's vertices.
 *
 * This function deallocates the memory previously allocated for the vertices of a shape.
 * It uses the custom allocator provided by the `stbtt_fontinfo` structure's `userdata` field
 * to perform the deallocation. This ensures that the memory management is consistent with
 * the allocator used during the shape's creation.
 *
 * @param info Pointer to the `stbtt_fontinfo` structure that contains the user-defined
 *             allocator and deallocator.
 * @param v    Pointer to the array of vertices to be freed. If `v` is NULL, the function
 *             does nothing.
 */
STBTT_DEF void stbtt_FreeShape(const stbtt_fontinfo *info, stbtt_vertex *v)
{
   STBTT_free(v, info->userdata);
}

/**
 * Searches for an SVG document associated with a specific glyph in a TrueType font.
 *
 * This function locates the SVG document corresponding to the given glyph index (`gl`) within the font's SVG table.
 * The SVG table is expected to contain a list of SVG documents, each associated with a range of glyph indices.
 * The function iterates through the list of SVG documents and returns the one that covers the specified glyph index.
 *
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param gl The glyph index for which to find the associated SVG document.
 * @return A pointer to the SVG document data if found, or `NULL` if no matching SVG document is found.
 */
STBTT_DEF stbtt_uint8 *stbtt_FindSVGDoc(const stbtt_fontinfo *info, int gl)
{
   int i;
   stbtt_uint8 *data = info->data;
   stbtt_uint8 *svg_doc_list = data + stbtt__get_svg((stbtt_fontinfo *) info);

   int numEntries = ttUSHORT(svg_doc_list);
   stbtt_uint8 *svg_docs = svg_doc_list + 2;

   for(i=0; i<numEntries; i++) {
      stbtt_uint8 *svg_doc = svg_docs + (12 * i);
      if ((gl >= ttUSHORT(svg_doc)) && (gl <= ttUSHORT(svg_doc + 2)))
         return svg_doc;
   }
   return 0;
}

/**
 * Retrieves the SVG document for a specified glyph from the font.
 *
 * This function searches for the SVG document associated with the given glyph index in the font.
 * If the font contains SVG data and the glyph has an associated SVG document, the function returns
 * a pointer to the SVG document and its length.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param gl The glyph index for which to retrieve the SVG document.
 * @param svg Pointer to a const char* where the SVG document pointer will be stored if found.
 * @return The length of the SVG document if found, or 0 if the font does not contain SVG data or
 *         the glyph does not have an associated SVG document.
 */
STBTT_DEF int stbtt_GetGlyphSVG(const stbtt_fontinfo *info, int gl, const char **svg)
{
   stbtt_uint8 *data = info->data;
   stbtt_uint8 *svg_doc;

   if (info->svg == 0)
      return 0;

   svg_doc = stbtt_FindSVGDoc(info, gl);
   if (svg_doc != NULL) {
      *svg = (char *) data + info->svg + ttULONG(svg_doc + 4);
      return ttULONG(svg_doc + 8);
   } else {
      return 0;
   }
}

/**
 * Retrieves the SVG (Scalable Vector Graphics) data for a given Unicode codepoint from the specified font.
 * 
 * This function first finds the glyph index corresponding to the provided Unicode codepoint using `stbtt_FindGlyphIndex`.
 * It then retrieves the SVG data associated with that glyph using `stbtt_GetGlyphSVG`.
 * 
 * @param info A pointer to the `stbtt_fontinfo` structure containing the font data.
 * @param unicode_codepoint The Unicode codepoint for which the SVG data is to be retrieved.
 * @param svg A pointer to a `const char*` where the SVG data will be stored. The SVG data is a null-terminated string.
 * 
 * @return Returns 1 if the SVG data is successfully retrieved, and 0 otherwise.
 */
STBTT_DEF int stbtt_GetCodepointSVG(const stbtt_fontinfo *info, int unicode_codepoint, const char **svg)
{
   return stbtt_GetGlyphSVG(info, stbtt_FindGlyphIndex(info, unicode_codepoint), svg);
}

//////////////////////////////////////////////////////////////////////////////
//
// antialiasing software rasterizer
//

STBTT_DEF void stbtt_GetGlyphBitmapBoxSubpixel(const stbtt_fontinfo *font, int glyph, fixedpt scale_x, fixedpt scale_y,fixedpt shift_x, fixedpt shift_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
   int x0=0,y0=0,x1,y1; // =0 suppresses compiler warning
   if (!stbtt_GetGlyphBox(font, glyph, &x0,&y0,&x1,&y1)) {
      // e.g. space character
      if (ix0) *ix0 = 0;
      if (iy0) *iy0 = 0;
      if (ix1) *ix1 = 0;
      if (iy1) *iy1 = 0;
   } else {
      // move to integral bboxes (treating pixels as little squares, what pixels get touched)?
      if (ix0) *ix0 = STBTT_ifloor( fixedpt_muli(scale_x, x0) + shift_x);
      if (iy0) *iy0 = STBTT_ifloor(-fixedpt_muli(scale_y, y1) + shift_y);
      if (ix1) *ix1 = STBTT_iceil ( fixedpt_muli(scale_x, x1) + shift_x);
      if (iy1) *iy1 = STBTT_iceil (-fixedpt_muli(scale_y, y0) + shift_y);
   }
}

/**
 * @brief Retrieves the bounding box of a glyph's bitmap.
 *
 * This function calculates the bounding box of a glyph's bitmap when rendered with the specified
 * scaling factors. The bounding box is returned in integer coordinates, representing the minimum
 * and maximum x and y positions of the glyph's bitmap.
 *
 * @param font Pointer to the stbtt_fontinfo structure containing the font data.
 * @param glyph The index of the glyph for which to retrieve the bitmap box.
 * @param scale_x The horizontal scaling factor for the glyph.
 * @param scale_y The vertical scaling factor for the glyph.
 * @param ix0 Pointer to an integer where the minimum x-coordinate of the bounding box will be stored.
 * @param iy0 Pointer to an integer where the minimum y-coordinate of the bounding box will be stored.
 * @param ix1 Pointer to an integer where the maximum x-coordinate of the bounding box will be stored.
 * @param iy1 Pointer to an integer where the maximum y-coordinate of the bounding box will be stored.
 *
 * @note This function internally calls `stbtt_GetGlyphBitmapBoxSubpixel` with subpixel offsets set to 0.
 */
STBTT_DEF void stbtt_GetGlyphBitmapBox(const stbtt_fontinfo *font, int glyph, fixedpt scale_x, fixedpt scale_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
   stbtt_GetGlyphBitmapBoxSubpixel(font, glyph, scale_x, scale_y,0,0, ix0, iy0, ix1, iy1);
}

/**
 * @brief Computes the bounding box of a codepoint's bitmap with subpixel precision.
 *
 * This function calculates the bounding box of the bitmap for a given codepoint in a font,
 * taking into account subpixel scaling and shifting. The bounding box is returned in integer
 * coordinates, which represent the pixel-aligned rectangle that fully contains the glyph's
 * bitmap after applying the specified scaling and shifting.
 *
 * @param font Pointer to the stbtt_fontinfo structure containing the font data.
 * @param codepoint The Unicode codepoint for which to compute the bitmap bounding box.
 * @param scale_x Horizontal scaling factor (fixed-point value).
 * @param scale_y Vertical scaling factor (fixed-point value).
 * @param shift_x Horizontal subpixel shift (fixed-point value).
 * @param shift_y Vertical subpixel shift (fixed-point value).
 * @param ix0 Pointer to store the leftmost pixel coordinate of the bounding box.
 * @param iy0 Pointer to store the topmost pixel coordinate of the bounding box.
 * @param ix1 Pointer to store the rightmost pixel coordinate of the bounding box.
 * @param iy1 Pointer to store the bottommost pixel coordinate of the bounding box.
 *
 * @note The function internally uses stbtt_FindGlyphIndex to locate the glyph index for the
 * specified codepoint and then calls stbtt_GetGlyphBitmapBoxSubpixel to compute the bounding box.
 */
STBTT_DEF void stbtt_GetCodepointBitmapBoxSubpixel(const stbtt_fontinfo *font, int codepoint, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
   stbtt_GetGlyphBitmapBoxSubpixel(font, stbtt_FindGlyphIndex(font,codepoint), scale_x, scale_y,shift_x,shift_y, ix0,iy0,ix1,iy1);
}

/**
 * @brief Computes the bounding box of a codepoint's bitmap when rendered with the given scale.
 *
 * This function calculates the bounding box (in integer pixel coordinates) that would contain
 * the bitmap of the specified codepoint when rendered with the given horizontal and vertical scales.
 * The bounding box is returned via the output parameters `ix0`, `iy0`, `ix1`, and `iy1`, which
 * represent the minimum and maximum x and y coordinates of the box, respectively.
 *
 * @param font Pointer to the stbtt_fontinfo structure containing the font data.
 * @param codepoint The Unicode codepoint of the character to compute the bounding box for.
 * @param scale_x The horizontal scale factor for the bitmap (in fixed-point format).
 * @param scale_y The vertical scale factor for the bitmap (in fixed-point format).
 * @param ix0 Pointer to store the minimum x-coordinate of the bounding box.
 * @param iy0 Pointer to store the minimum y-coordinate of the bounding box.
 * @param ix1 Pointer to store the maximum x-coordinate of the bounding box.
 * @param iy1 Pointer to store the maximum y-coordinate of the bounding box.
 *
 * @note This function internally calls `stbtt_GetCodepointBitmapBoxSubpixel` with subpixel offsets
 * set to 0, meaning the bounding box is computed without any subpixel positioning.
 */
STBTT_DEF void stbtt_GetCodepointBitmapBox(const stbtt_fontinfo *font, int codepoint, fixedpt scale_x, fixedpt scale_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
   stbtt_GetCodepointBitmapBoxSubpixel(font, codepoint, scale_x, scale_y,0,0, ix0,iy0,ix1,iy1);
}

//////////////////////////////////////////////////////////////////////////////
//
//  Rasterizer

typedef struct stbtt__hheap_chunk
{
   struct stbtt__hheap_chunk *next;
} stbtt__hheap_chunk;

typedef struct stbtt__hheap
{
   struct stbtt__hheap_chunk *head;
   void   *first_free;
   int    num_remaining_in_head_chunk;
} stbtt__hheap;

/**
 * Allocates a block of memory from the given heap.
 *
 * This function attempts to allocate a block of memory of the specified size from the heap.
 * If there are free blocks available in the heap (i.e., `hh->first_free` is not NULL), it reuses
 * one of those blocks. Otherwise, it allocates a new chunk of memory and returns a block from it.
 *
 * The size of the new chunk is determined based on the requested size:
 * - If the size is less than 32 bytes, the chunk will contain 2000 blocks.
 * - If the size is between 32 and 128 bytes, the chunk will contain 800 blocks.
 * - If the size is 128 bytes or larger, the chunk will contain 100 blocks.
 *
 * @param hh Pointer to the heap from which to allocate memory.
 * @param size The size of the memory block to allocate.
 * @param userdata User-defined data passed to the memory allocation function (STBTT_malloc).
 * @return A pointer to the allocated memory block, or NULL if the allocation fails.
 */
static void *stbtt__hheap_alloc(stbtt__hheap *hh, size_t size, void *userdata)
{
   if (hh->first_free) {
      void *p = hh->first_free;
      hh->first_free = * (void **) p;
      return p;
   } else {
      if (hh->num_remaining_in_head_chunk == 0) {
         int count = (size < 32 ? 2000 : size < 128 ? 800 : 100);
         stbtt__hheap_chunk *c = (stbtt__hheap_chunk *) STBTT_malloc(sizeof(stbtt__hheap_chunk) + size * count, userdata);
         if (c == NULL)
            return NULL;
         c->next = hh->head;
         hh->head = c;
         hh->num_remaining_in_head_chunk = count;
      }
      --hh->num_remaining_in_head_chunk;
      return (char *) (hh->head) + sizeof(stbtt__hheap_chunk) + size * hh->num_remaining_in_head_chunk;
   }
}

/**
 * Frees a block of memory in the given heap by adding it back to the free list.
 * 
 * This function takes a pointer to a heap structure (`hh`) and a pointer to a block of memory (`p`).
 * It updates the `first_free` pointer of the heap to point to the newly freed block, and the freed block
 * is linked to the previous `first_free` block, effectively adding it back to the free list.
 *
 * @param hh Pointer to the heap structure (`stbtt__hheap`) where the memory block is being freed.
 * @param p  Pointer to the memory block that is being freed. This block must have been previously allocated
 *           from the same heap.
 */
static void stbtt__hheap_free(stbtt__hheap *hh, void *p)
{
   *(void **) p = hh->first_free;
   hh->first_free = p;
}

/**
 * Frees all memory chunks allocated in the given heap structure.
 *
 * This function iterates through all the chunks in the provided heap (`hh`),
 * starting from the head, and frees each chunk using the `STBTT_free` function.
 * The `userdata` parameter is passed to `STBTT_free` to allow for custom memory
 * management if needed. After this function is called, the heap will be empty
 * and all associated memory will be deallocated.
 *
 * @param hh       Pointer to the heap structure (`stbtt__hheap`) to be cleaned up.
 * @param userdata User-defined data passed to the `STBTT_free` function for custom
 *                 memory management. This can be NULL if not needed.
 */
static void stbtt__hheap_cleanup(stbtt__hheap *hh, void *userdata)
{
   stbtt__hheap_chunk *c = hh->head;
   while (c) {
      stbtt__hheap_chunk *n = c->next;
      STBTT_free(c, userdata);
      c = n;
   }
}

typedef struct stbtt__edge {
   fixedpt x0,y0, x1,y1;
   int invert;
} stbtt__edge;


typedef struct stbtt__active_edge
{
   struct stbtt__active_edge *next;
   #if STBTT_RASTERIZER_VERSION==1
   int x,dx;
   fixedpt ey;
   int direction;
   #elif STBTT_RASTERIZER_VERSION==2
   fixedpt fx,fdx,fdy;
   int direction;
   fixedpt sy;
   fixedpt ey;
   #else
   #error "Unrecognized value of STBTT_RASTERIZER_VERSION"
   #endif
} stbtt__active_edge;

#if STBTT_RASTERIZER_VERSION == 1
#define STBTT_FIXSHIFT   10
#define STBTT_FIX        (1 << STBTT_FIXSHIFT)
#define STBTT_FIXMASK    (STBTT_FIX-1)

/**
 * @brief Creates and initializes a new active edge for the rasterization process.
 *
 * This function allocates memory for a new active edge from the given heap and initializes it
 * based on the provided edge data. The active edge represents a segment of a polygon edge that
 * is currently being processed during rasterization. The function calculates the slope (dx/dy)
 * of the edge, adjusts the starting x-coordinate based on the offset and start point, and sets
 * other properties such as the end y-coordinate, direction, and next pointer.
 *
 * @param hh Pointer to the heap from which memory for the active edge is allocated.
 * @param e Pointer to the edge data used to initialize the active edge.
 * @param off_x Horizontal offset applied to the x-coordinate of the active edge.
 * @param start_point The y-coordinate at which the active edge starts.
 * @param userdata Optional user data passed to the heap allocation function.
 *
 * @return A pointer to the newly created and initialized active edge. If memory allocation fails,
 *         the function returns NULL.
 */
static stbtt__active_edge *stbtt__new_active(stbtt__hheap *hh, stbtt__edge *e, int off_x, fixedpt start_point, void *userdata)
{
   stbtt__active_edge *z = (stbtt__active_edge *) stbtt__hheap_alloc(hh, sizeof(*z), userdata);
   fixedpt dxdy = fixedpt_div(e->x1 - e->x0, e->y1 - e->y0);
   STBTT_assert(z != NULL);
   if (!z) return z;

   // round dx down to avoid overshooting
   if (dxdy < 0)
      z->dx = -STBTT_ifloor(fixedpt_muli(dxdy, -STBTT_FIX));
   else
      z->dx = STBTT_ifloor(fixedpt_muli(dxdy, STBTT_FIX));

   z->x = STBTT_ifloor(fixedpt_muli(e->x0, STBTT_FIX) + fixedpt_muli(start_point - e->y0, z->dx)); // use z->dx so when we offset later it's by the same amount
   z->x -= off_x * STBTT_FIX;

   z->ey = e->y1;
   z->next = 0;
   z->direction = e->invert ? 1 : -1;
   return z;
}
#elif STBTT_RASTERIZER_VERSION == 2
/**
 * Creates and initializes a new active edge for the scanline rendering process.
 *
 * This function allocates memory for a new `stbtt__active_edge` structure from the given heap `hh`
 * and initializes it based on the provided edge `e`, offset `off_x`, and starting point `start_point`.
 * The active edge represents a segment of the edge `e` that is currently being processed during
 * scanline rendering.
 *
 * @param hh The heap from which to allocate memory for the new active edge.
 * @param e The edge from which the active edge is derived.
 * @param off_x The horizontal offset to apply to the edge's x-coordinate.
 * @param start_point The y-coordinate at which the active edge starts.
 * @param userdata User-defined data passed to the heap allocator.
 *
 * @return A pointer to the newly created and initialized `stbtt__active_edge` structure. 
 *         Returns NULL if memory allocation fails.
 */
static stbtt__active_edge *stbtt__new_active(stbtt__hheap *hh, stbtt__edge *e, int off_x, fixedpt start_point, void *userdata)
{
   stbtt__active_edge *z = (stbtt__active_edge *) stbtt__hheap_alloc(hh, sizeof(*z), userdata);
   fixedpt dxdy = fixedpt_div(e->x1 - e->x0, e->y1 - e->y0);
   STBTT_assert(z != NULL);
   //STBTT_assert(e->y0 <= start_point);
   if (!z) return z;
   z->fdx = dxdy;
   z->fdy = dxdy != 0 ? fixedpt_div(FIXEDPT_ONE, dxdy) : 0;
   z->fx = e->x0 + fixedpt_mul(dxdy, start_point - e->y0);
   z->fx -= fixedpt_fromint(off_x);
   z->direction = e->invert ? 1 : -1;
   z->sy = e->y0;
   z->ey = e->y1;
   z->next = 0;
   return z;
}
#else
#error "Unrecognized value of STBTT_RASTERIZER_VERSION"
#endif

#if STBTT_RASTERIZER_VERSION == 1
// note: this routine clips fills that extend off the edges... ideally this
// wouldn't happen, but it could happen if the truetype glyph bounding boxes
// are wrong, or if the user supplies a too-small bitmap
static void stbtt__fill_active_edges(unsigned char *scanline, int len, stbtt__active_edge *e, int max_weight)
{
   // non-zero winding fill
   int x0=0, w=0;

   while (e) {
      if (w == 0) {
         // if we're currently at zero, we need to record the edge start point
         x0 = e->x; w += e->direction;
      } else {
         int x1 = e->x; w += e->direction;
         // if we went to zero, we need to draw
         if (w == 0) {
            int i = x0 >> STBTT_FIXSHIFT;
            int j = x1 >> STBTT_FIXSHIFT;

            if (i < len && j >= 0) {
               if (i == j) {
                  // x0,x1 are the same pixel, so compute combined coverage
                  scanline[i] = scanline[i] + (stbtt_uint8) ((x1 - x0) * max_weight >> STBTT_FIXSHIFT);
               } else {
                  if (i >= 0) // add antialiasing for x0
                     scanline[i] = scanline[i] + (stbtt_uint8) (((STBTT_FIX - (x0 & STBTT_FIXMASK)) * max_weight) >> STBTT_FIXSHIFT);
                  else
                     i = -1; // clip

                  if (j < len) // add antialiasing for x1
                     scanline[j] = scanline[j] + (stbtt_uint8) (((x1 & STBTT_FIXMASK) * max_weight) >> STBTT_FIXSHIFT);
                  else
                     j = len; // clip

                  for (++i; i < j; ++i) // fill pixels between x0 and x1
                     scanline[i] = scanline[i] + (stbtt_uint8) max_weight;
               }
            }
         }
      }

      e = e->next;
   }
}

/**
 * Rasterizes a set of sorted edges into a bitmap using a scanline algorithm.
 * This function processes the edges in a sorted order, updating active edges
 * for each scanline, and fills the bitmap pixels based on the intersection of
 * active edges. The rasterization is performed with vertical subsampling to
 * achieve anti-aliasing.
 *
 * @param result         Pointer to the output bitmap where the rasterized
 *                       image will be stored.
 * @param e              Array of sorted edges to be rasterized.
 * @param n              Number of edges in the edge array.
 * @param vsubsample     Vertical subsampling factor for anti-aliasing.
 * @param off_x          Horizontal offset for the rasterization.
 * @param off_y          Vertical offset for the rasterization.
 * @param userdata       User-defined data passed to memory management functions.
 *
 * The function processes each scanline in the bitmap, updating active edges,
 * sorting them, and filling the scanline based on the active edges. The result
 * is stored in the provided bitmap. Memory for scanline processing is allocated
 * dynamically if the bitmap width exceeds 512 pixels.
 */
static void stbtt__rasterize_sorted_edges(stbtt__bitmap *result, stbtt__edge *e, int n, int vsubsample, int off_x, int off_y, void *userdata)
{
   stbtt__hheap hh = { 0, 0, 0 };
   stbtt__active_edge *active = NULL;
   int y,j=0;
   int max_weight = (255 / vsubsample);  // weight per vertical scanline
   int s; // vertical subsample index
   unsigned char scanline_data[512], *scanline;

   if (result->w > 512)
      scanline = (unsigned char *) STBTT_malloc(result->w, userdata);
   else
      scanline = scanline_data;

   y = off_y * vsubsample;
   e[n].y0 = fixedpt_fromint((off_y + result->h) * vsubsample + 1);

   while (j < result->h) {
      STBTT_memset(scanline, 0, result->w);
      for (s=0; s < vsubsample; ++s) {
         // find center of pixel for this scanline
         fixedpt scan_y = fixedpt_fromint(y) + FIXEDPT_ONE_HALF;
         stbtt__active_edge **step = &active;

         // update all active edges;
         // remove all active edges that terminate before the center of this scanline
         while (*step) {
            stbtt__active_edge * z = *step;
            if (z->ey <= scan_y) {
               *step = z->next; // delete from list
               STBTT_assert(z->direction);
               z->direction = 0;
               stbtt__hheap_free(&hh, z);
            } else {
               z->x += z->dx; // advance to position for current scanline
               step = &((*step)->next); // advance through list
            }
         }

         // resort the list if needed
         for(;;) {
            int changed=0;
            step = &active;
            while (*step && (*step)->next) {
               if ((*step)->x > (*step)->next->x) {
                  stbtt__active_edge *t = *step;
                  stbtt__active_edge *q = t->next;

                  t->next = q->next;
                  q->next = t;
                  *step = q;
                  changed = 1;
               }
               step = &(*step)->next;
            }
            if (!changed) break;
         }

         // insert all edges that start before the center of this scanline -- omit ones that also end on this scanline
         while (e->y0 <= scan_y) {
            if (e->y1 > scan_y) {
               stbtt__active_edge *z = stbtt__new_active(&hh, e, off_x, scan_y, userdata);
               if (z != NULL) {
                  // find insertion point
                  if (active == NULL)
                     active = z;
                  else if (z->x < active->x) {
                     // insert at front
                     z->next = active;
                     active = z;
                  } else {
                     // find thing to insert AFTER
                     stbtt__active_edge *p = active;
                     while (p->next && p->next->x < z->x)
                        p = p->next;
                     // at this point, p->next->x is NOT < z->x
                     z->next = p->next;
                     p->next = z;
                  }
               }
            }
            ++e;
         }

         // now process all active edges in XOR fashion
         if (active)
            stbtt__fill_active_edges(scanline, result->w, active, max_weight);

         ++y;
      }
      STBTT_memcpy(result->pixels + j * result->stride, scanline, result->w);
      ++j;
   }

   stbtt__hheap_cleanup(&hh, userdata);

   if (scanline != scanline_data)
      STBTT_free(scanline, userdata);
}

#elif STBTT_RASTERIZER_VERSION == 2

// the edge passed in here does not cross the vertical line at x or the vertical line at x+1
// (i.e. it has already been clipped to those)
static void stbtt__handle_clipped_edge(fixedpt *scanline, int x, stbtt__active_edge *e, fixedpt x0, fixedpt y0, fixedpt x1, fixedpt y1)
{
   if (y0 == y1) return;
   STBTT_assert(y0 < y1);
   STBTT_assert(e->sy <= e->ey);
   if (y0 > e->ey) return;
   if (y1 < e->sy) return;
   if (y0 < e->sy) {
      x0 += fixedpt_div(fixedpt_mul(x1-x0, e->sy - y0), y1-y0);
      y0 = e->sy;
   }
   if (y1 > e->ey) {
      x1 += fixedpt_div(fixedpt_mul(x1-x0, e->ey - y1), y1-y0);
      y1 = e->ey;
   }

   fixedpt fx = fixedpt_fromint(x);
   fixedpt fx1 = fx + FIXEDPT_ONE;
   if (x0 == fx)
      STBTT_assert(x1 <= fx1);
   else if (x0 == fx1)
      STBTT_assert(x1 >= fx);
   else if (x0 <= fx)
      STBTT_assert(x1 <= fx);
   else if (x0 >= fx1)
      STBTT_assert(x1 >= fx1);
   else
      STBTT_assert(x1 >= fx && x1 <= fx1);

   if (x0 <= fx && x1 <= fx)
      scanline[x] += fixedpt_muli(y1-y0, e->direction);
   else if (x0 >= fx1 && x1 >= fx1)
      ;
   else {
      STBTT_assert(x0 >= fx && x0 <= fx1 && x1 >= fx && x1 <= fx1);
      scanline[x] += fixedpt_mul(fixedpt_muli(y1-y0, e->direction), (FIXEDPT_ONE-fixedpt_divi((x0-fx)+(x1-fx), 2))); // coverage = 1 - average x position
   }
}

/**
 * Fills the active edges into the scanline buffers for a given y-coordinate.
 *
 * This function processes a linked list of active edges (`e`) and fills the
 * `scanline` and `scanline_fill` buffers with the contributions of these edges
 * at the specified y-coordinate (`y_top`). The function handles both vertical
 * and non-vertical edges, clipping them to the scanline and computing their
 * intersections with the pixel boundaries.
 *
 * The `scanline` buffer accumulates the coverage of the edges for anti-aliasing,
 * while the `scanline_fill` buffer accumulates the fill contributions for pixels
 * to the right of the edges.
 *
 * @param scanline       Buffer to store the anti-aliased coverage of the edges.
 * @param scanline_fill  Buffer to store the fill contributions of the edges.
 * @param len            Length of the scanline buffers.
 * @param e              Linked list of active edges to process.
 * @param y_top          The y-coordinate of the top of the current scanline.
 */
static void stbtt__fill_active_edges_new(fixedpt *scanline, fixedpt *scanline_fill, int len, stbtt__active_edge *e, fixedpt y_top)
{
   fixedpt y_bottom = y_top + FIXEDPT_ONE;

   while (e) {
      // brute force every pixel

      // compute intersection points with top & bottom
      STBTT_assert(e->ey >= y_top);

      if (e->fdx == 0) {
         fixedpt x0 = e->fx;
         if (x0 < fixedpt_fromint(len)) {
            if (x0 >= 0) {
               stbtt__handle_clipped_edge(scanline,fixedpt_toint(x0),e, x0,y_top, x0,y_bottom);
               stbtt__handle_clipped_edge(scanline_fill-1,fixedpt_toint(x0)+1,e, x0,y_top, x0,y_bottom);
            } else {
               stbtt__handle_clipped_edge(scanline_fill-1,0,e, x0,y_top, x0,y_bottom);
            }
         }
      } else {
         fixedpt x0 = e->fx;
         fixedpt dx = e->fdx;
         fixedpt xb = x0 + dx;
         fixedpt x_top, x_bottom;
         fixedpt sy0,sy1;
         fixedpt dy = e->fdy;
         STBTT_assert(e->sy <= y_bottom && e->ey >= y_top);

         // compute endpoints of line segment clipped to this scanline (if the
         // line segment starts on this scanline. x0 is the intersection of the
         // line with y_top, but that may be off the line segment.
         if (e->sy > y_top) {
            x_top = x0 + fixedpt_mul(dx, (e->sy - y_top));
            sy0 = e->sy;
         } else {
            x_top = x0;
            sy0 = y_top;
         }
         if (e->ey < y_bottom) {
            x_bottom = x0 + fixedpt_mul(dx, (e->ey - y_top));
            sy1 = e->ey;
         } else {
            x_bottom = xb;
            sy1 = y_bottom;
         }

         if (x_top >= 0 && x_bottom >= 0 && x_top < len && x_bottom < len) {
            // from here on, we don't have to range check x values

            if (fixedpt_toint(x_top) == fixedpt_toint(x_bottom)) {
               // simple case, only spans one pixel
               int x = fixedpt_toint(x_top);
               fixedpt height = sy1 - sy0;
               STBTT_assert(x >= 0 && x < len);
               fixedpt tmp = fixedpt_muli(height, e->direction);
               scanline[x] += fixedpt_mul(FIXEDPT_ONE-fixedpt_divi((x_top - fixedpt_fromint(x)) + (x_bottom-fixedpt_fromint(x)),2), tmp);
               scanline_fill[x] += tmp; // everything right of this pixel is filled
            } else {
               int x,x1,x2;
               fixedpt y_crossing, step, area;
               int sign;
               // covers 2+ pixels
               if (x_top > x_bottom) {
                  // flip scanline vertically; signed area is the same
                  fixedpt t;
                  sy0 = y_bottom - (sy0 - y_top);
                  sy1 = y_bottom - (sy1 - y_top);
                  t = sy0, sy0 = sy1, sy1 = t;
                  t = x_bottom, x_bottom = x_top, x_top = t;
                  dx = -dx;
                  dy = -dy;
                  t = x0, x0 = xb, xb = t;
               }

               x1 = fixedpt_toint(x_top);
               x2 = fixedpt_toint(x_bottom);
               // compute intersection with y axis at x1+1
               y_crossing = fixedpt_mul(fixedpt_fromint(x1+1) - x0, dy) + y_top;

               sign = e->direction;
               // area of the rectangle covered from y0..y_crossing
               area = fixedpt_muli(y_crossing-sy0, sign);
               // area of the triangle (x_top,y0), (x+1,y0), (x+1,y_crossing)
               scanline[x1] += fixedpt_mul(area, FIXEDPT_ONE-fixedpt_divi(x_top - fixedpt_fromint(x1-1),2));

               step = fixedpt_muli(dy, sign);
               for (x = x1+1; x < x2; ++x) {
                  scanline[x] += area + fixedpt_divi(step,2);
                  area += step;
               }
               y_crossing += fixedpt_muli(dy, x2 - (x1+1));

               STBTT_assert(STBTT_fabs(area) <= fixedpt_rconst(1.01f));

               scanline[x2] += area + fixedpt_mul(fixedpt_muli(FIXEDPT_ONE-fixedpt_divi(x_bottom-fixedpt_fromint(x2),2), sign), sy1-y_crossing);

               scanline_fill[x2] += fixedpt_muli(sy1-sy0, sign);
            }
         } else {
            // if edge goes outside of box we're drawing, we require
            // clipping logic. since this does not match the intended use
            // of this library, we use a different, very slow brute
            // force implementation
            int x;
            for (x=0; x < len; ++x) {
               // cases:
               //
               // there can be up to two intersections with the pixel. any intersection
               // with left or right edges can be handled by splitting into two (or three)
               // regions. intersections with top & bottom do not necessitate case-wise logic.
               //
               // the old way of doing this found the intersections with the left & right edges,
               // then used some simple logic to produce up to three segments in sorted order
               // from top-to-bottom. however, this had a problem: if an x edge was epsilon
               // across the x border, then the corresponding y position might not be distinct
               // from the other y segment, and it might ignored as an empty segment. to avoid
               // that, we need to explicitly produce segments based on x positions.

               // rename variables to clearly-defined pairs
               fixedpt y0 = y_top;
               fixedpt x1 = fixedpt_fromint(x);
               fixedpt x2 = fixedpt_fromint(x+1);
               fixedpt x3 = xb;
               fixedpt y3 = y_bottom;

               // x = e->x + e->dx * (y-y_top)
               // (y-y_top) = (x - e->x) / e->dx
               // y = (x - e->x) / e->dx + y_top
               fixedpt y1 = fixedpt_div(x1 - x0, dx) + y_top;
               fixedpt y2 = fixedpt_div(x2 - x0, dx) + y_top;

               if (x0 < x1 && x3 > x2) {         // three segments descending down-right
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x1,y1);
                  stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x2,y2);
                  stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x3,y3);
               } else if (x3 < x1 && x0 > x2) {  // three segments descending down-left
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x2,y2);
                  stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x1,y1);
                  stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x3,y3);
               } else if (x0 < x1 && x3 > x1) {  // two segments across x, down-right
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x1,y1);
                  stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x3,y3);
               } else if (x3 < x1 && x0 > x1) {  // two segments across x, down-left
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x1,y1);
                  stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x3,y3);
               } else if (x0 < x2 && x3 > x2) {  // two segments across x+1, down-right
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x2,y2);
                  stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x3,y3);
               } else if (x3 < x2 && x0 > x2) {  // two segments across x+1, down-left
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x2,y2);
                  stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x3,y3);
               } else {  // one segment
                  stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x3,y3);
               }
            }
         }
      }
      e = e->next;
   }
}

// directly AA rasterize edges w/o supersampling
static void stbtt__rasterize_sorted_edges(stbtt__bitmap *result, stbtt__edge *e, int n, int vsubsample, int off_x, int off_y, void *userdata)
{
   stbtt__hheap hh = { 0, 0, 0 };
   stbtt__active_edge *active = NULL;
   int y,j=0, i;
   fixedpt scanline_data[129], *scanline, *scanline2;

   STBTT__NOTUSED(vsubsample);

   if (result->w > 64)
      scanline = (fixedpt *) STBTT_malloc((result->w*2+1) * sizeof(fixedpt), userdata);
   else
      scanline = scanline_data;

   scanline2 = scanline + result->w;

   y = off_y;
   e[n].y0 = fixedpt_fromint((off_y + result->h) + 1);

   while (j < result->h) {
      // find center of pixel for this scanline
      fixedpt scan_y_top = fixedpt_fromint(y);
      int scan_y_bottom = y + 1;
      stbtt__active_edge **step = &active;

      STBTT_memset(scanline , 0, result->w*sizeof(scanline[0]));
      STBTT_memset(scanline2, 0, (result->w+1)*sizeof(scanline[0]));

      // update all active edges;
      // remove all active edges that terminate before the top of this scanline
      while (*step) {
         stbtt__active_edge * z = *step;
         if (z->ey <= scan_y_top) {
            *step = z->next; // delete from list
            STBTT_assert(z->direction);
            z->direction = 0;
            stbtt__hheap_free(&hh, z);
         } else {
            step = &((*step)->next); // advance through list
         }
      }

      // insert all edges that start before the bottom of this scanline
      while (e->y0 <= fixedpt_fromint(scan_y_bottom)) {
         if (e->y0 != e->y1) {
            stbtt__active_edge *z = stbtt__new_active(&hh, e, off_x, scan_y_top, userdata);
            if (z != NULL) {
               if (j == 0 && off_y != 0) {
                  if (z->ey < scan_y_top) {
                     // this can happen due to subpixel positioning and some kind of fp rounding error i think
                     z->ey = scan_y_top;
                  }
               }
               STBTT_assert(z->ey >= scan_y_top); // if we get really unlucky a tiny bit of an edge can be out of bounds
               // insert at front
               z->next = active;
               active = z;
            }
         }
         ++e;
      }

      // now process all active edges
      if (active)
         stbtt__fill_active_edges_new(scanline, scanline2+1, result->w, active, scan_y_top);

      {
         fixedpt sum = 0;
         for (i=0; i < result->w; ++i) {
            fixedpt k;
            int m;
            sum += scanline2[i];
            k = scanline[i] + sum;
            k = fixedpt_muli(STBTT_fabs(k),255) + FIXEDPT_ONE_HALF;
            m = fixedpt_toint(k);
            if (m > 255) m = 255;
            result->pixels[j*result->stride + i] = (unsigned char) m;
         }
      }
      // advance all the edges
      step = &active;
      while (*step) {
         stbtt__active_edge *z = *step;
         z->fx += z->fdx; // advance to position for current scanline
         step = &((*step)->next); // advance through list
      }

      ++y;
      ++j;
   }

   stbtt__hheap_cleanup(&hh, userdata);

   if (scanline != scanline_data)
      STBTT_free(scanline, userdata);
}
#else
#error "Unrecognized value of STBTT_RASTERIZER_VERSION"
#endif

#define STBTT__COMPARE(a,b)  ((a)->y0 < (b)->y0)

/**
 * Sorts an array of edges using the insertion sort algorithm.
 * 
 * This function sorts the given array of edges in place. The sorting is based on the comparison
 * function `STBTT__COMPARE`, which determines the order of the edges. The function iterates through
 * the array, and for each element, it inserts it into the correct position in the already sorted
 * portion of the array.
 * 
 * @param p A pointer to the array of `stbtt__edge` structures to be sorted.
 * @param n The number of elements in the array.
 */
static void stbtt__sort_edges_ins_sort(stbtt__edge *p, int n)
{
   int i,j;
   for (i=1; i < n; ++i) {
      stbtt__edge t = p[i], *a = &t;
      j = i;
      while (j > 0) {
         stbtt__edge *b = &p[j-1];
         int c = STBTT__COMPARE(a,b);
         if (!c) break;
         p[j] = p[j-1];
         --j;
      }
      if (i != j)
         p[j] = t;
   }
}

/**
 * Sorts an array of edges using a quicksort algorithm with a fallback to insertion sort for small arrays.
 * 
 * This function sorts the given array of edges in place. It uses a quicksort algorithm for large arrays,
 * but switches to insertion sort when the array size is small (n <= 12) for efficiency. The quicksort
 * implementation uses the median-of-three strategy to choose a pivot, which helps to avoid worst-case
 * performance on already sorted or reverse-sorted arrays. The function also handles duplicates efficiently
 * and ensures that the partitioning process is stable.
 *
 * @param p Pointer to the array of edges to be sorted.
 * @param n The number of edges in the array.
 */
static void stbtt__sort_edges_quicksort(stbtt__edge *p, int n)
{
   /* threshold for transitioning to insertion sort */
   while (n > 12) {
      stbtt__edge t;
      int c01,c12,c,m,i,j;

      /* compute median of three */
      m = n >> 1;
      c01 = STBTT__COMPARE(&p[0],&p[m]);
      c12 = STBTT__COMPARE(&p[m],&p[n-1]);
      /* if 0 >= mid >= end, or 0 < mid < end, then use mid */
      if (c01 != c12) {
         /* otherwise, we'll need to swap something else to middle */
         int z;
         c = STBTT__COMPARE(&p[0],&p[n-1]);
         /* 0>mid && mid<n:  0>n => n; 0<n => 0 */
         /* 0<mid && mid>n:  0>n => 0; 0<n => n */
         z = (c == c12) ? 0 : n-1;
         t = p[z];
         p[z] = p[m];
         p[m] = t;
      }
      /* now p[m] is the median-of-three */
      /* swap it to the beginning so it won't move around */
      t = p[0];
      p[0] = p[m];
      p[m] = t;

      /* partition loop */
      i=1;
      j=n-1;
      for(;;) {
         /* handling of equality is crucial here */
         /* for sentinels & efficiency with duplicates */
         for (;;++i) {
            if (!STBTT__COMPARE(&p[i], &p[0])) break;
         }
         for (;;--j) {
            if (!STBTT__COMPARE(&p[0], &p[j])) break;
         }
         /* make sure we haven't crossed */
         if (i >= j) break;
         t = p[i];
         p[i] = p[j];
         p[j] = t;

         ++i;
         --j;
      }
      /* recurse on smaller side, iterate on larger */
      if (j < (n-i)) {
         stbtt__sort_edges_quicksort(p,j);
         p = p+i;
         n = n-i;
      } else {
         stbtt__sort_edges_quicksort(p+i, n-i);
         n = j;
      }
   }
}

/**
 * Sorts an array of edges using a combination of quicksort and insertion sort.
 * This method first applies quicksort to the array for efficient sorting of larger
 * partitions, and then uses insertion sort to handle any remaining small unsorted
 * segments. This hybrid approach leverages the strengths of both algorithms: quicksort's
 * efficiency for large datasets and insertion sort's simplicity and effectiveness
 * for small datasets.
 *
 * @param p Pointer to the array of edges to be sorted.
 * @param n The number of edges in the array.
 */
static void stbtt__sort_edges(stbtt__edge *p, int n)
{
   stbtt__sort_edges_quicksort(p, n);
   stbtt__sort_edges_ins_sort(p, n);
}

typedef struct
{
   fixedpt x,y;
} stbtt__point;

/**
 * Rasterizes a set of 2D points into a bitmap using a specified scale, shift, and inversion.
 * The method processes the points into edges, sorts them, and then rasterizes them into the
 * provided bitmap using a scanline algorithm.
 *
 * @param result        Pointer to the output bitmap where the rasterized image will be stored.
 * @param pts           Array of 2D points defining the shape to be rasterized.
 * @param wcount        Array of integers specifying the number of points in each winding.
 * @param windings      Number of windings (contours) in the shape.
 * @param scale_x       Horizontal scaling factor applied to the points.
 * @param scale_y       Vertical scaling factor applied to the points.
 * @param shift_x       Horizontal shift applied to the points after scaling.
 * @param shift_y       Vertical shift applied to the points after scaling.
 * @param off_x         Horizontal offset applied to the final bitmap.
 * @param off_y         Vertical offset applied to the final bitmap.
 * @param invert        If non-zero, the y-axis is inverted during rasterization.
 * @param userdata      User-provided data passed to memory allocation functions.
 */
static void stbtt__rasterize(stbtt__bitmap *result, stbtt__point *pts, int *wcount, int windings, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int off_x, int off_y, int invert, void *userdata)
{
   fixedpt y_scale_inv = invert ? -scale_y : scale_y;
   stbtt__edge *e;
   int n,i,j,k,m;
#if STBTT_RASTERIZER_VERSION == 1
   int vsubsample = result->h < 8 ? 15 : 5;
#elif STBTT_RASTERIZER_VERSION == 2
   int vsubsample = 1;
#else
   #error "Unrecognized value of STBTT_RASTERIZER_VERSION"
#endif
   // vsubsample should divide 255 evenly; otherwise we won't reach full opacity

   // now we have to blow out the windings into explicit edge lists
   n = 0;
   for (i=0; i < windings; ++i)
      n += wcount[i];

   e = (stbtt__edge *) STBTT_malloc(sizeof(*e) * (n+1), userdata); // add an extra one as a sentinel
   if (e == 0) return;
   n = 0;

   m=0;
   for (i=0; i < windings; ++i) {
      stbtt__point *p = pts + m;
      m += wcount[i];
      j = wcount[i]-1;
      for (k=0; k < wcount[i]; j=k++) {
         int a=k,b=j;
         // skip the edge if horizontal
         if (p[j].y == p[k].y)
            continue;
         // add edge from j to k to the list
         e[n].invert = 0;
         if (invert ? p[j].y > p[k].y : p[j].y < p[k].y) {
            e[n].invert = 1;
            a=j,b=k;
         }
         e[n].x0 = fixedpt_mul(p[a].x, scale_x) + shift_x;
         e[n].y0 = fixedpt_muli(fixedpt_mul(p[a].y, y_scale_inv) + shift_y, vsubsample);
         e[n].x1 = fixedpt_mul(p[b].x, scale_x) + shift_x;
         e[n].y1 = fixedpt_muli(fixedpt_mul(p[b].y, y_scale_inv) + shift_y, vsubsample);
         ++n;
      }
   }

   // now sort the edges by their highest point (should snap to integer, and then by x)
   //STBTT_sort(e, n, sizeof(e[0]), stbtt__edge_compare);
   stbtt__sort_edges(e, n);

   // now, traverse the scanlines and find the intersections on each scanline, use xor winding rule
   stbtt__rasterize_sorted_edges(result, e, n, vsubsample, off_x, off_y, userdata);

   STBTT_free(e, userdata);
}

/**
 * Adds a point to the specified array of points at the given index.
 * 
 * This function assigns the provided x and y coordinates to the point at the 
 * specified index in the points array. If the points array is NULL, the function 
 * does nothing, which is typically used during the first pass when the array 
 * is unallocated.
 * 
 * @param points Pointer to the array of stbtt__point structures where the point 
 *               will be added. If NULL, the function returns immediately.
 * @param n      The index in the points array where the new point will be stored.
 * @param x      The x-coordinate of the point to add, represented as a fixed-point value.
 * @param y      The y-coordinate of the point to add, represented as a fixed-point value.
 */
static void stbtt__add_point(stbtt__point *points, int n, fixedpt x, fixedpt y)
{
   if (!points) return; // during first pass, it's unallocated
   points[n].x = x;
   points[n].y = y;
}

// tessellate until threshold p is happy... @TODO warped to compensate for non-linear stretching
static int stbtt__tesselate_curve(stbtt__point *points, int *num_points, fixedpt x0, fixedpt y0, fixedpt x1, fixedpt y1, fixedpt x2, fixedpt y2, fixedpt objspace_flatness_squared, int n)
{
   // midpoint
   fixedpt mx = fixedpt_divi(x0 + fixedpt_muli(x1,2) + x2,4);
   fixedpt my = fixedpt_divi(y0 + fixedpt_muli(y1,2) + y2,4);
   // versus directly drawn line
   fixedpt dx = fixedpt_divi(x0+x2,2) - mx;
   fixedpt dy = fixedpt_divi(y0+y2,2) - my;
   if (n > 16) // 65536 segments on one curve better be enough!
      return 1;
   if (fixedpt_mul(dx,dx)+fixedpt_mul(dy,dy) > objspace_flatness_squared) { // half-pixel error allowed... need to be smaller if AA
      stbtt__tesselate_curve(points, num_points, x0,y0, fixedpt_divi(x0+x1,2),fixedpt_divi(y0+y1,2), mx,my, objspace_flatness_squared,n+1);
      stbtt__tesselate_curve(points, num_points, mx,my, fixedpt_divi(x1+x2,2),fixedpt_divi(y1+y2,2), x2,y2, objspace_flatness_squared,n+1);
   } else {
      stbtt__add_point(points, *num_points,x2,y2);
      *num_points = *num_points+1;
   }
   return 1;
}

/**
 * Tesselates a cubic Bézier curve into a series of points.
 *
 * This function recursively subdivides a cubic Bézier curve defined by the control points
 * (x0, y0), (x1, y1), (x2, y2), and (x3, y3) until the curve is sufficiently "flat" based on
 * the provided `objspace_flatness_squared` threshold. The resulting points are stored in the
 * `points` array, and the number of points is updated in `num_points`.
 *
 * The flatness of the curve is determined by comparing the squared difference between the
 * sum of the lengths of the control polygon edges and the length of the straight line
 * connecting the start and end points. If the curve is not flat enough, it is subdivided
 * into two smaller cubic Bézier curves, and the process is repeated recursively.
 *
 * @param points An array of `stbtt__point` structures to store the tessellated points.
 * @param num_points A pointer to an integer that tracks the number of points in the `points` array.
 * @param x0 The x-coordinate of the start point of the curve.
 * @param y0 The y-coordinate of the start point of the curve.
 * @param x1 The x-coordinate of the first control point.
 * @param y1 The y-coordinate of the first control point.
 * @param x2 The x-coordinate of the second control point.
 * @param y2 The y-coordinate of the second control point.
 * @param x3 The x-coordinate of the end point of the curve.
 * @param y3 The y-coordinate of the end point of the curve.
 * @param objspace_flatness_squared The squared flatness threshold in object space.
 * @param n The current recursion depth, used to prevent infinite recursion.
 */
static void stbtt__tesselate_cubic(stbtt__point *points, int *num_points, float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, float objspace_flatness_squared, int n)
{
   // @TODO this "flatness" calculation is just made-up nonsense that seems to work well enough
   float dx0 = x1-x0;
   float dy0 = y1-y0;
   float dx1 = x2-x1;
   float dy1 = y2-y1;
   float dx2 = x3-x2;
   float dy2 = y3-y2;
   float dx = x3-x0;
   float dy = y3-y0;
   assert(0);
   float longlen = (float) (STBTT_sqrt(dx0*dx0+dy0*dy0)+STBTT_sqrt(dx1*dx1+dy1*dy1)+STBTT_sqrt(dx2*dx2+dy2*dy2));
   float shortlen = (float) STBTT_sqrt(dx*dx+dy*dy);
   float flatness_squared = longlen*longlen-shortlen*shortlen;

   if (n > 16) // 65536 segments on one curve better be enough!
      return;

   if (flatness_squared > objspace_flatness_squared) {
      float x01 = (x0+x1)/2;
      float y01 = (y0+y1)/2;
      float x12 = (x1+x2)/2;
      float y12 = (y1+y2)/2;
      float x23 = (x2+x3)/2;
      float y23 = (y2+y3)/2;

      float xa = (x01+x12)/2;
      float ya = (y01+y12)/2;
      float xb = (x12+x23)/2;
      float yb = (y12+y23)/2;

      float mx = (xa+xb)/2;
      float my = (ya+yb)/2;

      stbtt__tesselate_cubic(points, num_points, x0,y0, x01,y01, xa,ya, mx,my, objspace_flatness_squared,n+1);
      stbtt__tesselate_cubic(points, num_points, mx,my, xb,yb, x23,y23, x3,y3, objspace_flatness_squared,n+1);
   } else {
      stbtt__add_point(points, *num_points,fixedpt_rconst(x3),fixedpt_rconst(y3));
      *num_points = *num_points+1;
   }
}

// returns number of contours
static stbtt__point *stbtt_FlattenCurves(stbtt_vertex *vertices, int num_verts, fixedpt objspace_flatness, int **contour_lengths, int *num_contours, void *userdata)
{
   stbtt__point *points=0;
   int num_points=0;

   fixedpt objspace_flatness_squared = fixedpt_mul(objspace_flatness, objspace_flatness);
   int i,n=0,start=0, pass;

   // count how many "moves" there are to get the contour count
   for (i=0; i < num_verts; ++i)
      if (vertices[i].type == STBTT_vmove)
         ++n;

   *num_contours = n;
   if (n == 0) return 0;

   *contour_lengths = (int *) STBTT_malloc(sizeof(**contour_lengths) * n, userdata);

   if (*contour_lengths == 0) {
      *num_contours = 0;
      return 0;
   }

   // make two passes through the points so we don't need to realloc
   for (pass=0; pass < 2; ++pass) {
      stbtt_vertex_type x=0,y=0;
      if (pass == 1) {
         points = (stbtt__point *) STBTT_malloc(num_points * sizeof(points[0]), userdata);
         if (points == NULL) goto error;
      }
      num_points = 0;
      n= -1;
      for (i=0; i < num_verts; ++i) {
         switch (vertices[i].type) {
            case STBTT_vmove:
               // start the next contour
               if (n >= 0)
                  (*contour_lengths)[n] = num_points - start;
               ++n;
               start = num_points;

               x = vertices[i].x, y = vertices[i].y;
               stbtt__add_point(points, num_points++, fixedpt_fromint(x),fixedpt_fromint(y));
               break;
            case STBTT_vline:
               x = vertices[i].x, y = vertices[i].y;
               stbtt__add_point(points, num_points++, fixedpt_fromint(x),fixedpt_fromint(y));
               break;
            case STBTT_vcurve:
               stbtt__tesselate_curve(points, &num_points, fixedpt_fromint(x),fixedpt_fromint(y),
                                        fixedpt_fromint(vertices[i].cx), fixedpt_fromint(vertices[i].cy),
                                        fixedpt_fromint(vertices[i].x ), fixedpt_fromint(vertices[i].y),
                                        objspace_flatness_squared, 0);
               x = vertices[i].x, y = vertices[i].y;
               break;
            case STBTT_vcubic:
               stbtt__tesselate_cubic(points, &num_points, x,y,
                                        vertices[i].cx, vertices[i].cy,
                                        vertices[i].cx1, vertices[i].cy1,
                                        vertices[i].x,  vertices[i].y,
                                        fixedpt_tofloat(objspace_flatness_squared), 0);
               x = vertices[i].x, y = vertices[i].y;
               break;
         }
      }
      (*contour_lengths)[n] = num_points - start;
   }

   return points;
error:
   STBTT_free(points, userdata);
   STBTT_free(*contour_lengths, userdata);
   *contour_lengths = 0;
   *num_contours = 0;
   return NULL;
}

/**
 * Rasterizes a set of vertices into a bitmap using the specified transformation parameters.
 *
 * This function takes a set of vertices representing a path and rasterizes them into a bitmap.
 * The rasterization process involves flattening the curves in the path, applying scaling, shifting,
 * and offset transformations, and then filling the resulting shape in the bitmap.
 *
 * @param result             Pointer to the `stbtt__bitmap` structure where the rasterized image will be stored.
 * @param flatness_in_pixels The maximum allowed deviation from the original curve in pixels. Controls the smoothness of the curve flattening.
 * @param vertices           Array of `stbtt_vertex` structures representing the path to be rasterized.
 * @param num_verts          The number of vertices in the `vertices` array.
 * @param scale_x            The horizontal scaling factor to apply to the vertices.
 * @param scale_y            The vertical scaling factor to apply to the vertices.
 * @param shift_x            The horizontal shift to apply to the vertices after scaling.
 * @param shift_y            The vertical shift to apply to the vertices after scaling.
 * @param x_off              The horizontal offset in the bitmap where the rasterized shape will be placed.
 * @param y_off              The vertical offset in the bitmap where the rasterized shape will be placed.
 * @param invert             If non-zero, the rasterized shape will be inverted (e.g., black on white instead of white on black).
 * @param userdata           User-defined data pointer, which can be used for custom memory allocation or other purposes.
 *
 * @note The function internally flattens the curves in the path using `stbtt_FlattenCurves` and then rasterizes
 * the flattened path using `stbtt__rasterize`. The memory allocated for the flattened path and winding lengths
 * is freed before the function returns.
 */
STBTT_DEF void stbtt_Rasterize(stbtt__bitmap *result, fixedpt flatness_in_pixels, stbtt_vertex *vertices, int num_verts, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int x_off, int y_off, int invert, void *userdata)
{
   fixedpt scale            = scale_x > scale_y ? scale_y : scale_x;
   int winding_count      = 0;
   int *winding_lengths   = NULL;
   stbtt__point *windings = stbtt_FlattenCurves(vertices, num_verts, fixedpt_div(flatness_in_pixels, scale), &winding_lengths, &winding_count, userdata);
   if (windings) {
      stbtt__rasterize(result, windings, winding_lengths, winding_count, scale_x, scale_y, shift_x, shift_y, x_off, y_off, invert, userdata);
      STBTT_free(winding_lengths, userdata);
      STBTT_free(windings, userdata);
   }
}

/**
 * Frees the memory allocated for a bitmap.
 *
 * This function deallocates the memory previously allocated for a bitmap using the
 * `STBTT_free` function. It is typically used to clean up resources after a bitmap
 * is no longer needed.
 *
 * @param bitmap A pointer to the bitmap data to be freed. This should be a pointer
 *               previously allocated by a function in the STB TrueType library.
 * @param userdata A pointer to user-specific data that may be required by the
 *                 memory allocator. This is passed directly to `STBTT_free`.
 */
STBTT_DEF void stbtt_FreeBitmap(unsigned char *bitmap, void *userdata)
{
   STBTT_free(bitmap, userdata);
}

/**
 * Generates a bitmap for a specific glyph in a font, with subpixel precision.
 *
 * This function rasterizes a glyph from a TrueType font into a bitmap, allowing for subpixel
 * positioning and scaling. The bitmap is returned as an array of unsigned characters, where
 * each byte represents a pixel's intensity (0 = transparent, 255 = fully opaque).
 *
 * @param info       Pointer to the stbtt_fontinfo structure containing the font data.
 * @param scale_x    Horizontal scaling factor for the glyph (fixed-point format).
 * @param scale_y    Vertical scaling factor for the glyph (fixed-point format).
 * @param shift_x    Horizontal subpixel shift for the glyph (fixed-point format).
 * @param shift_y    Vertical subpixel shift for the glyph (fixed-point format).
 * @param glyph      The index of the glyph to render.
 * @param width      Pointer to store the width of the resulting bitmap (output parameter).
 * @param height     Pointer to store the height of the resulting bitmap (output parameter).
 * @param xoff       Pointer to store the horizontal offset of the bitmap (output parameter).
 * @param yoff       Pointer to store the vertical offset of the bitmap (output parameter).
 *
 * @return           Pointer to the generated bitmap data. The caller is responsible for freeing
 *                   this memory using STBTT_free(). Returns NULL if the glyph cannot be rendered
 *                   (e.g., due to invalid scaling or allocation failure).
 */
STBTT_DEF unsigned char *stbtt_GetGlyphBitmapSubpixel(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int glyph, int *width, int *height, int *xoff, int *yoff)
{
   int ix0,iy0,ix1,iy1;
   stbtt__bitmap gbm;
   stbtt_vertex *vertices;
   int num_verts = stbtt_GetGlyphShape(info, glyph, &vertices);

   if (scale_x == 0) scale_x = scale_y;
   if (scale_y == 0) {
      if (scale_x == 0) {
         STBTT_free(vertices, info->userdata);
         return NULL;
      }
      scale_y = scale_x;
   }

   stbtt_GetGlyphBitmapBoxSubpixel(info, glyph, scale_x, scale_y, shift_x, shift_y, &ix0,&iy0,&ix1,&iy1);

   // now we get the size
   gbm.w = (ix1 - ix0);
   gbm.h = (iy1 - iy0);
   gbm.pixels = NULL; // in case we error

   if (width ) *width  = gbm.w;
   if (height) *height = gbm.h;
   if (xoff  ) *xoff   = ix0;
   if (yoff  ) *yoff   = iy0;

   if (gbm.w && gbm.h) {
      gbm.pixels = (unsigned char *) STBTT_malloc(gbm.w * gbm.h, info->userdata);
      if (gbm.pixels) {
         gbm.stride = gbm.w;

         stbtt_Rasterize(&gbm, fixedpt_rconst(0.35f), vertices, num_verts, scale_x, scale_y, shift_x, shift_y, ix0, iy0, 1, info->userdata);
      }
   }
   STBTT_free(vertices, info->userdata);
   return gbm.pixels;
}

/**
 * @brief Renders a glyph into a bitmap with the specified scaling.
 *
 * This function generates a bitmap for a specified glyph from a font, scaled according to the given `scale_x` and `scale_y` parameters. 
 * The bitmap is rendered without subpixel positioning, meaning the glyph is aligned to the pixel grid.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing the font data.
 * @param scale_x Horizontal scaling factor for the glyph.
 * @param scale_y Vertical scaling factor for the glyph.
 * @param glyph The index of the glyph to render.
 * @param width Pointer to an integer where the width of the resulting bitmap will be stored.
 * @param height Pointer to an integer where the height of the resulting bitmap will be stored.
 * @param xoff Pointer to an integer where the x-offset of the glyph's bounding box will be stored.
 * @param yoff Pointer to an integer where the y-offset of the glyph's bounding box will be stored.
 *
 * @return A pointer to the generated bitmap. The bitmap is stored in a single-channel 8-bit grayscale format, 
 *         where each byte represents a pixel's intensity (0 = fully transparent, 255 = fully opaque).
 *         The caller is responsible for freeing the allocated memory using STBTT_FREE().
 */
STBTT_DEF unsigned char *stbtt_GetGlyphBitmap(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, int glyph, int *width, int *height, int *xoff, int *yoff)
{
   return stbtt_GetGlyphBitmapSubpixel(info, scale_x, scale_y, 0, 0, glyph, width, height, xoff, yoff);
}

/**
 * Renders a glyph into a bitmap with subpixel precision.
 *
 * This function takes a glyph from a font and renders it into a provided output bitmap buffer.
 * The rendering is done with subpixel precision, allowing for finer control over the glyph's
 * appearance. The function supports scaling and shifting the glyph in both the x and y directions.
 *
 * @param info Pointer to the stbtt_fontinfo structure containing font data.
 * @param output Pointer to the output bitmap buffer where the glyph will be rendered.
 * @param out_w Width of the output bitmap in pixels.
 * @param out_h Height of the output bitmap in pixels.
 * @param out_stride Number of bytes per row in the output bitmap (e.g., for padding).
 * @param scale_x Horizontal scaling factor for the glyph.
 * @param scale_y Vertical scaling factor for the glyph.
 * @param shift_x Horizontal subpixel shift for the glyph.
 * @param shift_y Vertical subpixel shift for the glyph.
 * @param glyph Index of the glyph to render.
 *
 * The function first retrieves the glyph's shape as a set of vertices. It then calculates the
 * bounding box of the glyph after applying the specified scaling and shifting. The glyph is
 * rasterized into the output bitmap using the calculated bounding box and the provided scaling
 * and shifting parameters. The resulting bitmap is stored in the `output` buffer.
 *
 * Note: The caller is responsible for ensuring that the `output` buffer is large enough to
 * accommodate the rendered glyph.
 */
STBTT_DEF void stbtt_MakeGlyphBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int glyph)
{
   int ix0,iy0;
   stbtt_vertex *vertices;
   int num_verts = stbtt_GetGlyphShape(info, glyph, &vertices);
   stbtt__bitmap gbm;

   stbtt_GetGlyphBitmapBoxSubpixel(info, glyph, scale_x, scale_y, shift_x, shift_y, &ix0,&iy0,0,0);
   gbm.pixels = output;
   gbm.w = out_w;
   gbm.h = out_h;
   gbm.stride = out_stride;

   if (gbm.w && gbm.h)
      stbtt_Rasterize(&gbm, fixedpt_rconst(0.35f), vertices, num_verts, scale_x, scale_y, shift_x, shift_y, ix0,iy0, 1, info->userdata);

   STBTT_free(vertices, info->userdata);
}

/**
 * Renders a glyph into a bitmap using the specified font information and scaling factors.
 *
 * This function generates a bitmap representation of a glyph from the provided font.
 * The glyph is scaled according to the given `scale_x` and `scale_y` factors and rendered
 * into the output buffer. The output buffer must be pre-allocated with sufficient space
 * to hold the rendered glyph.
 *
 * @param info         Pointer to the stbtt_fontinfo structure containing the font data.
 * @param output       Pointer to the output buffer where the glyph bitmap will be stored.
 *                     The buffer must be large enough to hold the rendered glyph.
 * @param out_w        Width of the output bitmap in pixels.
 * @param out_h        Height of the output bitmap in pixels.
 * @param out_stride   Number of bytes per row in the output buffer (typically `out_w`).
 * @param scale_x      Horizontal scaling factor for the glyph.
 * @param scale_y      Vertical scaling factor for the glyph.
 * @param glyph        Index of the glyph to render within the font.
 *
 * @note This function internally calls `stbtt_MakeGlyphBitmapSubpixel` with subpixel offsets
 * set to 0, meaning no subpixel rendering is applied.
 */
STBTT_DEF void stbtt_MakeGlyphBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, int glyph)
{
   stbtt_MakeGlyphBitmapSubpixel(info, output, out_w, out_h, out_stride, scale_x, scale_y, 0,0, glyph);
}

/**
 * Generates a bitmap for a specified Unicode codepoint with subpixel precision.
 *
 * This function renders a bitmap for the given Unicode codepoint using the provided font information,
 * scaling factors, and subpixel shifts. The resulting bitmap is returned as an array of unsigned
 * characters, where each pixel is represented by a grayscale value. The function also returns the
 * dimensions of the bitmap, as well as the x and y offsets to properly align the bitmap.
 *
 * @param info         Pointer to the stbtt_fontinfo structure containing the font data.
 * @param scale_x      Horizontal scaling factor for the bitmap.
 * @param scale_y      Vertical scaling factor for the bitmap.
 * @param shift_x      Horizontal subpixel shift for the bitmap.
 * @param shift_y      Vertical subpixel shift for the bitmap.
 * @param codepoint    The Unicode codepoint for which to generate the bitmap.
 * @param width        Pointer to an integer to store the width of the generated bitmap.
 * @param height       Pointer to an integer to store the height of the generated bitmap.
 * @param xoff         Pointer to an integer to store the horizontal offset of the bitmap.
 * @param yoff         Pointer to an integer to store the vertical offset of the bitmap.
 *
 * @return             Pointer to the generated bitmap as an array of unsigned characters.
 *                     The bitmap is stored in a grayscale format, with each pixel represented
 *                     by a single byte. The caller is responsible for freeing the memory allocated
 *                     for the bitmap.
 */
STBTT_DEF unsigned char *stbtt_GetCodepointBitmapSubpixel(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int codepoint, int *width, int *height, int *xoff, int *yoff)
{
   return stbtt_GetGlyphBitmapSubpixel(info, scale_x, scale_y,shift_x,shift_y, stbtt_FindGlyphIndex(info,codepoint), width,height,xoff,yoff);
}

/**
 * Renders a bitmap for a specific Unicode codepoint with subpixel precision and prefiltering.
 *
 * This function generates a bitmap for the specified codepoint using the provided font information.
 * The bitmap is rendered with subpixel precision, allowing for smoother edges and better alignment.
 * The function also supports prefiltering to improve the quality of the rendered glyph.
 *
 * @param info            Pointer to the stbtt_fontinfo structure containing the font data.
 * @param output          Pointer to the output buffer where the bitmap will be stored.
 * @param out_w           Width of the output bitmap in pixels.
 * @param out_h           Height of the output bitmap in pixels.
 * @param out_stride      Number of bytes per row in the output buffer.
 * @param scale_x         Horizontal scaling factor for the glyph.
 * @param scale_y         Vertical scaling factor for the glyph.
 * @param shift_x         Horizontal shift applied to the glyph.
 * @param shift_y         Vertical shift applied to the glyph.
 * @param oversample_x    Horizontal oversampling factor for subpixel rendering.
 * @param oversample_y    Vertical oversampling factor for subpixel rendering.
 * @param sub_x           Pointer to a fixedpt variable to store the horizontal subpixel offset.
 * @param sub_y           Pointer to a fixedpt variable to store the vertical subpixel offset.
 * @param codepoint       Unicode codepoint of the glyph to render.
 *
 * @note The function internally calls stbtt_FindGlyphIndex to locate the glyph index for the given codepoint
 *       and then uses stbtt_MakeGlyphBitmapSubpixelPrefilter to render the glyph with the specified parameters.
 */
STBTT_DEF void stbtt_MakeCodepointBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int oversample_x, int oversample_y, fixedpt *sub_x, fixedpt *sub_y, int codepoint)
{
   stbtt_MakeGlyphBitmapSubpixelPrefilter(info, output, out_w, out_h, out_stride, scale_x, scale_y, shift_x, shift_y, oversample_x, oversample_y, sub_x, sub_y, stbtt_FindGlyphIndex(info,codepoint));
}

/**
 * Renders a single Unicode codepoint as a bitmap with subpixel precision using the specified font.
 *
 * This function generates a bitmap for the given codepoint, applying subpixel scaling and shifting
 * to achieve precise rendering. The bitmap is written to the provided output buffer.
 *
 * @param info         Pointer to the stbtt_fontinfo structure containing the font data.
 * @param output       Pointer to the output buffer where the bitmap will be stored.
 * @param out_w        Width of the output bitmap in pixels.
 * @param out_h        Height of the output bitmap in pixels.
 * @param out_stride   Number of bytes per row in the output buffer (e.g., for alignment).
 * @param scale_x      Horizontal scale factor for the glyph (in fixed-point format).
 * @param scale_y      Vertical scale factor for the glyph (in fixed-point format).
 * @param shift_x      Horizontal subpixel shift (in fixed-point format).
 * @param shift_y      Vertical subpixel shift (in fixed-point format).
 * @param codepoint    Unicode codepoint to render.
 *
 * The function internally uses `stbtt_FindGlyphIndex` to locate the glyph index for the codepoint
 * and then calls `stbtt_MakeGlyphBitmapSubpixel` to render the glyph with the specified scaling
 * and shifting parameters.
 */
STBTT_DEF void stbtt_MakeCodepointBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int codepoint)
{
   stbtt_MakeGlyphBitmapSubpixel(info, output, out_w, out_h, out_stride, scale_x, scale_y, shift_x, shift_y, stbtt_FindGlyphIndex(info,codepoint));
}

/**
 * Generates a monochrome bitmap for a specified Unicode codepoint using the provided font information and scaling factors.
 * The bitmap is created without subpixel rendering, meaning it is aligned to the pixel grid.
 *
 * @param info        Pointer to the stbtt_fontinfo structure containing the font data.
 * @param scale_x     Horizontal scaling factor for the bitmap, in fixed-point format.
 * @param scale_y     Vertical scaling factor for the bitmap, in fixed-point format.
 * @param codepoint   The Unicode codepoint for which the bitmap is to be generated.
 * @param width       Pointer to an integer where the width of the generated bitmap will be stored.
 * @param height      Pointer to an integer where the height of the generated bitmap will be stored.
 * @param xoff        Pointer to an integer where the horizontal offset of the bitmap from the origin will be stored.
 * @param yoff        Pointer to an integer where the vertical offset of the bitmap from the origin will be stored.
 *
 * @return            A pointer to the generated monochrome bitmap. The bitmap is stored as a sequence of bytes,
 *                    where each byte represents 8 pixels (1 bit per pixel). The caller is responsible for freeing
 *                    the allocated memory using STBTT_FREE().
 */
STBTT_DEF unsigned char *stbtt_GetCodepointBitmap(const stbtt_fontinfo *info, fixedpt scale_x, fixedpt scale_y, int codepoint, int *width, int *height, int *xoff, int *yoff)
{
   return stbtt_GetCodepointBitmapSubpixel(info, scale_x, scale_y, 0, 0, codepoint, width,height,xoff,yoff);
}

/**
 * Renders a single Unicode codepoint into a bitmap using the specified font and scaling factors.
 *
 * This function generates a bitmap representation of the given codepoint using the font information
 * provided in `info`. The bitmap is rendered into the `output` buffer, which must be pre-allocated
 * with sufficient space to hold the resulting image. The dimensions of the output bitmap are specified
 * by `out_w` (width) and `out_h` (height). The `out_stride` parameter defines the number of bytes per
 * row in the output buffer, allowing for padding or alignment.
 *
 * The codepoint is scaled according to the `scale_x` and `scale_y` parameters, which control the
 * horizontal and vertical scaling of the glyph, respectively. These scaling factors are of type
 * `fixedpt`, which typically represents a fixed-point number for precise scaling control.
 *
 * The rendered bitmap is monochrome, with each pixel represented by a single byte in the `output`
 * buffer. The function internally calls `stbtt_MakeCodepointBitmapSubpixel` with subpixel offsets
 * set to 0, ensuring no subpixel rendering is applied.
 *
 * @param info         Pointer to the stbtt_fontinfo structure containing the font data.
 * @param output       Pointer to the output buffer where the bitmap will be stored.
 * @param out_w        Width of the output bitmap in pixels.
 * @param out_h        Height of the output bitmap in pixels.
 * @param out_stride   Number of bytes per row in the output buffer.
 * @param scale_x      Horizontal scaling factor for the glyph.
 * @param scale_y      Vertical scaling factor for the glyph.
 * @param codepoint    Unicode codepoint to render.
 */
STBTT_DEF void stbtt_MakeCodepointBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, int codepoint)
{
   stbtt_MakeCodepointBitmapSubpixel(info, output, out_w, out_h, out_stride, scale_x, scale_y, 0,0, codepoint);
}

#define STBTT__OVER_MASK  (STBTT_MAX_OVERSAMPLE-1)

/**
 * Applies a horizontal prefiltering operation to a 2D array of pixel data.
 *
 * This method processes each row of the pixel array, applying a moving average filter
 * with a specified kernel width. The filter computes the average of the pixel values
 * within the kernel window and replaces the center pixel with the computed average.
 * This operation is useful for smoothing or blurring the image horizontally.
 *
 * @param pixels A pointer to the pixel data array, which is modified in place.
 * @param w The width of the pixel array (number of columns).
 * @param h The height of the pixel array (number of rows).
 * @param stride_in_bytes The number of bytes between the start of consecutive rows
 *                        in the pixel array. This allows for handling arrays with padding.
 * @param kernel_width The width of the kernel (window) used for averaging. The kernel
 *                    must be at least 2 and no larger than STBTT_MAX_OVERSAMPLE.
 */
static void stbtt__h_prefilter(unsigned char *pixels, int w, int h, int stride_in_bytes, unsigned int kernel_width)
{
   unsigned char buffer[STBTT_MAX_OVERSAMPLE];
   int safe_w = w - kernel_width;
   int j;
   STBTT_memset(buffer, 0, STBTT_MAX_OVERSAMPLE); // suppress bogus warning from VS2013 -analyze
   for (j=0; j < h; ++j) {
      int i;
      unsigned int total;
      STBTT_memset(buffer, 0, kernel_width);

      total = 0;

      // make kernel_width a constant in common cases so compiler can optimize out the divide
      switch (kernel_width) {
         case 2:
            for (i=0; i <= safe_w; ++i) {
               total += pixels[i] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
               pixels[i] = (unsigned char) (total / 2);
            }
            break;
         case 3:
            for (i=0; i <= safe_w; ++i) {
               total += pixels[i] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
               pixels[i] = (unsigned char) (total / 3);
            }
            break;
         case 4:
            for (i=0; i <= safe_w; ++i) {
               total += pixels[i] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
               pixels[i] = (unsigned char) (total / 4);
            }
            break;
         case 5:
            for (i=0; i <= safe_w; ++i) {
               total += pixels[i] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
               pixels[i] = (unsigned char) (total / 5);
            }
            break;
         default:
            for (i=0; i <= safe_w; ++i) {
               total += pixels[i] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
               pixels[i] = (unsigned char) (total / kernel_width);
            }
            break;
      }

      for (; i < w; ++i) {
         STBTT_assert(pixels[i] == 0);
         total -= buffer[i & STBTT__OVER_MASK];
         pixels[i] = (unsigned char) (total / kernel_width);
      }

      pixels += stride_in_bytes;
   }
}

/**
 * Applies a vertical prefilter to a 2D array of pixel data using a specified kernel width.
 * This function processes the pixel data column-wise, computing a running average for each
 * pixel based on the surrounding pixels within the kernel width. The result is stored in-place.
 *
 * @param pixels A pointer to the pixel data array, which is modified in-place.
 * @param w The width of the pixel data array (number of columns).
 * @param h The height of the pixel data array (number of rows).
 * @param stride_in_bytes The number of bytes between the start of one row and the next in the pixel data array.
 * @param kernel_width The width of the kernel used for averaging. Must be a positive integer.
 *
 * The function operates as follows:
 * 1. For each column in the pixel data:
 *    a. Initializes a buffer to store intermediate values.
 *    b. Computes a running total of pixel values within the kernel width.
 *    c. Updates the pixel value with the average of the running total.
 *    d. Handles edge cases where the kernel extends beyond the bounds of the pixel data.
 * 2. The kernel width is optimized for common cases (2, 3, 4, 5) to improve performance.
 * 3. The function assumes that pixels outside the bounds of the array are zero.
 */
static void stbtt__v_prefilter(unsigned char *pixels, int w, int h, int stride_in_bytes, unsigned int kernel_width)
{
   unsigned char buffer[STBTT_MAX_OVERSAMPLE];
   int safe_h = h - kernel_width;
   int j;
   STBTT_memset(buffer, 0, STBTT_MAX_OVERSAMPLE); // suppress bogus warning from VS2013 -analyze
   for (j=0; j < w; ++j) {
      int i;
      unsigned int total;
      STBTT_memset(buffer, 0, kernel_width);

      total = 0;

      // make kernel_width a constant in common cases so compiler can optimize out the divide
      switch (kernel_width) {
         case 2:
            for (i=0; i <= safe_h; ++i) {
               total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
               pixels[i*stride_in_bytes] = (unsigned char) (total / 2);
            }
            break;
         case 3:
            for (i=0; i <= safe_h; ++i) {
               total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
               pixels[i*stride_in_bytes] = (unsigned char) (total / 3);
            }
            break;
         case 4:
            for (i=0; i <= safe_h; ++i) {
               total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
               pixels[i*stride_in_bytes] = (unsigned char) (total / 4);
            }
            break;
         case 5:
            for (i=0; i <= safe_h; ++i) {
               total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
               pixels[i*stride_in_bytes] = (unsigned char) (total / 5);
            }
            break;
         default:
            for (i=0; i <= safe_h; ++i) {
               total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
               buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
               pixels[i*stride_in_bytes] = (unsigned char) (total / kernel_width);
            }
            break;
      }

      for (; i < h; ++i) {
         STBTT_assert(pixels[i*stride_in_bytes] == 0);
         total -= buffer[i & STBTT__OVER_MASK];
         pixels[i*stride_in_bytes] = (unsigned char) (total / kernel_width);
      }

      pixels += 1;
   }
}

/**
 * Calculates the phase shift required to counteract the prefilter effect in oversampled space.
 * 
 * The prefilter is a box filter of width `oversample`, which shifts the phase by 
 * (oversample - 1)/2 pixels in oversampled space. This method computes the opposite shift
 * to counter this effect, ensuring proper alignment in the oversampled space.
 * 
 * @param oversample The oversampling factor. If zero, no shift is applied.
 * @return A fixed-point value representing the required phase shift to counteract the prefilter effect.
 */
static fixedpt stbtt__oversample_shift(int oversample)
{
   if (!oversample)
      return 0;

   // The prefilter is a box filter of width "oversample",
   // which shifts phase by (oversample - 1)/2 pixels in
   // oversampled space. We want to shift in the opposite
   // direction to counter this.
   return -fixedpt_divi(fixedpt_fromint(oversample - 1), 2 * oversample);
}

/**
 * Renders a glyph into a bitmap with subpixel precision and applies prefiltering.
 *
 * This function generates a bitmap for a specified glyph from a font, applying subpixel
 * positioning and prefiltering to improve the quality of the rendered glyph. The prefiltering
 * is applied in both horizontal and vertical directions if specified. The function also
 * calculates the subpixel shifts required for accurate rendering.
 *
 * @param info           Pointer to the stbtt_fontinfo structure containing font data.
 * @param output         Pointer to the output buffer where the bitmap will be stored.
 * @param out_w          Width of the output bitmap in pixels.
 * @param out_h          Height of the output bitmap in pixels.
 * @param out_stride     Number of bytes per row in the output bitmap.
 * @param scale_x        Horizontal scale factor for the glyph.
 * @param scale_y        Vertical scale factor for the glyph.
 * @param shift_x        Horizontal subpixel shift for the glyph.
 * @param shift_y        Vertical subpixel shift for the glyph.
 * @param prefilter_x    Horizontal prefilter width (must be >= 1).
 * @param prefilter_y    Vertical prefilter height (must be >= 1).
 * @param sub_x          Pointer to store the calculated horizontal subpixel shift.
 * @param sub_y          Pointer to store the calculated vertical subpixel shift.
 * @param glyph          Index of the glyph to render.
 */
STBTT_DEF void stbtt_MakeGlyphBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, fixedpt scale_x, fixedpt scale_y, fixedpt shift_x, fixedpt shift_y, int prefilter_x, int prefilter_y, fixedpt *sub_x, fixedpt *sub_y, int glyph)
{
   stbtt_MakeGlyphBitmapSubpixel(info,
                                 output,
                                 out_w - (prefilter_x - 1),
                                 out_h - (prefilter_y - 1),
                                 out_stride,
                                 scale_x,
                                 scale_y,
                                 shift_x,
                                 shift_y,
                                 glyph);

   if (prefilter_x > 1)
      stbtt__h_prefilter(output, out_w, out_h, out_stride, prefilter_x);

   if (prefilter_y > 1)
      stbtt__v_prefilter(output, out_w, out_h, out_stride, prefilter_y);

   *sub_x = stbtt__oversample_shift(prefilter_x);
   *sub_y = stbtt__oversample_shift(prefilter_y);
}

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"
#endif

/**
 * Retrieves the byte offset for a specific font within a TrueType or OpenType font collection.
 * 
 * This function is used to locate the starting position of a particular font in a font collection file (e.g., .ttc or .otc).
 * It takes a pointer to the font data and an index specifying which font in the collection to target.
 * The function internally calls `stbtt_GetFontOffsetForIndex_internal` to perform the actual offset calculation.
 * 
 * @param data A pointer to the raw font data, typically loaded from a file.
 * @param index The zero-based index of the font within the collection. For single-font files, this should be 0.
 * 
 * @return The byte offset of the specified font within the font data. If the index is invalid or the font is not found, the behavior is undefined.
 */
STBTT_DEF int stbtt_GetFontOffsetForIndex(const unsigned char *data, int index)
{
   return stbtt_GetFontOffsetForIndex_internal((unsigned char *) data, index);
}

/**
 * @brief Retrieves the number of fonts contained in a TrueType font collection (TTC) file.
 *
 * This function parses the provided font data to determine the number of individual fonts
 * included in a TrueType font collection. If the data represents a single font (not a collection),
 * the function will return 1. For invalid or corrupted data, the behavior is undefined.
 *
 * @param data A pointer to the raw data of the TrueType font or font collection.
 * @return The number of fonts contained in the font collection. Returns 1 if the data
 *         represents a single font, or 0 if the data is invalid or not a font.
 */
STBTT_DEF int stbtt_GetNumberOfFonts(const unsigned char *data)
{
   return stbtt_GetNumberOfFonts_internal((unsigned char *) data);
}

/**
 * Initializes a stbtt_fontinfo structure with the font data provided.
 * This function is used to prepare the font information structure for use
 * with other stb_truetype functions. It parses the font data starting at the
 * specified offset and populates the stbtt_fontinfo structure with the necessary
 * information to access the font's data.
 *
 * @param info Pointer to the stbtt_fontinfo structure to be initialized.
 * @param data Pointer to the raw font data (typically loaded from a file).
 * @param offset Offset within the font data where the font begins. This is useful
 *               for fonts embedded in larger files or for accessing specific fonts
 *               within a font collection (e.g., TTC files).
 * @return Returns 1 on success, 0 on failure (e.g., if the font data is invalid or
 *         the offset is out of bounds).
 */
STBTT_DEF int stbtt_InitFont(stbtt_fontinfo *info, const unsigned char *data, int offset)
{
   return stbtt_InitFont_internal(info, (unsigned char *) data, offset);
}

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC diagnostic pop
#endif

#endif // STB_TRUETYPE_IMPLEMENTATION


// FULL VERSION HISTORY
//
//   1.19 (2018-02-11) OpenType GPOS kerning (horizontal only), STBTT_fmod
//   1.18 (2018-01-29) add missing function
//   1.17 (2017-07-23) make more arguments const; doc fix
//   1.16 (2017-07-12) SDF support
//   1.15 (2017-03-03) make more arguments const
//   1.14 (2017-01-16) num-fonts-in-TTC function
//   1.13 (2017-01-02) support OpenType fonts, certain Apple fonts
//   1.12 (2016-10-25) suppress warnings about casting away const with -Wcast-qual
//   1.11 (2016-04-02) fix unused-variable warning
//   1.10 (2016-04-02) allow user-defined fabs() replacement
//                     fix memory leak if fontsize=0.0
//                     fix warning from duplicate typedef
//   1.09 (2016-01-16) warning fix; avoid crash on outofmem; use alloc userdata for PackFontRanges
//   1.08 (2015-09-13) document stbtt_Rasterize(); fixes for vertical & horizontal edges
//   1.07 (2015-08-01) allow PackFontRanges to accept arrays of sparse codepoints;
//                     allow PackFontRanges to pack and render in separate phases;
//                     fix stbtt_GetFontOFfsetForIndex (never worked for non-0 input?);
//                     fixed an assert() bug in the new rasterizer
//                     replace assert() with STBTT_assert() in new rasterizer
//   1.06 (2015-07-14) performance improvements (~35% faster on x86 and x64 on test machine)
//                     also more precise AA rasterizer, except if shapes overlap
//                     remove need for STBTT_sort
//   1.05 (2015-04-15) fix misplaced definitions for STBTT_STATIC
//   1.04 (2015-04-15) typo in example
//   1.03 (2015-04-12) STBTT_STATIC, fix memory leak in new packing, various fixes
//   1.02 (2014-12-10) fix various warnings & compile issues w/ stb_rect_pack, C++
//   1.01 (2014-12-08) fix subpixel position when oversampling to exactly match
//                        non-oversampled; STBTT_POINT_SIZE for packed case only
//   1.00 (2014-12-06) add new PackBegin etc. API, w/ support for oversampling
//   0.99 (2014-09-18) fix multiple bugs with subpixel rendering (ryg)
//   0.9  (2014-08-07) support certain mac/iOS fonts without an MS platformID
//   0.8b (2014-07-07) fix a warning
//   0.8  (2014-05-25) fix a few more warnings
//   0.7  (2013-09-25) bugfix: subpixel glyph bug fixed in 0.5 had come back
//   0.6c (2012-07-24) improve documentation
//   0.6b (2012-07-20) fix a few more warnings
//   0.6  (2012-07-17) fix warnings; added stbtt_ScaleForMappingEmToPixels,
//                        stbtt_GetFontBoundingBox, stbtt_IsGlyphEmpty
//   0.5  (2011-12-09) bugfixes:
//                        subpixel glyph renderer computed wrong bounding box
//                        first vertex of shape can be off-curve (FreeSans)
//   0.4b (2011-12-03) fixed an error in the font baking example
//   0.4  (2011-12-01) kerning, subpixel rendering (tor)
//                    bugfixes for:
//                        codepoint-to-glyph conversion using table fmt=12
//                        codepoint-to-glyph conversion using table fmt=4
//                        stbtt_GetBakedQuad with non-square texture (Zer)
//                    updated Hello World! sample to use kerning and subpixel
//                    fixed some warnings
//   0.3  (2009-06-24) cmap fmt=12, compound shapes (MM)
//                    userdata, malloc-from-userdata, non-zero fill (stb)
//   0.2  (2009-03-11) Fix unsigned/signed char warnings
//   0.1  (2009-03-09) First public release
//

/*
------------------------------------------------------------------------------
This software is available under 2 licenses -- choose whichever you prefer.
------------------------------------------------------------------------------
ALTERNATIVE A - MIT License
Copyright (c) 2017 Sean Barrett
Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
------------------------------------------------------------------------------
ALTERNATIVE B - Public Domain (www.unlicense.org)
This is free and unencumbered software released into the public domain.
Anyone is free to copy, modify, publish, use, compile, sell, or distribute this
software, either in source code form or as a compiled binary, for any purpose,
commercial or non-commercial, and by any means.
In jurisdictions that recognize copyright laws, the author or authors of this
software dedicate any and all copyright interest in the software to the public
domain. We make this dedication for the benefit of the public at large and to
the detriment of our heirs and successors. We intend this dedication to be an
overt act of relinquishment in perpetuity of all present and future rights to
this software under copyright law.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
------------------------------------------------------------------------------
*/
