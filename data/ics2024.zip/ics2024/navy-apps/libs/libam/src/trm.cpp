#include <am.h>

Area heap;

/**
 * @brief Outputs a single character to the standard output.
 * 
 * This function writes the specified character `ch` to the standard output stream.
 * It is typically used for low-level character output operations where direct
 * control over the output is required.
 * 
 * @param ch The character to be written to the standard output.
 */
void putch(char ch) {
}

/**
 * @brief Halts the program execution with the specified exit code.
 *
 * This method terminates the program immediately and returns the provided exit code
 * to the operating system. It can be used to gracefully exit the program in case of
 * critical errors or when the program has completed its intended task. The exit code
 * is typically used to indicate the reason for termination, where a value of 0
 * usually signifies successful completion, and non-zero values indicate errors or
 * specific conditions.
 *
 * @param code The exit code to be returned to the operating system. A value of 0
 *             indicates successful termination, while non-zero values indicate errors.
 */
void halt(int code) {
}
