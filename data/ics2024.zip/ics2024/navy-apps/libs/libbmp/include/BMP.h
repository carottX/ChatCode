#ifndef __BMP_H__
#define __BMP_H__

void* BMP_Load(const char *filename, int *width, int *height);

#endif
