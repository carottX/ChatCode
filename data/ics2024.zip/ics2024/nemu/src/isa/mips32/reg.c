/***************************************************************************************
* Copyright (c) 2014-2024 Zihao Yu, Nanjing University
*
* NEMU is licensed under Mulan PSL v2.
* You can use this software according to the terms and conditions of the Mulan PSL v2.
* You may obtain a copy of Mulan PSL v2 at:
*          http://license.coscl.org.cn/MulanPSL2
*
* THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
* MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
*
* See the Mulan PSL v2 for more details.
***************************************************************************************/

#include <isa.h>
#include "local-include/reg.h"

const char *regs[] = {
  "$0", "at", "v0", "v1", "a0", "a1", "a2", "a3",
  "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
  "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
  "t8", "t9", "k0", "k1", "gp", "sp", "s8", "ra"
};

/**
 * Displays the contents of the ISA (Instruction Set Architecture) registers.
 * This method outputs the current values stored in the CPU's registers to the standard output.
 * It is typically used for debugging purposes to inspect the state of the registers
 * during the execution of a program or after specific operations. The output format
 * may vary depending on the architecture, but it generally includes the register names
 * and their corresponding values in a human-readable format.
 */
void isa_reg_display() {
}

/**
 * Converts a string representation of an ISA register to its corresponding value.
 *
 * This function takes a string `s` that represents an ISA register and attempts to
 * convert it to its corresponding `word_t` value. The `success` parameter is used
 * to indicate whether the conversion was successful or not. If the string `s` is
 * a valid representation of an ISA register, the function returns the corresponding
 * value and sets `success` to `true`. If the string `s` is not a valid representation
 * of an ISA register, the function returns 0 and sets `success` to `false`.
 *
 * @param s The string representation of the ISA register.
 * @param success A pointer to a boolean that indicates whether the conversion was successful.
 * @return The `word_t` value corresponding to the ISA register, or 0 if the conversion failed.
 */
word_t isa_reg_str2val(const char *s, bool *success) {
  return 0;
}
